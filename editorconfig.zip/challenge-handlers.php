<?php
/**
 * Desafio de Transformação — handlers da API
 */

define('CHALLENGE_UPLOADS_DIR', __DIR__ . '/uploads/challenge/');
define('CHALLENGE_CATEGORIES', ['sofa', 'colchao', 'veiculo', 'tapete', 'poltrona', 'outro']);
define('CHALLENGE_STATUSES', ['draft', 'pending', 'approved', 'rejected', 'winner', 'champion']);

function challengeDefaultMissions(): array {
    return [
        'share'            => 50,
        'refer'            => 100,
        'whatsapp_group'   => 30,
        'quote'            => 80,
        'complete_profile' => 20,
    ];
}

function challengeGetMissions(PDO $pdo): array {
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'challenge_missions' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    if ($row && !empty($row['value'])) {
        $parsed = json_decode($row['value'], true);
        if (is_array($parsed)) return array_merge(challengeDefaultMissions(), $parsed);
    }
    return challengeDefaultMissions();
}

function challengeVoterHash(?string $cookieId = null): string {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $cookie = $cookieId ?? ($_COOKIE['alp_vote_id'] ?? '');
    return hash('sha256', $ip . '|' . $cookie);
}

function challengeIpHash(): string {
    return hash('sha256', $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function challengeGenerateReferralCode(): string {
    return strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
}

function challengeUniqueSlug(PDO $pdo, string $base, ?string $excludeId = null): string {
    $slug = slugify($base);
    if ($slug === '') $slug = 'participante';
    $candidate = $slug;
    $n = 1;
    while (true) {
        $sql = "SELECT id FROM challenge_participants WHERE slug = ?";
        $params = [$candidate];
        if ($excludeId) { $sql .= " AND id != ?"; $params[] = $excludeId; }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        if (!$stmt->fetch()) return $candidate;
        $candidate = $slug . '-' . $n++;
    }
}

function challengeProcessImage(string $sourcePath, string $basename): array {
    $dir = CHALLENGE_UPLOADS_DIR;
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $ext = strtolower(pathinfo($sourcePath, PATHINFO_EXTENSION));
    $result = ['url' => 'uploads/challenge/' . $basename, 'thumb_url' => null, 'webp_url' => null];

    if (!function_exists('imagecreatefromjpeg')) {
        copy($sourcePath, $dir . $basename);
        return $result;
    }

    $img = null;
    if (in_array($ext, ['jpg', 'jpeg'], true)) $img = @imagecreatefromjpeg($sourcePath);
    elseif ($ext === 'png') $img = @imagecreatefrompng($sourcePath);
    elseif ($ext === 'webp' && function_exists('imagecreatefromwebp')) $img = @imagecreatefromwebp($sourcePath);
    elseif ($ext === 'gif') $img = @imagecreatefromgif($sourcePath);

    if (!$img) {
        copy($sourcePath, $dir . $basename);
        return $result;
    }

    $w = imagesx($img);
    $h = imagesy($img);
    $maxW = 1600;
    if ($w > $maxW) {
        $nw = $maxW;
        $nh = (int) round($h * ($maxW / $w));
        $resized = imagecreatetruecolor($nw, $nh);
        imagecopyresampled($resized, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
        imagedestroy($img);
        $img = $resized;
        $w = $nw; $h = $nh;
    }

    $mainName = pathinfo($basename, PATHINFO_FILENAME) . '.jpg';
    $mainPath = $dir . $mainName;
    imagejpeg($img, $mainPath, 82);
    $result['url'] = 'uploads/challenge/' . $mainName;

    $thumbW = 400;
    $thumbH = (int) max(1, round($h * ($thumbW / $w)));
    $thumb = imagecreatetruecolor($thumbW, $thumbH);
    imagecopyresampled($thumb, $img, 0, 0, 0, 0, $thumbW, $thumbH, $w, $h);
    $thumbName = pathinfo($basename, PATHINFO_FILENAME) . '_thumb.jpg';
    imagejpeg($thumb, $dir . $thumbName, 75);
    $result['thumb_url'] = 'uploads/challenge/' . $thumbName;
    imagedestroy($thumb);

    if (function_exists('imagewebp')) {
        $webpName = pathinfo($basename, PATHINFO_FILENAME) . '.webp';
        imagewebp($img, $dir . $webpName, 80);
        $result['webp_url'] = 'uploads/challenge/' . $webpName;
    }

    imagedestroy($img);
    return $result;
}

function challengeEmbedUrl(string $type, string $url): ?string {
    if ($type === 'youtube' && preg_match('/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/', $url, $m)) {
        return 'https://www.youtube.com/embed/' . $m[1];
    }
    if ($type === 'instagram' && preg_match('/instagram\.com\/(?:reel|p)\/([a-zA-Z0-9_-]+)/', $url, $m)) {
        return 'https://www.instagram.com/p/' . $m[1] . '/embed';
    }
    if ($type === 'tiktok' && preg_match('/tiktok\.com\/@[^\/]+\/video\/(\d+)/', $url, $m)) {
        return 'https://www.tiktok.com/embed/v2/' . $m[1];
    }
    return null;
}

function challengeRowToArray(PDO $pdo, array $row, bool $full = false): array {
    $id = $row['id'];
    $out = [
        'id'                  => $id,
        'slug'                => $row['slug'],
        'nome'                => $row['nome'],
        'whatsapp'            => $full ? $row['whatsapp'] : challengeMaskPhone($row['whatsapp']),
        'email'               => $full ? ($row['email'] ?? '') : null,
        'cidade'              => $row['cidade'] ?? '',
        'categoria'           => $row['categoria'],
        'descricao'           => $row['descricao'] ?? '',
        'historia'            => $row['historia'] ?? '',
        'status'              => $row['status'],
        'pontos'              => (int) $row['pontos'],
        'votos'               => (int) $row['votos'],
        'compartilhamentos'   => (int) $row['compartilhamentos'],
        'referralCode'        => $row['referral_code'],
        'campaignMonth'       => $row['campaign_month'],
        'metaTitle'           => $row['meta_title'] ?? '',
        'metaDescription'     => $row['meta_description'] ?? '',
        'scoreSujeira'        => $row['score_sujeira'] !== null ? (float) $row['score_sujeira'] : null,
        'scoreManchas'        => $row['score_manchas'] !== null ? (float) $row['score_manchas'] : null,
        'scoreDesgaste'       => $row['score_desgaste'] !== null ? (float) $row['score_desgaste'] : null,
        'scoreOdorEstimado'   => $row['score_odor_estimado'] !== null ? (float) $row['score_odor_estimado'] : null,
        'indiceTransformacao' => $row['indice_transformacao'] !== null ? (float) $row['indice_transformacao'] : null,
        'crmStatus'           => $row['crm_status'] ?? 'novo',
        'isWinner'            => (bool) (int) ($row['is_winner'] ?? 0),
        'winnerMonth'         => $row['winner_month'],
        'transformationId'    => $row['transformation_id'],
        'createdAt'           => $row['created_at'],
        'updatedAt'           => $row['updated_at'],
    ];

    $photos = $pdo->prepare("SELECT * FROM challenge_photos WHERE participant_id = ? ORDER BY sort_order, id");
    $photos->execute([$id]);
    $out['photos'] = array_map(function ($p) {
        return [
            'id'        => (int) $p['id'],
            'url'       => $p['url'],
            'thumbUrl'  => $p['thumb_url'],
            'webpUrl'   => $p['webp_url'],
            'photoType' => $p['photo_type'],
            'sortOrder' => (int) $p['sort_order'],
        ];
    }, $photos->fetchAll());

    $videos = $pdo->prepare("SELECT * FROM challenge_videos WHERE participant_id = ? ORDER BY sort_order, id");
    $videos->execute([$id]);
    $out['videos'] = array_map(function ($v) {
        return [
            'id'        => (int) $v['id'],
            'videoType' => $v['video_type'],
            'url'       => $v['url'],
            'embedUrl'  => $v['embed_url'],
            'sortOrder' => (int) $v['sort_order'],
        ];
    }, $videos->fetchAll());

    if ($full) {
        $badges = $pdo->prepare("
            SELECT b.id, b.slug, b.nome, b.descricao, b.icon, pb.awarded_at
            FROM challenge_participant_badges pb
            JOIN challenge_badges b ON b.id = pb.badge_id
            WHERE pb.participant_id = ?
        ");
        $badges->execute([$id]);
        $out['badges'] = array_map(function ($b) {
            return [
                'id'         => $b['id'],
                'slug'       => $b['slug'],
                'nome'       => $b['nome'],
                'descricao'  => $b['descricao'],
                'icon'       => $b['icon'],
                'awardedAt'  => $b['awarded_at'],
            ];
        }, $badges->fetchAll());
    }

    return $out;
}

function challengeMaskPhone(string $phone): string {
    $digits = preg_replace('/\D/', '', $phone);
    if (strlen($digits) < 8) return '***';
    return substr($digits, 0, 2) . '****' . substr($digits, -4);
}

function challengeAwardPoints(PDO $pdo, string $participantId, int $points): void {
    $pdo->prepare("UPDATE challenge_participants SET pontos = pontos + ?, updated_at = ? WHERE id = ?")
        ->execute([$points, dbNow(), $participantId]);
}

function challengeCompleteMission(PDO $pdo, string $participantId, string $missionKey): ?int {
    $missions = challengeGetMissions($pdo);
    if (!isset($missions[$missionKey])) return null;
    $points = (int) $missions[$missionKey];
    try {
        $pdo->prepare("INSERT INTO challenge_mission_log (participant_id, mission_key, points, created_at) VALUES (?, ?, ?, ?)")
            ->execute([$participantId, $missionKey, $points, dbNow()]);
        challengeAwardPoints($pdo, $participantId, $points);
        return $points;
    } catch (PDOException $e) {
        return null;
    }
}

function challengeBuildSeo(array $data): array {
    $nome = $data['nome'] ?? 'Participante';
    $cat  = $data['categoria'] ?? 'estofado';
    $city = $data['cidade'] ?? '';
    $title = "Desafio {$nome} — Transformação de {$cat}" . ($city ? " em {$city}" : '');
    $desc  = mb_substr(strip_tags($data['historia'] ?? $data['descricao'] ?? ''), 0, 155);
    if ($desc === '') $desc = "Veja a transformação incrível de {$nome} no Desafio Auto Limpeza Pro.";
    return ['meta_title' => $title, 'meta_description' => $desc];
}

function challengePromoteToTransformation(PDO $pdo, string $participantId): ?string {
    $stmt = $pdo->prepare("SELECT * FROM challenge_participants WHERE id = ?");
    $stmt->execute([$participantId]);
    $p = $stmt->fetch();
    if (!$p) return null;

    $photos = $pdo->prepare("SELECT * FROM challenge_photos WHERE participant_id = ? ORDER BY sort_order, id");
    $photos->execute([$participantId]);
    $photoRows = $photos->fetchAll();
    $before = '';
    $after  = '';
    foreach ($photoRows as $ph) {
        if ($ph['photo_type'] === 'antes' && !$before) $before = $ph['url'];
        if ($ph['photo_type'] === 'depois' && !$after) $after = $ph['url'];
    }
    if (!$before && !empty($photoRows[0])) $before = $photoRows[0]['url'];
    if (!$after && count($photoRows) > 1) $after = $photoRows[1]['url'];

    $videos = $pdo->prepare("SELECT url FROM challenge_videos WHERE participant_id = ? LIMIT 1");
    $videos->execute([$participantId]);
    $videoRow = $videos->fetch();

    $trId   = $p['transformation_id'] ?: uniqid('tr_', true);
    $baseSlug = slugify('desafio-' . $p['slug']);
    $slug   = $baseSlug;
    $n = 1;
    while (true) {
        $chk = $pdo->prepare("SELECT id FROM cms_transformations WHERE slug = ? AND id != ?");
        $chk->execute([$slug, $trId]);
        if (!$chk->fetch()) break;
        $slug = $baseSlug . '-' . $n++;
    }
    $title  = "Desafio: {$p['nome']} — " . ucfirst($p['categoria']);
    $now    = dbNow();

    $pdo->prepare("
        INSERT INTO cms_transformations
            (id, slug, title, service_type, city, description, before_image, after_image, video_url, featured, sort_order, published, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, 1, ?, ?)
        ON DUPLICATE KEY UPDATE
            title = VALUES(title), description = VALUES(description),
            before_image = VALUES(before_image), after_image = VALUES(after_image),
            video_url = VALUES(video_url), featured = 1, updated_at = VALUES(updated_at)
    ")->execute([
        $trId, $slug, $title, $p['categoria'], $p['cidade'],
        $p['historia'] ?: $p['descricao'], $before, $after,
        $videoRow['url'] ?? null, $now, $now,
    ]);

    $pdo->prepare("UPDATE challenge_participants SET transformation_id = ?, updated_at = ? WHERE id = ?")
        ->execute([$trId, $now, $participantId]);

    return $trId;
}

// ── Handlers ────────────────────────────────────────────────────────────────

function handleChallengeParticipants(string $method): void {
    $pdo = db();

    if ($method === 'GET') {
        $admin   = isAdmin();
        $slug    = san($_GET['slug'] ?? null, 200);
        $id      = san($_GET['id'] ?? null, 64);
        $status  = san($_GET['status'] ?? null, 30);
        $cat     = san($_GET['categoria'] ?? null, 50);
        $month   = san($_GET['month'] ?? null, 7);
        $limit   = min(100, max(1, sanInt($_GET['limit'] ?? 20)));
        $offset  = max(0, sanInt($_GET['offset'] ?? 0));

        if ($slug || $id) {
            $sql = "SELECT * FROM challenge_participants WHERE " . ($slug ? "slug = ?" : "id = ?");
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$slug ?: $id]);
            $row = $stmt->fetch();
            if (!$row) jsonRespond(['error' => lang('not_found')], 404);
            if (!$admin && !in_array($row['status'], ['approved', 'winner', 'champion'], true)) {
                jsonRespond(['error' => lang('not_found')], 404);
            }
            jsonRespond(challengeRowToArray($pdo, $row, $admin));
        }

        $sql = "SELECT * FROM challenge_participants WHERE 1=1";
        $params = [];
        if (!$admin) { $sql .= " AND status IN ('approved','winner','champion')"; }
        elseif ($status) { $sql .= " AND status = ?"; $params[] = $status; }
        if ($cat) { $sql .= " AND categoria = ?"; $params[] = $cat; }
        if ($month) { $sql .= " AND campaign_month = ?"; $params[] = $month; }
        $sql .= " ORDER BY pontos DESC, votos DESC, created_at DESC LIMIT {$limit} OFFSET {$offset}";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        jsonRespond(array_map(fn($r) => challengeRowToArray($pdo, $r, false), $stmt->fetchAll()));
    }

    if ($method === 'POST') {
        rateLimit('challenge_register', 5);
        $b = jsonBody();
        $nome      = san($b['nome'] ?? '', 200) ?? '';
        $whatsapp  = san($b['whatsapp'] ?? '', 50) ?? '';
        $email     = san($b['email'] ?? null, 200);
        $cidade    = san($b['cidade'] ?? '', 100) ?? '';
        $categoria = san($b['categoria'] ?? 'sofa', 50) ?? 'sofa';
        $descricao = san($b['descricao'] ?? null, 2000);
        $historia  = $b['historia'] ?? null;
        if (is_string($historia)) $historia = mb_substr(strip_tags(trim($historia)), 0, 5000);
        $visitorId = san($b['visitorId'] ?? null, 64);
        $refCode   = san($b['referralCode'] ?? null, 20);

        if ($nome === '' || $whatsapp === '' || $cidade === '') {
            jsonRespond(['error' => 'nome, whatsapp e cidade são obrigatórios'], 400);
        }
        if (!in_array($categoria, CHALLENGE_CATEGORIES, true)) {
            jsonRespond(['error' => 'categoria inválida'], 400);
        }

        $id = uniqid('ch_', true);
        $slug = challengeUniqueSlug($pdo, $nome . '-' . $cidade);
        $code = challengeGenerateReferralCode();
        while (true) {
            $chk = $pdo->prepare("SELECT id FROM challenge_referrals WHERE code = ?");
            $chk->execute([$code]);
            if (!$chk->fetch()) break;
            $code = challengeGenerateReferralCode();
        }
        $month = date('Y-m');
        $seo   = challengeBuildSeo(['nome' => $nome, 'categoria' => $categoria, 'cidade' => $cidade, 'historia' => $historia, 'descricao' => $descricao]);
        $now   = dbNow();
        $referredBy = null;

        if ($refCode) {
            $refStmt = $pdo->prepare("SELECT referrer_id FROM challenge_referrals WHERE code = ?");
            $refStmt->execute([$refCode]);
            $refRow = $refStmt->fetch();
            if ($refRow) {
                $referredBy = $refRow['referrer_id'];
                $pdo->prepare("UPDATE challenge_referrals SET signups = signups + 1, updated_at = ? WHERE code = ?")
                    ->execute([$now, $refCode]);
                challengeAwardPoints($pdo, $referredBy, challengeGetMissions($pdo)['refer'] ?? 100);
            }
        }

        $pdo->prepare("
            INSERT INTO challenge_participants
                (id, slug, nome, whatsapp, email, cidade, categoria, descricao, historia, status,
                 pontos, votos, compartilhamentos, referral_code, referred_by, campaign_month,
                 meta_title, meta_description, visitor_id, crm_status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0, 0, 0, ?, ?, ?, ?, ?, ?, 'novo', ?, ?)
        ")->execute([
            $id, $slug, $nome, $whatsapp, $email, $cidade, $categoria, $descricao, $historia,
            $code, $referredBy, $month, $seo['meta_title'], $seo['meta_description'], $visitorId, $now, $now,
        ]);

        $pdo->prepare("INSERT INTO challenge_referrals (referrer_id, code, created_at, updated_at) VALUES (?, ?, ?, ?)")
            ->execute([$id, $code, $now, $now]);

        $pdo->prepare("INSERT INTO leads (name, phone, service, city, source) VALUES (?, ?, ?, ?, ?)")
            ->execute([$nome, $whatsapp, 'desafio-' . $categoria, $cidade, 'desafio_transformacao']);

        if (!empty($b['photos']) && is_array($b['photos'])) {
            $sort = 0;
            foreach (array_slice($b['photos'], 0, 20) as $ph) {
                $url = san($ph['url'] ?? '', 500);
                if (!$url) continue;
                $pdo->prepare("INSERT INTO challenge_photos (participant_id, url, thumb_url, webp_url, photo_type, sort_order, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
                    ->execute([
                        $id, $url,
                        san($ph['thumbUrl'] ?? null, 500),
                        san($ph['webpUrl'] ?? null, 500),
                        san($ph['photoType'] ?? 'geral', 20) ?? 'geral',
                        $sort++, $now,
                    ]);
            }
        }

        if (!empty($b['videos']) && is_array($b['videos'])) {
            $vsort = 0;
            foreach ($b['videos'] as $vid) {
                $vtype = san($vid['videoType'] ?? 'upload', 20) ?? 'upload';
                $vurl  = san($vid['url'] ?? '', 500);
                if (!$vurl) continue;
                $embed = challengeEmbedUrl($vtype, $vurl);
                $pdo->prepare("INSERT INTO challenge_videos (participant_id, video_type, url, embed_url, sort_order, created_at) VALUES (?, ?, ?, ?, ?, ?)")
                    ->execute([$id, $vtype, $vurl, $embed, $vsort++, $now]);
            }
        }

        challengeCompleteMission($pdo, $id, 'complete_profile');

        $aiScores = challengeAnalyzeParticipant($pdo, $id);

        $stmt = $pdo->prepare("SELECT * FROM challenge_participants WHERE id = ?");
        $stmt->execute([$id]);
        $result = challengeRowToArray($pdo, $stmt->fetch(), true);
        if ($aiScores) $result['aiAnalysis'] = $aiScores;
        jsonRespond($result, 201);
    }

    if ($method === 'PUT') {
        requireAdmin();
        $b = jsonBody();
        $id = san($b['id'] ?? null, 64);
        if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);

        $stmt = $pdo->prepare("SELECT * FROM challenge_participants WHERE id = ?");
        $stmt->execute([$id]);
        $existing = $stmt->fetch();
        if (!$existing) jsonRespond(['error' => lang('not_found')], 404);

        $now = dbNow();
        $fields = [];
        $params = [];

        foreach ([
            'status' => 'status', 'crmStatus' => 'crm_status', 'nome' => 'nome',
            'categoria' => 'categoria', 'cidade' => 'cidade', 'historia' => 'historia',
            'descricao' => 'descricao', 'isWinner' => 'is_winner', 'winnerMonth' => 'winner_month',
        ] as $js => $db) {
            if (!array_key_exists($js, $b)) continue;
            $val = $b[$js];
            if ($js === 'isWinner') $val = $val ? 1 : 0;
            if (in_array($js, ['nome', 'categoria', 'cidade', 'status', 'crmStatus', 'winnerMonth'], true)) {
                $val = san((string) $val, 200);
            }
            $fields[] = "`{$db}` = ?";
            $params[] = $val;
        }

        if (isset($b['scoreSujeira'])) { $fields[] = 'score_sujeira = ?'; $params[] = sanFloat($b['scoreSujeira']); }
        if (isset($b['scoreManchas'])) { $fields[] = 'score_manchas = ?'; $params[] = sanFloat($b['scoreManchas']); }
        if (isset($b['scoreDesgaste'])) { $fields[] = 'score_desgaste = ?'; $params[] = sanFloat($b['scoreDesgaste']); }
        if (isset($b['scoreOdorEstimado'])) { $fields[] = 'score_odor_estimado = ?'; $params[] = sanFloat($b['scoreOdorEstimado']); }
        if (isset($b['indiceTransformacao'])) { $fields[] = 'indice_transformacao = ?'; $params[] = sanFloat($b['indiceTransformacao']); }

        if (empty($fields)) jsonRespond(['error' => 'Nada para atualizar'], 400);

        $fields[] = 'updated_at = ?';
        $params[] = $now;
        $params[] = $id;
        $pdo->prepare("UPDATE challenge_participants SET " . implode(', ', $fields) . " WHERE id = ?")->execute($params);

        if (!empty($b['badgeId'])) {
            try {
                $pdo->prepare("INSERT INTO challenge_participant_badges (participant_id, badge_id, awarded_at) VALUES (?, ?, ?)")
                    ->execute([$id, san($b['badgeId'], 64), $now]);
            } catch (PDOException $e) { /* já possui */ }
        }

        if (!empty($b['isWinner']) || ($b['status'] ?? '') === 'winner') {
            $pdo->prepare("UPDATE challenge_participants SET is_winner = 1, status = 'winner', winner_month = ? WHERE id = ?")
                ->execute([$b['winnerMonth'] ?? date('Y-m'), $id]);
            challengePromoteToTransformation($pdo, $id);
            challengeAnalyzeParticipant($pdo, $id);
            try {
                $pdo->prepare("INSERT INTO challenge_participant_badges (participant_id, badge_id, awarded_at) VALUES (?, 'bdg_mes', ?)")
                    ->execute([$id, $now]);
            } catch (PDOException $e) { /* */ }
        }

        if (($b['status'] ?? '') === 'approved' && $existing['status'] !== 'approved') {
            challengeAnalyzeParticipant($pdo, $id);
        }

        $stmt = $pdo->prepare("SELECT * FROM challenge_participants WHERE id = ?");
        $stmt->execute([$id]);
        jsonRespond(challengeRowToArray($pdo, $stmt->fetch(), true));
    }

    if ($method === 'DELETE') {
        requireAdmin();
        $id = san($_GET['id'] ?? jsonBody()['id'] ?? null, 64);
        if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);
        $pdo->prepare("DELETE FROM challenge_photos WHERE participant_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM challenge_videos WHERE participant_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM challenge_votes WHERE participant_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM challenge_participant_badges WHERE participant_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM challenge_mission_log WHERE participant_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM challenge_participants WHERE id = ?")->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => lang('method_not_allowed')], 405);
}

function handleChallengeVote(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => lang('method_not_allowed')], 405);
    rateLimit('challenge_vote', 30);

    $b = jsonBody();
    $participantId = san($b['participantId'] ?? null, 64);
    $cookieId      = san($b['cookieId'] ?? null, 64);
    $visitorId     = san($b['visitorId'] ?? null, 64);

    if (!$participantId) jsonRespond(['error' => 'participantId obrigatório'], 400);

    $pdo = db();
    $stmt = $pdo->prepare("SELECT id, status FROM challenge_participants WHERE id = ?");
    $stmt->execute([$participantId]);
    $p = $stmt->fetch();
    if (!$p || !in_array($p['status'], ['approved', 'winner', 'champion'], true)) {
        jsonRespond(['error' => 'Participante não disponível para voto'], 400);
    }

    $voterHash = challengeVoterHash($cookieId);
    $now = dbNow();

    try {
        $pdo->prepare("INSERT INTO challenge_votes (participant_id, voter_hash, ip_hash, cookie_id, visitor_id, created_at) VALUES (?, ?, ?, ?, ?, ?)")
            ->execute([$participantId, $voterHash, challengeIpHash(), $cookieId, $visitorId, $now]);
        $pdo->prepare("UPDATE challenge_participants SET votos = votos + 1, pontos = pontos + 10, updated_at = ? WHERE id = ?")
            ->execute([$now, $participantId]);
        jsonRespond(['ok' => true, 'voted' => true]);
    } catch (PDOException $e) {
        jsonRespond(['ok' => false, 'voted' => false, 'error' => 'Você já votou neste participante'], 409);
    }
}

function handleChallengeShare(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => lang('method_not_allowed')], 405);
    rateLimit('challenge_share', 20);

    $b = jsonBody();
    $participantId = san($b['participantId'] ?? null, 64);
    if (!$participantId) jsonRespond(['error' => 'participantId obrigatório'], 400);

    $pdo = db();
    $now = dbNow();
    $pdo->prepare("UPDATE challenge_participants SET compartilhamentos = compartilhamentos + 1, updated_at = ? WHERE id = ?")
        ->execute([$now, $participantId]);
    $pts = challengeCompleteMission($pdo, $participantId, 'share');
    jsonRespond(['ok' => true, 'pointsAwarded' => $pts]);
}

function handleChallengeReferral(string $method): void {
    $pdo = db();

    if ($method === 'GET') {
        $code = strtoupper(san($_GET['code'] ?? null, 20) ?? '');
        if (!$code) jsonRespond(['error' => 'code obrigatório'], 400);
        $stmt = $pdo->prepare("
            SELECT r.*, p.nome, p.slug FROM challenge_referrals r
            JOIN challenge_participants p ON p.id = r.referrer_id
            WHERE r.code = ?
        ");
        $stmt->execute([$code]);
        $row = $stmt->fetch();
        if (!$row) jsonRespond(['error' => lang('not_found')], 404);
        jsonRespond([
            'code'      => $row['code'],
            'clicks'    => (int) $row['clicks'],
            'signups'   => (int) $row['signups'],
            'referrer'  => ['nome' => $row['nome'], 'slug' => $row['slug']],
        ]);
    }

    if ($method === 'POST') {
        rateLimit('challenge_referral_click', 60);
        $b = jsonBody();
        $code = strtoupper(san($b['code'] ?? null, 20) ?? '');
        if (!$code) jsonRespond(['error' => 'code obrigatório'], 400);

        $now = dbNow();
        $pdo->prepare("INSERT INTO challenge_referral_clicks (code, ip_hash, created_at) VALUES (?, ?, ?)")
            ->execute([$code, challengeIpHash(), $now]);
        $pdo->prepare("UPDATE challenge_referrals SET clicks = clicks + 1, updated_at = ? WHERE code = ?")
            ->execute([$now, $code]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => lang('method_not_allowed')], 405);
}

function handleChallengeRanking(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => lang('method_not_allowed')], 405);

    $pdo = db();
    $cat   = san($_GET['categoria'] ?? null, 50);
    $month = san($_GET['month'] ?? date('Y-m'), 7);
    $year  = san($_GET['year'] ?? null, 4);
    $limit = min(100, max(1, sanInt($_GET['limit'] ?? 10)));
    $sort  = san($_GET['sort'] ?? 'pontos', 20);

    $sql = "SELECT * FROM challenge_participants WHERE status IN ('approved','winner','champion')";
    $params = [];
    if ($cat) { $sql .= " AND categoria = ?"; $params[] = $cat; }
    if ($year) { $sql .= " AND campaign_month LIKE ?"; $params[] = $year . '-%'; }
    elseif ($month) { $sql .= " AND campaign_month = ?"; $params[] = $month; }

    $orderCol = $sort === 'votos' ? 'votos' : ($sort === 'shares' ? 'compartilhamentos' : 'pontos');
    $sql .= " ORDER BY {$orderCol} DESC, votos DESC LIMIT {$limit}";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    jsonRespond(array_map(fn($r) => challengeRowToArray($pdo, $r, false), $stmt->fetchAll()));
}

function handleChallengeHall(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => lang('method_not_allowed')], 405);

    $pdo = db();
    $stmt = $pdo->query("
        SELECT p.* FROM challenge_participants p
        WHERE p.is_winner = 1 OR p.status IN ('winner','champion')
        ORDER BY p.winner_month DESC, p.pontos DESC
        LIMIT 50
    ");
    jsonRespond(array_map(fn($r) => challengeRowToArray($pdo, $r, false), $stmt->fetchAll()));
}

function handleChallengeMissions(string $method): void {
    $pdo = db();

    if ($method === 'GET') {
        jsonRespond(challengeGetMissions($pdo));
    }

    requireAdmin();
    if ($method === 'POST') {
        $b = jsonBody();
        $json = json_encode($b, JSON_UNESCAPED_UNICODE);
        $pdo->prepare("INSERT INTO site_config (key_name, value, updated_at) VALUES ('challenge_missions', ?, ?)
            ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)")
            ->execute([$json, dbNow()]);
        jsonRespond(['ok' => true, 'missions' => challengeGetMissions($pdo)]);
    }

    jsonRespond(['error' => lang('method_not_allowed')], 405);
}

function handleChallengeMissionComplete(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => lang('method_not_allowed')], 405);
    rateLimit('challenge_mission', 20);

    $b = jsonBody();
    $participantId = san($b['participantId'] ?? null, 64);
    $missionKey    = san($b['missionKey'] ?? null, 50);
    if (!$participantId || !$missionKey) jsonRespond(['error' => 'participantId e missionKey obrigatórios'], 400);

    $pts = challengeCompleteMission(db(), $participantId, $missionKey);
    if ($pts === null) jsonRespond(['ok' => false, 'error' => 'Missão já concluída ou inválida'], 409);
    jsonRespond(['ok' => true, 'pointsAwarded' => $pts]);
}

function handleChallengeStats(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => lang('method_not_allowed')], 405);

    $pdo = db();
    $month = date('Y-m');

    $stats = [
        'participants'        => (int) $pdo->query("SELECT COUNT(*) FROM challenge_participants")->fetchColumn(),
        'pending'             => (int) $pdo->query("SELECT COUNT(*) FROM challenge_participants WHERE status = 'pending'")->fetchColumn(),
        'approved'            => (int) $pdo->query("SELECT COUNT(*) FROM challenge_participants WHERE status = 'approved'")->fetchColumn(),
        'winners'             => (int) $pdo->query("SELECT COUNT(*) FROM challenge_participants WHERE is_winner = 1")->fetchColumn(),
        'totalVotes'          => (int) $pdo->query("SELECT COALESCE(SUM(votos),0) FROM challenge_participants")->fetchColumn(),
        'totalShares'         => (int) $pdo->query("SELECT COALESCE(SUM(compartilhamentos),0) FROM challenge_participants")->fetchColumn(),
        'totalReferralClicks' => (int) $pdo->query("SELECT COALESCE(SUM(clicks),0) FROM challenge_referrals")->fetchColumn(),
        'leads'               => (int) $pdo->query("SELECT COUNT(*) FROM leads WHERE source = 'desafio_transformacao'")->fetchColumn(),
    ];

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM challenge_participants WHERE campaign_month = ?");
    $stmt->execute([$month]);
    $stats['participantsMonth'] = (int) $stmt->fetchColumn();

    $byCategory = $pdo->query("SELECT categoria, COUNT(*) as total FROM challenge_participants GROUP BY categoria")->fetchAll();
    $stats['byCategory'] = array_column($byCategory, 'total', 'categoria');

    $recent = $pdo->query("SELECT DATE(created_at) as day, COUNT(*) as total FROM challenge_participants GROUP BY DATE(created_at) ORDER BY day DESC LIMIT 30")->fetchAll();
    $stats['daily'] = $recent;

    jsonRespond($stats);
}

function handleChallengeUpload(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => lang('method_not_allowed')], 405);
    rateLimit('challenge_upload', 15);

    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        jsonRespond(['error' => 'Nenhum arquivo enviado'], 400);
    }

    $file = $_FILES['file'];
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $allowedExt = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $detected = $finfo ? finfo_file($finfo, $file['tmp_name']) : null;
    if ($finfo) finfo_close($finfo);
    if (!$detected) {
        jsonRespond(['error' => 'Não foi possível validar o tipo do arquivo'], 400);
    }
    $mime = $detected;
    if (!in_array($mime, $allowed, true)) {
        jsonRespond(['error' => 'Use JPG, PNG, GIF ou WebP'], 400);
    }
    if ($file['size'] > 5 * 1024 * 1024) {
        jsonRespond(['error' => 'Máximo 5MB por foto'], 400);
    }

    if (!is_dir(CHALLENGE_UPLOADS_DIR)) mkdir(CHALLENGE_UPLOADS_DIR, 0755, true);

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) {
        jsonRespond(['error' => 'Extensão não permitida'], 400);
    }
    $ext = $ext ?: 'jpg';
    $basename = uniqid('chimg_', true) . '.' . $ext;
    $tmpDest = CHALLENGE_UPLOADS_DIR . $basename;

    if (!move_uploaded_file($file['tmp_name'], $tmpDest)) {
        jsonRespond(['error' => 'Falha no upload'], 500);
    }

    $processed = challengeProcessImage($tmpDest, $basename);
    if ($processed['url'] !== 'uploads/challenge/' . $basename && file_exists($tmpDest)) {
        @unlink($tmpDest);
    }

    $localPath = challengeResolveLocalPath($processed['url']);
    if ($localPath) {
        $analysis = challengeAnalyzeImageFile($localPath);
        if ($analysis) {
            $processed['analysis'] = [
                'scoreSujeira'      => $analysis['score_sujeira'],
                'scoreManchas'      => $analysis['score_manchas'],
                'scoreDesgaste'     => $analysis['score_desgaste'],
                'scoreOdorEstimado' => $analysis['score_odor_estimado'],
                'messiness'         => $analysis['messiness'],
                'engine'            => 'gd-local',
            ];
        }
    }

    jsonRespond($processed);
}

function handleChallengeBadges(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => lang('method_not_allowed')], 405);
    $rows = db()->query("SELECT * FROM challenge_badges ORDER BY pontos DESC")->fetchAll();
    jsonRespond(array_map(fn($b) => [
        'id'        => $b['id'],
        'slug'      => $b['slug'],
        'nome'      => $b['nome'],
        'descricao' => $b['descricao'],
        'icon'      => $b['icon'],
        'pontos'    => (int) $b['pontos'],
    ], $rows));
}

function handleChallengeAnalyze(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => lang('method_not_allowed')], 405);
    rateLimit('challenge_analyze', 10);

    $b = jsonBody();
    $participantId = san($b['participantId'] ?? null, 64);
    if (!$participantId) jsonRespond(['error' => 'participantId obrigatório'], 400);

    $pdo = db();
    $stmt = $pdo->prepare("SELECT id, status FROM challenge_participants WHERE id = ?");
    $stmt->execute([$participantId]);
    $p = $stmt->fetch();
    if (!$p) jsonRespond(['error' => lang('not_found')], 404);

    if (!isAdmin() && !in_array($p['status'], ['pending', 'approved', 'winner', 'champion'], true)) {
        jsonRespond(['error' => lang('unauthorized')], 401);
    }

    $result = challengeAnalyzeParticipant($pdo, $participantId);
    if (!$result) jsonRespond(['error' => 'Não foi possível analisar as imagens'], 422);
    jsonRespond(['ok' => true, 'analysis' => $result]);
}

function handleChallengeCertificate(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => lang('method_not_allowed')], 405);

    $slug = san($_GET['slug'] ?? null, 200);
    if (!$slug) jsonRespond(['error' => 'slug obrigatório'], 400);

    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM challenge_participants WHERE slug = ? AND (is_winner = 1 OR status IN ('winner','champion'))");
    $stmt->execute([$slug]);
    $p = $stmt->fetch();
    if (!$p) jsonRespond(['error' => 'Certificado disponível apenas para campeões'], 404);

    $participant = challengeRowToArray($pdo, $p, false);
    $pageUrl = rtrim(SITE_URL, '/') . '/desafio/' . rawurlencode($slug);
    $qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=' . rawurlencode($pageUrl);
    $monthLabel = $p['winner_month'] ?? $p['campaign_month'];
    $parts = explode('-', $monthLabel);
    $monthNames = ['','Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    $monthBR = ($parts[1] ?? '') !== '' ? ($monthNames[(int)$parts[1]] ?? $monthLabel) . ' ' . ($parts[0] ?? '') : $monthLabel;
    $indice = $p['indice_transformacao'] !== null ? number_format((float)$p['indice_transformacao'], 0) : '—';
    $nome = htmlspecialchars($p['nome'], ENT_QUOTES, 'UTF-8');
    $cidade = htmlspecialchars($p['cidade'], ENT_QUOTES, 'UTF-8');
    $cat = htmlspecialchars(ucfirst($p['categoria']), ENT_QUOTES, 'UTF-8');

    header('Content-Type: text/html; charset=utf-8');
    echo <<<HTML
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Certificado — {$nome} | Auto Limpeza Pro</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:Georgia,'Times New Roman',serif;background:#0a0f1e;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
  .cert{max-width:720px;width:100%;background:linear-gradient(145deg,#111827,#0f172a);border:3px solid #f59e0b;border-radius:24px;padding:48px 40px;text-align:center;position:relative;box-shadow:0 25px 80px rgba(245,158,11,.15)}
  .cert::before{content:'';position:absolute;inset:12px;border:1px solid rgba(245,158,11,.35);border-radius:16px;pointer-events:none}
  .logo{font-size:11px;letter-spacing:.25em;text-transform:uppercase;color:#22d3ee;margin-bottom:8px}
  h1{font-size:13px;letter-spacing:.2em;text-transform:uppercase;color:#f59e0b;margin-bottom:24px}
  .name{font-size:32px;font-weight:700;color:#fff;margin:16px 0;line-height:1.2}
  .subtitle{font-size:15px;color:#94a3b8;line-height:1.7;margin-bottom:24px}
  .badge{display:inline-block;padding:8px 20px;border-radius:999px;background:rgba(245,158,11,.15);color:#fbbf24;font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;margin-bottom:24px}
  .stats{display:flex;justify-content:center;gap:32px;margin:24px 0;flex-wrap:wrap}
  .stat .val{font-size:28px;font-weight:700;color:#22d3ee}
  .stat .lbl{font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:.1em}
  .qr{margin-top:24px}
  .qr img{border-radius:12px;background:#fff;padding:8px}
  .footer{margin-top:28px;font-size:11px;color:#64748b}
  @media print{body{background:#fff;padding:0}.cert{box-shadow:none;border-color:#b45309;color:#1e293b;background:#fff}.cert::before{border-color:#d97706}.name{color:#0f172a}.logo{color:#0891b2}}
  .print-btn{margin-top:20px;padding:12px 28px;background:#f59e0b;color:#0f172a;border:none;border-radius:12px;font-weight:700;cursor:pointer;font-size:14px}
</style>
</head>
<body>
<div class="cert">
  <p class="logo">Auto Limpeza Pro</p>
  <h1>Certificado de Transformação</h1>
  <p class="badge">🏆 Campeão do Desafio — {$monthBR}</p>
  <p class="subtitle">Certificamos que</p>
  <p class="name">{$nome}</p>
  <p class="subtitle">de <strong>{$cidade}</strong> participou do Desafio de Transformação<br>na categoria <strong>{$cat}</strong> com resultado excepcional.</p>
  <div class="stats">
    <div class="stat"><div class="val">{$indice}</div><div class="lbl">Índice transformação</div></div>
    <div class="stat"><div class="val">{$p['votos']}</div><div class="lbl">Votos públicos</div></div>
    <div class="stat"><div class="val">{$p['pontos']}</div><div class="lbl">Pontos</div></div>
  </div>
  <div class="qr"><img src="{$qrUrl}" width="140" height="140" alt="QR Code"></div>
  <p class="footer">Emitido em {$monthBR} · autolimpezapro.com.br<br>Validação: {$pageUrl}</p>
  <button class="print-btn" onclick="window.print()">🖨️ Salvar como PDF (Imprimir)</button>
</div>
</body>
</html>
HTML;
    exit;
}

function challengeSitemapEntries(PDO $pdo): string {
    $base = rtrim(SITE_URL, '/');
    $today = date('Y-m-d');
    $xml = '';

    $staticPages = [
        ['/desafio', 'weekly', '0.9'],
        ['/desafio/ranking', 'weekly', '0.85'],
        ['/hall-da-fama', 'monthly', '0.85'],
        ['/transformacoes', 'weekly', '0.9'],
    ];
    foreach ($staticPages as [$path, $freq, $pri]) {
        $xml .= "  <url><loc>{$base}{$path}</loc><changefreq>{$freq}</changefreq><priority>{$pri}</priority><lastmod>{$today}</lastmod></url>\n";
    }

    try {
        $rows = $pdo->query("
            SELECT slug, updated_at FROM challenge_participants
            WHERE status IN ('approved','winner','champion')
            ORDER BY updated_at DESC LIMIT 500
        ")->fetchAll();
        foreach ($rows as $r) {
            $loc = $base . '/desafio/' . rawurlencode($r['slug']);
            $lm = substr($r['updated_at'], 0, 10);
            $pri = '0.8';
            $xml .= "  <url><loc>{$loc}</loc><changefreq>weekly</changefreq><priority>{$pri}</priority><lastmod>{$lm}</lastmod></url>\n";
        }
    } catch (PDOException $e) {
        appLog('warn', 'challenge sitemap skip', ['err' => $e->getMessage()]);
    }

    return $xml;
}
