<?php
/**
 * Motor de seleção de produtos afiliados (relevância + rotação).
 * Não inventa URLs. Não carrega o catálogo inteiro. Não usa ORDER BY RAND().
 * Inserção no post permanece em blogAffiliateLinksInjectBlocks().
 */

function blogAffiliateCfgInt(string $key, int $default): int {
    if (!defined($key)) {
        return $default;
    }
    return max(0, (int)constant($key));
}

function blogAffiliateNormalize(string $s): string {
    $s = mb_strtolower(trim($s));
    if ($s === '') {
        return '';
    }
    $from = ['á','à','â','ã','ä','é','è','ê','ë','í','ì','î','ï','ó','ò','ô','õ','ö','ú','ù','û','ü','ç','ñ'];
    $to   = ['a','a','a','a','a','e','e','e','e','i','i','i','i','o','o','o','o','o','u','u','u','u','c','n'];
    return str_replace($from, $to, $s);
}

/** Cidades / SEO local — NÃO devem dominar o matching de produto. */
function blogAffiliateGeoStopwords(): array {
    static $list = null;
    if ($list !== null) {
        return $list;
    }
    $cities = function_exists('blogAffiliateDefaultCities')
        ? blogAffiliateDefaultCities()
        : ['Vespasiano', 'São José da Lapa', 'Belo Horizonte', 'Lagoa Santa'];
    $extra = [
        'bh', 'rmbh', 'mg', 'minas', 'minas gerais', 'grande bh',
        'regiao metropolitana', 'região metropolitana', 'contagem', 'betim',
        'cidade', 'bairro', 'municipio', 'município', 'metropolitana',
    ];
    $out = [];
    foreach (array_merge($cities, $extra) as $c) {
        $n = blogAffiliateNormalize((string)$c);
        if ($n !== '') {
            $out[$n] = true;
            foreach (preg_split('/\s+/u', $n) as $part) {
                if (mb_strlen($part) >= 4) {
                    $out[$part] = true;
                }
            }
        }
    }
    $list = $out;
    return $list;
}

function blogAffiliateGenericStopwords(): array {
    return [
        'para' => true, 'com' => true, 'uma' => true, 'umas' => true, 'uns' => true,
        'como' => true, 'dicas' => true, 'guia' => true, 'sobre' => true, 'neste' => true,
        'nesta' => true, 'desse' => true, 'dessa' => true, 'mais' => true, 'muito' => true,
        'apos' => true, 'depois' => true, 'antes' => true, 'melhor' => true, 'veja' => true,
        'saiba' => true, 'tudo' => true, 'voce' => true, 'sua' => true, 'seu' => true,
        'casa' => true, 'profissional' => true, 'auto' => true, 'limpeza' => true,
        'pro' => true, 'blog' => true, 'dica' => true, 'passo' => true, 'aqui' => true,
        'onde' => true, 'quando' => true, 'qual' => true, 'quais' => true, 'fazer' => true,
        'hoje' => true, 'agora' => true, 'regiao' => true, 'região' => true,
    ];
}

/**
 * Clusters comerciais (produto) vs. contexto do post.
 * @return array<string, list<string>>
 */
function blogAffiliateClusterLexicon(): array {
    return [
        'impermeabilizacao' => [
            'impermeabil', 'impermeabilizante', 'protetor de tecido', 'protetor de estofado',
            'protecao de tecido', 'protecao de estofado', 'spray imperme', 'kit impermeabil',
        ],
        'estofado' => [
            'estofado', 'sofa', 'sofá', 'poltrona', 'tecido', 'almofada', 'higienizacao de sofa',
        ],
        'colchao' => ['colchao', 'colchão', 'acaro', 'ácaro', 'antiacaro'],
        'tapete' => ['tapete', 'carpete'],
        'cadeira' => ['cadeira', 'escritorio', 'escritório'],
        'couro' => ['couro', 'hidratante de couro', 'hidratacao couro'],
        'manchas' => ['mancha', 'tira mancha', 'tira-mancha', 'removedor de mancha'],
        'automotivo' => [
            'automotiv', 'carro', 'veiculo', 'veículo', 'pneu', 'motor', 'pretinho',
            'polimento', 'cera automot', 'banco de carro', 'lavagem automot', 'shampoo automot',
        ],
        'pos-obra' => ['pos-obra', 'pos obra', 'pós-obra', 'reboco', 'obra nova'],
    ];
}

function blogAffiliateClusterInText(string $normHay): array {
    $hits = [];
    foreach (blogAffiliateClusterLexicon() as $cluster => $needles) {
        foreach ($needles as $n) {
            $nn = blogAffiliateNormalize($n);
            if ($nn !== '' && mb_strpos($normHay, $nn) !== false) {
                $hits[$cluster] = true;
                break;
            }
        }
    }
    return array_keys($hits);
}

function blogAffiliateDetectIntent(string $normHay): string {
    if (preg_match('/impermeabil|proteger|protecao|conserv|hidratar|hidratacao|evitar liquido|evitar mancha/u', $normHay)) {
        return 'protecao';
    }
    if (preg_match('/compar|melhor produto|qual produto|vs\b|versus/u', $normHay)) {
        return 'comparativa';
    }
    if (preg_match('/comprar|kit |oferta|preco|preço/u', $normHay)) {
        return 'compra';
    }
    if (preg_match('/limpar|higieniz|sujo|extrator|shampoo|tira mancha|remover/u', $normHay)) {
        return 'limpeza';
    }
    return 'informacional';
}

/**
 * Contexto semântico do post. Localização fica em `location` e NÃO entra em searchTokens.
 * @param array<string,mixed> $params
 * @return array<string,mixed>
 */
function blogAffiliateBuildSemanticContext(array $params): array {
    $title = (string)($params['title'] ?? '');
    $keyword = (string)($params['keyword'] ?? $params['topic'] ?? '');
    $category = (string)($params['category'] ?? '');
    $serviceId = (string)($params['serviceId'] ?? $params['service_id'] ?? '');
    $city = (string)($params['city'] ?? '');
    $slug = (string)($params['slug'] ?? '');
    $content = mb_substr((string)($params['content'] ?? ''), 0, 1800);
    $tags = $params['tags'] ?? [];
    if (is_string($tags)) {
        $tags = array_filter(array_map('trim', explode(',', $tags)));
    }
    if (!is_array($tags)) {
        $tags = [];
    }

    $rawHay = implode(' ', array_filter([
        $title, $keyword, $category, $serviceId, $slug, $content, implode(' ', $tags),
    ]));
    $normHay = blogAffiliateNormalize($rawHay);
    $geo = blogAffiliateGeoStopwords();
    $generic = blogAffiliateGenericStopwords();

    $location = blogAffiliateNormalize($city);
    if ($location === '') {
        foreach (array_keys($geo) as $g) {
            if (mb_strlen($g) >= 5 && mb_strpos($normHay, $g) !== false) {
                $location = $g;
                break;
            }
        }
    }

    $clusters = blogAffiliateClusterInText($normHay);
    $intent = blogAffiliateDetectIntent($normHay);

    $tokens = [];
    $parts = preg_split('/[^a-z0-9]+/u', $normHay) ?: [];
    foreach ($parts as $p) {
        $p = trim($p);
        if (mb_strlen($p) < 4) {
            continue;
        }
        if (isset($geo[$p]) || isset($generic[$p])) {
            continue;
        }
        $tokens[$p] = true;
    }

    $primary = [];
    foreach (['impermeabilizacao', 'impermeabilizante', 'estofado', 'sofa', 'tecido', 'colchao', 'tapete', 'cadeira', 'couro', 'automotivo'] as $k) {
        if (isset($tokens[$k]) || mb_strpos($normHay, $k) !== false) {
            $primary[$k] = true;
        }
    }
    if (in_array('impermeabilizacao', $clusters, true)) {
        $primary['impermeabilizante'] = true;
        $primary['protetor'] = true;
        $primary['tecido'] = true;
        $primary['estofado'] = true;
    }

    $niche = 'limpeza';
    $sub = $category !== '' ? blogAffiliateNormalize($category) : 'geral';
    if (in_array('impermeabilizacao', $clusters, true)) {
        $niche = 'limpeza de estofados';
        $sub = 'impermeabilizacao';
    } elseif (in_array('estofado', $clusters, true) || in_array('cadeira', $clusters, true)) {
        $niche = 'limpeza de estofados';
        $sub = in_array('cadeira', $clusters, true) ? 'cadeiras' : 'estofados';
    } elseif (in_array('colchao', $clusters, true)) {
        $niche = 'limpeza de colchao';
        $sub = 'colchao';
    } elseif (in_array('tapete', $clusters, true)) {
        $niche = 'limpeza de tapete';
        $sub = 'tapetes';
    } elseif (in_array('automotivo', $clusters, true)) {
        $niche = 'limpeza automotiva';
        $sub = 'automotivo';
    } elseif (in_array('pos-obra', $clusters, true)) {
        $niche = 'limpeza pos-obra';
        $sub = 'pos-obra';
    } elseif ($serviceId !== '') {
        $sub = blogAffiliateNormalize($serviceId);
        $niche = $sub;
    }

    $productTypes = [];
    if ($intent === 'protecao' || in_array('impermeabilizacao', $clusters, true)) {
        $productTypes = ['impermeabilizante para sofa', 'impermeabilizante para tecido', 'protetor de estofados'];
    } elseif ($intent === 'limpeza' && (in_array('estofado', $clusters, true) || $sub === 'estofados' || $sub === 'sofa')) {
        $productTypes = ['limpador para estofados', 'higienizador de sofa', 'tira manchas estofado'];
    } elseif (in_array('couro', $clusters, true)) {
        $productTypes = ['hidratante para couro', 'limpador de couro'];
    } elseif (in_array('colchao', $clusters, true)) {
        $productTypes = ['higienizador de colchao', 'spray antiacaro'];
    } elseif (in_array('automotivo', $clusters, true)) {
        $productTypes = ['shampoo automotivo', 'kit limpeza automotiva'];
    }

    $excluded = [];
    if (!in_array('automotivo', $clusters, true) && ($niche === 'limpeza de estofados' || $sub === 'impermeabilizacao' || $sub === 'colchao' || $sub === 'tapetes')) {
        $excluded = ['pneus', 'motor', 'lavagem automotiva', 'polimento automotivo', 'pretinho', 'shampoo automotivo'];
    }

    $categories = array_values(array_unique(array_filter([
        $sub,
        $category !== '' ? blogAffiliateNormalize($category) : null,
        $sub === 'impermeabilizacao' ? 'impermeabilizacao' : null,
        $sub === 'impermeabilizacao' || $niche === 'limpeza de estofados' ? 'estofados' : null,
        $sub === 'impermeabilizacao' || $niche === 'limpeza de estofados' ? 'sofa' : null,
        $sub === 'impermeabilizacao' ? 'manchas' : null,
    ])));
    $serviceIds = array_values(array_unique(array_filter([
        $serviceId !== '' ? blogAffiliateNormalize($serviceId) : null,
        $sub,
        $sub === 'impermeabilizacao' ? 'impermeabilizacao' : null,
        $niche === 'limpeza de estofados' ? 'estofado' : null,
        $niche === 'limpeza de estofados' ? 'sofa' : null,
    ])));

    $searchTokens = array_keys($primary);
    foreach (array_keys($tokens) as $t) {
        if (count($searchTokens) >= 8) {
            break;
        }
        if (!in_array($t, $searchTokens, true)) {
            $searchTokens[] = $t;
        }
    }

    $postKey = trim($slug !== '' ? $slug : ($title !== '' ? $title : $keyword));

    return [
        'niche' => $niche,
        'subcategory' => $sub,
        'topic' => mb_substr($title !== '' ? $title : $keyword, 0, 180),
        'intent' => $intent,
        'keywords' => array_slice(array_keys($primary) ?: array_keys($tokens), 0, 12),
        'productTypes' => $productTypes,
        'excludedContexts' => $excluded,
        'location' => $location,
        'clusters' => $clusters,
        'categories' => $categories,
        'serviceIds' => $serviceIds,
        'searchTokens' => $searchTokens,
        'normHay' => $normHay,
        'postKey' => $postKey,
        'slug' => $slug,
        'postId' => isset($params['id']) ? (int)$params['id'] : (isset($params['postId']) ? (int)$params['postId'] : 0),
        'recordUsage' => !empty($params['recordUsage']),
        'forceReselect' => !empty($params['forceReselect']),
    ];
}

function blogAffiliateUrlIsValid(string $url): bool {
    $url = trim($url);
    if ($url === '' || mb_strlen($url) < 12) {
        return false;
    }
    if (!preg_match('#^https?://#i', $url)) {
        return false;
    }
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

/**
 * Score de um produto vs. contexto do post. Cidade NÃO pontua em afiliado.
 * @param array<string,mixed> $link
 * @param array<string,mixed> $ctx
 * @return array{score:int,reasons:list<string>,mismatch:bool}
 */
function blogAffiliateScoreLinkAgainstContext(array $link, array $ctx): array {
    $type = (string)($link['linkType'] ?? 'affiliate');
    if (in_array($type, ['local_service', 'booking'], true)) {
        return ['score' => 10000 + (int)($link['sortOrder'] ?? 0), 'reasons' => ['cta_local'], 'mismatch' => false];
    }

    $score = 0;
    $reasons = [];
    $mismatch = false;

    $prodHay = blogAffiliateNormalize(implode(' ', array_filter([
        (string)($link['title'] ?? ''),
        (string)($link['anchorText'] ?? ''),
        (string)($link['category'] ?? ''),
        (string)($link['serviceId'] ?? ''),
        (string)($link['keywords'] ?? ''),
        (string)($link['contextHint'] ?? ''),
    ])));
    $prodClusters = blogAffiliateClusterInText($prodHay);
    $postClusters = $ctx['clusters'] ?? [];
    $intent = (string)($ctx['intent'] ?? '');
    $sub = (string)($ctx['subcategory'] ?? '');
    $normHay = (string)($ctx['normHay'] ?? '');

    $cat = blogAffiliateNormalize((string)($link['category'] ?? ''));
    $svc = blogAffiliateNormalize((string)($link['serviceId'] ?? ''));

    if ($sub !== '' && $sub !== 'geral' && ($cat === $sub || $svc === $sub)) {
        $score += 40;
        $reasons[] = 'subnicho_exato';
    } elseif ($cat !== '' && $cat !== 'geral' && in_array($cat, $ctx['categories'] ?? [], true)) {
        $score += 25;
        $reasons[] = 'categoria_compativel';
    } elseif ($svc !== '' && in_array($svc, $ctx['serviceIds'] ?? [], true)) {
        $score += 25;
        $reasons[] = 'servico_compativel';
    }

    $postIsUpholstery = in_array('estofado', $postClusters, true)
        || in_array('impermeabilizacao', $postClusters, true)
        || in_array('colchao', $postClusters, true)
        || in_array('tapete', $postClusters, true)
        || in_array('cadeira', $postClusters, true)
        || in_array($sub, ['impermeabilizacao', 'estofados', 'sofa', 'colchao', 'tapetes', 'cadeiras'], true);
    $postIsAuto = in_array('automotivo', $postClusters, true) || $sub === 'automotivo';
    $prodIsAuto = in_array('automotivo', $prodClusters, true) || $cat === 'automotivo' || $svc === 'automotivo';
    $prodIsUpholstery = in_array('estofado', $prodClusters, true)
        || in_array('impermeabilizacao', $prodClusters, true)
        || in_array('colchao', $prodClusters, true)
        || in_array('tapete', $prodClusters, true)
        || in_array($cat, ['estofados', 'sofa', 'impermeabilizacao', 'colchao', 'tapetes', 'manchas'], true);

    if ($postIsUpholstery && $prodIsAuto && !$postIsAuto) {
        $score -= 80;
        $mismatch = true;
        $reasons[] = 'mismatch_automotivo';
    }
    if ($postIsAuto && $prodIsUpholstery && !$prodIsAuto) {
        $score -= 80;
        $mismatch = true;
        $reasons[] = 'mismatch_estofado_em_auto';
    }

    if (in_array('impermeabilizacao', $postClusters, true) || $sub === 'impermeabilizacao' || $intent === 'protecao') {
        if (in_array('impermeabilizacao', $prodClusters, true) || $cat === 'impermeabilizacao' || $svc === 'impermeabilizacao') {
            $score += 35;
            $reasons[] = 'tipo_impermeabilizante';
        }
        if (preg_match('/shampoo|extrator|aspirador automot/u', $prodHay) && !preg_match('/impermeabil|protetor/u', $prodHay)) {
            $score -= 25;
            $reasons[] = 'tipo_inadequado_para_protecao';
        }
    }

    if ($intent === 'limpeza' && preg_match('/limpador|higieniz|tira mancha|extrator|shampoo/u', $prodHay)) {
        $score += 18;
        $reasons[] = 'intencao_limpeza';
    }
    if ($intent === 'protecao' && preg_match('/impermeabil|protetor|protecao|hidratan/u', $prodHay)) {
        $score += 22;
        $reasons[] = 'intencao_protecao';
    }

    $kwHits = 0;
    foreach (($ctx['searchTokens'] ?? []) as $token) {
        $token = blogAffiliateNormalize((string)$token);
        if (mb_strlen($token) < 4) {
            continue;
        }
        if (mb_strpos($prodHay, $token) !== false) {
            $kwHits++;
            $score += ($kwHits <= 2 ? 15 : 8);
        }
    }
    if ($kwHits > 0) {
        $reasons[] = 'keywords_' . $kwHits;
    }

    foreach (($ctx['productTypes'] ?? []) as $pt) {
        $ptn = blogAffiliateNormalize((string)$pt);
        if ($ptn !== '' && mb_strpos($prodHay, $ptn) !== false) {
            $score += 25;
            $reasons[] = 'product_type';
            break;
        }
        $bits = preg_split('/\s+/u', $ptn) ?: [];
        $bitHits = 0;
        foreach ($bits as $b) {
            if (mb_strlen($b) >= 5 && mb_strpos($prodHay, $b) !== false) {
                $bitHits++;
            }
        }
        if ($bitHits >= 2) {
            $score += 16;
            $reasons[] = 'product_type_parcial';
            break;
        }
    }

    // sort_order NÃO é base do ranking (evita IDs baixos ganharem empate)
    $title = blogAffiliateNormalize((string)($link['title'] ?? ''));
    if ($title !== '' && $normHay !== '' && mb_strlen($title) >= 8 && mb_strpos($normHay, $title) !== false) {
        $score += 12;
        $reasons[] = 'titulo_no_post';
    }

    if (!blogAffiliateUrlIsValid((string)($link['url'] ?? ''))) {
        $score = -999;
        $mismatch = true;
        $reasons[] = 'INVALID_URL';
    }

    return ['score' => $score, 'reasons' => $reasons, 'mismatch' => $mismatch];
}

/** Wrapper compatível com a assinatura antiga (sem bônus de cidade em afiliado). */
function blogAffiliateLinkScore(array $link, array $params): int {
    $ctx = blogAffiliateBuildSemanticContext($params);
    return blogAffiliateScoreLinkAgainstContext($link, $ctx)['score'];
}

function ensureBlogAffiliateUsageTable(PDO $pdo): void {
    static $done = false;
    if ($done) {
        return;
    }
    $sqlFile = __DIR__ . '/migrations/2026-08-11-blog_affiliate_selection.sql';
    if (is_file($sqlFile) && function_exists('alpRunSqlMigration')) {
        alpRunSqlMigration($pdo, $sqlFile);
    } elseif (function_exists('cmsTableExists') && !cmsTableExists($pdo, 'blog_affiliate_link_usage')) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `blog_affiliate_link_usage` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `product_id` INT UNSIGNED NOT NULL,
            `post_id` INT UNSIGNED DEFAULT NULL,
            `post_slug` VARCHAR(200) DEFAULT NULL,
            `niche` VARCHAR(120) DEFAULT NULL,
            `subcategory` VARCHAR(120) DEFAULT NULL,
            `topic` VARCHAR(300) DEFAULT NULL,
            `intent` VARCHAR(80) DEFAULT NULL,
            `fallback_level` TINYINT UNSIGNED NOT NULL DEFAULT 1,
            `reason` VARCHAR(240) DEFAULT NULL,
            `used_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_blog_aff_usage_slug_product` (`post_slug`, `product_id`),
            INDEX `idx_blog_aff_usage_product_used` (`product_id`, `used_at`),
            INDEX `idx_blog_aff_usage_used` (`used_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    foreach ([
        "ALTER TABLE `blog_affiliate_links` ADD COLUMN `use_count` INT UNSIGNED NOT NULL DEFAULT 0",
        "ALTER TABLE `blog_affiliate_links` ADD COLUMN `last_used_at` DATETIME DEFAULT NULL",
        "ALTER TABLE `blog_affiliate_links` ADD INDEX `idx_blog_aff_select_cat` (`active`, `link_type`, `category`)",
        "ALTER TABLE `blog_affiliate_links` ADD INDEX `idx_blog_aff_select_svc` (`active`, `link_type`, `service_id`)",
        "ALTER TABLE `blog_affiliate_links` ADD INDEX `idx_blog_aff_use` (`active`, `link_type`, `use_count`, `last_used_at`)",
    ] as $sql) {
        try {
            $pdo->exec($sql);
        } catch (Throwable $e) { /* exists */ }
    }
    $done = true;
}

/**
 * @return array<int, array{count:int,last:string|null}>
 */
function blogAffiliateLoadUsageMap(PDO $pdo, array $productIds, int $cooldownDays): array {
    $map = [];
    if (!$productIds) {
        return $map;
    }
    $ids = array_values(array_unique(array_map('intval', $productIds)));
    $ph = implode(',', array_fill(0, count($ids), '?'));
    try {
        $stmt = $pdo->prepare(
            "SELECT id, use_count, last_used_at FROM blog_affiliate_links WHERE id IN ($ph)"
        );
        $stmt->execute($ids);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) {
            $map[(int)$r['id']] = [
                'count' => (int)($r['use_count'] ?? 0),
                'last' => $r['last_used_at'] ?? null,
            ];
        }
    } catch (Throwable $e) {
        foreach ($ids as $id) {
            $map[$id] = ['count' => 0, 'last' => null];
        }
    }
    return $map;
}

/**
 * IDs usados nos últimos N registros (cooldown por posts).
 * @return list<int>
 */
function blogAffiliateRecentProductIds(PDO $pdo, int $limit): array {
    $limit = max(1, min(200, $limit));
    try {
        if (!function_exists('cmsTableExists') || !cmsTableExists($pdo, 'blog_affiliate_link_usage')) {
            return [];
        }
        $stmt = $pdo->query(
            "SELECT product_id FROM blog_affiliate_link_usage ORDER BY used_at DESC, id DESC LIMIT {$limit}"
        );
        $ids = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) {
            $ids[] = (int)$r['product_id'];
        }
        return array_values(array_unique($ids));
    } catch (Throwable $e) {
        return [];
    }
}

function blogAffiliateExistingPickForSlug(PDO $pdo, string $slug): ?int {
    $slug = trim($slug);
    if ($slug === '') {
        return null;
    }
    try {
        $stmt = $pdo->prepare(
            'SELECT product_id FROM blog_affiliate_link_usage WHERE post_slug = ? ORDER BY used_at DESC, id DESC LIMIT 1'
        );
        $stmt->execute([$slug]);
        $id = $stmt->fetchColumn();
        return $id ? (int)$id : null;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * Busca candidatos no banco (não carrega 10k). Prepared statements.
 * @return array{locals:list<array>,affiliates:list<array>,fallbackLevel:int}
 */
function blogAffiliateLinksFetchCandidates(PDO $pdo, array $ctx, int $limit): array {
    $limit = max(30, min(500, $limit));
    $locals = [];
    try {
        $stmt = $pdo->query(
            "SELECT * FROM blog_affiliate_links
             WHERE active = 1 AND link_type IN ('local_service','booking')
               AND url IS NOT NULL AND CHAR_LENGTH(url) > 8
             ORDER BY sort_order ASC, id ASC"
        );
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) {
            $locals[] = decodeBlogAffiliateLink($r);
        }
    } catch (Throwable $e) {
        $locals = [];
    }

    $hasUseCols = true;
    $order = 'use_count ASC, (last_used_at IS NULL) DESC, last_used_at ASC, id ASC';
    try {
        $pdo->query('SELECT use_count, last_used_at FROM blog_affiliate_links LIMIT 0');
    } catch (Throwable $e) {
        $hasUseCols = false;
        $order = 'id ASC';
    }

    $base = "active = 1 AND link_type = 'affiliate' AND url IS NOT NULL AND CHAR_LENGTH(url) > 12";
    $attempts = [];

    $cats = array_values(array_filter($ctx['categories'] ?? []));
    $svcs = array_values(array_filter($ctx['serviceIds'] ?? []));
    $tokens = array_slice(array_values(array_filter($ctx['searchTokens'] ?? [])), 0, 6);

    $buildIn = static function (array $vals): array {
        $clean = [];
        foreach ($vals as $v) {
            $v = trim((string)$v);
            if ($v !== '' && mb_strlen($v) <= 100) {
                $clean[] = $v;
            }
        }
        return array_values(array_unique($clean));
    };
    $cats = $buildIn($cats);
    $svcs = $buildIn($svcs);

    // Nível 1 — subnicho/categoria + tokens
    $attempts[] = ['level' => 1, 'cats' => $cats, 'svcs' => $svcs, 'tokens' => $tokens, 'requireToken' => $tokens !== []];
    // Nível 2 — categoria/serviço sem exigir token
    $attempts[] = ['level' => 2, 'cats' => $cats, 'svcs' => $svcs, 'tokens' => [], 'requireToken' => false];
    // Nível 3 — só tokens comerciais (sem geo)
    $attempts[] = ['level' => 3, 'cats' => [], 'svcs' => [], 'tokens' => $tokens, 'requireToken' => $tokens !== []];

    $affiliates = [];
    $fallbackLevel = 4;
    foreach ($attempts as $att) {
        $ors = [];
        $params = [];
        if ($att['cats']) {
            $ph = implode(',', array_fill(0, count($att['cats']), '?'));
            $ors[] = "category IN ($ph)";
            $params = array_merge($params, $att['cats']);
        }
        if ($att['svcs']) {
            $ph = implode(',', array_fill(0, count($att['svcs']), '?'));
            $ors[] = "service_id IN ($ph)";
            $params = array_merge($params, $att['svcs']);
        }
        foreach ($att['tokens'] as $t) {
            $t = str_replace(['%', '_'], '', (string)$t);
            if (mb_strlen($t) < 4) {
                continue;
            }
            $ors[] = '(title LIKE ? OR keywords LIKE ? OR context_hint LIKE ? OR category LIKE ? OR service_id LIKE ?)';
            $like = '%' . $t . '%';
            array_push($params, $like, $like, $like, $like, $like);
        }
        if (!$ors) {
            continue;
        }
        $sql = "SELECT * FROM blog_affiliate_links WHERE {$base} AND (" . implode(' OR ', $ors) . ") ORDER BY {$order} LIMIT {$limit}";
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            if (function_exists('appLog')) {
                appLog('warn', 'affiliate_candidate_query_failed', ['err' => $e->getMessage(), 'level' => $att['level']]);
            }
            continue;
        }
        $got = [];
        foreach ($rows as $r) {
            $link = decodeBlogAffiliateLink($r);
            if (!empty($r['use_count'])) {
                $link['useCount'] = (int)$r['use_count'];
            }
            if (!empty($r['last_used_at'])) {
                $link['lastUsedAt'] = $r['last_used_at'];
            }
            if (!blogAffiliateUrlIsValid((string)($link['url'] ?? ''))) {
                continue;
            }
            $got[] = $link;
        }
        if ($got) {
            $affiliates = $got;
            $fallbackLevel = (int)$att['level'];
            break;
        }
    }

    if (!$affiliates) {
        if (function_exists('appLog')) {
            appLog('info', 'affiliate_selection', ['code' => 'NO_CANDIDATES', 'topic' => $ctx['topic'] ?? '']);
        }
    }

    return ['locals' => $locals, 'affiliates' => $affiliates, 'fallbackLevel' => $fallbackLevel, 'hasUseCols' => $hasUseCols];
}

/**
 * Escolhe do TOP-K por relevância + menor uso + recência. Sem RAND().
 * @param list<array{link:array,score:int,reasons:list<string>,mismatch:bool}> $scored
 * @return array{picked:list<array>,log:array}
 */
function blogAffiliateChooseFromRanked(
    array $scored,
    array $ctx,
    int $maxAffiliate,
    array $recentIds,
    int $cooldownDays,
    int $minScore
): array {
    $maxAffiliate = max(1, min(12, $maxAffiliate));
    $topK = blogAffiliateCfgInt('AFFILIATE_PRODUCT_TOP_K', 8);
    $now = time();
    $cooldownSec = max(1, $cooldownDays) * 86400;

    $eligible = [];
    $removedCooldown = [];
    $removedMismatch = 0;
    foreach ($scored as $row) {
        if (!empty($row['mismatch']) || (int)$row['score'] < $minScore) {
            $removedMismatch++;
            continue;
        }
        $eligible[] = $row;
    }
    usort($eligible, static function (array $a, array $b): int {
        return (int)$b['score'] <=> (int)$a['score'];
    });

    $log = [
        'code' => null,
        'candidates' => count($scored),
        'removedMismatchOrLow' => $removedMismatch,
        'cooldownRemoved' => 0,
        'eligible' => 0,
        'top' => [],
        'selected' => null,
        'reason' => '',
        'fallbackLevel' => (int)($ctx['_fallbackLevel'] ?? 1),
    ];

    if (!$eligible) {
        $log['code'] = 'NO_CANDIDATES';
        $log['reason'] = 'nenhum produto acima do score mínimo / sem mismatch';
        return ['picked' => [], 'log' => $log];
    }

    $best = (int)$eligible[0]['score'];
    $bandFloor = max($minScore, $best - 12);
    $band = [];
    foreach ($eligible as $row) {
        if ((int)$row['score'] >= $bandFloor && count($band) < max($topK, $maxAffiliate + 2)) {
            $band[] = $row;
        }
        if (count($band) >= max($topK, 10)) {
            break;
        }
    }
    if (count($band) < 3) {
        $band = array_slice($eligible, 0, min($topK, count($eligible)));
    }

    $fresh = [];
    foreach ($band as $row) {
        $id = (int)($row['link']['id'] ?? 0);
        $last = $row['link']['lastUsedAt'] ?? null;
        $inRecentPosts = $id > 0 && in_array($id, $recentIds, true);
        $inRecentDays = false;
        if (is_string($last) && $last !== '') {
            $ts = strtotime($last);
            if ($ts && ($now - $ts) < $cooldownSec) {
                $inRecentDays = true;
            }
        }
        if ($inRecentPosts || $inRecentDays) {
            $removedCooldown[] = $id;
            continue;
        }
        $fresh[] = $row;
    }
    $log['cooldownRemoved'] = count($removedCooldown);
    $pool = $fresh ?: $band;
    if (!$fresh && $band) {
        $log['code'] = 'ALL_IN_COOLDOWN';
    }
    $log['eligible'] = count($pool);

    $postKey = (string)($ctx['postKey'] ?? '');
    $seed = (int)sprintf('%u', crc32($postKey !== '' ? $postKey : 'alp'));
    usort($pool, static function (array $a, array $b) use ($seed): int {
        $ua = (int)($a['link']['useCount'] ?? 0);
        $ub = (int)($b['link']['useCount'] ?? 0);
        if ($ua !== $ub) {
            return $ua <=> $ub;
        }
        $la = (string)($a['link']['lastUsedAt'] ?? '');
        $lb = (string)($b['link']['lastUsedAt'] ?? '');
        if ($la === '' && $lb !== '') {
            return -1;
        }
        if ($lb === '' && $la !== '') {
            return 1;
        }
        if ($la !== $lb) {
            return strcmp($la, $lb);
        }
        $ia = (int)($a['link']['id'] ?? 0);
        $ib = (int)($b['link']['id'] ?? 0);
        return ($seed ^ $ia) <=> ($seed ^ $ib);
    });

    $log['top'] = array_map(static function (array $row): array {
        return [
            'id' => (int)($row['link']['id'] ?? 0),
            'title' => (string)($row['link']['title'] ?? ''),
            'score' => (int)$row['score'],
            'useCount' => (int)($row['link']['useCount'] ?? 0),
        ];
    }, array_slice($pool, 0, 5));

    $picked = [];
    $seenUrl = [];
    $seenCat = [];
    foreach ($pool as $row) {
        if (count($picked) >= $maxAffiliate) {
            break;
        }
        $url = (string)($row['link']['url'] ?? '');
        if ($url === '' || isset($seenUrl[$url])) {
            continue;
        }
        $cat = blogAffiliateNormalize((string)($row['link']['category'] ?? ''));
        // Diversidade: a partir do 2º, prefere outra categoria se houver opção
        if (count($picked) >= 1 && $cat !== '' && isset($seenCat[$cat]) && count($pool) > count($picked) + 1) {
            continue;
        }
        $link = $row['link'];
        $link['_score'] = (int)$row['score'];
        $link['_reasons'] = $row['reasons'];
        $picked[] = $link;
        $seenUrl[$url] = true;
        if ($cat !== '') {
            $seenCat[$cat] = true;
        }
    }
    // Completa se diversidade pulou demais
    if (count($picked) < min($maxAffiliate, count($pool))) {
        foreach ($pool as $row) {
            if (count($picked) >= $maxAffiliate) {
                break;
            }
            $url = (string)($row['link']['url'] ?? '');
            if ($url === '' || isset($seenUrl[$url])) {
                continue;
            }
            $link = $row['link'];
            $link['_score'] = (int)$row['score'];
            $link['_reasons'] = $row['reasons'];
            $picked[] = $link;
            $seenUrl[$url] = true;
        }
    }

    if ($picked) {
        $first = $picked[0];
        $log['selected'] = [
            'id' => (int)($first['id'] ?? 0),
            'title' => (string)($first['title'] ?? ''),
            'score' => (int)($first['_score'] ?? 0),
        ];
        $log['reason'] = 'alta relevância + menor frequência de uso'
            . (!empty($first['_reasons']) ? ' (' . implode(',', array_slice($first['_reasons'], 0, 4)) . ')' : '');
        if ($log['code'] === null) {
            $log['code'] = 'OK';
        }
    } else {
        $log['code'] = 'NO_CANDIDATES';
        $log['reason'] = 'pool vazio após filtros';
    }

    return ['picked' => $picked, 'log' => $log];
}

function blogAffiliateLogSelection(array $ctx, array $log): void {
    if (!function_exists('appLog')) {
        return;
    }
    appLog('info', 'affiliate_selection', [
        'post' => $ctx['slug'] ?: ($ctx['topic'] ?? ''),
        'niche' => $ctx['niche'] ?? '',
        'subcategory' => $ctx['subcategory'] ?? '',
        'intent' => $ctx['intent'] ?? '',
        'location' => $ctx['location'] ?? '',
        'code' => $log['code'] ?? '',
        'candidates' => $log['candidates'] ?? 0,
        'cooldownRemoved' => $log['cooldownRemoved'] ?? 0,
        'eligible' => $log['eligible'] ?? 0,
        'top' => $log['top'] ?? [],
        'selected' => $log['selected'] ?? null,
        'reason' => $log['reason'] ?? '',
        'fallbackLevel' => $log['fallbackLevel'] ?? 1,
        'fallback' => (($log['fallbackLevel'] ?? 1) >= 3) || (($log['code'] ?? '') !== 'OK'),
    ]);
}

function blogAffiliateLinksRecordUsage(PDO $pdo, array $product, array $ctx, array $log): void {
    $id = (int)($product['id'] ?? 0);
    $slug = trim((string)($ctx['slug'] ?? ''));
    if ($id <= 0 || $slug === '') {
        return;
    }
    $now = function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s');
    $postId = (int)($ctx['postId'] ?? 0);
    try {
        $pdo->beginTransaction();
        $ins = $pdo->prepare(
            'INSERT INTO blog_affiliate_link_usage
                (product_id, post_id, post_slug, niche, subcategory, topic, intent, fallback_level, reason, used_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $ins->execute([
            $id,
            $postId > 0 ? $postId : null,
            $slug,
            mb_substr((string)($ctx['niche'] ?? ''), 0, 120),
            mb_substr((string)($ctx['subcategory'] ?? ''), 0, 120),
            mb_substr((string)($ctx['topic'] ?? ''), 0, 300),
            mb_substr((string)($ctx['intent'] ?? ''), 0, 80),
            (int)($log['fallbackLevel'] ?? 1),
            mb_substr((string)($log['reason'] ?? ''), 0, 240),
            $now,
        ]);
        $pdo->prepare(
            'UPDATE blog_affiliate_links SET use_count = COALESCE(use_count,0) + 1, last_used_at = ?, updated_at = ? WHERE id = ?'
        )->execute([$now, $now, $id]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $sqlState = (string)($e->errorInfo[0] ?? '');
        $drv = (int)($e->errorInfo[1] ?? 0);
        $isDup = $sqlState === '23000' || $drv === 1062 || stripos($e->getMessage(), 'Duplicate') !== false;
        if ($isDup) {
            return;
        }
        if (function_exists('appLog')) {
            appLog('warn', 'affiliate_selection', ['code' => 'SELECTION_ERROR', 'err' => $e->getMessage()]);
        }
    }
}

/**
 * Seleciona links para o post (CTA local + afiliados relevantes com rotação).
 * @return list<array>
 */
function blogAffiliateLinksPickForPost(PDO $pdo, array $params, int $maxAffiliate = 4): array {
    if (function_exists('ensureBlogAffiliateLinksTable')) {
        ensureBlogAffiliateLinksTable($pdo);
    }
    ensureBlogAffiliateUsageTable($pdo);

    $ctx = blogAffiliateBuildSemanticContext($params);
    $candidateLimit = blogAffiliateCfgInt('AFFILIATE_PRODUCT_CANDIDATE_LIMIT', 250);
    $minScore = blogAffiliateCfgInt('AFFILIATE_PRODUCT_MIN_SCORE', 28);
    $cooldownPosts = blogAffiliateCfgInt('AFFILIATE_PRODUCT_COOLDOWN_POSTS', 20);
    $cooldownDays = blogAffiliateCfgInt('AFFILIATE_PRODUCT_COOLDOWN_DAYS', 30);

    $bundle = blogAffiliateLinksFetchCandidates($pdo, $ctx, $candidateLimit);
    $ctx['_fallbackLevel'] = $bundle['fallbackLevel'];
    $locals = $bundle['locals'];
    $affiliates = $bundle['affiliates'];

    $slug = (string)($ctx['slug'] ?? '');
    $reuseId = null;
    if ($slug !== '' && empty($ctx['forceReselect'])) {
        $reuseId = blogAffiliateExistingPickForSlug($pdo, $slug);
    }

    $ids = [];
    foreach ($affiliates as $a) {
        $ids[] = (int)($a['id'] ?? 0);
    }
    $usage = blogAffiliateLoadUsageMap($pdo, $ids, $cooldownDays);
    foreach ($affiliates as &$a) {
        $id = (int)($a['id'] ?? 0);
        if (isset($usage[$id])) {
            $a['useCount'] = $usage[$id]['count'];
            $a['lastUsedAt'] = $usage[$id]['last'];
        } else {
            $a['useCount'] = (int)($a['useCount'] ?? 0);
            $a['lastUsedAt'] = $a['lastUsedAt'] ?? null;
        }
    }
    unset($a);

    $scored = [];
    foreach ($affiliates as $link) {
        $sr = blogAffiliateScoreLinkAgainstContext($link, $ctx);
        $link['_score'] = $sr['score'];
        $scored[] = [
            'link' => $link,
            'score' => $sr['score'],
            'reasons' => $sr['reasons'],
            'mismatch' => $sr['mismatch'],
        ];
    }

    $recentIds = blogAffiliateRecentProductIds($pdo, $cooldownPosts);
    $choice = blogAffiliateChooseFromRanked($scored, $ctx, $maxAffiliate, $recentIds, $cooldownDays, $minScore);
    $pickedAff = $choice['picked'];
    $log = $choice['log'];
    $log['fallbackLevel'] = (int)$bundle['fallbackLevel'];
    if ((int)$bundle['fallbackLevel'] >= 3 && ($log['code'] ?? '') === 'OK') {
        $log['code'] = 'FALLBACK_USED';
    }

    if ($reuseId) {
        $found = null;
        foreach ($scored as $row) {
            if ((int)($row['link']['id'] ?? 0) === $reuseId) {
                $found = $row['link'];
                $found['_score'] = $row['score'];
                $found['_reasons'] = $row['reasons'];
                break;
            }
        }
        if ($found && blogAffiliateUrlIsValid((string)($found['url'] ?? ''))) {
            $pickedAff = array_values(array_filter($pickedAff, static fn($l) => (int)($l['id'] ?? 0) !== $reuseId));
            array_unshift($pickedAff, $found);
            $pickedAff = array_slice($pickedAff, 0, $maxAffiliate);
            $log['reason'] = 'idempotente: produto já registrado neste post';
            $log['selected'] = ['id' => $reuseId, 'title' => (string)($found['title'] ?? ''), 'score' => (int)($found['_score'] ?? 0)];
            $log['code'] = 'OK';
        }
    }

    blogAffiliateLogSelection($ctx, $log);
    $GLOBALS['ALP_LAST_AFFILIATE_SELECTION'] = ['ctx' => $ctx, 'log' => $log];

    if ($pickedAff && !empty($ctx['recordUsage']) && empty($reuseId)) {
        blogAffiliateLinksRecordUsage($pdo, $pickedAff[0], $ctx, $log);
    }

    return array_merge($locals, $pickedAff);
}

/**
 * Métricas de catálogo + uso (admin).
 * @return array<string,mixed>
 */
function blogAffiliateSelectionStats(PDO $pdo): array {
    ensureBlogAffiliateUsageTable($pdo);
    $q = static function (PDO $pdo, string $sql) {
        try {
            return $pdo->query($sql)->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            return [];
        }
    };
    $totals = $q($pdo, "SELECT
        COUNT(*) AS total,
        SUM(active = 1) AS active,
        SUM(active = 1 AND link_type = 'affiliate') AS affiliates,
        SUM(active = 1 AND link_type = 'affiliate' AND (url IS NULL OR url = '')) AS no_url,
        SUM(active = 1 AND link_type = 'affiliate' AND (category IS NULL OR category = '' OR category = 'geral')) AS weak_category,
        SUM(active = 1 AND link_type = 'affiliate' AND (keywords IS NULL OR keywords = '')) AS no_keywords,
        SUM(active = 1 AND link_type = 'affiliate' AND COALESCE(use_count,0) = 0) AS never_used
        FROM blog_affiliate_links");
    $byCat = [];
    try {
        $stmt = $pdo->query(
            "SELECT COALESCE(NULLIF(category,''),'sem_categoria') AS category, COUNT(*) AS n
             FROM blog_affiliate_links WHERE active = 1 AND link_type = 'affiliate'
             GROUP BY category ORDER BY n DESC LIMIT 20"
        );
        $byCat = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $byCat = [];
    }
    $most = [];
    $least = [];
    try {
        $most = $pdo->query(
            "SELECT id, title, use_count, last_used_at FROM blog_affiliate_links
             WHERE active = 1 AND link_type = 'affiliate' AND COALESCE(use_count,0) > 0
             ORDER BY use_count DESC, last_used_at DESC LIMIT 10"
        )->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $least = $pdo->query(
            "SELECT id, title, use_count, last_used_at FROM blog_affiliate_links
             WHERE active = 1 AND link_type = 'affiliate'
             ORDER BY COALESCE(use_count,0) ASC, (last_used_at IS NULL) DESC, id ASC LIMIT 10"
        )->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $most = [];
        $least = [];
    }
    $recent = [];
    try {
        if (function_exists('cmsTableExists') && cmsTableExists($pdo, 'blog_affiliate_link_usage')) {
            $recent = $pdo->query(
                "SELECT u.product_id, l.title, u.post_slug, u.niche, u.subcategory, u.used_at
                 FROM blog_affiliate_link_usage u
                 LEFT JOIN blog_affiliate_links l ON l.id = u.product_id
                 ORDER BY u.used_at DESC LIMIT 15"
            )->fetchAll(PDO::FETCH_ASSOC) ?: [];
        }
    } catch (Throwable $e) {
        $recent = [];
    }

    return [
        'totals' => $totals,
        'byCategory' => $byCat,
        'mostUsed' => $most,
        'leastUsed' => $least,
        'recentUsage' => $recent,
        'config' => [
            'cooldownPosts' => blogAffiliateCfgInt('AFFILIATE_PRODUCT_COOLDOWN_POSTS', 20),
            'cooldownDays' => blogAffiliateCfgInt('AFFILIATE_PRODUCT_COOLDOWN_DAYS', 30),
            'topK' => blogAffiliateCfgInt('AFFILIATE_PRODUCT_TOP_K', 8),
            'candidateLimit' => blogAffiliateCfgInt('AFFILIATE_PRODUCT_CANDIDATE_LIMIT', 250),
            'minScore' => blogAffiliateCfgInt('AFFILIATE_PRODUCT_MIN_SCORE', 28),
        ],
    ];
}
