<?php
/**
 * Agendador de tarefas — configure no cPanel:
 * wget -q -O - "https://SEU-DOMINIO/cron.php?key=SUA_CRON_SECRET"
 * Recomendado: a cada 15 minutos.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/site.php';
require_once __DIR__ . '/lang.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/logs-service.php';
require_once __DIR__ . '/mail-handlers.php';
require_once __DIR__ . '/web-push-service.php';
require_once __DIR__ . '/notification-center.php';
require_once __DIR__ . '/notification-handlers.php';
require_once __DIR__ . '/notification-center-handlers.php';
require_once __DIR__ . '/notification-engine-handlers.php';
require_once __DIR__ . '/telegram-service.php';
require_once __DIR__ . '/slack-service.php';
require_once __DIR__ . '/communication/hub.php';
require_once __DIR__ . '/communication/event-bus.php';
require_once __DIR__ . '/communication/providers.php';
require_once __DIR__ . '/communication/queue-adapter.php';
require_once __DIR__ . '/communication/segments.php';
require_once __DIR__ . '/communication/hub-handlers.php';
require_once __DIR__ . '/financial-handlers.php';
require_once __DIR__ . '/crm-handlers.php';
require_once __DIR__ . '/automation-handlers.php';
require_once __DIR__ . '/weather-service.php';
require_once __DIR__ . '/cron-jobs.php';
require_once __DIR__ . '/job-queue.php';
require_once __DIR__ . '/prospeccao-service.php';
require_once __DIR__ . '/modules/prospeccao-engine/bootstrap.php';
// Centro de Conteúdo IA — necessário para processAiContentJobs() no cron
require_once __DIR__ . '/cms-handlers.php';
require_once __DIR__ . '/cms-blog-handlers.php';
require_once __DIR__ . '/ai-handlers.php';
require_once __DIR__ . '/ai-gateway.php';
require_once __DIR__ . '/ai-image-gateway.php';
require_once __DIR__ . '/blog-post-helpers.php';
require_once __DIR__ . '/content-studio-handlers.php';
require_once __DIR__ . '/gemini-service.php';

if (function_exists('alpEnsureSchema')) {
    alpEnsureSchema();
}

header('Content-Type: application/json; charset=utf-8');

// Aceita header X-Cron-Key (preferido — não vaza em access logs).
// ?key= ainda aceito por compatibilidade com wget do cPanel, mas gera warning.
$key = trim((string)($_SERVER['HTTP_X_CRON_KEY'] ?? ''));
$keyFromQuery = false;
if ($key === '') {
    $key = (string)($_GET['key'] ?? '');
    $keyFromQuery = $key !== '';
}
if (!defined('CRON_SECRET') || CRON_SECRET === '' || strpos((string)CRON_SECRET, 'SUBSTITUA') === 0) {
    http_response_code(403);
    echo json_encode(['error' => 'CRON_SECRET não configurado']);
    exit;
}
if ($key === '' || !hash_equals((string)CRON_SECRET, $key)) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}
if ($keyFromQuery && function_exists('appLog')) {
    appLog('warning', 'cron_key_via_query', ['hint' => 'Use header X-Cron-Key']);
}

echo json_encode(runCronJobs(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
