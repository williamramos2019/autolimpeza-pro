-- Origem de eventos de conversão (WhatsApp, lead, etc.)
ALTER TABLE conversion_events ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal';
