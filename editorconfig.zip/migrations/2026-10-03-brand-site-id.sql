-- Multi-site: origem principal | telhados
ALTER TABLE leads ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal';
ALTER TABLE appointments ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal';
ALTER TABLE blog_posts ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal';
