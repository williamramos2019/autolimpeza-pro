-- CMS Extra Modules v1 — Menus, Downloads, Forms, Newsletter, Popups, Redirects, Backups, Widgets
-- Idempotente (CREATE IF NOT EXISTS)

CREATE TABLE IF NOT EXISTS `cms_menus` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(200) NOT NULL,
  `slug`       VARCHAR(120) NOT NULL,
  `location`   VARCHAR(40)  NOT NULL DEFAULT 'header',
  `items_json` JSON         DEFAULT NULL,
  `active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` DATETIME     NOT NULL,
  `updated_at` DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cms_menu_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cms_downloads` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`       VARCHAR(300) NOT NULL,
  `slug`        VARCHAR(160) NOT NULL,
  `file_url`    VARCHAR(600) NOT NULL,
  `file_name`   VARCHAR(255) DEFAULT NULL,
  `mime`        VARCHAR(120) DEFAULT NULL,
  `size_bytes`  INT UNSIGNED DEFAULT 0,
  `category`    VARCHAR(120) DEFAULT NULL,
  `description` TEXT         DEFAULT NULL,
  `downloads`   INT UNSIGNED NOT NULL DEFAULT 0,
  `active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`  DATETIME     NOT NULL,
  `updated_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cms_dl_slug` (`slug`),
  KEY `idx_cms_dl_active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cms_forms` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`             VARCHAR(200) NOT NULL,
  `slug`             VARCHAR(120) NOT NULL,
  `fields_json`      JSON         DEFAULT NULL,
  `notify_email`     VARCHAR(255) DEFAULT NULL,
  `success_message`  VARCHAR(500) DEFAULT 'Enviado com sucesso.',
  `active`           TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`       DATETIME     NOT NULL,
  `updated_at`       DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cms_form_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cms_form_submissions` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `form_id`    INT UNSIGNED NOT NULL,
  `payload`    JSON         NOT NULL,
  `ip`         VARCHAR(64)  DEFAULT NULL,
  `created_at` DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cms_form_sub_form` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cms_newsletter_subscribers` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email`      VARCHAR(255) NOT NULL,
  `name`       VARCHAR(200) DEFAULT NULL,
  `status`     VARCHAR(20)  NOT NULL DEFAULT 'active',
  `source`     VARCHAR(80)  DEFAULT 'site',
  `created_at` DATETIME     NOT NULL,
  `updated_at` DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cms_nl_email` (`email`),
  KEY `idx_cms_nl_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cms_popups` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`         VARCHAR(200) NOT NULL,
  `slug`         VARCHAR(120) NOT NULL,
  `title`        VARCHAR(300) DEFAULT NULL,
  `content_html` LONGTEXT     DEFAULT NULL,
  `cta_label`    VARCHAR(120) DEFAULT NULL,
  `cta_url`      VARCHAR(500) DEFAULT NULL,
  `trigger_type` VARCHAR(40)  NOT NULL DEFAULT 'delay',
  `delay_sec`    INT UNSIGNED NOT NULL DEFAULT 3,
  `pages_json`   JSON         DEFAULT NULL,
  `active`       TINYINT(1)   NOT NULL DEFAULT 1,
  `starts_at`    DATETIME     DEFAULT NULL,
  `ends_at`      DATETIME     DEFAULT NULL,
  `created_at`   DATETIME     NOT NULL,
  `updated_at`   DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cms_popup_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cms_redirects` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `from_path`   VARCHAR(500) NOT NULL,
  `to_url`      VARCHAR(800) NOT NULL,
  `status_code` SMALLINT     NOT NULL DEFAULT 301,
  `hits`        INT UNSIGNED NOT NULL DEFAULT 0,
  `active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `notes`       VARCHAR(500) DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL,
  `updated_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cms_redir_from` (`from_path`(191)),
  KEY `idx_cms_redir_active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cms_backups` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `filename`    VARCHAR(255) NOT NULL,
  `file_path`   VARCHAR(600) NOT NULL,
  `size_bytes`  INT UNSIGNED DEFAULT 0,
  `type`        VARCHAR(40)  NOT NULL DEFAULT 'manual',
  `status`      VARCHAR(40)  NOT NULL DEFAULT 'ready',
  `notes`       VARCHAR(500) DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cms_backup_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cms_widgets` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(200) NOT NULL,
  `slug`        VARCHAR(120) NOT NULL,
  `type`        VARCHAR(60)  NOT NULL DEFAULT 'html',
  `config_json` JSON         DEFAULT NULL,
  `html`        LONGTEXT     DEFAULT NULL,
  `active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order`  INT          NOT NULL DEFAULT 0,
  `created_at`  DATETIME     NOT NULL,
  `updated_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cms_widget_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
