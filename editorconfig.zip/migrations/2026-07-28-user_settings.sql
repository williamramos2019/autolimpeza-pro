-- Migração: perfil/admin settings por usuário
-- Data: 2026-07-28
-- Sem FK rígida (compatível com installs legados / engines mistos)

CREATE TABLE IF NOT EXISTS `user_settings` (
  `user_id`       INT UNSIGNED NOT NULL,
  `profile_json`  JSON NULL,
  `company_json`  JSON NULL,
  `employees_json` JSON NULL,
  `notifications_json` JSON NULL,
  `security_json` JSON NULL,
  `primary_color` VARCHAR(32) DEFAULT '#0EA5FF',
  `meta_json`     JSON NULL,
  `updated_at`    DATETIME NOT NULL,
  `created_at`    DATETIME NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
