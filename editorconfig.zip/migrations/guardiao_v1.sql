-- Capitão Guardião — observações, diagnósticos e base de conhecimento (admin only)

CREATE TABLE IF NOT EXISTS `guardiao_observations` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `snapshot_json` JSON            NOT NULL,
  `created_at`    DATETIME        NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_guardiao_obs_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `guardiao_diagnostics` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `scope`         VARCHAR(40)     NOT NULL,
  `query`         TEXT            DEFAULT NULL,
  `report_json`   JSON            NOT NULL,
  `confidence`    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `evidence_json` JSON            DEFAULT NULL,
  `admin_email`   VARCHAR(200)    DEFAULT NULL,
  `created_at`    DATETIME        NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_guardiao_diag_scope` (`scope`),
  KEY `idx_guardiao_diag_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `guardiao_knowledge` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `problem_key` VARCHAR(120) NOT NULL,
  `problem`     TEXT         NOT NULL,
  `resolution`  TEXT         NOT NULL,
  `module`      VARCHAR(40)  DEFAULT NULL,
  `impact`      VARCHAR(20)  DEFAULT 'medium',
  `created_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_guardiao_knowledge_key` (`problem_key`),
  KEY `idx_guardiao_knowledge_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
