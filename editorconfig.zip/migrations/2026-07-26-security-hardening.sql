-- v1.23.0 — Security hardening (2026-07-26)
-- Execute via install/repair ou mysql CLI. Erros "Duplicate column/key" são seguros (já aplicado).

-- 1) Session token hashing
ALTER TABLE `admin_sessions` ADD COLUMN `token_hash` CHAR(64) NULL AFTER `token`;
ALTER TABLE `admin_sessions` ADD COLUMN `token_prefix` CHAR(8) NULL AFTER `token_hash`;
ALTER TABLE `admin_sessions` ADD INDEX `idx_admin_sess_hash` (`token_hash`);

ALTER TABLE `client_sessions` ADD COLUMN `token_hash` CHAR(64) NULL AFTER `token`;
ALTER TABLE `client_sessions` ADD COLUMN `token_prefix` CHAR(8) NULL AFTER `token_hash`;
ALTER TABLE `client_sessions` ADD INDEX `idx_client_sess_hash` (`token_hash`);

ALTER TABLE `technician_sessions` ADD COLUMN `token_hash` CHAR(64) NULL AFTER `token`;
ALTER TABLE `technician_sessions` ADD COLUMN `token_prefix` CHAR(8) NULL AFTER `token_hash`;
ALTER TABLE `technician_sessions` ADD INDEX `idx_tech_sess_hash` (`token_hash`);

-- Invalida sessões plaintext (obriga re-login)
DELETE FROM `admin_sessions` WHERE `token_hash` IS NULL OR `token_hash` = '';
DELETE FROM `client_sessions` WHERE `token_hash` IS NULL OR `token_hash` = '';
DELETE FROM `technician_sessions` WHERE `token_hash` IS NULL OR `token_hash` = '';

-- 2) Índices portal client_id
ALTER TABLE `loyalty_pieces` ADD INDEX `idx_loyalty_client` (`client_id`);
ALTER TABLE `warranty_tickets` ADD INDEX `idx_warranty_client` (`client_id`);
ALTER TABLE `hygiene_passports` ADD INDEX `idx_hygiene_client` (`client_id`);
ALTER TABLE `client_notifications` ADD INDEX `idx_cn_client` (`client_id`, `read_at`);
ALTER TABLE `quote_photos` ADD INDEX `idx_quote_client` (`client_id`);
ALTER TABLE `conversations` ADD INDEX `idx_chat_client` (`client_id`);
ALTER TABLE `coupon_redemptions` ADD INDEX `idx_redeem_client` (`client_id`);

-- 3) Google sub único
ALTER TABLE `clients` ADD UNIQUE KEY `uk_google_sub` (`google_sub`);

-- 4) FK support_messages
DELETE sm FROM `support_messages` sm
  LEFT JOIN `support_tickets` st ON st.id = sm.ticket_id
  WHERE st.id IS NULL;
ALTER TABLE `support_messages`
  ADD CONSTRAINT `fk_support_msg_ticket`
  FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets`(`id`) ON DELETE CASCADE;

-- 5) Evolution encrypted column
ALTER TABLE `crm_whatsapp_config` ADD COLUMN `evolution_api_key_enc` TEXT NULL AFTER `evolution_api_key`;
