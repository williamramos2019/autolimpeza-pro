-- AI Image Gateway v1 — 2026-07-21
CREATE TABLE IF NOT EXISTS `ai_image_providers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `provider_type` VARCHAR(40) NOT NULL,
  `api_key_enc` TEXT DEFAULT NULL,
  `base_url` VARCHAR(500) DEFAULT NULL,
  `model` VARCHAR(120) DEFAULT NULL,
  `priority` INT NOT NULL DEFAULT 100,
  `timeout_sec` INT NOT NULL DEFAULT 45,
  `daily_limit` INT DEFAULT NULL,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `last_error` VARCHAR(500) DEFAULT NULL,
  `last_used_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_ai_img_prio` (`priority`, `enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ai_image_logs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `prompt_hash` VARCHAR(64) NOT NULL,
  `provider` VARCHAR(120) DEFAULT NULL,
  `provider_type` VARCHAR(40) DEFAULT NULL,
  `model` VARCHAR(120) DEFAULT NULL,
  `status` VARCHAR(20) NOT NULL,
  `error_code` VARCHAR(60) DEFAULT NULL,
  `error_message` VARCHAR(500) DEFAULT NULL,
  `latency_ms` INT DEFAULT NULL,
  `image_url` VARCHAR(800) DEFAULT NULL,
  `meta_json` JSON DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_ai_img_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
