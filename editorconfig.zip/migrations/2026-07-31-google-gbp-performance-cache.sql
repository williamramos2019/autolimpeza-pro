-- Google Business Profile Performance — cache de métricas (TTL gerenciado em PHP)
CREATE TABLE IF NOT EXISTS `google_gbp_api_cache` (
    `cache_key` VARCHAR(191) NOT NULL PRIMARY KEY,
    `payload` LONGTEXT NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `created_at` DATETIME NOT NULL,
    INDEX `idx_gbp_cache_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
