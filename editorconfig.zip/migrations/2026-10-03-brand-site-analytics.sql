-- site_id em analytics (visitas). Legado = principal.
ALTER TABLE analytics ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal';
