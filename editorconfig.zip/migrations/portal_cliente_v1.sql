-- Portal do Cliente v1 — 2026-07-18
-- Migração aditiva (idempotente). Preferir ensurePortalTables() via API/install.

-- Colunas client_id
ALTER TABLE loyalty_pieces ADD COLUMN IF NOT EXISTS `client_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE warranty_tickets ADD COLUMN IF NOT EXISTS `client_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE hygiene_passports ADD COLUMN IF NOT EXISTS `client_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE client_notifications ADD COLUMN IF NOT EXISTS `client_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE quote_photos ADD COLUMN IF NOT EXISTS `client_id` INT UNSIGNED DEFAULT NULL;

ALTER TABLE clients ADD COLUMN IF NOT EXISTS `password_set` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE clients ADD COLUMN IF NOT EXISTS `google_sub` VARCHAR(64) DEFAULT NULL;
ALTER TABLE clients ADD COLUMN IF NOT EXISTS `avatar_url` VARCHAR(500) DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `client_addresses` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id`    INT UNSIGNED NOT NULL,
  `label`        VARCHAR(40)  NOT NULL DEFAULT 'casa',
  `address`      VARCHAR(500) NOT NULL,
  `city`         VARCHAR(100) DEFAULT NULL,
  `state`        VARCHAR(50)  DEFAULT NULL,
  `neighborhood` VARCHAR(150) DEFAULT NULL,
  `zip_code`     VARCHAR(20)  DEFAULT NULL,
  `latitude`     DECIMAL(10,7) DEFAULT NULL,
  `longitude`    DECIMAL(10,7) DEFAULT NULL,
  `is_favorite`  TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`   DATETIME     NOT NULL,
  `updated_at`   DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_client_addr` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `client_reviews` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id`      INT UNSIGNED NOT NULL,
  `appointment_id` VARCHAR(64)  NOT NULL,
  `rating`         TINYINT UNSIGNED NOT NULL,
  `comment`        TEXT         DEFAULT NULL,
  `created_at`     DATETIME     NOT NULL,
  `updated_at`     DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_client_appt_review` (`client_id`, `appointment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `coupons` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`             VARCHAR(40)  NOT NULL,
  `title`            VARCHAR(150) NOT NULL,
  `description`      VARCHAR(500) DEFAULT NULL,
  `discount_type`    VARCHAR(20)  NOT NULL DEFAULT 'percent',
  `discount_value`   DECIMAL(10,2) NOT NULL DEFAULT 0,
  `min_amount`       DECIMAL(10,2) DEFAULT NULL,
  `expires_at`       DATETIME     DEFAULT NULL,
  `active`           TINYINT(1)   NOT NULL DEFAULT 1,
  `max_redemptions`  INT UNSIGNED DEFAULT NULL,
  `redemption_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at`       DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_coupon_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `coupon_redemptions` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `coupon_id`   INT UNSIGNED NOT NULL,
  `client_id`   INT UNSIGNED NOT NULL,
  `redeemed_at` DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_coupon_client` (`coupon_id`, `client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id`  INT UNSIGNED NOT NULL,
  `subject`    VARCHAR(200) NOT NULL,
  `status`     VARCHAR(20)  NOT NULL DEFAULT 'open',
  `priority`   VARCHAR(20)  NOT NULL DEFAULT 'normal',
  `created_at` DATETIME     NOT NULL,
  `updated_at` DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_support_client` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `support_messages` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ticket_id`   INT UNSIGNED NOT NULL,
  `sender_type` VARCHAR(20)  NOT NULL,
  `body`        TEXT         NOT NULL,
  `created_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_msg_ticket` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Nota: MySQL < 8.0.12 pode não aceitar ADD COLUMN IF NOT EXISTS.
-- Nesse caso, use ensurePortalTables() / ensureClientTables() via install.php?step=repair.
