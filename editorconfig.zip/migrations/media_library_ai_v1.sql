-- Media Library IA/meta v1 — 2026-07-21
ALTER TABLE media_library ADD COLUMN alt VARCHAR(255) NULL;
ALTER TABLE media_library ADD COLUMN caption VARCHAR(255) NULL;
ALTER TABLE media_library ADD COLUMN description TEXT NULL;
ALTER TABLE media_library ADD COLUMN thumb_url VARCHAR(500) NULL;
ALTER TABLE media_library ADD COLUMN webp_url VARCHAR(500) NULL;
ALTER TABLE media_library ADD COLUMN avif_url VARCHAR(500) NULL;
ALTER TABLE media_library ADD COLUMN source VARCHAR(20) NULL;
ALTER TABLE media_library ADD COLUMN provider VARCHAR(60) NULL;
ALTER TABLE media_library ADD COLUMN prompt TEXT NULL;
ALTER TABLE media_library ADD COLUMN meta_json JSON NULL;
