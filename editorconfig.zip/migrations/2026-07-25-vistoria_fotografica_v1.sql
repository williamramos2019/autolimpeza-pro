-- Vistoria Fotográfica v1 — Checklist Antes / Avarias / Depois
-- 2026-07-25

CREATE TABLE IF NOT EXISTS `vistorias` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `token` VARCHAR(64) NOT NULL,
  `cliente_nome` VARCHAR(255) NOT NULL,
  `cliente_telefone` VARCHAR(30) DEFAULT NULL,
  `tipo_servico` VARCHAR(100) NOT NULL,
  `observacoes_entrada` TEXT DEFAULT NULL,
  `observacoes_saida` TEXT DEFAULT NULL,
  `instrucoes_cuidados` TEXT DEFAULT NULL,
  `status` ENUM('em_andamento', 'concluido') NOT NULL DEFAULT 'em_andamento',
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_vistoria_token` (`token`),
  KEY `idx_vistoria_status` (`status`),
  KEY `idx_vistoria_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `vistoria_fotos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `vistoria_id` INT UNSIGNED NOT NULL,
  `tipo` ENUM('antes', 'avaria', 'depois') NOT NULL,
  `foto_path` VARCHAR(255) NOT NULL,
  `descricao` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vistoria_fotos_vistoria` (`vistoria_id`),
  KEY `idx_vistoria_fotos_tipo` (`tipo`),
  CONSTRAINT `fk_vistoria_fotos_vistoria`
    FOREIGN KEY (`vistoria_id`) REFERENCES `vistorias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
