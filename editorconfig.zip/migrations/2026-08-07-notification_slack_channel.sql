-- Slack Incoming Webhook — canal paralelo da Central de Notificações (v1.25.30)
CREATE TABLE IF NOT EXISTS `notification_slack_config` (
  `id` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `webhook_url_enc` TEXT DEFAULT NULL,
  `workspace_label` VARCHAR(120) DEFAULT NULL,
  `default_channel_label` VARCHAR(120) DEFAULT NULL,
  `bot_username` VARCHAR(80) DEFAULT NULL,
  `icon_emoji` VARCHAR(40) DEFAULT NULL,
  `min_priority` VARCHAR(20) NOT NULL DEFAULT 'info',
  `environment` VARCHAR(20) NOT NULL DEFAULT 'production',
  `webhooks_by_topic` JSON DEFAULT NULL,
  `auto_send` TINYINT(1) NOT NULL DEFAULT 1,
  `connection_status` VARCHAR(30) NOT NULL DEFAULT 'disconnected',
  `last_test_at` DATETIME DEFAULT NULL,
  `last_test_status` VARCHAR(20) DEFAULT NULL,
  `last_test_error` VARCHAR(500) DEFAULT NULL,
  `last_test_duration_ms` INT UNSIGNED DEFAULT NULL,
  `last_error` VARCHAR(500) DEFAULT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
