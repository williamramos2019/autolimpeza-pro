-- 2026-07-19 — WhatsApp Evolution: cache de QR code para evitar regeneração a cada poll
-- Aplicada automaticamente em runtime por ensureCrmTables() (ALTER com try/catch).
-- Este arquivo documenta a mudança para instalação manual/nova.

ALTER TABLE `crm_whatsapp_config`
    ADD COLUMN `qr_generated_at` DATETIME DEFAULT NULL;
