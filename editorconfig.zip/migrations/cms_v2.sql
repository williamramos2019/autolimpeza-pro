-- CMS v2 — Migração aditiva (segura para instalações existentes)
-- Não remove nem altera dados existentes.

-- ── Extensão blog_posts ───────────────────────────────────────────────────
-- Colunas adicionadas via migrate-cms.php (verifica INFORMATION_SCHEMA)

-- ── Categorias do blog ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `blog_categories` (
  `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `slug`             VARCHAR(120)  NOT NULL,
  `name`             VARCHAR(200)  NOT NULL,
  `icon`             VARCHAR(50)   DEFAULT 'BookOpen',
  `color`            VARCHAR(20)   DEFAULT '#1FB1F9',
  `description`      TEXT          DEFAULT NULL,
  `meta_title`       VARCHAR(500)  DEFAULT NULL,
  `meta_description` TEXT          DEFAULT NULL,
  `canonical`        VARCHAR(500)  DEFAULT NULL,
  `og_image`         VARCHAR(500)  DEFAULT NULL,
  `sort_order`       INT           NOT NULL DEFAULT 0,
  `active`           TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`       DATETIME      NOT NULL,
  `updated_at`       DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cat_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Tags ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `blog_tags` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug`       VARCHAR(120) NOT NULL,
  `name`       VARCHAR(200) NOT NULL,
  `created_at` DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tag_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `blog_post_tags` (
  `post_slug` VARCHAR(200) NOT NULL,
  `tag_id`    INT UNSIGNED NOT NULL,
  PRIMARY KEY (`post_slug`, `tag_id`),
  INDEX `idx_tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Dicas rápidas ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `blog_tips` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug`        VARCHAR(200) NOT NULL,
  `title`       VARCHAR(500) NOT NULL,
  `image_url`   VARCHAR(500) DEFAULT NULL,
  `text`        TEXT         NOT NULL,
  `category_id` INT UNSIGNED DEFAULT NULL,
  `featured`    TINYINT(1)   NOT NULL DEFAULT 0,
  `status`      VARCHAR(20)  NOT NULL DEFAULT 'published',
  `sort_order`  INT          NOT NULL DEFAULT 0,
  `created_at`  DATETIME     NOT NULL,
  `updated_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tip_slug` (`slug`),
  INDEX `idx_tip_featured` (`featured`),
  INDEX `idx_tip_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Biblioteca de mídia ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `media_library` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `filename`      VARCHAR(255) NOT NULL,
  `original_name` VARCHAR(255) DEFAULT NULL,
  `folder`        VARCHAR(50)  NOT NULL DEFAULT 'Blog',
  `url`           VARCHAR(500) NOT NULL,
  `mime`          VARCHAR(100) DEFAULT NULL,
  `size`          INT UNSIGNED DEFAULT 0,
  `width`         INT UNSIGNED DEFAULT NULL,
  `height`        INT UNSIGNED DEFAULT NULL,
  `uploaded_by`   INT UNSIGNED DEFAULT NULL,
  `created_at`    DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_media_folder` (`folder`),
  INDEX `idx_media_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Blocos personalizados ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `custom_blocks` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `identifier`  VARCHAR(100) NOT NULL,
  `name`        VARCHAR(200) NOT NULL,
  `html`        LONGTEXT     DEFAULT NULL,
  `css`         LONGTEXT     DEFAULT NULL,
  `js`          LONGTEXT     DEFAULT NULL,
  `active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `created_by`  INT UNSIGNED DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL,
  `updated_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_block_identifier` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Comentários ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `blog_comments` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_slug`   VARCHAR(200) NOT NULL,
  `author_name` VARCHAR(200) NOT NULL,
  `email`       VARCHAR(255) DEFAULT NULL,
  `content`     TEXT         NOT NULL,
  `status`      VARCHAR(20)  NOT NULL DEFAULT 'pending',
  `created_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_comment_post` (`post_slug`),
  INDEX `idx_comment_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Versionamento de posts (tabela auxiliar) ────────────────────────────────
CREATE TABLE IF NOT EXISTS `blog_post_revisions` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_slug`   VARCHAR(200) NOT NULL,
  `title`       VARCHAR(500) NOT NULL,
  `excerpt`     TEXT         DEFAULT NULL,
  `content`     LONGTEXT     DEFAULT NULL,
  `blocks`      JSON         DEFAULT NULL,
  `meta_title`  VARCHAR(500) DEFAULT NULL,
  `meta_description` TEXT    DEFAULT NULL,
  `status`      VARCHAR(20)  DEFAULT NULL,
  `author_id`   INT UNSIGNED DEFAULT NULL,
  `author_name` VARCHAR(200) DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_rev_slug` (`post_slug`),
  INDEX `idx_rev_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Autores editoriais ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `blog_authors` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug`          VARCHAR(120) NOT NULL,
  `name`          VARCHAR(200) NOT NULL,
  `photo_url`     VARCHAR(500) DEFAULT NULL,
  `bio`           TEXT         DEFAULT NULL,
  `specialty`     VARCHAR(200) DEFAULT NULL,
  `social_json`   JSON         DEFAULT NULL,
  `active`        TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order`    INT          NOT NULL DEFAULT 0,
  `created_at`    DATETIME     NOT NULL,
  `updated_at`    DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_author_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
