-- CRM Premium v1 — migration compatível (additive only)
-- Executado automaticamente via ensureCrmTables() ou install.php?step=repair

-- Colunas extras em leads (ignorar erro se já existirem)
-- ALTER TABLE leads ADD COLUMN visitor_id VARCHAR(64) DEFAULT NULL;
-- ALTER TABLE leads ADD COLUMN crm_status VARCHAR(30) NOT NULL DEFAULT 'novo';
-- ALTER TABLE leads ADD COLUMN device VARCHAR(50) DEFAULT NULL;
-- ALTER TABLE leads ADD COLUMN email VARCHAR(255) DEFAULT NULL;
-- ALTER TABLE leads ADD COLUMN contact_id INT UNSIGNED DEFAULT NULL;
-- ALTER TABLE leads ADD COLUMN estimated_value DECIMAL(12,2) DEFAULT NULL;

-- Tabelas criadas via crm-handlers.php ensureCrmTables():
-- crm_contacts, crm_activities, crm_automations, crm_whatsapp_config, crm_whatsapp_messages
