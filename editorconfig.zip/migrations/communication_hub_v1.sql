-- ============================================================================
-- Communication Hub v1 — 2026-07-18
-- Migração ADITIVA e IDEMPOTENTE (executada via alpRunSqlMigration, que ignora
-- erros de "já existe"). NUNCA renomeia, apaga ou altera dados existentes.
-- Tabelas preservadas integralmente: system_notifications, client_notifications,
-- push_devices, push_subscriptions, notification_queue, notification_templates,
-- notification_logs, notification_template_versions, notification_campaigns,
-- notification_engine_sends, notification_delivery_logs, captain_automation_*.
-- ============================================================================

-- ── Event Bus canônico ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `communication_events` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `event_key`   VARCHAR(80)  NOT NULL,
    `source`      VARCHAR(80)  DEFAULT NULL,
    `actor_type`  VARCHAR(20)  DEFAULT NULL,
    `actor_id`    VARCHAR(64)  DEFAULT NULL,
    `title`       VARCHAR(200) DEFAULT NULL,
    `payload`     JSON         DEFAULT NULL,
    `uuid`        VARCHAR(32)  DEFAULT NULL,
    `status`      VARCHAR(20)  NOT NULL DEFAULT 'received',
    `listeners`   INT          NOT NULL DEFAULT 0,
    `is_test`     TINYINT(1)   NOT NULL DEFAULT 0,
    `error`       TEXT         DEFAULT NULL,
    `created_at`  DATETIME     NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_ce_key` (`event_key`, `created_at`),
    INDEX `idx_ce_uuid` (`uuid`),
    INDEX `idx_ce_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Dead Letter Queue (mensagens que esgotaram tentativas) ──────────────────
CREATE TABLE IF NOT EXISTS `notification_queue_dlq` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `queue_id`    INT UNSIGNED DEFAULT NULL,
    `uuid`        VARCHAR(32)  NOT NULL,
    `cliente_id`  VARCHAR(64)  DEFAULT NULL,
    `tipo`        VARCHAR(80)  NOT NULL,
    `canal`       VARCHAR(30)  NOT NULL DEFAULT 'multi',
    `tentativas`  TINYINT      NOT NULL DEFAULT 0,
    `payload`     JSON         NOT NULL,
    `erro`        TEXT         DEFAULT NULL,
    `moved_at`    DATETIME     NOT NULL,
    `reprocessed_at` DATETIME  DEFAULT NULL,
    `created_at`  DATETIME     NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_dlq_uuid` (`uuid`),
    INDEX `idx_dlq_moved` (`moved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Auditoria da Notification AI (Gemini via AI Gateway) ────────────────────
CREATE TABLE IF NOT EXISTS `communication_ai_log` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `action`      VARCHAR(40)  NOT NULL,
    `channel`     VARCHAR(30)  DEFAULT NULL,
    `input_json`  JSON         DEFAULT NULL,
    `output_json` JSON         DEFAULT NULL,
    `provider`    VARCHAR(40)  DEFAULT NULL,
    `duration_ms` INT          DEFAULT NULL,
    `admin_email` VARCHAR(255) DEFAULT NULL,
    `status`      VARCHAR(20)  NOT NULL DEFAULT 'ok',
    `error`       TEXT         DEFAULT NULL,
    `created_at`  DATETIME     NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_cal_action` (`action`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Trilha de auditoria das ações do Capitão Clean no Hub ───────────────────
CREATE TABLE IF NOT EXISTS `communication_captain_actions` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `action`      VARCHAR(60)  NOT NULL,
    `params_json` JSON         DEFAULT NULL,
    `result_json` JSON         DEFAULT NULL,
    `status`      VARCHAR(20)  NOT NULL DEFAULT 'ok',
    `requires_confirmation` TINYINT(1) NOT NULL DEFAULT 0,
    `confirmed_by` VARCHAR(255) DEFAULT NULL,
    `admin_email` VARCHAR(255) DEFAULT NULL,
    `created_at`  DATETIME     NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_cca_action` (`action`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Colunas aditivas — notification_queue (retry/backoff/lease/timeline) ────
-- (alpRunSqlMigration ignora erro "Duplicate column")
ALTER TABLE `notification_queue` ADD COLUMN `next_retry_at` DATETIME DEFAULT NULL;
ALTER TABLE `notification_queue` ADD COLUMN `locked_by` VARCHAR(64) DEFAULT NULL;
ALTER TABLE `notification_queue` ADD COLUMN `locked_at` DATETIME DEFAULT NULL;
ALTER TABLE `notification_queue` ADD COLUMN `event_id` BIGINT UNSIGNED DEFAULT NULL;
ALTER TABLE `notification_queue` ADD COLUMN `canal_entregue` VARCHAR(30) DEFAULT NULL;

-- ── Colunas aditivas — notification_logs (vínculo com evento canônico) ──────
ALTER TABLE `notification_logs` ADD COLUMN `event_id` BIGINT UNSIGNED DEFAULT NULL;

-- ── Colunas aditivas — notification_campaigns (multicanal/rascunho/duplicar) ─
ALTER TABLE `notification_campaigns` ADD COLUMN `channels` JSON DEFAULT NULL;
ALTER TABLE `notification_campaigns` ADD COLUMN `content_json` JSON DEFAULT NULL;
ALTER TABLE `notification_campaigns` ADD COLUMN `paused_at` DATETIME DEFAULT NULL;
ALTER TABLE `notification_campaigns` ADD COLUMN `duplicated_from` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `notification_campaigns` ADD COLUMN `ai_generated` TINYINT(1) NOT NULL DEFAULT 0;
