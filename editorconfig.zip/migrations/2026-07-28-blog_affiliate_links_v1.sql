-- Blog: banco de links de afiliados e serviço local (Capitão Clean)
-- Idempotente — executado via alpRunSqlMigration

CREATE TABLE IF NOT EXISTS `blog_affiliate_links` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(300) NOT NULL,
  `anchor_text` VARCHAR(500) NOT NULL,
  `url` VARCHAR(2000) NOT NULL,
  `link_type` VARCHAR(30) NOT NULL DEFAULT 'affiliate',
  `category` VARCHAR(100) DEFAULT NULL,
  `service_id` VARCHAR(80) DEFAULT NULL,
  `cities` JSON DEFAULT NULL,
  `keywords` VARCHAR(500) DEFAULT NULL,
  `context_hint` TEXT DEFAULT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  `click_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_blog_aff_active` (`active`, `sort_order`),
  INDEX `idx_blog_aff_type` (`link_type`),
  INDEX `idx_blog_aff_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
