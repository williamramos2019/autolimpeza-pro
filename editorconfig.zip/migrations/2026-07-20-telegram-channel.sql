-- Telegram channel MVP — config singleton + campos em crm_contacts
-- Idempotente via ensureTelegramTables() em runtime; este arquivo documenta o schema.

CREATE TABLE IF NOT EXISTS `crm_telegram_config` (
  `id` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `bot_token_enc` TEXT DEFAULT NULL,
  `bot_username` VARCHAR(120) DEFAULT NULL,
  `webhook_secret` VARCHAR(64) DEFAULT NULL,
  `webhook_url` VARCHAR(500) DEFAULT NULL,
  `enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `auto_send` TINYINT(1) NOT NULL DEFAULT 1,
  `connection_status` VARCHAR(30) NOT NULL DEFAULT 'disconnected',
  `last_error` VARCHAR(500) DEFAULT NULL,
  `last_sync_at` DATETIME DEFAULT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `crm_contacts`
  ADD COLUMN `telegram_chat_id` VARCHAR(64) DEFAULT NULL,
  ADD COLUMN `telegram_username` VARCHAR(120) DEFAULT NULL,
  ADD COLUMN `telegram_notify` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN `notify_pref` VARCHAR(20) NOT NULL DEFAULT 'both';

CREATE INDEX `idx_telegram_chat` ON `crm_contacts` (`telegram_chat_id`);
