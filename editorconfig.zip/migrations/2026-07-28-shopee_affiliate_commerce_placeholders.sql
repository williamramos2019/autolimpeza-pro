-- Shopee Affiliate — placeholders de vitrine (preços) para seed sem commerce
-- 2026-07-28
--
-- O seed `2026-07-28-shopee_affiliate_links_seed.sql` não popula image_url /
-- sale_price / original_price / discount_percent / rating.
-- Este UPDATE preenche preços placeholder por categoria (image_url permanece NULL
-- até sync real da Shopee). Só altera linhas com sale_price IS NULL.
--
-- Requer colunas de `2026-07-28-blog_affiliate_commerce.sql`.

-- Equipamentos (aspiradores / extratoras)
UPDATE `blog_affiliate_links`
SET
  `sale_price` = 199.90,
  `original_price` = 279.90,
  `discount_percent` = 29,
  `rating` = 4.50,
  `updated_at` = NOW()
WHERE `sale_price` IS NULL
  AND `link_type` = 'affiliate'
  AND `category` = 'equipamentos';

-- Estofados (espumas, limpadores, kits)
UPDATE `blog_affiliate_links`
SET
  `sale_price` = 49.90,
  `original_price` = 69.90,
  `discount_percent` = 29,
  `rating` = 4.40,
  `updated_at` = NOW()
WHERE `sale_price` IS NULL
  AND `link_type` = 'affiliate'
  AND `category` = 'estofados';

-- Pós-obra / desengraxantes
UPDATE `blog_affiliate_links`
SET
  `sale_price` = 39.90,
  `original_price` = 54.90,
  `discount_percent` = 27,
  `rating` = 4.30,
  `updated_at` = NOW()
WHERE `sale_price` IS NULL
  AND `link_type` = 'affiliate'
  AND `category` = 'pos-obra';

-- Higiene / sanitização
UPDATE `blog_affiliate_links`
SET
  `sale_price` = 59.90,
  `original_price` = 84.90,
  `discount_percent` = 29,
  `rating` = 4.40,
  `updated_at` = NOW()
WHERE `sale_price` IS NULL
  AND `link_type` = 'affiliate'
  AND `category` = 'higiene';

-- Automotivo
UPDATE `blog_affiliate_links`
SET
  `sale_price` = 34.90,
  `original_price` = 49.90,
  `discount_percent` = 30,
  `rating` = 4.20,
  `updated_at` = NOW()
WHERE `sale_price` IS NULL
  AND `link_type` = 'affiliate'
  AND `category` = 'automotivo';

-- Geral / fallback (qualquer seed ainda sem preço)
UPDATE `blog_affiliate_links`
SET
  `sale_price` = 44.90,
  `original_price` = 64.90,
  `discount_percent` = 31,
  `rating` = 4.30,
  `updated_at` = NOW()
WHERE `sale_price` IS NULL
  AND `link_type` = 'affiliate';
