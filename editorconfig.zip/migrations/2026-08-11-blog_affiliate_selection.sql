-- Motor de seleção de afiliados: histórico de uso + índices de ranking
-- Idempotente — alpRunSqlMigration ignora erros de objeto já existente.
-- Colunas use_count/last_used_at são adicionadas via ALTER no PHP (MySQL 5.7).

CREATE TABLE IF NOT EXISTS `blog_affiliate_link_usage` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NOT NULL,
  `post_id` INT UNSIGNED DEFAULT NULL,
  `post_slug` VARCHAR(200) DEFAULT NULL,
  `niche` VARCHAR(120) DEFAULT NULL,
  `subcategory` VARCHAR(120) DEFAULT NULL,
  `topic` VARCHAR(300) DEFAULT NULL,
  `intent` VARCHAR(80) DEFAULT NULL,
  `fallback_level` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `reason` VARCHAR(240) DEFAULT NULL,
  `used_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_blog_aff_usage_slug_product` (`post_slug`, `product_id`),
  INDEX `idx_blog_aff_usage_product_used` (`product_id`, `used_at`),
  INDEX `idx_blog_aff_usage_used` (`used_at`),
  INDEX `idx_blog_aff_usage_niche` (`niche`, `used_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
