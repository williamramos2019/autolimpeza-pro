-- Engagement + contador de views de posts (idempotente)
-- 2026-07-28

CREATE TABLE IF NOT EXISTS blog_post_views (
  slug VARCHAR(200) NOT NULL PRIMARY KEY,
  views INT UNSIGNED NOT NULL DEFAULT 0,
  unique_views INT UNSIGNED NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_post_view_visitors (
  slug VARCHAR(200) NOT NULL,
  visitor_id VARCHAR(64) NOT NULL,
  first_viewed_at DATETIME NOT NULL,
  PRIMARY KEY (slug, visitor_id),
  KEY idx_bpvv_visitor (visitor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS engagement_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  event_type VARCHAR(40) NOT NULL,
  path VARCHAR(255) NULL,
  slug VARCHAR(200) NULL,
  depth SMALLINT UNSIGNED NULL,
  visitor_id VARCHAR(64) NULL,
  session_id VARCHAR(64) NULL,
  meta_json TEXT NULL,
  created_at DATETIME NOT NULL,
  KEY idx_eng_type_created (event_type, created_at),
  KEY idx_eng_slug (slug),
  KEY idx_eng_path (path(100), created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
