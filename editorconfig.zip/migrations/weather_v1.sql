-- Monitoramento climático Capitão Clean — migration aditiva (idempotente)

CREATE TABLE IF NOT EXISTS `appointment_weather_monitor` (
  `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `appointment_id`        VARCHAR(64)  NOT NULL,
  `latitude`              DECIMAL(10,7) DEFAULT NULL,
  `longitude`             DECIMAL(10,7) DEFAULT NULL,
  `city`                  VARCHAR(120) DEFAULT NULL,
  `address`               VARCHAR(500) DEFAULT NULL,
  `service_date`          DATE         NOT NULL,
  `service_time`          VARCHAR(10)  DEFAULT NULL,
  `precip_prob`           TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `temperature`           DECIMAL(5,2) DEFAULT NULL,
  `humidity`              TINYINT UNSIGNED DEFAULT NULL,
  `wind_kmh`              DECIMAL(6,2) DEFAULT NULL,
  `condition_code`        VARCHAR(40)  DEFAULT NULL,
  `condition_label`       VARCHAR(120) DEFAULT NULL,
  `risk_level`            VARCHAR(10)  NOT NULL DEFAULT 'green',
  `status_label`          VARCHAR(200) DEFAULT NULL,
  `captain_recommendation` TEXT        DEFAULT NULL,
  `provider`              VARCHAR(40)  DEFAULT 'open-meteo',
  `last_payload`          JSON         DEFAULT NULL,
  `pending_checks`        JSON         DEFAULT NULL,
  `last_checked_at`       DATETIME     DEFAULT NULL,
  `next_check_at`         DATETIME     DEFAULT NULL,
  `created_at`            DATETIME     NOT NULL,
  `updated_at`            DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_weather_appt` (`appointment_id`),
  KEY `idx_weather_next` (`next_check_at`),
  KEY `idx_weather_date` (`service_date`),
  KEY `idx_weather_risk` (`risk_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `appointment_weather_history` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `appointment_id`  VARCHAR(64)  NOT NULL,
  `check_type`      VARCHAR(30)  NOT NULL DEFAULT 'scheduled',
  `precip_prob`     TINYINT UNSIGNED DEFAULT NULL,
  `temperature`     DECIMAL(5,2) DEFAULT NULL,
  `condition_label` VARCHAR(120) DEFAULT NULL,
  `risk_level`      VARCHAR(10)  DEFAULT NULL,
  `message`         TEXT         DEFAULT NULL,
  `payload`         JSON         DEFAULT NULL,
  `notified`        TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`      DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wh_hist_appt` (`appointment_id`),
  KEY `idx_wh_hist_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `weather_api_cache` (
  `cache_key`   VARCHAR(128) NOT NULL,
  `payload`     JSON         NOT NULL,
  `expires_at`  DATETIME     NOT NULL,
  `created_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`cache_key`),
  KEY `idx_weather_cache_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
