-- Vistoria comercial v1 — aprovação do cliente + CRM + WhatsApp
-- 2026-07-26
-- Idempotente via ensureVistoriaTables() em vistoria-handlers.php (try/catch).
-- Este SQL é referência para ambientes que aplicam migrations manualmente.

ALTER TABLE `vistorias`
  MODIFY COLUMN `status` ENUM('em_andamento', 'concluido', 'aprovado_cliente')
    NOT NULL DEFAULT 'em_andamento';

-- Execute uma a uma se alguma coluna já existir:
ALTER TABLE `vistorias` ADD COLUMN `aprovado_em` DATETIME DEFAULT NULL AFTER `status`;
ALTER TABLE `vistorias` ADD COLUMN `lead_id` INT UNSIGNED DEFAULT NULL AFTER `aprovado_em`;
ALTER TABLE `vistorias` ADD COLUMN `wa_enviado_em` DATETIME DEFAULT NULL AFTER `lead_id`;
