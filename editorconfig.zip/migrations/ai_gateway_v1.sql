-- AI Gateway — migration aditiva (idempotente)

CREATE TABLE IF NOT EXISTS `ai_providers` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`             VARCHAR(120) NOT NULL,
  `provider_type`    VARCHAR(40)  NOT NULL,
  `api_key_enc`      TEXT         DEFAULT NULL,
  `base_url`         VARCHAR(500) DEFAULT NULL,
  `model`            VARCHAR(120) DEFAULT NULL,
  `priority`         INT          NOT NULL DEFAULT 100,
  `weight`           INT          NOT NULL DEFAULT 1,
  `timeout_sec`      INT          NOT NULL DEFAULT 90,
  `rate_limit`       INT          DEFAULT NULL,
  `enabled`          TINYINT(1)   NOT NULL DEFAULT 1,
  `last_used_at`     DATETIME     DEFAULT NULL,
  `last_error`       TEXT         DEFAULT NULL,
  `avg_latency_ms`   INT UNSIGNED DEFAULT NULL,
  `created_at`       DATETIME     NOT NULL,
  `updated_at`       DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ai_prov_enabled_prio` (`enabled`, `priority`),
  KEY `idx_ai_prov_type` (`provider_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ai_gateway_logs` (
  `id`                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `module`            VARCHAR(40)     NOT NULL DEFAULT 'default',
  `prompt_hash`       VARCHAR(64)     DEFAULT NULL,
  `provider`          VARCHAR(120)    DEFAULT NULL,
  `model`             VARCHAR(120)    DEFAULT NULL,
  `latency_ms`        INT UNSIGNED    DEFAULT NULL,
  `tokens_in`         INT UNSIGNED    DEFAULT NULL,
  `tokens_out`        INT UNSIGNED    DEFAULT NULL,
  `status`            VARCHAR(20)     NOT NULL DEFAULT 'error',
  `error_code`        VARCHAR(40)     DEFAULT NULL,
  `failover_attempts` JSON            DEFAULT NULL,
  `created_at`        DATETIME        NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ai_gw_logs_module` (`module`),
  KEY `idx_ai_gw_logs_created` (`created_at`),
  KEY `idx_ai_gw_logs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ai_module_routing` (
  `module_key`           VARCHAR(40)  NOT NULL,
  `strategy`             VARCHAR(20)  NOT NULL DEFAULT 'priority',
  `preferred_provider_id` INT UNSIGNED DEFAULT NULL,
  `cache_ttl_sec`        INT          NOT NULL DEFAULT 120,
  `updated_at`           DATETIME     NOT NULL,
  PRIMARY KEY (`module_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ai_prompts` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `module`     VARCHAR(40)  NOT NULL,
  `key`        VARCHAR(80)  NOT NULL,
  `name`       VARCHAR(200) NOT NULL,
  `content`    MEDIUMTEXT   NOT NULL,
  `version`    INT          NOT NULL DEFAULT 1,
  `active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` DATETIME     NOT NULL,
  `updated_at` DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ai_prompt_module_key` (`module`, `key`),
  KEY `idx_ai_prompt_active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
