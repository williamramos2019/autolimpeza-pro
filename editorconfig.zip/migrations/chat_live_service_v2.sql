-- Chat operacional preparado para Live Service 2.0 — UI permanece desativada.

ALTER TABLE `conversations` ADD COLUMN `appointment_id` VARCHAR(64) DEFAULT NULL;
ALTER TABLE `conversations` ADD COLUMN `client_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `conversations` ADD COLUMN `technician_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `conversations` ADD COLUMN `status` VARCHAR(20) NOT NULL DEFAULT 'open';
ALTER TABLE `conversations` ADD COLUMN `ready` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `conversations` ADD INDEX `idx_chat_appointment` (`appointment_id`, `status`);

ALTER TABLE `messages` ADD COLUMN `sender_type` VARCHAR(20) DEFAULT NULL;
ALTER TABLE `messages` ADD COLUMN `sender_id` VARCHAR(64) DEFAULT NULL;
ALTER TABLE `messages` ADD COLUMN `client_uuid` VARCHAR(64) DEFAULT NULL;
ALTER TABLE `messages` ADD COLUMN `delivered_at` DATETIME DEFAULT NULL;
ALTER TABLE `messages` ADD COLUMN `read_at` DATETIME DEFAULT NULL;
ALTER TABLE `messages` ADD UNIQUE KEY `uk_chat_client_uuid` (`client_uuid`);

CREATE TABLE IF NOT EXISTS `chat_attachments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `message_id` INT UNSIGNED NOT NULL,
  `url` VARCHAR(500) NOT NULL,
  `mime` VARCHAR(120) DEFAULT NULL,
  `size_bytes` INT UNSIGNED DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_chat_attachment_message` (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `chat_typing` (
  `conversation_id` INT UNSIGNED NOT NULL,
  `actor_type` VARCHAR(20) NOT NULL,
  `actor_id` VARCHAR(64) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`conversation_id`, `actor_type`, `actor_id`),
  INDEX `idx_chat_typing_expiry` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
