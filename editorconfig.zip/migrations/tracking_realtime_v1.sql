-- Acompanhamento em tempo real v1 — 2026-07-18
-- Migração aditiva (idempotente). Preferir ensureTrackingTables() via API/install.

CREATE TABLE IF NOT EXISTS `technicians` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email`         VARCHAR(255) NOT NULL,
  `name`          VARCHAR(200) NOT NULL,
  `phone`         VARCHAR(50)  DEFAULT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `avatar_url`    VARCHAR(500) DEFAULT NULL,
  `active`        TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`    DATETIME     NOT NULL,
  `updated_at`    DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tech_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `technician_sessions` (
  `token`          VARCHAR(64)  NOT NULL,
  `technician_id`  INT UNSIGNED NOT NULL,
  `expires_at`     DATETIME     NOT NULL,
  `created_at`     DATETIME     NOT NULL,
  PRIMARY KEY (`token`),
  INDEX `idx_tech_session` (`technician_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `appointment_events` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `appointment_id` VARCHAR(64)  NOT NULL,
  `event_key`      VARCHAR(80)  NOT NULL,
  `from_status`    VARCHAR(30)  DEFAULT NULL,
  `to_status`      VARCHAR(30)  DEFAULT NULL,
  `actor_type`     VARCHAR(20)  DEFAULT NULL,
  `actor_id`       VARCHAR(64)  DEFAULT NULL,
  `title`          VARCHAR(200) NOT NULL,
  `detail`         VARCHAR(500) DEFAULT NULL,
  `lat`            DECIMAL(10,7) DEFAULT NULL,
  `lng`            DECIMAL(10,7) DEFAULT NULL,
  `meta_json`      JSON         DEFAULT NULL,
  `created_at`     DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_appt_events` (`appointment_id`, `created_at`),
  INDEX `idx_appt_event_key` (`event_key`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `appointment_tracking_sessions` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `appointment_id` VARCHAR(64)  NOT NULL,
  `technician_id`  INT UNSIGNED NOT NULL,
  `status`         VARCHAR(20)  NOT NULL DEFAULT 'active',
  `started_at`     DATETIME     NOT NULL,
  `ended_at`       DATETIME     DEFAULT NULL,
  `last_lat`       DECIMAL(10,7) DEFAULT NULL,
  `last_lng`       DECIMAL(10,7) DEFAULT NULL,
  `last_accuracy`  DECIMAL(10,2) DEFAULT NULL,
  `last_speed`     DECIMAL(10,2) DEFAULT NULL,
  `last_heading`   DECIMAL(10,2) DEFAULT NULL,
  `last_ping_at`   DATETIME     DEFAULT NULL,
  `distance_m`     DECIMAL(12,2) NOT NULL DEFAULT 0,
  `eta_minutes`    INT UNSIGNED DEFAULT NULL,
  `route_distance_m` DECIMAL(12,2) DEFAULT NULL,
  `near_notified`  TINYINT(1)   NOT NULL DEFAULT 0,
  `delay_notified` TINYINT(1)   NOT NULL DEFAULT 0,
  `gps_stale_notified` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`     DATETIME     NOT NULL,
  `updated_at`     DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_track_appt` (`appointment_id`, `status`),
  INDEX `idx_track_tech` (`technician_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `appointment_location_points` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_id`     BIGINT UNSIGNED NOT NULL,
  `appointment_id` VARCHAR(64)  NOT NULL,
  `technician_id`  INT UNSIGNED NOT NULL,
  `lat`            DECIMAL(10,7) NOT NULL,
  `lng`            DECIMAL(10,7) NOT NULL,
  `accuracy`       DECIMAL(10,2) DEFAULT NULL,
  `speed`          DECIMAL(10,2) DEFAULT NULL,
  `heading`        DECIMAL(10,2) DEFAULT NULL,
  `recorded_at`    DATETIME     NOT NULL,
  `created_at`     DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_loc_session` (`session_id`, `recorded_at`),
  INDEX `idx_loc_appt` (`appointment_id`, `recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `appointment_checklist_items` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `appointment_id` VARCHAR(64)  NOT NULL,
  `label`          VARCHAR(200) NOT NULL,
  `checked`        TINYINT(1)   NOT NULL DEFAULT 0,
  `photo_url`      VARCHAR(500) DEFAULT NULL,
  `note`           VARCHAR(500) DEFAULT NULL,
  `sort_order`     INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_by`     VARCHAR(64)  DEFAULT NULL,
  `created_at`     DATETIME     NOT NULL,
  `updated_at`     DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_checklist_appt` (`appointment_id`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tracking_analytics_daily` (
  `id`                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `day`                DATE         NOT NULL,
  `neighborhood`       VARCHAR(150) DEFAULT NULL,
  `city`               VARCHAR(150) DEFAULT NULL,
  `trips`              INT UNSIGNED NOT NULL DEFAULT 0,
  `travel_seconds`     INT UNSIGNED NOT NULL DEFAULT 0,
  `service_seconds`    INT UNSIGNED NOT NULL DEFAULT 0,
  `idle_seconds`       INT UNSIGNED NOT NULL DEFAULT 0,
  `distance_m`         DECIMAL(14,2) NOT NULL DEFAULT 0,
  `on_time_count`      INT UNSIGNED NOT NULL DEFAULT 0,
  `late_count`         INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at`         DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_track_analytics` (`day`, `neighborhood`, `city`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
