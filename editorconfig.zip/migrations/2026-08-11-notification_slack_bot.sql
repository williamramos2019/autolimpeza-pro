-- Slack Bot Token + Channel ID (fallback chat.postMessage) — v1.25.42
-- MySQL 5.7: sem IF NOT EXISTS. Se a coluna já existir, slackEnsureBotColumns() no PHP cobre.
ALTER TABLE `notification_slack_config`
  ADD COLUMN `bot_token_enc` TEXT DEFAULT NULL AFTER `webhook_url_enc`;
ALTER TABLE `notification_slack_config`
  ADD COLUMN `default_channel_id` VARCHAR(80) DEFAULT NULL AFTER `bot_token_enc`;
