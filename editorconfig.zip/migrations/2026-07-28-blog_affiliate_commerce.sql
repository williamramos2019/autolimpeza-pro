-- Blog affiliates: campos de vitrine (imagem, preços, rating)
-- 2026-07-28

-- Rodar no phpMyAdmin se ensureBlogAffiliateLinksTable ainda não criou as colunas.
-- Ignorar erro "Duplicate column" se já existir.

ALTER TABLE `blog_affiliate_links` ADD COLUMN `image_url` VARCHAR(2000) DEFAULT NULL;
ALTER TABLE `blog_affiliate_links` ADD COLUMN `sale_price` DECIMAL(12,2) DEFAULT NULL;
ALTER TABLE `blog_affiliate_links` ADD COLUMN `original_price` DECIMAL(12,2) DEFAULT NULL;
ALTER TABLE `blog_affiliate_links` ADD COLUMN `rating` DECIMAL(3,2) DEFAULT NULL;
ALTER TABLE `blog_affiliate_links` ADD COLUMN `discount_percent` SMALLINT UNSIGNED DEFAULT NULL;
