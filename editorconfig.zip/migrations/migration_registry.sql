-- Migration registry — controle aditivo de versões aplicadas
-- Não substitui ensure*Tables(); apenas registra migrações conhecidas.

CREATE TABLE IF NOT EXISTS `schema_migrations` (
  `version`    VARCHAR(120) NOT NULL,
  `applied_at` DATETIME     NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
