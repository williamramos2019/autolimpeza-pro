-- Meta de capa IA em blog_posts (v1.25.19)
-- image_url já existe; acrescenta prompt/status/provider/timestamp

ALTER TABLE `blog_posts`
  ADD COLUMN `image_prompt` MEDIUMTEXT NULL AFTER `image_url`;

ALTER TABLE `blog_posts`
  ADD COLUMN `image_status` VARCHAR(20) NULL DEFAULT NULL AFTER `image_prompt`;

ALTER TABLE `blog_posts`
  ADD COLUMN `image_provider` VARCHAR(80) NULL AFTER `image_status`;

ALTER TABLE `blog_posts`
  ADD COLUMN `image_generated_at` DATETIME NULL AFTER `image_provider`;

-- Posts legados com capa → completed
UPDATE `blog_posts`
SET `image_status` = 'completed',
    `image_generated_at` = COALESCE(`updated_at`, `created_at`, NOW())
WHERE `image_url` IS NOT NULL
  AND TRIM(`image_url`) <> ''
  AND (`image_status` IS NULL OR `image_status` = '');
