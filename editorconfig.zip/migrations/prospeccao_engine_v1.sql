-- Prospecção Engine Pro — migration aditiva (idempotente)

CREATE TABLE IF NOT EXISTS `prospeccao_engine_jobs` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `status`           VARCHAR(20)  NOT NULL DEFAULT 'queued',
  `phase`            VARCHAR(30)  NOT NULL DEFAULT 'init',
  `city`             VARCHAR(120) NOT NULL,
  `categories`       JSON         NOT NULL,
  `radius_m`         INT UNSIGNED NOT NULL DEFAULT 5000,
  `progress_pct`     DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `total_cells`      INT UNSIGNED NOT NULL DEFAULT 0,
  `completed_cells`  INT UNSIGNED NOT NULL DEFAULT 0,
  `leads_found`      INT UNSIGNED NOT NULL DEFAULT 0,
  `leads_enriched`   INT UNSIGNED NOT NULL DEFAULT 0,
  `leads_merged`     INT UNSIGNED NOT NULL DEFAULT 0,
  `config_json`      JSON         DEFAULT NULL,
  `state_json`       JSON         DEFAULT NULL,
  `error_message`    TEXT         DEFAULT NULL,
  `started_at`       DATETIME     DEFAULT NULL,
  `completed_at`     DATETIME     DEFAULT NULL,
  `created_by`       VARCHAR(120) DEFAULT NULL,
  `created_at`       DATETIME     NOT NULL,
  `updated_at`       DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pe_job_status` (`status`),
  KEY `idx_pe_job_city` (`city`),
  KEY `idx_pe_job_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `prospeccao_engine_job_events` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `job_id`      INT UNSIGNED NOT NULL,
  `event_type`  VARCHAR(40)  NOT NULL DEFAULT 'log',
  `level`       VARCHAR(10)  NOT NULL DEFAULT 'info',
  `message`     TEXT         NOT NULL,
  `meta_json`   JSON         DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pe_event_job` (`job_id`),
  KEY `idx_pe_event_type` (`event_type`),
  KEY `idx_pe_event_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `prospeccao_engine_leads` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `job_id`          INT UNSIGNED NOT NULL,
  `place_id`        VARCHAR(120) DEFAULT NULL,
  `name`            VARCHAR(255) NOT NULL,
  `category`        VARCHAR(120) DEFAULT NULL,
  `phone`           VARCHAR(50)  DEFAULT NULL,
  `email`           VARCHAR(255) DEFAULT NULL,
  `website`         VARCHAR(500) DEFAULT NULL,
  `social_json`     JSON         DEFAULT NULL,
  `rating`          DECIMAL(3,1) DEFAULT NULL,
  `reviews_count`   INT UNSIGNED DEFAULT NULL,
  `location_json`   JSON         DEFAULT NULL,
  `hours_json`      JSON         DEFAULT NULL,
  `score_ipc`       INT UNSIGNED NOT NULL DEFAULT 0,
  `lead_score`      VARCHAR(10)  NOT NULL DEFAULT 'baixo',
  `raw_json`        JSON         DEFAULT NULL,
  `enriched_at`     DATETIME     DEFAULT NULL,
  `normalized_at`   DATETIME     DEFAULT NULL,
  `merged_at`       DATETIME     DEFAULT NULL,
  `prospect_id`     INT UNSIGNED DEFAULT NULL,
  `crm_status`      VARCHAR(30)  DEFAULT NULL,
  `source`          VARCHAR(40)  NOT NULL DEFAULT 'prospeccao-engine',
  `dedup_key`       VARCHAR(200) DEFAULT NULL,
  `created_at`      DATETIME     NOT NULL,
  `updated_at`      DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pe_lead_place_job` (`job_id`, `place_id`),
  KEY `idx_pe_lead_job` (`job_id`),
  KEY `idx_pe_lead_place` (`place_id`),
  KEY `idx_pe_lead_ipc` (`score_ipc`),
  KEY `idx_pe_lead_merged` (`merged_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `prospeccao_engine_grid_cells` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `job_id`        INT UNSIGNED NOT NULL,
  `city`          VARCHAR(120) NOT NULL,
  `category`      VARCHAR(120) NOT NULL,
  `cell_lat`      DECIMAL(10,7) NOT NULL,
  `cell_lng`      DECIMAL(10,7) NOT NULL,
  `radius_m`      INT UNSIGNED NOT NULL,
  `status`        VARCHAR(20)  NOT NULL DEFAULT 'pending',
  `places_found`  INT UNSIGNED NOT NULL DEFAULT 0,
  `page_token`    VARCHAR(300) DEFAULT NULL,
  `retry_count`   TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `last_error`    TEXT         DEFAULT NULL,
  `completed_at`  DATETIME     DEFAULT NULL,
  `created_at`    DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pe_cell_job_status` (`job_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `prospeccao_engine_api_cache` (
  `cache_key`      VARCHAR(64)  NOT NULL,
  `response_json`  MEDIUMTEXT NOT NULL,
  `expires_at`     DATETIME     NOT NULL,
  `created_at`     DATETIME     NOT NULL,
  PRIMARY KEY (`cache_key`),
  KEY `idx_pe_cache_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
