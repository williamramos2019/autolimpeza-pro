-- Live Service 2.0 — 2026-07-18
-- Migração somente aditiva; não remove nem reescreve histórico.

CREATE TABLE IF NOT EXISTS `tracking_teams` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `city` VARCHAR(150) DEFAULT NULL,
  `neighborhood` VARCHAR(150) DEFAULT NULL,
  `base_lat` DECIMAL(10,7) DEFAULT NULL,
  `base_lng` DECIMAL(10,7) DEFAULT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_tracking_team_city` (`city`, `active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tracking_team_members` (
  `team_id` INT UNSIGNED NOT NULL,
  `technician_id` INT UNSIGNED NOT NULL,
  `role` VARCHAR(40) NOT NULL DEFAULT 'member',
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`team_id`, `technician_id`),
  INDEX `idx_tracking_member_tech` (`technician_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tracking_vehicles` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `plate` VARCHAR(20) DEFAULT NULL,
  `model` VARCHAR(120) DEFAULT NULL,
  `team_id` INT UNSIGNED DEFAULT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tracking_vehicle_plate` (`plate`),
  INDEX `idx_tracking_vehicle_team` (`team_id`, `active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `technicians` ADD COLUMN `city` VARCHAR(150) DEFAULT NULL;
ALTER TABLE `technicians` ADD COLUMN `neighborhood` VARCHAR(150) DEFAULT NULL;
ALTER TABLE `technicians` ADD COLUMN `available` TINYINT(1) NOT NULL DEFAULT 1;

ALTER TABLE `appointments` ADD COLUMN `tracking_team_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `appointments` ADD COLUMN `tracking_vehicle_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `appointments` ADD COLUMN `client_signature_url` VARCHAR(500) DEFAULT NULL;
ALTER TABLE `appointments` ADD COLUMN `client_signed_at` DATETIME DEFAULT NULL;
ALTER TABLE `appointments` ADD INDEX `idx_tracking_team` (`tracking_team_id`);
ALTER TABLE `appointments` ADD INDEX `idx_tracking_vehicle` (`tracking_vehicle_id`);

ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `active_key` VARCHAR(64) DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `team_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `vehicle_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `movement_status` VARCHAR(20) NOT NULL DEFAULT 'moving';
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `last_altitude` DECIMAL(10,2) DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `last_altitude_accuracy` DECIMAL(10,2) DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `max_speed` DECIMAL(10,2) DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `moving_seconds` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `idle_seconds` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `last_motion_at` DATETIME DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `last_route_at` DATETIME DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `last_route_lat` DECIMAL(10,7) DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `last_route_lng` DECIMAL(10,7) DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `route_geometry_json` LONGTEXT DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `route_changes` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `archive_json` LONGTEXT DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD COLUMN `archived_at` DATETIME DEFAULT NULL;
ALTER TABLE `appointment_tracking_sessions` ADD UNIQUE KEY `uk_tracking_active_key` (`active_key`);

ALTER TABLE `appointment_location_points` ADD COLUMN `sample_uuid` VARCHAR(64) DEFAULT NULL;
ALTER TABLE `appointment_location_points` ADD COLUMN `altitude` DECIMAL(10,2) DEFAULT NULL;
ALTER TABLE `appointment_location_points` ADD COLUMN `altitude_accuracy` DECIMAL(10,2) DEFAULT NULL;
ALTER TABLE `appointment_location_points` ADD UNIQUE KEY `uk_tracking_sample_uuid` (`sample_uuid`);

ALTER TABLE `tracking_analytics_daily` ADD COLUMN `team_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `tracking_analytics_daily` ADD COLUMN `technician_id` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `tracking_analytics_daily` ADD COLUMN `max_speed` DECIMAL(10,2) DEFAULT NULL;
ALTER TABLE `tracking_analytics_daily` ADD COLUMN `moving_seconds` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `tracking_analytics_daily` ADD COLUMN `route_changes` INT UNSIGNED NOT NULL DEFAULT 0;
