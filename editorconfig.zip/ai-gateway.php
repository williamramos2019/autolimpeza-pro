<?php
/**
 * AI Gateway — camada central de roteamento, failover, cache e métricas.
 * Todos os módulos generativos devem usar AIGateway::chat().
 */

// ── Criptografia de chaves ────────────────────────────────────────────────

function aiGatewayEncryptionKey(): string {
    if (defined('AI_GATEWAY_ENCRYPTION_KEY') && AI_GATEWAY_ENCRYPTION_KEY !== '') {
        return hash('sha256', (string) AI_GATEWAY_ENCRYPTION_KEY, true);
    }
    if (function_exists('mailEncryptionKey')) {
        return mailEncryptionKey();
    }
    $parts = [];
    if (defined('DB_NAME') && DB_NAME !== '') $parts[] = DB_NAME;
    if (defined('DB_PASS') && DB_PASS !== '') $parts[] = DB_PASS;
    if (defined('ADMIN_TOKEN') && ADMIN_TOKEN !== '') $parts[] = ADMIN_TOKEN;
    return hash('sha256', $parts ? implode('|', $parts) : 'autolimpezapro-ai-gateway', true);
}

function encryptAiSecret(string $plain): string {
    if ($plain === '') return '';
    $iv  = random_bytes(16);
    $enc = openssl_encrypt($plain, 'AES-256-CBC', aiGatewayEncryptionKey(), OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $enc);
}

function decryptAiSecret(string $stored): string {
    if ($stored === '') return '';
    $raw = base64_decode($stored, true);
    if ($raw === false || strlen($raw) < 17) return '';
    $iv  = substr($raw, 0, 16);
    $enc = substr($raw, 16);
    $dec = openssl_decrypt($enc, 'AES-256-CBC', aiGatewayEncryptionKey(), OPENSSL_RAW_DATA, $iv);
    if ($dec === false || $dec === '') return '';
    // Chave de criptografia trocada → lixo binário; não usar como API key.
    if (!preg_match('/^[\x20-\x7E]+$/', $dec)) {
        return '';
    }
    return $dec;
}

/** Formato mínimo aceitável por tipo (evita sync preso em decrypt lixo tipo "IProvi…"). */
function aiGatewayIsPlausibleApiKey(string $type, string $key): bool {
    $key = trim($key);
    if ($key === '' || strlen($key) < 12) {
        return false;
    }
    if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $key)) {
        return false;
    }
    return match ($type) {
        'openai', 'openai_compatible' => function_exists('isValidOpenAiApiKey')
            ? isValidOpenAiApiKey($key)
            : str_starts_with($key, 'sk-'),
        'gemini' => function_exists('isValidGeminiApiKey')
            ? isValidGeminiApiKey($key)
            : (bool) preg_match('/^(AIza|AQ\.)/i', $key),
        'anthropic' => str_starts_with($key, 'sk-ant-'),
        'openrouter' => str_starts_with($key, 'sk-or-') || strlen($key) >= 20,
        default => (bool) preg_match('/^[A-Za-z0-9_\-\.\/\+=:]{16,}$/', $key),
    };
}

function aiGatewayKeyPreview(?string $key): ?string {
    if (!$key || $key === '') return null;
    if (strlen($key) <= 12) return str_repeat('•', strlen($key));
    return mb_substr($key, 0, 6) . '…' . mb_substr($key, -4);
}

/**
 * Normaliza chave de API para string (nunca null).
 * sanSecret() devolve null para vazio — sem normalizar, `$apiKey === ''` falha e
 * TypeError estoura em AIProviderAdapter::complete(string $apiKey, ...).
 *
 * @param string|null $fromRequest valor já passado por sanSecret (ou raw)
 * @param string|null $encStored   api_key_enc do banco (opcional)
 * @param string|null $providerType tipo para fallback em site_config/config.php
 */
function aiGatewayNormalizeApiKey(?string $fromRequest = null, ?string $encStored = null, ?string $providerType = null): string {
    $key = '';
    if ($fromRequest !== null) {
        if (function_exists('sanSecret')) {
            $key = sanSecret($fromRequest) ?? '';
        } else {
            $key = trim($fromRequest);
        }
    }
    if ($key === '' && $encStored !== null && $encStored !== '') {
        $key = decryptAiSecret((string) $encStored);
        if ($providerType && $key !== '' && !aiGatewayIsPlausibleApiKey($providerType, $key)) {
            $key = '';
        }
    }
    if ($key === '' && $providerType && function_exists('aiConfigKey')) {
        $key = (string) (aiConfigKey($providerType) ?? '');
    }
    return is_string($key) ? $key : '';
}

// ── Schema ────────────────────────────────────────────────────────────────

function ensureAiGatewayTables(PDO $pdo): void {
    static $verified = false;
    if ($verified) return;

    $required = ['ai_providers', 'ai_gateway_logs', 'ai_module_routing', 'ai_prompts'];
    $allExist = static function () use ($pdo, $required): bool {
        foreach ($required as $tbl) {
            try {
                $pdo->query("SELECT 1 FROM `{$tbl}` LIMIT 1");
            } catch (Throwable $e) {
                return false;
            }
        }
        return true;
    };

    if (!$allExist()) {
        alpRunSqlMigration($pdo, __DIR__ . '/migrations/ai_gateway_v1.sql');
    }

    if ($allExist()) {
        aiGatewaySeedDefaults($pdo);
        aiGatewaySyncProviderKeysFromConfig($pdo);
        aiGatewayRetireDeadModels($pdo);
        $verified = true;
    }
}

/**
 * Substitui modelos descontinuados (Gemini 1.5/2.0 desligados pelo Google em
 * 2025/2026) gravados no banco por equivalentes ativos. Idempotente.
 */
function aiGatewayRetireDeadModels(PDO $pdo): void {
    $dead = [
        'gemini-1.5-flash', 'gemini-1.5-flash-8b', 'gemini-1.5-pro',
        'gemini-2.0-flash', 'gemini-2.0-flash-001',
        'gemini-2.0-flash-lite', 'gemini-2.0-flash-lite-001',
        'google/gemini-2.0-flash-exp:free',
    ];
    try {
        $ph = implode(',', array_fill(0, count($dead), '?'));
        // Provedor Gemini: limpa modelo morto → volta a usar a cadeia de fallback.
        $pdo->prepare("UPDATE ai_providers SET model = NULL, updated_at = ? WHERE provider_type = 'gemini' AND model IN ($ph)")
            ->execute(array_merge([dbNow()], $dead));
        // OpenRouter: modelo gratuito ativo escolhido automaticamente pela plataforma.
        $pdo->prepare("UPDATE ai_providers SET model = ?, updated_at = ? WHERE provider_type = 'openrouter' AND model IN ($ph)")
            ->execute(array_merge(['openrouter/free', dbNow()], $dead));
        // Modelo preferido do painel (site_config) apontando para modelo morto.
        $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'gemini_model' LIMIT 1");
        $stmt->execute();
        $stored = trim((string)($stmt->fetchColumn() ?: ''));
        if ($stored !== '' && in_array($stored, $dead, true) && function_exists('siteConfigSet')) {
            siteConfigSet($pdo, 'gemini_model', 'gemini-3.5-flash');
        }
    } catch (Throwable $e) {
        // limpeza nunca bloqueia o gateway
    }
}

/** Espelha chave salva no painel para site_config (usada quando a const do config.php está vazia). */
function aiGatewayMirrorKeyToSiteConfig(PDO $pdo, string $type, string $apiKey): void {
    $map = [
        'gemini'     => 'gemini_key',
        'openai'     => 'openai_key',
        'openrouter' => 'openrouter_key',
        'deepseek'   => 'deepseek_key',
        'groq'       => 'groq_key',
    ];
    $keyName = $map[$type] ?? null;
    if (!$keyName || $apiKey === '' || !function_exists('siteConfigSet')) {
        return;
    }
    try {
        siteConfigSet($pdo, $keyName, $apiKey);
    } catch (Throwable $e) { /* espelho nunca bloqueia */ }
}

/** Sincroniza chaves de config.php / site_config → ai_providers (criptografadas).
 * @param string|null $forceType Se definido (ex.: openai), sobrescreve TODAS as linhas desse tipo.
 */
function aiGatewaySyncProviderKeysFromConfig(PDO $pdo, ?string $forceType = null): void {
    if (!function_exists('aiConfigKey')) {
        return;
    }
    if (function_exists('ensureGeminiKeyFromConfig')) {
        ensureGeminiKeyFromConfig($pdo);
    }

    $typeToConfig = [
        'gemini'     => 'gemini',
        'openai'     => 'openai',
        'openrouter' => 'openrouter',
        'deepseek'   => 'deepseek',
        'groq'       => 'groq',
    ];

    $now = dbNow();
    foreach ($typeToConfig as $type => $configKey) {
        $key = aiConfigKey($configKey);
        if (!$key) {
            continue;
        }
        if (!aiGatewayIsPlausibleApiKey($type, $key)) {
            continue;
        }
        $enc = encryptAiSecret($key);
        try {
            if ($forceType !== null && $forceType === $type) {
                $pdo->prepare(
                    'UPDATE ai_providers SET api_key_enc = ?, enabled = 1, last_error = NULL, updated_at = ? WHERE provider_type = ?'
                )->execute([$enc, $now, $type]);
                $cntStmt = $pdo->prepare('SELECT COUNT(*) FROM ai_providers WHERE provider_type = ?');
                $cntStmt->execute([$type]);
                if ((int) $cntStmt->fetchColumn() === 0) {
                    $pdo->prepare(
                        'INSERT INTO ai_providers (name, provider_type, api_key_enc, base_url, model, priority, weight, timeout_sec, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)'
                    )->execute([
                        ucfirst($type) . ' Primary',
                        $type,
                        $enc,
                        aiGatewayDefaultBaseUrl($type),
                        aiGatewayDefaultModel($type),
                        $type === 'gemini' ? 10 : 50,
                        1,
                        90,
                        1,
                        $now,
                        $now,
                    ]);
                }
                continue;
            }

            $stmt = $pdo->prepare(
                'SELECT id, api_key_enc FROM ai_providers WHERE provider_type = ? ORDER BY priority ASC, id ASC'
            );
            $stmt->execute([$type]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if ($rows) {
                foreach ($rows as $row) {
                    $existing = decryptAiSecret((string) ($row['api_key_enc'] ?? ''));
                    // Vazia OU ilegível (criptografia antiga / lixo) → regrava a partir do config.
                    if ($existing === '' || !aiGatewayIsPlausibleApiKey($type, $existing)) {
                        $pdo->prepare(
                            'UPDATE ai_providers SET api_key_enc = ?, enabled = 1, last_error = NULL, updated_at = ? WHERE id = ?'
                        )->execute([$enc, $now, (int) $row['id']]);
                    }
                }
            } else {
                $pdo->prepare(
                    'INSERT INTO ai_providers (name, provider_type, api_key_enc, base_url, model, priority, weight, timeout_sec, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)'
                )->execute([
                    ucfirst($type) . ' Primary',
                    $type,
                    $enc,
                    aiGatewayDefaultBaseUrl($type),
                    aiGatewayDefaultModel($type),
                    $type === 'gemini' ? 10 : 50,
                    1,
                    90,
                    1,
                    $now,
                    $now,
                ]);
            }
        } catch (Throwable $e) {
            // diagnóstico / gateway continua com fallback aiConfigKey()
        }
    }
}

function aiGatewaySeedDefaults(PDO $pdo): void {
    $count = (int)$pdo->query('SELECT COUNT(*) FROM ai_providers')->fetchColumn();
    if ($count === 0) {
        aiGatewaySeedProvidersFromConfig($pdo);
    }
    $routingCount = (int)$pdo->query('SELECT COUNT(*) FROM ai_module_routing')->fetchColumn();
    if ($routingCount === 0) {
        $now = dbNow();
        $defaults = [
            ['capitao', 'priority', 120],
            ['blog', 'priority', 0],
            ['logs', 'priority', 60],
            ['chat', 'round_robin', 120],
            ['seo', 'priority', 120],
            ['prospeccao', 'priority', 0],
            ['default', 'priority', 120],
        ];
        $ins = $pdo->prepare('INSERT INTO ai_module_routing (module_key, strategy, preferred_provider_id, cache_ttl_sec, updated_at) VALUES (?,?,?,?,?)');
        foreach ($defaults as [$mod, $strat, $ttl]) {
            $ins->execute([$mod, $strat, null, $ttl, $now]);
        }
    }
}

function aiGatewaySeedProvidersFromConfig(PDO $pdo): void {
    if (!function_exists('aiConfigKey')) return;

    $seeds = [
        ['Gemini Primary', 'gemini', 'gemini', 10, null, 90],
        ['OpenRouter', 'openrouter', 'openrouter', 20, 'openrouter/free', 60],
        ['DeepSeek', 'deepseek', 'deepseek', 30, 'deepseek-chat', 60],
        ['Groq', 'groq', 'groq', 40, 'llama-3.1-8b-instant', 45],
        ['OpenAI', 'openai', 'openai', 50, 'gpt-4o-mini', 90],
    ];

    $now = dbNow();
    $ins = $pdo->prepare('INSERT INTO ai_providers (name, provider_type, api_key_enc, base_url, model, priority, weight, timeout_sec, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)');

    foreach ($seeds as [$name, $type, $configKey, $prio, $model, $timeout]) {
        $key = aiConfigKey($configKey);
        if (!$key) continue;
        $enc = encryptAiSecret($key);
        $baseUrl = aiGatewayDefaultBaseUrl($type);
        $ins->execute([$name, $type, $enc, $baseUrl, $model, $prio, 1, $timeout, 1, $now, $now]);
    }
}

function aiGatewayDefaultBaseUrl(string $type): ?string {
    $map = [
        'openai'            => 'https://api.openai.com/v1',
        'openrouter'        => 'https://openrouter.ai/api/v1',
        'deepseek'          => 'https://api.deepseek.com',
        'groq'              => 'https://api.groq.com/openai/v1',
        'anthropic'         => 'https://api.anthropic.com/v1',
        'mistral'           => 'https://api.mistral.ai/v1',
        'together'          => 'https://api.together.xyz/v1',
        'cerebras'          => 'https://api.cerebras.ai/v1',
        'gemini'            => null,
        'openai_compatible' => null,
    ];
    return $map[$type] ?? null;
}

function aiGatewayDefaultModel(string $type): string {
    $map = [
        'gemini'     => 'gemini-3.5-flash',
        'openai'     => 'gpt-4o-mini',
        'openrouter' => 'openrouter/free',
        'deepseek'   => 'deepseek-chat',
        'groq'       => 'llama-3.1-8b-instant',
        'anthropic'  => 'claude-3-5-haiku-latest',
        'mistral'    => 'mistral-small-latest',
        'together'   => 'meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo',
        'cerebras'   => 'llama3.1-8b',
    ];
    return $map[$type] ?? 'gpt-4o-mini';
}

// ── Gateway ───────────────────────────────────────────────────────────────

class AIGateway {
    /** @var array<string,int> round-robin cursor per module */
    private static array $rrIndex = [];

    /** @var array<string,array{ms:int,at:int}> in-memory latency hints */
    private static array $latencyHints = [];

    /**
     * @param array{system?:string,user?:string,maxTokens?:int,module?:string,temperature?:float,json?:bool,timeout?:int,skipCache?:bool,provider_id?:int} $opts
     * @return array{status:string,provider:?string,model:?string,content:?string,finish_reason:?string,usage:?array,latency_ms:int,tokens_input:?int,tokens_output:?int,timestamp:string,error?:string,cached?:bool}
     */
    public static function chat(array $opts): array {
        $started   = microtime(true);
        $system    = (string)($opts['system'] ?? '');
        $user      = (string)($opts['user'] ?? '');
        $maxTokens = (int)($opts['maxTokens'] ?? 1024);
        $module    = san((string)($opts['module'] ?? 'default'), 40) ?? 'default';
        $temperature = (float)($opts['temperature'] ?? 0.65);
        $jsonMode  = !empty($opts['json']);
        $skipCache = !empty($opts['skipCache']);
        $timestamp = date('c');

        if ($system === '' && $user === '') {
            return self::errorResult('Prompt vazio', $started, $timestamp);
        }

        $pdo = null;
        try {
            $pdo = db();
            ensureAiGatewayTables($pdo);
        } catch (Throwable $e) {
            return self::legacyFallback($system, $user, $maxTokens, $temperature, $jsonMode, $opts, $started, $timestamp, $module);
        }

        $routing = self::getModuleRouting($pdo, $module);
        $cacheTtl = (int)($routing['cache_ttl_sec'] ?? 120);

        if (!$skipCache && $cacheTtl > 0) {
            $cached = self::readCache($module, $system, $user, $maxTokens, $temperature, $jsonMode, $cacheTtl);
            if ($cached !== null) {
                $cached['cached'] = true;
                $cached['latency_ms'] = (int) round((microtime(true) - $started) * 1000);
                return $cached;
            }
        }

        $providers = self::loadProviders($pdo, $routing, $opts);
        if (!$providers) {
            return self::legacyFallback($system, $user, $maxTokens, $temperature, $jsonMode, $opts, $started, $timestamp, $module);
        }

        $failoverAttempts = [];
        $lastError = 'Nenhum provedor de IA disponível. Configure chaves no AI Gateway ou em Configurações.';

        foreach ($providers as $row) {
            $providerName = (string)$row['name'];
            $type         = (string)$row['provider_type'];
            $apiKey = aiGatewayNormalizeApiKey(
                null,
                (string)($row['api_key_enc'] ?? ''),
                $type
            );
            if ($apiKey === '') {
                $failoverAttempts[] = ['provider' => $providerName, 'error' => 'sem_chave'];
                continue;
            }

            $adapterOpts = [
                'temperature' => $temperature,
                'json'        => $jsonMode,
                'timeout'     => (int)($opts['timeout'] ?? $row['timeout_sec'] ?? 90),
                'model'       => $row['model'] ?: aiGatewayDefaultModel($type),
                'base_url'    => $row['base_url'] ?: aiGatewayDefaultBaseUrl($type),
            ];

            $t0 = microtime(true);
            try {
                $result = AIProviderAdapter::complete($type, $apiKey, $system, $user, $maxTokens, $adapterOpts);
            } catch (Throwable $e) {
                $ms = (int) round((microtime(true) - $t0) * 1000);
                $errCode = self::classifyError(0, $e->getMessage());
                $failoverAttempts[] = ['provider' => $providerName, 'type' => $type, 'error' => $e->getMessage(), 'code' => $errCode];
                self::updateProviderStats($pdo, (int)$row['id'], false, $ms, $e->getMessage());
                $lastError = $e->getMessage();
                continue;
            }

            $ms = (int) round((microtime(true) - $t0) * 1000);
            self::recordLatencyHint($module, $providerName, $ms);

            if (($result['ok'] ?? false) && !empty($result['content'])) {
                $normalized = [
                    'status'        => 'ok',
                    'provider'      => $providerName,
                    'model'         => $result['model'] ?? $adapterOpts['model'],
                    'content'       => $result['content'],
                    'finish_reason' => $result['finish_reason'] ?? 'stop',
                    'usage'         => $result['usage'] ?? null,
                    'latency_ms'    => (int) round((microtime(true) - $started) * 1000),
                    'tokens_input'  => $result['tokens_input'] ?? null,
                    'tokens_output' => $result['tokens_output'] ?? null,
                    'timestamp'     => $timestamp,
                ];
                self::updateProviderStats($pdo, (int)$row['id'], true, $ms, null);
                self::logRequest($pdo, $module, $system, $user, $normalized, 'ok', null, $failoverAttempts);
                if ($cacheTtl > 0 && !$skipCache) {
                    self::writeCache($module, $system, $user, $maxTokens, $temperature, $jsonMode, $normalized, $cacheTtl);
                }
                return $normalized;
            }

            $httpCode = (int)($result['http_code'] ?? 0);
            $errMsg   = (string)($result['error'] ?? 'resposta vazia');
            $errCode  = self::classifyError($httpCode, $errMsg);
            $failoverAttempts[] = ['provider' => $providerName, 'type' => $type, 'http' => $httpCode, 'error' => $errMsg, 'code' => $errCode];
            self::updateProviderStats($pdo, (int)$row['id'], false, $ms, $errMsg);
            $lastError = $errMsg;

            if (in_array($errCode, ['auth', 'forbidden'], true)) {
                continue;
            }
        }

        $failResult = self::errorResult(
            'Todos os provedores de IA falharam. ' . $lastError,
            $started,
            $timestamp,
            $failoverAttempts
        );
        self::logRequest($pdo, $module, $system, $user, $failResult, 'error', $failoverAttempts[count($failoverAttempts) - 1]['code'] ?? 'all_failed', $failoverAttempts);
        return $failResult;
    }

    /** @return array<string,mixed> */
    private static function getModuleRouting(PDO $pdo, string $module): array {
        ensureAiGatewayTables($pdo);
        try {
            $stmt = $pdo->prepare('SELECT * FROM ai_module_routing WHERE module_key = ? LIMIT 1');
            $stmt->execute([$module]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) return $row;
            $stmt->execute(['default']);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ?: ['strategy' => 'priority', 'cache_ttl_sec' => 120, 'preferred_provider_id' => null];
        } catch (Throwable $e) {
            return ['strategy' => 'priority', 'cache_ttl_sec' => 120, 'preferred_provider_id' => null];
        }
    }

    /** @return array<int,array<string,mixed>> */
    private static function loadProviders(PDO $pdo, array $routing, array $opts): array {
        ensureAiGatewayTables($pdo);
        try {
            $rows = $pdo->query('SELECT * FROM ai_providers WHERE enabled = 1 ORDER BY priority ASC, id ASC')->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            return [];
        }
        if (!$rows) return [];

        $prefId = (int)($opts['provider_id'] ?? $routing['preferred_provider_id'] ?? 0);
        if ($prefId > 0) {
            $pref = array_values(array_filter($rows, fn($r) => (int)$r['id'] === $prefId));
            $rest = array_values(array_filter($rows, fn($r) => (int)$r['id'] !== $prefId));
            $rows = array_merge($pref, $rest);
        }

        $strategy = (string)($routing['strategy'] ?? 'priority');
        if ($strategy === 'lowest_latency') {
            usort($rows, function ($a, $b) {
                $la = (int)($a['avg_latency_ms'] ?? 999999);
                $lb = (int)($b['avg_latency_ms'] ?? 999999);
                if ($la === $lb) return (int)$a['priority'] <=> (int)$b['priority'];
                return $la <=> $lb;
            });
        } elseif ($strategy === 'round_robin' && count($rows) > 1) {
            $mod = (string)($opts['module'] ?? 'default');
            $idx = self::$rrIndex[$mod] ?? 0;
            $rotated = [];
            for ($i = 0; $i < count($rows); $i++) {
                $rotated[] = $rows[($idx + $i) % count($rows)];
            }
            self::$rrIndex[$mod] = ($idx + 1) % count($rows);
            $rows = $rotated;
        }

        return $rows;
    }

    public static function classifyError(int $httpCode, string $message): string {
        $m = strtolower($message);
        if ($httpCode === 401) return 'auth';
        if ($httpCode === 403) return 'forbidden';
        if ($httpCode === 404) return 'not_found';
        if ($httpCode === 408) return 'timeout';
        if ($httpCode === 429) return 'rate_limit';
        if (in_array($httpCode, [500, 502, 503, 504], true)) return 'server_error';
        if (str_contains($m, 'timeout') || str_contains($m, 'timed out')) return 'timeout';
        if (str_contains($m, 'rate limit') || str_contains($m, 'quota')) return 'rate_limit';
        if (str_contains($m, 'resposta vazia') || str_contains($m, 'empty')) return 'empty_response';
        return $httpCode > 0 ? 'http_' . $httpCode : 'connection';
    }

    private static function recordLatencyHint(string $module, string $provider, int $ms): void {
        self::$latencyHints[$module . ':' . $provider] = ['ms' => $ms, 'at' => time()];
    }

    private static function updateProviderStats(PDO $pdo, int $id, bool $ok, int $ms, ?string $error): void {
        try {
            if ($ok) {
                $pdo->prepare('UPDATE ai_providers SET last_used_at = ?, avg_latency_ms = COALESCE(ROUND((COALESCE(avg_latency_ms,?) + ?) / 2), ?), last_error = NULL, updated_at = ? WHERE id = ?')
                    ->execute([dbNow(), $ms, $ms, $ms, dbNow(), $id]);
            } else {
                $pdo->prepare('UPDATE ai_providers SET last_error = ?, updated_at = ? WHERE id = ?')
                    ->execute([mb_substr((string)$error, 0, 500), dbNow(), $id]);
            }
        } catch (Throwable $e) { /* */ }
    }

    private static function logRequest(PDO $pdo, string $module, string $system, string $user, array $result, string $status, ?string $errorCode, array $failover): void {
        try {
            $hash = hash('sha256', $module . '|' . $system . '|' . $user);
            $pdo->prepare('INSERT INTO ai_gateway_logs (module, prompt_hash, provider, model, latency_ms, tokens_in, tokens_out, status, error_code, failover_attempts, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([
                    $module,
                    $hash,
                    $result['provider'] ?? null,
                    $result['model'] ?? null,
                    $result['latency_ms'] ?? null,
                    $result['tokens_input'] ?? null,
                    $result['tokens_output'] ?? null,
                    $status,
                    $errorCode,
                    $failover ? json_encode($failover, JSON_UNESCAPED_UNICODE) : null,
                    dbNow(),
                ]);
        } catch (Throwable $e) { /* */ }
    }

    private static function cacheDir(): string {
        $dir = __DIR__ . '/cache/ai_gateway';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        return $dir;
    }

    private static function cacheKey(string $module, string $system, string $user, int $maxTokens, float $temp, bool $json): string {
        return hash('sha256', json_encode([$module, $system, $user, $maxTokens, $temp, $json]));
    }

    private static function readCache(string $module, string $system, string $user, int $maxTokens, float $temp, bool $json, int $ttl): ?array {
        $file = self::cacheDir() . '/' . self::cacheKey($module, $system, $user, $maxTokens, $temp, $json) . '.json';
        if (!is_file($file)) return null;
        if (filemtime($file) < time() - $ttl) {
            @unlink($file);
            return null;
        }
        $data = json_decode((string)file_get_contents($file), true);
        return is_array($data) ? $data : null;
    }

    private static function writeCache(string $module, string $system, string $user, int $maxTokens, float $temp, bool $json, array $result, int $ttl): void {
        $file = self::cacheDir() . '/' . self::cacheKey($module, $system, $user, $maxTokens, $temp, $json) . '.json';
        @file_put_contents($file, json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    public static function clearCache(): void {
        $dir = self::cacheDir();
        if (!is_dir($dir)) return;
        foreach (glob($dir . '/*.json') ?: [] as $f) {
            @unlink($f);
        }
    }

    /** Métricas agregadas dos últimos 7 dias (computadas de ai_gateway_logs). */
    public static function metrics(PDO $pdo, int $days = 7): array {
        ensureAiGatewayTables($pdo);
        $since = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        try {
            $totals = $pdo->prepare("SELECT COUNT(*) AS total,
                SUM(status = 'ok') AS ok_count,
                SUM(status != 'ok') AS err_count,
                AVG(latency_ms) AS avg_latency,
                SUM(tokens_in) AS tokens_in,
                SUM(tokens_out) AS tokens_out
                FROM ai_gateway_logs WHERE created_at >= ?");
            $totals->execute([$since]);
            $t = $totals->fetch(PDO::FETCH_ASSOC) ?: [];

            $byProvider = $pdo->prepare("SELECT provider, COUNT(*) AS calls, SUM(status='ok') AS ok_count, AVG(latency_ms) AS avg_latency FROM ai_gateway_logs WHERE created_at >= ? GROUP BY provider ORDER BY calls DESC");
            $byProvider->execute([$since]);
            $byModule = $pdo->prepare("SELECT module, COUNT(*) AS calls, SUM(status='ok') AS ok_count FROM ai_gateway_logs WHERE created_at >= ? GROUP BY module ORDER BY calls DESC");
            $byModule->execute([$since]);

            $providers = $pdo->query('SELECT id, name, provider_type, model, priority, enabled, avg_latency_ms, last_used_at, last_error FROM ai_providers ORDER BY priority ASC')->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            $t = [];
            $byProvider = null;
            $byModule = null;
            $providers = [];
        }

        return [
            'periodDays'   => $days,
            'totalCalls'   => (int)($t['total'] ?? 0),
            'successRate'  => ($t['total'] ?? 0) > 0 ? round(100 * (int)($t['ok_count'] ?? 0) / (int)$t['total'], 1) : 0,
            'avgLatencyMs' => $t['avg_latency'] ? (int)round((float)$t['avg_latency']) : null,
            'tokensIn'     => (int)($t['tokens_in'] ?? 0),
            'tokensOut'    => (int)($t['tokens_out'] ?? 0),
            'byProvider'   => $byProvider ? $byProvider->fetchAll(PDO::FETCH_ASSOC) : [],
            'byModule'     => $byModule ? $byModule->fetchAll(PDO::FETCH_ASSOC) : [],
            'providers'    => $providers,
            'schemaOk'     => !empty($providers) || ($t['total'] ?? 0) > 0,
        ];
    }

    private static function errorResult(string $error, float $started, string $timestamp, array $failover = []): array {
        return [
            'status'        => 'error',
            'provider'      => null,
            'model'         => null,
            'content'       => null,
            'finish_reason' => null,
            'usage'         => null,
            'latency_ms'    => (int) round((microtime(true) - $started) * 1000),
            'tokens_input'  => null,
            'tokens_output' => null,
            'timestamp'     => $timestamp,
            'error'         => $error,
            'failover'      => $failover,
        ];
    }

    /** Fallback legado quando tabelas gateway indisponíveis. */
    private static function legacyFallback(string $system, string $user, int $maxTokens, float $temperature, bool $json, array $opts, float $started, string $timestamp, string $module): array {
        if (!class_exists('GeminiService')) {
            require_once __DIR__ . '/gemini-service.php';
        }
        $r = GeminiService::generateDirect($system, $user, $maxTokens, [
            'temperature' => $temperature,
            'json'        => $json,
            'timeout'     => $opts['timeout'] ?? 90,
        ]);
        if ($r['ok'] ?? false) {
            return [
                'status'        => 'ok',
                'provider'      => 'gemini',
                'model'         => $r['model'] ?? null,
                'content'       => $r['text'] ?? null,
                'finish_reason' => 'stop',
                'usage'         => null,
                'latency_ms'    => (int) round((microtime(true) - $started) * 1000),
                'tokens_input'  => null,
                'tokens_output' => $r['tokens'] ?? null,
                'timestamp'     => $timestamp,
            ];
        }
        return self::errorResult((string)($r['error'] ?? 'IA indisponível'), $started, $timestamp);
    }
}

/**
 * Adaptadores HTTP por tipo de provedor — usados internamente pelo gateway.
 */
class AIProviderAdapter {
    /**
     * @param array{temperature?:float,json?:bool,timeout?:int,model?:string,base_url?:?string} $opts
     * @return array{ok:bool,content:?string,model:?string,finish_reason:?string,usage:?array,tokens_input:?int,tokens_output:?int,http_code?:int,error?:string}
     */
    public static function complete(string $type, string $apiKey, string $system, string $user, int $maxTokens, array $opts = []): array {
        if (trim($apiKey) === '') {
            return [
                'ok'            => false,
                'content'       => null,
                'model'         => null,
                'finish_reason' => null,
                'usage'         => null,
                'tokens_input'  => null,
                'tokens_output' => null,
                'http_code'     => 0,
                'error'         => 'Chave API ausente — configure no AI Gateway ou em Configurações.',
            ];
        }
        return match ($type) {
            'gemini' => self::gemini($apiKey, $system, $user, $maxTokens, $opts),
            'anthropic' => self::anthropic($apiKey, $system, $user, $maxTokens, $opts),
            default => self::openAiCompatible($type, $apiKey, $system, $user, $maxTokens, $opts),
        };
    }

    /** @param array{temperature?:float,json?:bool,timeout?:int,model?:string,single_model?:bool} $opts */
    private static function gemini(string $apiKey, string $system, string $user, int $maxTokens, array $opts): array {
        if (!class_exists('GeminiService')) {
            require_once __DIR__ . '/gemini-service.php';
        }
        // single_model: teste/diagnóstico rápido — 1 modelo só, sem varrer o fallback
        // (a cadeia completa em host compartilhado estoura max_execution_time → HTTP 500).
        if (!empty($opts['single_model'])) {
            $requested = trim((string)($opts['model'] ?? ''));
            $models = [$requested !== '' ? $requested : (GeminiService::resolveModels()[0] ?? 'gemini-3.5-flash')];
        } else {
            $models = GeminiService::resolveModels();
        }
        $temperature = (float)($opts['temperature'] ?? 0.65);
        $timeout     = (int)($opts['timeout'] ?? 90);
        $jsonMode    = !empty($opts['json']);

        $payloadArr = [
            'systemInstruction' => ['parts' => [['text' => $system]]],
            'contents'          => [['role' => 'user', 'parts' => [['text' => $user]]]],
            'generationConfig'  => ['temperature' => $temperature, 'maxOutputTokens' => $maxTokens],
        ];
        if ($jsonMode) {
            $payloadArr['generationConfig']['responseMimeType'] = 'application/json';
        }
        $payload = json_encode($payloadArr, JSON_UNESCAPED_UNICODE);
        $lastErr = 'Sem resposta Gemini';
        $lastCode = 0;

        foreach ($models as $model) {
            $modelAttempts = 0;
            $maxRetry = 2;

            while ($modelAttempts <= $maxRetry) {
                $modelAttempts++;
                try {
                    $res = aiHttpPost(geminiGenerateContentUrl($model), geminiApiHeaders($apiKey), $payload, $timeout);
                } catch (Throwable $e) {
                    $lastErr = $e->getMessage();
                    $lastCode = 0;
                    break;
                }

                $code = (int)$res['code'];
                $lastCode = $code;
                $parsed = json_decode((string)$res['body'], true);

                if ($code === 200) {
                    $text = self::extractGeminiText($parsed);
                    if ($text !== '') {
                        $usage = $parsed['usageMetadata'] ?? null;
                        return [
                            'ok' => true, 'content' => $text, 'model' => $model, 'finish_reason' => 'stop',
                            'usage' => $usage, 'tokens_input' => $usage['promptTokenCount'] ?? null,
                            'tokens_output' => $usage['candidatesTokenCount'] ?? null, 'http_code' => 200,
                        ];
                    }
                    $lastErr = 'resposta vazia';
                    break;
                }

                $apiErr = is_array($parsed) ? ($parsed['error']['message'] ?? null) : null;
                $lastErr = is_string($apiErr) && $apiErr !== '' ? $apiErr : "HTTP {$code}";

                if (in_array($code, [401, 403], true)) {
                    return ['ok' => false, 'content' => null, 'model' => $model, 'finish_reason' => null, 'usage' => null, 'tokens_input' => null, 'tokens_output' => null, 'http_code' => $code, 'error' => $lastErr];
                }
                if (in_array($code, [500, 502, 503, 504], true) && $modelAttempts <= $maxRetry) {
                    usleep(400000 * $modelAttempts);
                    continue;
                }
                if ($code === 429) {
                    usleep(500000 * $modelAttempts);
                    break;
                }
                if ($code === 404 || $code === 400) {
                    break;
                }
                break;
            }
        }

        return ['ok' => false, 'content' => null, 'model' => null, 'finish_reason' => null, 'usage' => null, 'tokens_input' => null, 'tokens_output' => null, 'http_code' => $lastCode, 'error' => $lastErr];
    }

    /** @param array{temperature?:float,json?:bool,timeout?:int,model?:string,base_url?:?string} $opts */
    private static function openAiCompatible(string $type, string $apiKey, string $system, string $user, int $maxTokens, array $opts): array {
        $model = (string)($opts['model'] ?? aiGatewayDefaultModel($type));
        $base  = rtrim((string)($opts['base_url'] ?? aiGatewayDefaultBaseUrl($type) ?? 'https://api.openai.com/v1'), '/');
        $url   = str_ends_with($base, '/chat/completions') ? $base : $base . '/chat/completions';
        $timeout = (int)($opts['timeout'] ?? 60);

        $body = [
            'model' => $model,
            'max_tokens' => $maxTokens,
            'temperature' => (float)($opts['temperature'] ?? 0.65),
            'messages' => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => $user],
            ],
        ];
        if (!empty($opts['json'])) {
            $body['response_format'] = ['type' => 'json_object'];
        }

        $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey];
        if ($type === 'openrouter') {
            $headers[] = 'HTTP-Referer: ' . (defined('SITE_URL') ? SITE_URL : 'https://autolimpezapro.com.br');
        }

        try {
            $res = aiHttpPost($url, $headers, json_encode($body, JSON_UNESCAPED_UNICODE), $timeout);
        } catch (Throwable $e) {
            return ['ok' => false, 'content' => null, 'model' => $model, 'finish_reason' => null, 'usage' => null, 'tokens_input' => null, 'tokens_output' => null, 'http_code' => 0, 'error' => $e->getMessage()];
        }

        $code = (int)$res['code'];
        $data = json_decode((string)$res['body'], true);
        if ($code !== 200) {
            $err = is_array($data) ? ($data['error']['message'] ?? $data['error'] ?? "HTTP {$code}") : "HTTP {$code}";
            return ['ok' => false, 'content' => null, 'model' => $model, 'finish_reason' => null, 'usage' => null, 'tokens_input' => null, 'tokens_output' => null, 'http_code' => $code, 'error' => is_string($err) ? $err : json_encode($err)];
        }

        $content = trim((string)($data['choices'][0]['message']['content'] ?? ''));
        $usage   = $data['usage'] ?? null;
        return [
            'ok' => $content !== '', 'content' => $content ?: null, 'model' => $data['model'] ?? $model,
            'finish_reason' => $data['choices'][0]['finish_reason'] ?? 'stop', 'usage' => $usage,
            'tokens_input' => $usage['prompt_tokens'] ?? null, 'tokens_output' => $usage['completion_tokens'] ?? null,
            'http_code' => $code, 'error' => $content === '' ? 'resposta vazia' : null,
        ];
    }

    /** @param array{temperature?:float,json?:bool,timeout?:int,model?:string,base_url?:?string} $opts */
    private static function anthropic(string $apiKey, string $system, string $user, int $maxTokens, array $opts): array {
        $model = (string)($opts['model'] ?? aiGatewayDefaultModel('anthropic'));
        $url   = rtrim((string)($opts['base_url'] ?? 'https://api.anthropic.com/v1'), '/') . '/messages';
        $body  = [
            'model' => $model,
            'max_tokens' => $maxTokens,
            'system' => $system,
            'messages' => [['role' => 'user', 'content' => $user]],
        ];
        $headers = [
            'Content-Type: application/json',
            'x-api-key: ' . $apiKey,
            'anthropic-version: 2023-06-01',
        ];
        try {
            $res = aiHttpPost($url, $headers, json_encode($body, JSON_UNESCAPED_UNICODE), (int)($opts['timeout'] ?? 60));
        } catch (Throwable $e) {
            return ['ok' => false, 'content' => null, 'model' => $model, 'finish_reason' => null, 'usage' => null, 'tokens_input' => null, 'tokens_output' => null, 'http_code' => 0, 'error' => $e->getMessage()];
        }
        $code = (int)$res['code'];
        $data = json_decode((string)$res['body'], true);
        if ($code !== 200) {
            $err = is_array($data) ? ($data['error']['message'] ?? "HTTP {$code}") : "HTTP {$code}";
            return ['ok' => false, 'content' => null, 'model' => $model, 'finish_reason' => null, 'usage' => null, 'tokens_input' => null, 'tokens_output' => null, 'http_code' => $code, 'error' => $err];
        }
        $text = '';
        foreach ($data['content'] ?? [] as $block) {
            if (($block['type'] ?? '') === 'text') $text .= $block['text'] ?? '';
        }
        $text = trim($text);
        $usage = $data['usage'] ?? null;
        return [
            'ok' => $text !== '', 'content' => $text ?: null, 'model' => $model, 'finish_reason' => $data['stop_reason'] ?? 'stop',
            'usage' => $usage, 'tokens_input' => $usage['input_tokens'] ?? null, 'tokens_output' => $usage['output_tokens'] ?? null,
            'http_code' => $code, 'error' => $text === '' ? 'resposta vazia' : null,
        ];
    }

    private static function extractGeminiText(?array $data): string {
        if (!is_array($data)) return '';
        $text = '';
        foreach ($data['candidates'][0]['content']['parts'] ?? [] as $part) {
            if (isset($part['text'])) $text .= $part['text'];
        }
        return trim($text);
    }
}
