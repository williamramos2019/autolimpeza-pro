<?php
/**
 * Central de Logs e Diagnóstico — handlers HTTP
 */

require_once __DIR__ . '/logs-service.php';

function handleSystemLogs(string $method): void {
    requireAdmin();
    $pdo = db();
    ensureSystemLogsTable($pdo);

    if ($method === 'GET') {
        $filters = [
            'level'    => $_GET['level'] ?? null,
            'type'     => $_GET['type'] ?? null,
            'q'        => $_GET['q'] ?? null,
            'from'     => $_GET['from'] ?? null,
            'to'       => $_GET['to'] ?? null,
            'ip'       => $_GET['ip'] ?? null,
            'resolved' => $_GET['resolved'] ?? '0',
            'limit'    => $_GET['limit'] ?? 100,
            'offset'   => $_GET['offset'] ?? 0,
        ];
        jsonRespond(systemLogQuery($pdo, $filters));
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $action = $b['action'] ?? '';
        if ($action === 'resolve' && !empty($b['id'])) {
            $pdo->prepare('UPDATE system_logs SET resolved = 1 WHERE id = ?')->execute([(int)$b['id']]);
            jsonRespond(['ok' => true]);
        }
        // Arquiva histórico: marca como resolvidos os logs em aberto mais antigos que N dias
        if ($action === 'resolve_older') {
            $days = max(1, min(365, (int)($b['days'] ?? 7)));
            // INTERVAL não aceita placeholder de forma confiável no MySQL — $days já é int sanitizado
            $affected = $pdo->exec(
                "UPDATE system_logs SET resolved = 1
                 WHERE resolved = 0
                   AND created_at < DATE_SUB(NOW(), INTERVAL {$days} DAY)"
            );
            jsonRespond(['ok' => true, 'resolved' => (int)$affected, 'days' => $days]);
        }
        jsonRespond(['error' => 'Ação inválida'], 400);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleSystemLogsIngest(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('logs_ingest', 30);
    $b = jsonBody();
    $type    = san($b['type'] ?? 'javascript', 40) ?? 'javascript';
    $level   = san($b['level'] ?? 'error', 20) ?? 'error';
    $message = san($b['message'] ?? 'Frontend error', 2000) ?? 'Frontend error';

    // Endpoint público: limita tamanho de todos os campos livres (anti-flood/exfil)
    $trace = $b['stack'] ?? $b['trace'] ?? null;
    if (is_string($trace)) $trace = mb_substr($trace, 0, 4000);
    elseif ($trace !== null) $trace = null;

    $payload = $b['payload'] ?? null;
    if ($payload !== null) {
        $encoded = json_encode($payload, JSON_UNESCAPED_UNICODE);
        $payload = $encoded !== false ? mb_substr($encoded, 0, 4000) : null;
    }

    systemLog($type, $level, $message, [
        'file'    => san($b['file'] ?? null, 300),
        'line'    => isset($b['line']) && is_numeric($b['line']) ? (int)$b['line'] : null,
        'trace'   => $trace,
        'url'     => san($b['url'] ?? null, 500),
        'browser' => san($b['browser'] ?? null, 200),
        'device'  => san($b['device'] ?? null, 100),
        'city'    => san($b['city'] ?? null, 100),
        'payload' => $payload,
    ]);
    jsonRespond(['ok' => true]);
}

function handleSystemLogsStats(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    jsonRespond(systemLogStats(db()));
}

function handleSystemLogsExport(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $format = $_GET['format'] ?? 'json';
    $filters = [
        'level' => $_GET['level'] ?? null,
        'type'  => $_GET['type'] ?? null,
        'q'     => $_GET['q'] ?? null,
        'from'  => $_GET['from'] ?? null,
        'to'    => $_GET['to'] ?? null,
        'limit' => min(2000, (int)($_GET['limit'] ?? 500)),
        'offset'=> 0,
    ];
    $data = systemLogQuery(db(), $filters);
    if ($format === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="system-logs-' . date('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['id','type','level','message','file','line','url','ip','created_at']);
        foreach ($data['items'] as $row) {
            fputcsv($out, [$row['id'],$row['type'],$row['level'],$row['message'],$row['file'],$row['line'],$row['url'],$row['ip'],$row['created_at']]);
        }
        fclose($out);
        exit;
    }
    jsonRespond($data);
}

function handleSystemDiagnostico(string $method): void {
    requireAdmin();
    if (!in_array($method, ['GET', 'POST'], true)) {
        jsonRespond(['error' => 'Use GET ou POST'], 405);
    }
    jsonRespond(runSystemDiagnostico(db()));
}

function handleSystemLogsAnalyze(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);

    $pdo = db();
    ensureSystemLogsTable($pdo);
    $b = jsonBody();
    $logId = (int)($b['logId'] ?? 0);

    $logs = [];
    if ($logId > 0) {
        $stmt = $pdo->prepare('SELECT * FROM system_logs WHERE id = ? LIMIT 1');
        $stmt->execute([$logId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) $logs[] = $row;
    } else {
        $logs = $pdo->query(
            "SELECT * FROM system_logs WHERE level IN ('error','critical','fatal','warning')
             ORDER BY id DESC LIMIT 15"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    if (!$logs) {
        jsonRespond(['analysis' => 'Nenhum erro recente para analisar. Sistema estável.', 'suggestions' => []]);
    }

    $summary = [];
    foreach ($logs as $l) {
        $summary[] = sprintf(
            '[%s] %s %s — %s (%s:%s)',
            $l['created_at'], strtoupper($l['level']), $l['type'], mb_substr($l['message'], 0, 200),
            $l['file'] ?? '-', $l['line'] ?? '-'
        );
    }
    $prompt = "Analise estes logs do sistema Auto Limpeza Pro (PHP/MySQL/cPanel). "
        . "Responda em português com: 1) diagnóstico em 2-4 frases diretas; 2) lista de possíveis causas; 3) sugestões de correção práticas.\n\n"
        . implode("\n", $summary);

    $analysis = null;
    $suggestions = [];
    $aiError = null;
    $aiLayer = 'heuristic';

    if (function_exists('aiConfigKey') && (aiConfigKey('gemini') || aiProviderHasAnyKey())) {
        if (!class_exists('AIGateway')) {
            require_once __DIR__ . '/ai-gateway.php';
        }
        $gw = AIGateway::chat([
            'system'    => 'Você é o Capitão Clean, especialista em diagnóstico de sistemas web PHP. '
                . 'Responda APENAS JSON válido: {"analysis":"diagnóstico em 2-4 frases","suggestions":["sugestão prática 1","sugestão 2"]}',
            'user'      => $prompt,
            'maxTokens' => 2048,
            'module'    => 'logs',
            'json'      => true,
            'temperature' => 0.5,
        ]);
        if (($gw['status'] ?? '') === 'ok' && !empty($gw['content'])) {
            $result = json_decode((string)$gw['content'], true);
            if (!is_array($result)) {
                $result = function_exists('aiExtractJson') ? aiExtractJson((string)$gw['content']) : null;
            }
            if (is_array($result) && !empty($result['analysis'])) {
                $analysis = $result['analysis'];
                $suggestions = is_array($result['suggestions'] ?? null) ? $result['suggestions'] : [];
                $aiLayer = 'ai-gateway';
            }
        }
        if (!$analysis && ($gw['content'] ?? null)) {
            $analysis = (string)$gw['content'];
            $aiLayer = 'ai-gateway-raw';
        }
        if (!$analysis && !empty($gw['error'])) {
            $aiError = (string)$gw['error'];
        }
        if (!$analysis && class_exists('GeminiService')) {
            require_once __DIR__ . '/gemini-service.php';
            $result = GeminiService::generateJson(
                'Você é o Capitão Clean, especialista em diagnóstico de sistemas web PHP. '
                . 'Responda APENAS JSON válido: {"analysis":"diagnóstico em 2-4 frases","suggestions":["sugestão prática 1","sugestão 2"]}',
                $prompt,
                2048
            );
            if (is_array($result) && !empty($result['analysis'])) {
                $analysis = $result['analysis'];
                $suggestions = is_array($result['suggestions'] ?? null) ? $result['suggestions'] : [];
                $aiLayer = 'gemini';
            } elseif (is_array($result) && !empty($result['text'])) {
                $analysis = $result['text'];
                $aiLayer = 'gemini';
            } else {
                $text = GeminiService::generateText(
                    'Você é o Capitão Clean, especialista em diagnóstico de sistemas web PHP.',
                    $prompt,
                    2048
                );
                if ($text) {
                    $analysis = $text;
                    $aiLayer = 'gemini';
                }
            }
        }
    }

    if (!$analysis && function_exists('capitaoAiChat')) {
        $text = capitaoAiChat('Analise logs do sistema', $prompt);
        if ($text) $analysis = $text;
    }

    if (!$analysis) {
        $analysis = systemLogHeuristicAnalysis($logs);
        $suggestions = systemLogHeuristicSuggestions($logs);
        if (!$aiError && !function_exists('aiConfigKey')) {
            $aiError = 'Módulo de IA não carregado no servidor';
        } elseif (!$aiError && !aiConfigKey('gemini') && !aiProviderHasAnyKey()) {
            $aiError = 'Chave Gemini não configurada — Admin → Configurações ou GEMINI_API_KEY em config.php';
        }
    }

    jsonRespond([
        'analysis'    => $analysis,
        'suggestions' => $suggestions,
        'logCount'    => count($logs),
        'layer'       => $aiLayer,
        'aiError'     => $aiError,
    ]);
}

function systemLogHeuristicAnalysis(array $logs): string {
    $msgs = array_column($logs, 'message');
    $joined = strtolower(implode(' ', $msgs));
    if (str_contains($joined, 'gemini') || str_contains($joined, '403')) {
        return 'A API Gemini retornou erro de autenticação ou permissão (HTTP 403). Verifique a chave em Admin → Configurações.';
    }
    if (str_contains($joined, 'pdo') || str_contains($joined, 'mysql') || str_contains($joined, 'sql')) {
        return 'O banco de dados recusou uma operação. Pode ser tabela ausente, credencial incorreta ou query inválida.';
    }
    if (str_contains($joined, 'upload') || str_contains($joined, 'move_uploaded')) {
        return 'Falha no upload de arquivos. Verifique permissões da pasta uploads/ e limite MAX_UPLOAD_MB no config.php.';
    }
    if (str_contains($joined, 'unauthorized') || str_contains($joined, 'token')) {
        return 'Erro de autenticação admin. Peça ao usuário para sair e entrar novamente no painel.';
    }
    return 'Foram detectados ' . count($logs) . ' eventos recentes. Revise o stack trace e o horário para correlacionar com deploys ou alterações no CMS.';
}

function systemLogHeuristicSuggestions(array $logs): array {
    $out = ['Execute install.php?step=repair para atualizar tabelas.', 'Verifique storage/logs/ e permissões 755.'];
    foreach ($logs as $l) {
        if ($l['type'] === 'api') $out[] = 'Teste a API afetada em Admin → Sistema → Diagnóstico.';
        if ($l['type'] === 'javascript') $out[] = 'Limpe cache do navegador e confirme que assets/ está atualizado.';
    }
    return array_values(array_unique($out));
}

function runSystemDiagnostico(PDO $pdo): array {
    ensureSystemLogsTable($pdo);

    if (!function_exists('ensureAiGatewayTables') && is_file(__DIR__ . '/ai-gateway.php')) {
        require_once __DIR__ . '/ai-gateway.php';
    }
    if (!function_exists('ensureProspeccaoEngineTables') && is_file(__DIR__ . '/modules/prospeccao-engine/bootstrap.php')) {
        require_once __DIR__ . '/modules/prospeccao-engine/bootstrap.php';
    }

    // Auto-criação defensiva de tabelas aditivas (idempotente)
    if (function_exists('ensureCmsMigrated')) {
        try { ensureCmsMigrated(); } catch (Throwable $e) { /* diagnóstico continua */ }
    }
    if (function_exists('ensureAiGatewayTables')) {
        try {
            ensureAiGatewayTables($pdo);
            if (function_exists('aiGatewaySyncProviderKeysFromConfig')) {
                aiGatewaySyncProviderKeysFromConfig($pdo);
            }
        } catch (Throwable $e) { /* */ }
    }
    if (function_exists('ensureProspeccaoEngineTables')) {
        try { ensureProspeccaoEngineTables($pdo); } catch (Throwable $e) { /* */ }
    }

    $checks = [];
    $score  = 0;
    $max    = 0;
    $missingTables = [];

    $add = function (string $id, string $label, string $status, string $detail = '', ?string $suggestion = null) use (&$checks, &$score, &$max, &$missingTables): void {
        $max++;
        if ($status === 'ok') $score++;
        if ($status === 'error' && str_starts_with($id, 'table_')) {
            $missingTables[] = str_replace('table_', '', $id);
        }
        $checks[] = compact('id', 'label', 'status', 'detail', 'suggestion');
    };

    $checkTable = function (string $tbl, string $label = '') use ($pdo, $add): void {
        $label = $label !== '' ? $label : "Tabela {$tbl}";
        try {
            $pdo->query("SELECT 1 FROM `{$tbl}` LIMIT 1");
            $add("table_{$tbl}", $label, 'ok');
        } catch (Throwable $e) {
            $add("table_{$tbl}", $label, 'error', 'Ausente ou inacessível', 'Execute install.php?step=repair');
        }
    };

    // Banco
    try {
        $pdo->query('SELECT 1');
        $add('db', 'Banco de dados MySQL', 'ok', DB_NAME . ' @ ' . DB_HOST);
    } catch (Throwable $e) {
        $add('db', 'Banco de dados MySQL', 'error', $e->getMessage(), 'Verifique DB_* no config.php');
    }

    $requiredTables = ['appointments', 'site_config', 'admin_users', 'system_logs', 'blog_posts', 'clients'];
    foreach ($requiredTables as $tbl) {
        $checkTable($tbl);
    }

    // AI Gateway
    foreach (['ai_providers', 'ai_gateway_logs', 'ai_module_routing'] as $tbl) {
        $checkTable($tbl, "Tabela {$tbl} (AI Gateway)");
    }

    // Prospecção Engine Pro
    foreach (['prospeccao_engine_jobs', 'prospeccao_engine_job_events', 'prospeccao_engine_leads'] as $tbl) {
        $checkTable($tbl, "Tabela {$tbl} (Prospecção Engine)");
    }

    // Storage / logs
    $logDir = systemLogsBaseDir();
    $writable = is_writable($logDir);
    $add('logs_dir', 'Pasta storage/logs/', $writable ? 'ok' : 'error', $logDir, 'chmod 755 ou 775 na pasta storage/');

    $uploads = defined('UPLOADS_DIR') ? UPLOADS_DIR : (__DIR__ . '/uploads/');
    $add('uploads', 'Pasta uploads/', is_dir($uploads) && is_writable($uploads) ? 'ok' : 'warn', $uploads, 'Crie uploads/ com permissão de escrita');

    // APIs / chaves
    if (function_exists('ensureGeminiKeyFromConfig')) {
        try { ensureGeminiKeyFromConfig($pdo); } catch (Throwable $e) { /* */ }
    }
    $gemini = function_exists('aiConfigKey') ? aiConfigKey('gemini') : null;
    $geminiDetail = $gemini ? 'Resolvida (gemini_key / config.php)' : 'Não configurada';
    if (!$gemini) {
        try {
            $legacy = (bool)$pdo->query("SELECT 1 FROM site_config WHERE key_name = 'gemini_api_key' AND value != '' LIMIT 1")->fetchColumn();
            if ($legacy) {
                $geminiDetail = 'Legado gemini_api_key detectado — execute install.php?step=repair';
            }
        } catch (Throwable $e) {
            // ignore
        }
    }
    $add('gemini', 'Chave Gemini', $gemini ? 'ok' : 'warn', $geminiDetail, 'Admin → Configurações → Chave Gemini');

    $openai = function_exists('aiConfigKey') ? aiConfigKey('openai') : null;
    $add('openai', 'Chave OpenAI', $openai ? 'ok' : 'warn', $openai ? 'Configurada' : 'Opcional');

    // SMTP
    try {
        $stmt = $pdo->query("SELECT value FROM site_config WHERE key_name = 'smtp_password_enc' LIMIT 1");
        $smtp = (bool)$stmt->fetchColumn();
        $add('smtp', 'SMTP', $smtp ? 'ok' : 'warn', $smtp ? 'Senha configurada' : 'Sem senha SMTP');
    } catch (Throwable $e) {
        $add('smtp', 'SMTP', 'warn', 'Não verificado');
    }

    // Cron
    $siteBase = defined('SITE_URL') ? rtrim((string) SITE_URL, '/') : '';
    $cronSecret = defined('CRON_SECRET') && CRON_SECRET !== '' ? 'definido' : (defined('ADMIN_TOKEN') ? 'fallback ADMIN_TOKEN' : 'ausente');
    $cronStatus = defined('CRON_SECRET') && CRON_SECRET !== '' ? 'ok' : 'warn';
    $cronSuggestion = defined('CRON_SECRET') && CRON_SECRET !== ''
        ? 'Configure cPanel: wget -q -O - "' . ($siteBase !== '' ? $siteBase : 'https://SEU-DOMINIO') . '/cron.php?key=CRON_SECRET"'
        : 'Defina CRON_SECRET no config.php (não use ADMIN_TOKEN em produção)';
    $add('cron', 'Cron secret', $cronStatus, $cronSecret, $cronSuggestion);
    try {
        $stmt = $pdo->query("SELECT value FROM site_config WHERE key_name = 'cron_last_run_at' LIMIT 1");
        $lastRun = (string) ($stmt->fetchColumn() ?: '');
        $add('cron_last', 'Última execução cron', $lastRun !== '' ? 'ok' : 'warn', $lastRun !== '' ? $lastRun : 'Nunca executou', 'Agende cron.php no cPanel a cada 15 min');
    } catch (Throwable $e) {
        $add('cron_last', 'Última execução cron', 'warn', 'Não verificado');
    }

    // CMS blog — tenta criar tabelas ausentes automaticamente
    require_once __DIR__ . '/migrate-cms.php';
    $cmsMissingBefore = [];
    foreach (['blog_categories', 'blog_comments', 'blog_authors'] as $tbl) {
        if (!cmsTableExists($pdo, $tbl)) {
            $cmsMissingBefore[] = $tbl;
        }
    }
    if ($cmsMissingBefore) {
        try {
            runCmsMigrations($pdo);
        } catch (Throwable $e) { /* continua diagnóstico */ }
    }
    foreach (['blog_categories', 'blog_comments', 'blog_authors'] as $tbl) {
        $exists = cmsTableExists($pdo, $tbl);
        $detail = $exists
            ? (in_array($tbl, $cmsMissingBefore, true) ? 'Criada agora (auto-repair)' : 'Presente')
            : 'Ausente';
        $add(
            "cms_{$tbl}",
            "Tabela {$tbl}",
            $exists ? 'ok' : 'error',
            $detail,
            $exists ? '' : 'Execute install.php?step=repair ou migrate-cms.php?run=1'
        );
        if (!$exists) {
            $missingTables[] = $tbl;
        }
    }

    if ($missingTables) {
        $add('schema_repair', 'Reparo de schema', 'error', 'Tabelas ausentes: ' . implode(', ', array_unique($missingTables)), 'Acesse install.php?step=repair para criar automaticamente');
    }

    // Web Push VAPID
    $webPushOk = function_exists('webPushIsConfigured') && webPushIsConfigured($pdo);
    $subCount = 0;
    if ($webPushOk) {
        try {
            ensurePushSubscriptionsTable($pdo);
            $subCount = (int)$pdo->query('SELECT COUNT(*) FROM push_subscriptions WHERE enabled = 1')->fetchColumn();
        } catch (Throwable $e) { /* */ }
    }
    $add(
        'webpush',
        'Web Push (VAPID)',
        $webPushOk ? ($subCount > 0 ? 'ok' : 'warn') : 'warn',
        $webPushOk ? "{$subCount} assinatura(s) ativa(s)" : 'Chaves não configuradas',
        'Admin → Comunicação → Push → Gerar chaves VAPID'
    );

    // PHP
    $add('php', 'Versão PHP', version_compare(PHP_VERSION, '7.4', '>=') ? 'ok' : 'error', PHP_VERSION);
    $add('pdo_mysql', 'Extensão pdo_mysql', extension_loaded('pdo_mysql') ? 'ok' : 'error');
    $add('curl', 'Extensão cURL (APIs)', extension_loaded('curl') ? 'ok' : 'warn');

    // Módulos
    $add('cms', 'CMS / Blog', 'ok', 'Rotas cms/* e blog/* registradas');
    $add('crm', 'CRM Premium', 'ok', 'Rotas crm/* registradas');
    $add('agenda', 'Agenda', 'ok', 'Tabela appointments');

    $overall = $max > 0 ? (int)round(($score / $max) * 100) : 0;
    $grade = $overall >= 90 ? 'A' : ($overall >= 75 ? 'B' : ($overall >= 60 ? 'C' : 'D'));

    systemLog('app', 'info', 'Diagnóstico executado', ['score' => $overall, 'checks' => count($checks)]);

    return [
        'overallScore' => $overall,
        'grade'        => $grade,
        'checks'       => $checks,
        'errors'       => array_values(array_filter($checks, fn($c) => $c['status'] === 'error')),
        'warnings'     => array_values(array_filter($checks, fn($c) => $c['status'] === 'warn')),
        'missingTables'=> array_values(array_unique($missingTables)),
        'repairUrl'    => '/install.php?step=repair',
        'cronUrl'      => $siteBase !== '' ? $siteBase . '/cron.php?key=CRON_SECRET' : null,
        'generatedAt'  => date('c'),
        'phpVersion'   => PHP_VERSION,
        'debugMode'    => systemLogDebugMode(),
    ];
}
