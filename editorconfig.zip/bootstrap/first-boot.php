<?php

/**
 * Preparação anterior ao autoload do Composer.
 * Sem Laravel: só filesystem e .env, para o HostGator não 500 no primeiro GET.
 *
 * @return list<string>
 */
function checklist_obras_required_directories(string $base): array
{
    $s = DIRECTORY_SEPARATOR;

    return [
        $base.$s.'storage',
        $base.$s.'storage'.$s.'app',
        $base.$s.'storage'.$s.'app'.$s.'public',
        $base.$s.'storage'.$s.'app'.$s.'private',
        $base.$s.'storage'.$s.'framework',
        $base.$s.'storage'.$s.'framework'.$s.'cache',
        $base.$s.'storage'.$s.'framework'.$s.'sessions',
        $base.$s.'storage'.$s.'framework'.$s.'views',
        $base.$s.'storage'.$s.'logs',
        $base.$s.'bootstrap'.$s.'cache',
        $base.$s.'public'.$s.'storage',
    ];
}

function checklist_obras_app_key_missing(string $contents): bool
{
    if (preg_match('/^APP_KEY=(.*)$/m', $contents, $match) !== 1) {
        return true;
    }

    $value = trim(str_replace(["\r", '"', "'"], '', $match[1]));

    return $value === '';
}

function checklist_obras_ensure_directories(string $base): void
{
    foreach (checklist_obras_required_directories($base) as $dir) {
        if (! is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
    }
}

function checklist_obras_ensure_env(string $base): void
{
    $env = $base.DIRECTORY_SEPARATOR.'.env';
    $example = $base.DIRECTORY_SEPARATOR.'.env.example';

    if (! is_file($env) && is_file($example)) {
        copy($example, $env);
    }

    if (! is_file($env) || ! is_readable($env) || ! is_writable($env)) {
        return;
    }

    $contents = (string) file_get_contents($env);
    if (! checklist_obras_app_key_missing($contents)) {
        return;
    }

    $key = 'base64:'.base64_encode(random_bytes(32));
    if (preg_match('/^APP_KEY=/m', $contents) === 1) {
        $contents = preg_replace('/^APP_KEY=.*$/m', 'APP_KEY='.$key, $contents, 1) ?? $contents;
    } else {
        $contents = rtrim($contents)."\nAPP_KEY=".$key."\n";
    }

    file_put_contents($env, $contents);
}

function checklist_obras_first_boot(string $base): void
{
    checklist_obras_ensure_directories($base);
    checklist_obras_ensure_env($base);
}
