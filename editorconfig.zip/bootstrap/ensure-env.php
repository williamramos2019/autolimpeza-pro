<?php

require __DIR__.DIRECTORY_SEPARATOR.'first-boot.php';

checklist_obras_first_boot(dirname(__DIR__));
