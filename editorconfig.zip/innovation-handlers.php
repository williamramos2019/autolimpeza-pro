<?php
/**
 * Inovações exclusivas Auto Limpeza Pro
 * 7 funcionalidades que nenhum CMS de higienização oferece
 */

/** Extrai visitor_id string mesmo se o cliente enviar o objeto VisitorInfo por engano. */
function innovationVisitorId(array $b): ?string {
    $v = $b['visitorId'] ?? $b['visitor_id'] ?? null;
    if (is_array($v)) {
        $v = $v['visitorId'] ?? $v['visitor_id'] ?? null;
    }
    return is_string($v) ? san($v, 64) : null;
}

function ensureInnovationTables(PDO $pdo): void {
    static $ensured = false;
    if ($ensured) {
        return;
    }
    $ensured = true;

    $pdo->exec("CREATE TABLE IF NOT EXISTS `hygiene_passports` (
        `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `code`             VARCHAR(16)  NOT NULL,
        `client_name`      VARCHAR(150) NOT NULL,
        `phone`            VARCHAR(30)  DEFAULT NULL,
        `piece_type`       VARCHAR(50)  NOT NULL,
        `piece_label`      VARCHAR(150) NOT NULL,
        `service_date`     DATE         NOT NULL,
        `next_maintenance` DATE         NOT NULL,
        `technician`       VARCHAR(100) DEFAULT NULL,
        `guarantee_until`  DATE         DEFAULT NULL,
        `services_json`    JSON         DEFAULT NULL,
        `hygiene_score`    TINYINT UNSIGNED DEFAULT 95,
        `appointment_id`   VARCHAR(64)  DEFAULT NULL,
        `verified_count`   INT UNSIGNED NOT NULL DEFAULT 0,
        `created_at`       DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_code` (`code`),
        INDEX `idx_phone` (`phone`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `stain_scans` (
        `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `visitor_id`      VARCHAR(64)  DEFAULT NULL,
        `phone`           VARCHAR(30)  DEFAULT NULL,
        `city`            VARCHAR(100) DEFAULT NULL,
        `neighborhood`    VARCHAR(150) DEFAULT NULL,
        `stain_type`      VARCHAR(80)  NOT NULL,
        `severity`        VARCHAR(20)  NOT NULL,
        `treatment`       TEXT         NOT NULL,
        `estimated_price` DECIMAL(10,2) NOT NULL DEFAULT 0,
        `photo_url`       VARCHAR(500) DEFAULT NULL,
        `analysis_json`   JSON         DEFAULT NULL,
        `created_at`      DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_city` (`city`),
        INDEX `idx_stain` (`stain_type`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `fabric_lifespan_calcs` (
        `id`                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `visitor_id`           VARCHAR(64)  DEFAULT NULL,
        `phone`                VARCHAR(30)  DEFAULT NULL,
        `client_name`          VARCHAR(150) DEFAULT NULL,
        `piece_type`           VARCHAR(50)  NOT NULL,
        `fabric_type`          VARCHAR(50)  NOT NULL,
        `has_pets`             TINYINT(1)   NOT NULL DEFAULT 0,
        `has_kids`             TINYINT(1)   NOT NULL DEFAULT 0,
        `smokes`               TINYINT(1)   NOT NULL DEFAULT 0,
        `last_cleaning_months` INT UNSIGNED NOT NULL DEFAULT 12,
        `health_score`         TINYINT UNSIGNED NOT NULL,
        `next_cleaning_date`   DATE         NOT NULL,
        `recommendation`       TEXT         DEFAULT NULL,
        `created_at`           DATETIME     NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `warranty_tickets` (
        `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `code`            VARCHAR(16)  NOT NULL,
        `appointment_id`  VARCHAR(64)  DEFAULT NULL,
        `client_name`     VARCHAR(150) NOT NULL,
        `phone`           VARCHAR(30)  NOT NULL,
        `service_date`    DATE         NOT NULL,
        `expires_at`      DATE         NOT NULL,
        `status`          VARCHAR(20)  NOT NULL DEFAULT 'active',
        `claim_reason`    TEXT         DEFAULT NULL,
        `claim_at`        DATETIME     DEFAULT NULL,
        `services_json`   JSON         DEFAULT NULL,
        `timeline_json`   JSON         DEFAULT NULL,
        `created_at`      DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_warranty_code` (`code`),
        INDEX `idx_warranty_phone` (`phone`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `loyalty_pieces` (
        `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `phone`             VARCHAR(30)  NOT NULL,
        `client_name`       VARCHAR(150) NOT NULL,
        `piece_type`        VARCHAR(50)  NOT NULL,
        `piece_label`       VARCHAR(150) NOT NULL,
        `cleanings_count`   INT UNSIGNED NOT NULL DEFAULT 0,
        `points`            INT UNSIGNED NOT NULL DEFAULT 0,
        `tier`              VARCHAR(20)  NOT NULL DEFAULT 'bronze',
        `last_service_date` DATE         DEFAULT NULL,
        `next_reward_at`    INT UNSIGNED NOT NULL DEFAULT 100,
        `created_at`        DATETIME     NOT NULL,
        `updated_at`        DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_loyalty_piece` (`phone`, `piece_type`, `piece_label`(80)),
        INDEX `idx_loyalty_phone` (`phone`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function innovationRandomCode(int $len = 8): string {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';
    for ($i = 0; $i < $len; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $code;
}

function innovationAnalyzeStain(array $b): array {
    $stainTypes = [
        'urina'       => ['label' => 'Urina / xixi', 'base' => 180, 'treatment' => 'Enzimas bacterianas + extração a vapor + neutralizador de odores'],
        'cafe'        => ['label' => 'Café', 'base' => 120, 'treatment' => 'Pré-tratamento alcalino + extração profunda'],
        'vinho'       => ['label' => 'Vinho tinto', 'base' => 150, 'treatment' => 'Neutralização ácida + clareador seguro para tecido'],
        'gordura'     => ['label' => 'Gordura / óleo', 'base' => 140, 'treatment' => 'Desengordurante profissional + vapor'],
        'sangue'      => ['label' => 'Sangue', 'base' => 160, 'treatment' => 'Enzimas proteolíticas + extração a frio'],
        'mofo'        => ['label' => 'Mofo / umidade', 'base' => 200, 'treatment' => 'Antifúngico + secagem forçada + higienização profunda'],
        'tinta'       => ['label' => 'Tinta / caneta', 'base' => 170, 'treatment' => 'Solvente específico + teste de cor prévio'],
        'pet'         => ['label' => 'Pelos / sujeira pet', 'base' => 130, 'treatment' => 'Aspiração HEPA + shampoo hipoalergênico'],
        'geral'       => ['label' => 'Sujeira geral', 'base' => 110, 'treatment' => 'Higienização padrão com extração e proteção'],
    ];

    $hint = strtolower((string)($b['stainHint'] ?? $b['stainType'] ?? ''));
    $level = strtolower((string)($b['cleaningLevel'] ?? $b['severity'] ?? 'média'));
    $score = (float)($b['dirtScore'] ?? 0.5);

    $type = 'geral';
    foreach (array_keys($stainTypes) as $k) {
        if (str_contains($hint, $k)) { $type = $k; break; }
    }

    $severity = 'média';
    $mult = 1.0;
    if ($level === 'leve' || $score < 0.3) { $severity = 'leve'; $mult = 0.85; }
    elseif ($level === 'pesada' || $score > 0.55) { $severity = 'pesada'; $mult = 1.35; }

    $info = $stainTypes[$type];
    $price = round($info['base'] * $mult, 0);

    return [
        'stainType' => $type,
        'stainLabel' => $info['label'],
        'severity' => $severity,
        'treatment' => $info['treatment'],
        'estimatedPrice' => $price,
        'observation' => "Mancha identificada como {$info['label']} com intensidade {$severity}. Valor estimado a partir de R$ {$price}.",
        'confidence' => min(0.95, 0.65 + ($score * 0.2)),
    ];
}

function innovationLifespanCalc(array $b): array {
    $fabric = san($b['fabricType'] ?? 'sintetico', 30) ?? 'sintetico';
    $piece  = san($b['pieceType'] ?? 'sofa', 30) ?? 'sofa';
    $pets   = !empty($b['hasPets']);
    $kids   = !empty($b['hasKids']);
    $smokes = !empty($b['smokes']);
    $months = max(0, min(60, (int)($b['lastCleaningMonths'] ?? 12)));

    $baseMonths = match ($fabric) {
        'couro' => 8, 'veludo' => 5, 'linho' => 6, 'algodao' => 7, default => 6,
    };
    if ($pets) $baseMonths -= 2;
    if ($kids) $baseMonths -= 1;
    if ($smokes) $baseMonths -= 2;
    $baseMonths = max(3, $baseMonths); // evita divisão por zero / intervalo inválido

    $health = 100;
    $health -= min(50, $months * 4);
    if ($pets) $health -= 12;
    if ($kids) $health -= 8;
    if ($smokes) $health -= 15;
    $health = max(5, min(100, $health));

    // Meses restantes até o próximo ciclo (não usa % com overdue invertido)
    $cyclePos = $months % $baseMonths;
    $remaining = $cyclePos === 0 && $months > 0 ? $baseMonths : ($baseMonths - $cyclePos);
    if ($months === 0) $remaining = $baseMonths;
    $remaining = max(1, (int)$remaining);
    $nextDate = date('Y-m-d', strtotime("+{$remaining} months"));

    $rec = $health < 40
        ? 'Urgente: agende higienização profunda para proteger sua saúde e o tecido.'
        : ($health < 70
            ? 'Recomendado agendar nos próximos 30 dias para manter o estofado saudável.'
            : 'Seu estofado está em boa condição. Mantenha a rotina preventiva.');

    return [
        'healthScore' => $health,
        'nextCleaningDate' => $nextDate,
        'monthsUntilNext' => $remaining,
        'recommendation' => $rec,
        'fabricType' => $fabric,
        'pieceType' => $piece,
    ];
}

function innovationLoyaltyTier(int $points): string {
    if ($points >= 300) return 'gold';
    if ($points >= 150) return 'silver';
    return 'bronze';
}

function innovationLoyaltyDiscount(string $tier): int {
    return match ($tier) { 'gold' => 15, 'silver' => 10, default => 5 };
}

/** Mascara nome em respostas públicas (LGPD) — "João Silva" → "João S***". */
function innovationMaskName(?string $name): string {
    $name = trim((string)$name);
    if ($name === '') return '';
    $parts = preg_split('/\s+/u', $name) ?: [];
    if (count($parts) === 1) {
        $first = $parts[0];
        $len = mb_strlen($first);
        if ($len <= 2) return str_repeat('*', $len);
        return mb_substr($first, 0, 1) . str_repeat('*', max(1, $len - 1));
    }
    $first = $parts[0];
    $lastInitial = mb_substr($parts[count($parts) - 1], 0, 1);
    return $first . ' ' . $lastInitial . '***';
}

/** Mascara telefone público — só últimos 4 dígitos. */
function innovationMaskPhone(?string $phone): string {
    $digits = preg_replace('/\D+/', '', (string)$phone) ?? '';
    if ($digits === '') return '';
    $tail = substr($digits, -4);
    return '****' . $tail;
}

// ── 1. Passaporte de Higiene ───────────────────────────────────────────────

function handleInnovationPassports(string $method): void {
    $pdo = db();
    ensureInnovationTables($pdo);
    $code = san($_GET['code'] ?? null, 16);

    if ($method === 'GET' && $code) {
        $stmt = $pdo->prepare('SELECT * FROM hygiene_passports WHERE code = ? LIMIT 1');
        $stmt->execute([strtoupper($code)]);
        $row = $stmt->fetch();
        if (!$row) jsonRespond(['error' => 'Passaporte não encontrado'], 404);
        $pdo->prepare('UPDATE hygiene_passports SET verified_count = verified_count + 1 WHERE id = ?')->execute([$row['id']]);
        jsonRespond([
            'code' => $row['code'],
            'clientName' => innovationMaskName($row['client_name'] ?? ''),
            'pieceType' => $row['piece_type'],
            'pieceLabel' => $row['piece_label'],
            'serviceDate' => $row['service_date'],
            'nextMaintenance' => $row['next_maintenance'],
            'technician' => $row['technician'],
            'guaranteeUntil' => $row['guarantee_until'],
            'hygieneScore' => (int)$row['hygiene_score'],
            'services' => json_decode($row['services_json'] ?? '[]', true),
            'verified' => true,
        ]);
    }

    requireAdmin();
    if ($method === 'GET') {
        $rows = $pdo->query('SELECT * FROM hygiene_passports ORDER BY created_at DESC LIMIT 200')->fetchAll();
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'], 'code' => $r['code'], 'clientName' => $r['client_name'],
            'phone' => $r['phone'], 'pieceLabel' => $r['piece_label'], 'serviceDate' => $r['service_date'],
            'hygieneScore' => (int)$r['hygiene_score'], 'verifiedCount' => (int)$r['verified_count'],
        ], $rows));
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $code = innovationRandomCode(10);
        $serviceDate = san($b['serviceDate'] ?? date('Y-m-d'), 10) ?? date('Y-m-d');
        $nextMaint = date('Y-m-d', strtotime($serviceDate . ' +6 months'));
        $guarantee = date('Y-m-d', strtotime($serviceDate . ' +30 days'));
        $stmt = $pdo->prepare('INSERT INTO hygiene_passports
            (code, client_name, phone, piece_type, piece_label, service_date, next_maintenance, technician, guarantee_until, services_json, hygiene_score, appointment_id, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([
            $code,
            san($b['clientName'] ?? 'Cliente', 150) ?? 'Cliente',
            san($b['phone'] ?? null, 30),
            san($b['pieceType'] ?? 'sofa', 50) ?? 'sofa',
            san($b['pieceLabel'] ?? 'Sofá', 150) ?? 'Sofá',
            $serviceDate,
            san($b['nextMaintenance'] ?? $nextMaint, 10) ?? $nextMaint,
            san($b['technician'] ?? 'Equipe Auto Limpeza Pro', 100),
            san($b['guaranteeUntil'] ?? $guarantee, 10) ?? $guarantee,
            json_encode($b['services'] ?? [], JSON_UNESCAPED_UNICODE),
            min(100, max(70, (int)($b['hygieneScore'] ?? 95))),
            san($b['appointmentId'] ?? null, 64),
            dbNow(),
        ]);
        $appointmentId = san($b['appointmentId'] ?? null, 64);
        if ($appointmentId && function_exists('communicationDispatch')) {
            communicationDispatch($pdo, 'WarrantyCreated', 'Garantia criada', 'A garantia do atendimento já está disponível.', [
                'appointment_id' => $appointmentId,
                'guarantee_until' => san($b['guaranteeUntil'] ?? $guarantee, 10) ?? $guarantee,
                'passport_code' => $code,
            ], [
                'source' => 'hygiene_passport',
                'action_url' => '/passaporte/' . $code,
                'dedupe_key' => $appointmentId . ':warranty',
                'async' => true,
            ]);
        }
        jsonRespond(['ok' => true, 'code' => $code, 'url' => '/passaporte/' . $code], 201);
    }

    jsonRespond(['error' => 'Método não suportado'], 405);
}

// ── 2. Scanner de Manchas ──────────────────────────────────────────────────

function handleInnovationStainScan(string $method): void {
    $pdo = db();
    ensureInnovationTables($pdo);

    if ($method === 'POST') {
        $b = jsonBody();
        $analysis = innovationAnalyzeStain($b);
        $stmt = $pdo->prepare('INSERT INTO stain_scans
            (visitor_id, phone, city, neighborhood, stain_type, severity, treatment, estimated_price, photo_url, analysis_json, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([
            innovationVisitorId($b),
            san($b['phone'] ?? null, 30),
            san($b['city'] ?? null, 100),
            san($b['neighborhood'] ?? null, 150),
            $analysis['stainType'],
            $analysis['severity'],
            $analysis['treatment'],
            $analysis['estimatedPrice'],
            san($b['photoUrl'] ?? null, 500),
            json_encode($analysis, JSON_UNESCAPED_UNICODE),
            dbNow(),
        ]);
        $analysis['id'] = (int)$pdo->lastInsertId();
        jsonRespond($analysis, 201);
    }

    requireAdmin();
    if ($method === 'GET') {
        $rows = $pdo->query('SELECT * FROM stain_scans ORDER BY created_at DESC LIMIT 300')->fetchAll();
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'], 'stainType' => $r['stain_type'], 'severity' => $r['severity'],
            'city' => $r['city'], 'neighborhood' => $r['neighborhood'],
            'estimatedPrice' => (float)$r['estimated_price'], 'createdAt' => $r['created_at'],
        ], $rows));
    }
    jsonRespond(['error' => 'Método não suportado'], 405);
}

// ── 3. Mapa de Calor de Manchas ────────────────────────────────────────────

function handleInnovationStainHeatmap(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    ensureInnovationTables($pdo);

    $byCity = $pdo->query("SELECT city, stain_type, COUNT(*) c FROM stain_scans WHERE city != '' GROUP BY city, stain_type ORDER BY c DESC")->fetchAll();
    $byNeighborhood = $pdo->query("SELECT neighborhood, city, stain_type, COUNT(*) c FROM stain_scans WHERE neighborhood != '' GROUP BY neighborhood, city, stain_type ORDER BY c DESC LIMIT 100")->fetchAll();
    $byType = $pdo->query("SELECT stain_type, COUNT(*) c, AVG(estimated_price) avg_price FROM stain_scans GROUP BY stain_type ORDER BY c DESC")->fetchAll();

    jsonRespond([
        'byCity' => array_map(fn($r) => ['city' => $r['city'], 'stainType' => $r['stain_type'], 'count' => (int)$r['c']], $byCity),
        'byNeighborhood' => array_map(fn($r) => ['neighborhood' => $r['neighborhood'], 'city' => $r['city'], 'stainType' => $r['stain_type'], 'count' => (int)$r['c']], $byNeighborhood),
        'byType' => array_map(fn($r) => ['stainType' => $r['stain_type'], 'count' => (int)$r['c'], 'avgPrice' => round((float)$r['avg_price'], 0)], $byType),
        'total' => (int)$pdo->query('SELECT COUNT(*) FROM stain_scans')->fetchColumn(),
    ]);
}

// ── 4. Calculadora Vida Útil ───────────────────────────────────────────────

function handleInnovationLifespan(string $method): void {
    $pdo = db();
    ensureInnovationTables($pdo);

    if ($method === 'POST') {
        $b = jsonBody();
        $result = innovationLifespanCalc($b);
        $stmt = $pdo->prepare('INSERT INTO fabric_lifespan_calcs
            (visitor_id, phone, client_name, piece_type, fabric_type, has_pets, has_kids, smokes, last_cleaning_months, health_score, next_cleaning_date, recommendation, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([
            innovationVisitorId($b),
            san($b['phone'] ?? null, 30),
            san($b['clientName'] ?? null, 150),
            $result['pieceType'],
            $result['fabricType'],
            !empty($b['hasPets']) ? 1 : 0,
            !empty($b['hasKids']) ? 1 : 0,
            !empty($b['smokes']) ? 1 : 0,
            (int)($b['lastCleaningMonths'] ?? 12),
            $result['healthScore'],
            $result['nextCleaningDate'],
            $result['recommendation'],
            dbNow(),
        ]);
        $result['id'] = (int)$pdo->lastInsertId();
        jsonRespond($result, 201);
    }

    requireAdmin();
    if ($method === 'GET') {
        $rows = $pdo->query('SELECT * FROM fabric_lifespan_calcs ORDER BY created_at DESC LIMIT 200')->fetchAll();
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'], 'phone' => $r['phone'], 'healthScore' => (int)$r['health_score'],
            'nextCleaningDate' => $r['next_cleaning_date'], 'fabricType' => $r['fabric_type'],
            'createdAt' => $r['created_at'],
        ], $rows));
    }
    jsonRespond(['error' => 'Método não suportado'], 405);
}

// ── 5. Rota Inteligente do Técnico ─────────────────────────────────────────

function handleInnovationRoute(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    $date = san($_GET['date'] ?? date('Y-m-d'), 10) ?? date('Y-m-d');

    try {
        $rows = $pdo->prepare("SELECT id, time, date, client, phone, address, neighborhood, services, status
            FROM appointments WHERE date = ? AND status NOT IN ('cancelled') ORDER BY time ASC");
        $rows->execute([$date]);
        $appts = $rows->fetchAll();
    } catch (Throwable $e) {
        jsonRespond(['stops' => [], 'totalKm' => 0, 'date' => $date, 'message' => 'Sem agendamentos']);
    }

    $baseLat = -19.7378;
    $baseLng = -43.9922;
    $stops = [];
    foreach ($appts as $a) {
        $nb = $a['neighborhood'] ?? '';
        $hash = crc32($nb . ($a['address'] ?? ''));
        $stops[] = [
            'id' => $a['id'],
            'time' => $a['time'],
            'client' => $a['client'],
            'phone' => $a['phone'],
            'address' => $a['address'] ?? '',
            'neighborhood' => $nb,
            'services' => json_decode($a['services'] ?? '[]', true),
            'status' => $a['status'],
            'lat' => $baseLat + (($hash & 0xFFFF) / 0xFFFF - 0.5) * 0.08,
            'lng' => $baseLng + ((($hash >> 16) & 0xFFFF) / 0xFFFF - 0.5) * 0.08,
        ];
    }

    usort($stops, fn($a, $b) => strcmp($a['time'], $b['time']));

    $ordered = [];
    $remaining = $stops;
    $curLat = $baseLat;
    $curLng = $baseLng;
    $totalKm = 0;
    while ($remaining) {
        $best = 0;
        $bestDist = PHP_FLOAT_MAX;
        foreach ($remaining as $i => $s) {
            $d = hypot($s['lat'] - $curLat, $s['lng'] - $curLng);
            if ($d < $bestDist) { $bestDist = $d; $best = $i; }
        }
        $pick = $remaining[$best];
        $totalKm += $bestDist * 111;
        $pick['distanceFromPrevKm'] = round($bestDist * 111, 1);
        $ordered[] = $pick;
        $curLat = $pick['lat'];
        $curLng = $pick['lng'];
        array_splice($remaining, $best, 1);
    }

    jsonRespond([
        'date' => $date,
        'stops' => $ordered,
        'totalStops' => count($ordered),
        'estimatedKm' => round($totalKm, 1),
        'baseLocation' => 'São José da Lapa, MG',
    ]);
}

// ── 6. Garantia Digital ────────────────────────────────────────────────────

function handleInnovationWarranty(string $method): void {
    $pdo = db();
    ensureInnovationTables($pdo);
    $code = san($_GET['code'] ?? null, 16);

    if ($method === 'GET' && $code) {
        $stmt = $pdo->prepare('SELECT * FROM warranty_tickets WHERE code = ? LIMIT 1');
        $stmt->execute([strtoupper($code)]);
        $row = $stmt->fetch();
        if (!$row) jsonRespond(['error' => 'Garantia não encontrada'], 404);
        $daysLeft = max(0, (int)((strtotime($row['expires_at']) - time()) / 86400));
        jsonRespond([
            'code' => $row['code'],
            'clientName' => innovationMaskName($row['client_name'] ?? ''),
            'phone' => innovationMaskPhone($row['phone'] ?? ''),
            'serviceDate' => $row['service_date'],
            'expiresAt' => $row['expires_at'],
            'status' => $row['status'],
            'daysLeft' => $daysLeft,
            'active' => $row['status'] === 'active' && $daysLeft > 0,
            'services' => json_decode($row['services_json'] ?? '[]', true),
            'timeline' => json_decode($row['timeline_json'] ?? '[]', true),
            'claimReason' => $row['claim_reason'],
        ]);
    }

    if ($method === 'PUT' && $code) {
        $b = jsonBody();
        $reason = san($b['reason'] ?? null, 500);
        if (!$reason) jsonRespond(['error' => 'Informe o motivo'], 400);
        $stmt = $pdo->prepare('SELECT * FROM warranty_tickets WHERE code = ? AND status = ? LIMIT 1');
        $stmt->execute([strtoupper($code), 'active']);
        $row = $stmt->fetch();
        if (!$row) jsonRespond(['error' => 'Garantia indisponível'], 404);
        if (strtotime($row['expires_at']) < time()) jsonRespond(['error' => 'Garantia expirada'], 410);
        $timeline = json_decode($row['timeline_json'] ?? '[]', true) ?: [];
        $timeline[] = ['event' => 'claim', 'at' => dbNow(), 'note' => $reason];
        $pdo->prepare('UPDATE warranty_tickets SET status = ?, claim_reason = ?, claim_at = ?, timeline_json = ? WHERE id = ?')
            ->execute(['claimed', $reason, dbNow(), json_encode($timeline), $row['id']]);
        if (function_exists('dispatchNotificationEvent')) {
            dispatchNotificationEvent($pdo, 'warranty_claim', 'Solicitação de garantia', "{$row['client_name']} — {$reason}", [
                'code' => $row['code'],
                'phone' => $row['phone'],
                'client' => $row['client_name'],
            ], ['action_url' => '/inovacoes', 'priority' => 'high']);
        }
        jsonRespond(['ok' => true, 'message' => 'Solicitação registrada. Entraremos em contato em até 24h.']);
    }

    requireAdmin();
    if ($method === 'GET') {
        $rows = $pdo->query('SELECT * FROM warranty_tickets ORDER BY created_at DESC LIMIT 200')->fetchAll();
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'], 'code' => $r['code'], 'clientName' => $r['client_name'],
            'status' => $r['status'], 'expiresAt' => $r['expires_at'], 'serviceDate' => $r['service_date'],
        ], $rows));
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $code = innovationRandomCode(10);
        $serviceDate = san($b['serviceDate'] ?? date('Y-m-d'), 10) ?? date('Y-m-d');
        $expires = date('Y-m-d', strtotime($serviceDate . ' +30 days'));
        $timeline = [
            ['event' => 'created', 'at' => dbNow(), 'note' => 'Garantia ativada'],
            ['event' => 'service', 'at' => $serviceDate, 'note' => 'Serviço realizado'],
            ['event' => 'expires', 'at' => $expires, 'note' => 'Fim da garantia'],
        ];
        $stmt = $pdo->prepare('INSERT INTO warranty_tickets
            (code, appointment_id, client_name, phone, service_date, expires_at, services_json, timeline_json, created_at)
            VALUES (?,?,?,?,?,?,?,?,?)');
        $stmt->execute([
            $code,
            san($b['appointmentId'] ?? null, 64),
            san($b['clientName'] ?? 'Cliente', 150) ?? 'Cliente',
            san($b['phone'] ?? '', 30) ?? '',
            $serviceDate,
            $expires,
            json_encode($b['services'] ?? [], JSON_UNESCAPED_UNICODE),
            json_encode($timeline, JSON_UNESCAPED_UNICODE),
            dbNow(),
        ]);
        jsonRespond(['ok' => true, 'code' => $code, 'url' => '/garantia/' . $code], 201);
    }

    jsonRespond(['error' => 'Método não suportado'], 405);
}

// ── 7. Fidelidade por Peça ─────────────────────────────────────────────────

/** Reduz o nome a "Primeiro S." para consultas públicas (anti-enumeração de PII). */
function innovationMaskClientName(string $name): string {
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    if (!$parts || $parts[0] === '') return 'Cliente';
    $masked = $parts[0];
    if (count($parts) > 1 && $parts[1] !== '') {
        $masked .= ' ' . mb_strtoupper(mb_substr($parts[1], 0, 1)) . '.';
    }
    return $masked;
}

function handleInnovationLoyalty(string $method): void {
    $pdo = db();
    ensureInnovationTables($pdo);
    $phone = preg_replace('/\D/', '', (string)($_GET['phone'] ?? ''));

    if ($method === 'GET' && $phone) {
        // Consulta pública é limitada e não expõe PII completa (nome inteiro/datas)
        // a menos que o requisitante seja o próprio cliente autenticado ou admin.
        rateLimit('loyalty_lookup', 10);
        $fullAccess = isAdmin();
        if (!$fullAccess && function_exists('clientSessionClientId')) {
            $cid = clientSessionClientId();
            if ($cid) {
                $stmtC = $pdo->prepare('SELECT phone FROM clients WHERE id = ? LIMIT 1');
                $stmtC->execute([$cid]);
                $clientPhone = preg_replace('/\D/', '', (string)$stmtC->fetchColumn());
                $fullAccess = $clientPhone !== '' && hash_equals($clientPhone, $phone);
            }
        }

        $stmt = $pdo->prepare('SELECT * FROM loyalty_pieces WHERE phone = ? ORDER BY points DESC');
        $stmt->execute([$phone]);
        $rows = $stmt->fetchAll();
        if (!$rows) jsonRespond(['phone' => $phone, 'pieces' => [], 'totalPoints' => 0, 'tier' => 'bronze', 'discountPercent' => innovationLoyaltyDiscount('bronze')]);
        $total = array_sum(array_column($rows, 'points'));
        $tier = innovationLoyaltyTier($total);
        jsonRespond([
            'phone' => $phone,
            'clientName' => $fullAccess
                ? $rows[0]['client_name']
                : innovationMaskClientName((string)$rows[0]['client_name']),
            'totalPoints' => $total,
            'tier' => $tier,
            'discountPercent' => innovationLoyaltyDiscount($tier),
            'pieces' => array_map(fn($r) => [
                'pieceType' => $r['piece_type'], 'pieceLabel' => $r['piece_label'],
                'cleaningsCount' => (int)$r['cleanings_count'], 'points' => (int)$r['points'],
                'tier' => $r['tier'],
                'lastServiceDate' => $fullAccess ? $r['last_service_date'] : null,
            ], $rows),
        ]);
    }

    requireAdmin();
    if ($method === 'GET') {
        $rows = $pdo->query('SELECT * FROM loyalty_pieces ORDER BY points DESC LIMIT 300')->fetchAll();
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'], 'phone' => $r['phone'], 'clientName' => $r['client_name'],
            'pieceLabel' => $r['piece_label'], 'points' => (int)$r['points'], 'tier' => $r['tier'],
            'cleaningsCount' => (int)$r['cleanings_count'],
        ], $rows));
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $phone = preg_replace('/\D/', '', (string)($b['phone'] ?? ''));
        if (strlen($phone) < 10) jsonRespond(['error' => 'Telefone inválido'], 400);
        $pieceType = san($b['pieceType'] ?? 'sofa', 50) ?? 'sofa';
        $pieceLabel = san($b['pieceLabel'] ?? 'Sofá', 150) ?? 'Sofá';
        $addPoints = max(10, min(100, (int)($b['points'] ?? 50)));

        $stmt = $pdo->prepare('SELECT * FROM loyalty_pieces WHERE phone = ? AND piece_type = ? AND piece_label = ? LIMIT 1');
        $stmt->execute([$phone, $pieceType, $pieceLabel]);
        $existing = $stmt->fetch();

        if ($existing) {
            $newPoints = (int)$existing['points'] + $addPoints;
            $tier = innovationLoyaltyTier($newPoints);
            $pdo->prepare('UPDATE loyalty_pieces SET points = ?, cleanings_count = cleanings_count + 1, tier = ?, last_service_date = ?, updated_at = ? WHERE id = ?')
                ->execute([$newPoints, $tier, date('Y-m-d'), dbNow(), $existing['id']]);
            jsonRespond(['ok' => true, 'points' => $newPoints, 'tier' => $tier, 'discount' => innovationLoyaltyDiscount($tier)]);
        }

        $tier = innovationLoyaltyTier($addPoints);
        $pdo->prepare('INSERT INTO loyalty_pieces (phone, client_name, piece_type, piece_label, cleanings_count, points, tier, last_service_date, created_at, updated_at)
            VALUES (?,?,?,?,1,?,?,?,?,?)')->execute([
            $phone,
            san($b['clientName'] ?? 'Cliente', 150) ?? 'Cliente',
            $pieceType, $pieceLabel, $addPoints, $tier, date('Y-m-d'), dbNow(), dbNow(),
        ]);
        jsonRespond(['ok' => true, 'points' => $addPoints, 'tier' => $tier, 'discount' => innovationLoyaltyDiscount($tier)], 201);
    }

    jsonRespond(['error' => 'Método não suportado'], 405);
}
