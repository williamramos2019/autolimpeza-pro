<?php
/**
 * Blog — banco de links de afiliados + serviço local (Capitão Clean).
 * Usado na geração IA, Content Studio e save manual de posts.
 * Seleção inteligente: blog-affiliate-selection.php (relevância + rotação).
 */

require_once __DIR__ . '/blog-affiliate-selection.php';

function ensureBlogAffiliateLinksTable(PDO $pdo): void {
    static $done = false;
    if ($done) {
        return;
    }
    if (!function_exists('cmsTableExists')) {
        $migrate = __DIR__ . '/migrate-cms.php';
        if (is_file($migrate)) {
            require_once $migrate;
        }
    }
    $sqlFile = __DIR__ . '/migrations/2026-07-28-blog_affiliate_links_v1.sql';
    if (is_file($sqlFile) && function_exists('alpRunSqlMigration')) {
        alpRunSqlMigration($pdo, $sqlFile);
    } elseif (!cmsTableExists($pdo, 'blog_affiliate_links')) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `blog_affiliate_links` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `title` VARCHAR(300) NOT NULL,
            `anchor_text` VARCHAR(500) NOT NULL,
            `url` VARCHAR(2000) NOT NULL,
            `link_type` VARCHAR(30) NOT NULL DEFAULT 'affiliate',
            `category` VARCHAR(100) DEFAULT NULL,
            `service_id` VARCHAR(80) DEFAULT NULL,
            `cities` JSON DEFAULT NULL,
            `keywords` VARCHAR(500) DEFAULT NULL,
            `context_hint` TEXT DEFAULT NULL,
            `image_url` VARCHAR(2000) DEFAULT NULL,
            `sale_price` DECIMAL(12,2) DEFAULT NULL,
            `original_price` DECIMAL(12,2) DEFAULT NULL,
            `rating` DECIMAL(3,2) DEFAULT NULL,
            `discount_percent` SMALLINT UNSIGNED DEFAULT NULL,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `sort_order` INT NOT NULL DEFAULT 0,
            `click_count` INT UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_blog_aff_active` (`active`, `sort_order`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    // Colunas de vitrine (idempotente)
    $commerceCols = [
        "ALTER TABLE `blog_affiliate_links` ADD COLUMN `image_url` VARCHAR(2000) DEFAULT NULL",
        "ALTER TABLE `blog_affiliate_links` ADD COLUMN `sale_price` DECIMAL(12,2) DEFAULT NULL",
        "ALTER TABLE `blog_affiliate_links` ADD COLUMN `original_price` DECIMAL(12,2) DEFAULT NULL",
        "ALTER TABLE `blog_affiliate_links` ADD COLUMN `rating` DECIMAL(3,2) DEFAULT NULL",
        "ALTER TABLE `blog_affiliate_links` ADD COLUMN `discount_percent` SMALLINT UNSIGNED DEFAULT NULL",
    ];
    foreach ($commerceCols as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { /* exists */ }
    }
    if (function_exists('ensureBlogAffiliateUsageTable')) {
        ensureBlogAffiliateUsageTable($pdo);
    }
    $done = true;
    blogAffiliateLinksSeedDefaults($pdo);
    blogAffiliateLinksEnsureShopeeSeed($pdo);
    blogAffiliateLinksEnsureCommercePlaceholders($pdo);
}

/** Preenche preços/rating placeholder quando a vitrine ainda está vazia (idempotente). */
function blogAffiliateLinksEnsureCommercePlaceholders(PDO $pdo): void {
    if (!function_exists('cmsTableExists') || !cmsTableExists($pdo, 'blog_affiliate_links')) {
        return;
    }
    $sqlFile = __DIR__ . '/migrations/2026-07-28-shopee_affiliate_commerce_placeholders.sql';
    if (is_file($sqlFile) && function_exists('alpRunSqlMigration')) {
        try {
            alpRunSqlMigration($pdo, $sqlFile);
        } catch (Throwable $e) {
            if (function_exists('appLog')) {
                appLog('warn', 'blog_affiliate_commerce_placeholders', ['err' => $e->getMessage()]);
            }
        }
        return;
    }
    // Fallback sem alpRunSqlMigration: um UPDATE genérico
    try {
        $pdo->exec("UPDATE blog_affiliate_links
            SET sale_price = COALESCE(sale_price, 49.90),
                original_price = COALESCE(original_price, 69.90),
                discount_percent = COALESCE(discount_percent, 29),
                rating = COALESCE(rating, 4.80)
            WHERE link_type = 'affiliate' AND active = 1 AND sale_price IS NULL");
    } catch (Throwable $e) { /* ignore */ }
}

/** Garante catálogo Shopee no banco (migração idempotente) se houver poucos afiliados. */
function blogAffiliateLinksEnsureShopeeSeed(PDO $pdo): void {
    if (!function_exists('cmsTableExists') || !cmsTableExists($pdo, 'blog_affiliate_links')) {
        return;
    }
    try {
        $affCount = (int)$pdo->query(
            "SELECT COUNT(*) FROM blog_affiliate_links WHERE link_type = 'affiliate' AND active = 1"
        )->fetchColumn();
        if ($affCount >= 10) {
            return;
        }
        $sqlFile = __DIR__ . '/migrations/2026-07-28-shopee_affiliate_links_seed.sql';
        if (is_file($sqlFile) && function_exists('alpRunSqlMigration')) {
            alpRunSqlMigration($pdo, $sqlFile);
        }
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('warn', 'blog_affiliate_shopee_seed', ['err' => $e->getMessage()]);
        }
    }
}

/** @return list<string> */
function blogAffiliateDefaultCities(): array {
    return [
        'Vespasiano', 'São José da Lapa', 'Belo Horizonte', 'Lagoa Santa',
        'Confins', 'Santa Luzia', 'Ribeirão das Neves', 'Sabará', 'Pedro Leopoldo',
    ];
}

function blogAffiliateLinksSeedDefaults(PDO $pdo): void {
    if (!cmsTableExists($pdo, 'blog_affiliate_links')) {
        return;
    }
    $count = (int)$pdo->query('SELECT COUNT(*) FROM blog_affiliate_links')->fetchColumn();
    if ($count > 0) {
        return;
    }
    $now = dbNow();
    $site = defined('SITE_URL') ? rtrim((string)SITE_URL, '/') : 'https://autolimpezapro.com.br';
    $waMsg = 'Olá! Vi o blog da Auto Limpeza Pro e gostaria de solicitar um orçamento de higienização sem compromisso.';
    $waUrl = function_exists('waLink') ? waLink($waMsg) : 'https://wa.me/5531980252882?text=' . rawurlencode($waMsg);
    $citiesJson = json_encode(blogAffiliateDefaultCities(), JSON_UNESCAPED_UNICODE);

    $defaults = [
        [
            'Agendamento WhatsApp',
            'Agende sua higienização em Vespasiano com a equipe Auto Limpeza Pro',
            $waUrl,
            'local_service',
            null,
            null,
            $citiesJson,
            'whatsapp, orçamento, agendar, atendimento domiciliar',
            'CTA principal — serviço profissional na região metropolitana de BH',
            1,
        ],
        [
            'Agenda online',
            'Reserve seu horário de higienização pela agenda online',
            $site . '/agenda',
            'booking',
            null,
            null,
            $citiesJson,
            'agenda, agendamento, horário',
            'CTA secundário — página de agendamento do site',
            2,
        ],
    ];

    $stmt = $pdo->prepare(
        'INSERT INTO blog_affiliate_links
            (title, anchor_text, url, link_type, category, service_id, cities, keywords, context_hint, active, sort_order, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)'
    );
    foreach ($defaults as $row) {
        $stmt->execute([...$row, $now, $now]);
    }
}

function decodeBlogAffiliateLink(array $r): array {
    $cities = $r['cities'] ?? null;
    if (is_string($cities)) {
        $decoded = json_decode($cities, true);
        $cities = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($cities)) {
        $cities = [];
    }
    return [
        'id' => (int)$r['id'],
        'title' => (string)($r['title'] ?? ''),
        'anchorText' => (string)($r['anchor_text'] ?? ''),
        'url' => (string)($r['url'] ?? ''),
        'linkType' => (string)($r['link_type'] ?? 'affiliate'),
        'category' => $r['category'] ?? null,
        'serviceId' => $r['service_id'] ?? null,
        'cities' => array_values(array_map('strval', $cities)),
        'keywords' => $r['keywords'] ?? null,
        'contextHint' => $r['context_hint'] ?? null,
        'imageUrl' => $r['image_url'] ?? null,
        'salePrice' => isset($r['sale_price']) && $r['sale_price'] !== null ? (float)$r['sale_price'] : null,
        'originalPrice' => isset($r['original_price']) && $r['original_price'] !== null ? (float)$r['original_price'] : null,
        'rating' => isset($r['rating']) && $r['rating'] !== null ? (float)$r['rating'] : null,
        'discountPercent' => isset($r['discount_percent']) && $r['discount_percent'] !== null ? (int)$r['discount_percent'] : null,
        'active' => (bool)($r['active'] ?? true),
        'sortOrder' => (int)($r['sort_order'] ?? 0),
        'clickCount' => (int)($r['click_count'] ?? 0),
        'useCount' => (int)($r['use_count'] ?? 0),
        'lastUsedAt' => $r['last_used_at'] ?? null,
    ];
}

/** @return list<array> */
function blogAffiliateLinksFetchAll(PDO $pdo, bool $activeOnly = true): array {
    ensureBlogAffiliateLinksTable($pdo);
    $sql = 'SELECT * FROM blog_affiliate_links';
    if ($activeOnly) {
        $sql .= ' WHERE active = 1';
    }
    $sql .= ' ORDER BY sort_order ASC, id ASC';
    $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    return array_map('decodeBlogAffiliateLink', $rows ?: []);
}

/** Formata lista para o prompt Capitão Clean. */
function blogAffiliateLinksFormatForPrompt(array $links): string {
    if (!$links) {
        return "(Nenhum link cadastrado no banco — use apenas CTAs genéricos sem URL inventada.)";
    }
    $lines = [];
    foreach ($links as $i => $link) {
        $n = $i + 1;
        $type = strtoupper((string)($link['linkType'] ?? 'AFFILIATE'));
        $lines[] = "{$n}. [{$type}] {$link['title']}"
            . "\n   Âncora sugerida: \"{$link['anchorText']}\""
            . "\n   URL EXATA: {$link['url']}"
            . (!empty($link['contextHint']) ? "\n   Contexto: {$link['contextHint']}" : '');
    }
    return implode("\n", $lines);
}

function blogAffiliateLinksBookingUrl(array $links): ?string {
    foreach ($links as $link) {
        if (in_array($link['linkType'] ?? '', ['local_service', 'booking'], true)) {
            return (string)($link['url'] ?? '');
        }
    }
    return null;
}

/** Verifica se URL já aparece nos blocos ou no content. */
function blogAffiliateUrlPresentInPost(array $post, string $url): bool {
    if ($url === '') {
        return true;
    }
    $needle = preg_quote($url, '/');
    $content = (string)($post['content'] ?? '');
    if (preg_match('/' . $needle . '/i', $content)) {
        return true;
    }
    $blocks = $post['blocks'] ?? [];
    if (is_string($blocks)) {
        $decoded = json_decode($blocks, true);
        $blocks = is_array($decoded) ? $decoded : [];
    }
    foreach ($blocks as $b) {
        if (!is_array($b)) {
            continue;
        }
        $blob = json_encode($b, JSON_UNESCAPED_UNICODE);
        if ($blob && preg_match('/' . $needle . '/i', $blob)) {
            return true;
        }
    }
    return false;
}

/**
 * Remove prateleiras/links afiliados antigos para permitir reinjeção com cards ricos.
 * @param list<array> $blocks
 * @param list<string> $affiliateUrls
 * @return list<array>
 */
function blogAffiliateLinksStripAffiliateBlocks(array $blocks, array $affiliateUrls = []): array {
    $urlSet = [];
    foreach ($affiliateUrls as $u) {
        $u = trim((string)$u);
        if ($u !== '') {
            $urlSet[$u] = true;
        }
    }
    $out = [];
    foreach ($blocks as $b) {
        if (!is_array($b)) {
            $out[] = $b;
            continue;
        }
        $type = (string)($b['type'] ?? '');
        if ($type === 'affiliateShelf') {
            continue;
        }
        if ($type === 'linkE') {
            $url = (string)($b['url'] ?? '');
            $isShopee = str_contains($url, 'shope.ee') || str_contains($url, 'shopee.com.br') || str_contains($url, 's.shopee');
            if ($isShopee || isset($urlSet[$url])) {
                continue;
            }
        }
        $out[] = $b;
    }
    return array_values($out);
}

/**
 * Injeta blocos affiliateShelf (3 cards), quote e linkE com links do banco.
 * @param list<array> $blocks
 * @return list<array>
 */
function blogAffiliateLinksInjectBlocks(array $blocks, array $links, string $region): array {
    if (!$links) {
        return $blocks;
    }

    $local = null;
    $booking = null;
    $affiliates = [];
    foreach ($links as $link) {
        $type = (string)($link['linkType'] ?? 'affiliate');
        if ($type === 'local_service' && !$local) {
            $local = $link;
        } elseif ($type === 'booking' && !$booking) {
            $booking = $link;
        } elseif ($type === 'affiliate') {
            $affiliates[] = $link;
        }
    }
    if (!$local && $booking) {
        $local = $booking;
    }

    $affiliateUrls = array_map(static fn($l) => (string)($l['url'] ?? ''), $affiliates);
    $blocks = blogAffiliateLinksStripAffiliateBlocks($blocks, $affiliateUrls);

    $postProbe = ['content' => '', 'blocks' => $blocks];
    $toInsertAffiliate = array_slice($affiliates, 0, 3);

    $insertAt = max(0, (int)floor(count($blocks) * 0.55));
    $faqIdx = null;
    foreach ($blocks as $i => $b) {
        if (is_array($b) && ($b['type'] ?? '') === 'faq') {
            $faqIdx = $i;
            break;
        }
    }
    $affiliateInsertAt = $faqIdx !== null ? max(0, $faqIdx) : max(0, count($blocks) - 1);

    // CTA local no meio — ALERTA DE AGENDA (escassez regional)
    if ($local && !blogAffiliateUrlPresentInPost($postProbe, (string)$local['url'])) {
        $regionLabel = $region !== '' ? $region : 'Vespasiano, São José da Lapa e Belo Horizonte';
        $ctaQuote = "ALERTA DE AGENDA EM {$regionLabel}: Devido à alta demanda de atendimentos domiciliares nesta semana em Vespasiano, São José da Lapa e BH, restam poucas vagas no nosso itinerário. Não espere a mancha fixar ou a alergia piorar!";
        $urgencyAnchor = (string)($local['anchorText'] ?? '');
        if ($urgencyAnchor === '' || preg_match('/^(clique|saiba|veja|acesse)/iu', $urgencyAnchor)) {
            $urgencyAnchor = 'Garantir meu horário com condição especial hoje';
        }
        $midBlocks = [
            [
                'type' => 'quote',
                'text' => $ctaQuote,
                'author' => 'Capitão Clean — Auto Limpeza Pro',
            ],
            [
                'type' => 'linkE',
                'text' => '{{url}}',
                'url' => (string)$local['url'],
                'linkLabel' => $urgencyAnchor,
                'rel' => '',
            ],
        ];
        $blocksBefore = array_slice($blocks, 0, $insertAt);
        $blocksAfter = array_slice($blocks, $insertAt);
        $blocks = array_merge($blocksBefore, $midBlocks, $blocksAfter);
        if ($faqIdx !== null && $faqIdx >= $insertAt) {
            $faqIdx += count($midBlocks);
        }
        $affiliateInsertAt = $faqIdx !== null ? $faqIdx : max(0, count($blocks) - 1);
    }

    // Recomendação: 1 card visual (foto/preço/rating) alinhado ao tema do post
    $affiliateProducts = [];
    foreach (array_slice($toInsertAffiliate, 0, 1) as $link) {
        $sale = $link['salePrice'] ?? null;
        $orig = $link['originalPrice'] ?? null;
        $discount = $link['discountPercent'] ?? null;
        if ($sale !== null && ($orig === null || (float)$orig <= (float)$sale) && (float)$sale > 0) {
            $orig = round(((float)$sale) / 0.7, 2);
            $discount = (int)round((1 - ((float)$sale / (float)$orig)) * 100);
        } elseif ($discount === null && $sale !== null && $orig !== null && (float)$orig > (float)$sale && (float)$orig > 0) {
            $discount = (int)round((1 - ((float)$sale / (float)$orig)) * 100);
        }
        $rating = isset($link['rating']) ? (float)$link['rating'] : 4.8;
        if ($rating <= 0) {
            $rating = 4.8;
        }
        $title = (string)($link['title'] ?? $link['anchorText'] ?? 'Produto recomendado para manutenção');
        $title = preg_replace('/\b(afiliad[oa]s?|shopee|amazon|comissão|comissao|parceir[oa]s?|propaganda|link\s*patrocinado)\b/iu', '', $title) ?? $title;
        $title = trim(preg_replace('/\s{2,}/u', ' ', $title) ?? $title);
        if ($title === '') {
            $title = 'Produto recomendado para manutenção';
        }
        if (function_exists('mb_strlen') && mb_strlen($title) > 72) {
            $title = rtrim(mb_substr($title, 0, 72)) . '…';
        } elseif (strlen($title) > 72) {
            $title = rtrim(substr($title, 0, 72)) . '…';
        }
        $affiliateProducts[] = [
            'id' => (int)($link['id'] ?? 0),
            'title' => $title,
            'url' => (string)$link['url'],
            'imageUrl' => $link['imageUrl'] ?? null,
            'salePrice' => $sale !== null ? (float)$sale : null,
            'originalPrice' => $orig !== null ? (float)$orig : null,
            'rating' => $rating,
            'discountPercent' => $discount,
            'badge' => 'Recomendado pela equipe',
            'rel' => 'nofollow sponsored',
        ];
    }
    if ($affiliateProducts) {
        $shelf = [
            'type' => 'affiliateShelf',
            'title' => 'Dica para Manutenção em Casa',
            'moreLabel' => 'Ver produto recomendado',
            'moreUrl' => (string)($affiliateProducts[0]['url'] ?? ''),
            'products' => $affiliateProducts,
        ];
        $blocksBefore = array_slice($blocks, 0, $affiliateInsertAt);
        $blocksAfter = array_slice($blocks, $affiliateInsertAt);
        $blocks = array_merge($blocksBefore, [$shelf], $blocksAfter);
    }

    // CTA final — urgência
    $finalLink = $local ?: $booking;
    if ($finalLink && !blogAffiliateUrlPresentInPost(['content' => '', 'blocks' => $blocks], (string)$finalLink['url'])) {
        $finalAnchor = (string)($finalLink['anchorText'] ?? '');
        if ($finalAnchor === '' || preg_match('/^(clique|saiba|veja|acesse)/iu', $finalAnchor)) {
            $finalAnchor = 'Garantir meu agendamento prioritário agora';
        }
        $blocks[] = [
            'type' => 'h2',
            'text' => 'Últimas vagas desta semana — não adie',
        ];
        $blocks[] = [
            'type' => 'linkE',
            'text' => 'Cada dia a mais com ácaros e umidade no estofado aumenta o risco. {{url}} antes que a agenda da região feche.',
            'url' => (string)$finalLink['url'],
            'linkLabel' => $finalAnchor,
            'rel' => in_array($finalLink['linkType'] ?? '', ['local_service', 'booking'], true) ? '' : 'nofollow sponsored',
        ];
    }

    return $blocks;
}

/**
 * Enriquece post com links do banco (manual ou IA).
 * @param array<string,mixed> $post
 * @return array<string,mixed>
 */
function blogAffiliateLinksFetchAllowlist(PDO $pdo): array {
    ensureBlogAffiliateLinksTable($pdo);
    $out = [];
    try {
        $stmt = $pdo->query('SELECT id, url, anchor_text FROM blog_affiliate_links WHERE active = 1 AND url IS NOT NULL AND url != \'\'');
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) {
            $u = (string)($r['url'] ?? '');
            if ($u !== '') {
                $out[$u] = [
                    'id' => (int)$r['id'],
                    'url' => $u,
                    'anchorText' => (string)($r['anchor_text'] ?? ''),
                ];
            }
        }
    } catch (Throwable $e) {
        foreach (blogAffiliateLinksFetchAll($pdo, true) as $l) {
            $out[(string)$l['url']] = $l;
        }
    }
    return $out;
}

function blogAffiliateLinksEnrichPost(PDO $pdo, array $post): array {
    try {
        ensureBlogAffiliateLinksTable($pdo);
        $contentSnippet = '';
        if (!empty($post['content']) && is_string($post['content'])) {
            $contentSnippet = $post['content'];
        } elseif (!empty($post['blocks']) && function_exists('cmsBlocksToPlainText')) {
            $contentSnippet = cmsBlocksToPlainText($post['blocks']);
        }
        $params = [
            'title' => $post['title'] ?? '',
            'keyword' => $post['keywords'] ?? ($post['keyword'] ?? ''),
            'category' => $post['category'] ?? '',
            'serviceId' => $post['serviceId'] ?? $post['service_id'] ?? '',
            'city' => $post['city'] ?? '',
            'tags' => $post['tags'] ?? [],
            'slug' => $post['slug'] ?? '',
            'id' => $post['id'] ?? 0,
            'content' => mb_substr((string)$contentSnippet, 0, 1800),
            'recordUsage' => $post['recordAffiliateUsage'] ?? true,
            'forceReselect' => !empty($post['forceAffiliateReselect']),
        ];
        if (is_string($params['tags'])) {
            $params['tags'] = array_map('trim', explode(',', $params['tags']));
        }
        $links = blogAffiliateLinksPickForPost($pdo, $params);
        if (!$links) {
            return $post;
        }

        $region = (string)($post['city'] ?? '');
        if ($region === '' && !empty($params['cities']) && is_array($params['cities'])) {
            $region = implode(', ', array_slice($params['cities'], 0, 3));
        }
        if ($region === '') {
            $region = 'Vespasiano, São José da Lapa e Belo Horizonte';
        }

        $blocks = $post['blocks'] ?? [];
        if (is_string($blocks)) {
            $decoded = json_decode($blocks, true);
            $blocks = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($blocks)) {
            $blocks = [];
        }

        $post['blocks'] = blogAffiliateLinksInjectBlocks($blocks, $links, $region);
        $post['affiliateLinksApplied'] = array_map(static fn($l) => [
            'id' => $l['id'] ?? null,
            'title' => $l['title'] ?? '',
            'url' => $l['url'] ?? '',
            'linkType' => $l['linkType'] ?? '',
        ], $links);
        if (!empty($GLOBALS['ALP_LAST_AFFILIATE_SELECTION']['log'])) {
            $post['affiliateSelectionLog'] = $GLOBALS['ALP_LAST_AFFILIATE_SELECTION']['log'];
        }

        // Sanitiza externalLinks da IA — só URLs do banco (não inventa link)
        $allowedUrls = blogAffiliateLinksFetchAllowlist($pdo);
        if (!empty($post['externalLinks']) && is_array($post['externalLinks'])) {
            $clean = [];
            foreach ($post['externalLinks'] as $ext) {
                if (!is_array($ext)) {
                    continue;
                }
                $u = (string)($ext['url'] ?? '');
                if ($u !== '' && isset($allowedUrls[$u])) {
                    $clean[] = [
                        'anchor' => san($ext['anchor'] ?? $allowedUrls[$u]['anchorText'], 500) ?? $allowedUrls[$u]['anchorText'],
                        'url' => $u,
                    ];
                }
            }
            $post['externalLinks'] = $clean;
        }
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('warn', 'blog_affiliate_enrich_failed', ['err' => $e->getMessage()]);
        }
    }
    return $post;
}

/** Bloco de instruções Capitão Clean — medo + escassez + SEO local + afiliados. */
function blogCapitaoCleanPromptSection(array $params, string $linkListFormatted): string {
    $titulo = trim((string)($params['keyword'] ?? $params['topic'] ?? $params['title'] ?? 'Higienização profissional'));
    $cidade = trim((string)($params['city'] ?? ''));
    if ($cidade === '' && !empty($params['cities']) && is_array($params['cities'])) {
        $cidade = implode(', ', array_slice($params['cities'], 0, 4));
    }
    if ($cidade === '') {
        $cidade = 'Vespasiano, São José da Lapa, Belo Horizonte e Região Metropolitana';
    }
    $linkAgendamento = blogAffiliateLinksBookingUrl(
        blogAffiliateLinksPickForPost(db(), $params)
    ) ?? '(usar link LOCAL_SERVICE da lista)';

    return <<<CAP
Você é o Capitão Clean — especialista em Copywriting de Alta Conversão, Psicologia Consumidora e SEO Local On-Page do Auto Limpeza Pro.

MISSÃO: SEO agressivo + copy com GATILHOS DE MEDO (ácaros, bactérias invisíveis, mofo, desvalorização do estofado/veículo) e ESCASSEZ/URGÊNCIA (vagas limitadas na região). Converter em DUAS frentes:
1) PRIMÁRIO — prestar serviço, ensinar técnica de higienização/manutenção e gerar autoridade para a Auto Limpeza Pro (agendar em Vespasiano, São José da Lapa, BH e Região Metropolitana).
2) SECUNDÁRIO — no meio ou ao final, 1 bloco affiliateShelf com 1 produto de manutenção em casa (relação direta com o tema; ex.: urina no colchão → neutralizador/protetor impermeável).

DADOS DO POST:
- TÍTULO/TEMA: {$titulo}
- REGIONALIZAÇÃO: {$cidade}
- LINKS DO BANCO (use APENAS estes — NUNCA invente URLs):
{$linkListFormatted}

REGRA DE OURO — TEXTO PÚBLICO (NUNCA use estas palavras nem equivalentes):
- Proibido: "Afiliado", "Shopee", "Amazon", "Comissão", "Parceiro", "Propaganda", "Link Patrocinado", "Marketplace".
- NUNCA exiba badges/logotipos de lojas (sem tag SHOPEE/AMAZON).
- CTAs do produto: "Conferir Oferta", "Ver na Loja", "Garantir o Seu" ou "Ver Produto Recomendado".
- Título do shelf: "Dica para Manutenção em Casa" ou "Recomendação do Especialista".
- Card do produto: nome curto, DE (preço original), POR (preço promocional), desconto (-XX%), avaliação (★), imageUrl, url (só no href).

REGRAS DE COPY (MEDO E ESCASSEZ):
1. MEDO / Aversão à perda: problemas CONCRETOS do tema (ácaros, alergias, fungos, mofo profundo, perda de valor de revenda); adiar sai mais caro. Nunca H2 genérico.
2. ESCASSEZ: agenda domiciliar em Vespasiano, São José da Lapa e BH disputada — poucas vagas por semana.
3. Explique por que paninho com água piora (fungo no fundo da espuma).
4. Âncoras de impacto/urgência (ex.: "Garantir meu agendamento prioritário em Vespasiano", "Ver produto recomendado para manutenção"). Proibido "clique aqui" / "saiba mais".
5. URLs EXATAS da lista. Serviço local: bloco quote (ALERTA DE AGENDA) no meio + linkE no final. Produto: 1 bloco affiliateShelf (não linkE solto com nome de loja).
6. PROIBIDO em título/H2/corpo: "O Perigo Oculto", "O Perigo Escondido", "O Risco Oculto", "O Perigo Invisível", "A Ameaça Invisível", "O Inimigo Oculto" — cada subtítulo deve ser específico a {$titulo}.

ESTRUTURA OBRIGATÓRIA (no JSON):
- coverImagePrompt: prompt DETALHADO EM INGLÊS — objeto físico EXATO do artigo (sofá, banco de carro, colchão, tapete, pós-obra). Proibido capa genérica/aleatória.
- title (H1): alto impacto — dor, risco ou curiosidade + SEO (sem clichês da lista proibida).
- Intro concreta (blocks p): problema específico de {$titulo}; impacto na saúde da família; urgência local.
- Conteúdo H2/H3 escaneável e ESPECÍFICOS ao tema, negritos via **texto**, tópicos curtos.
- quote CTA: "ALERTA DE AGENDA EM {$cidade}: … restam poucas vagas… Não espere a mancha fixar ou a alergia piorar!" + linkE com âncora urgente apontando para {$linkAgendamento} (ou URL LOCAL_SERVICE da lista).
- 1 affiliateShelf com title "Dica para Manutenção em Casa" e products[0] com title, url, imageUrl, salePrice, originalPrice, discountPercent, rating.
- FAQ 3–4 itens eliminando objeções (preço, secagem, segurança dos produtos, atendimento local).

TOM: autoritário, visceral, persuasivo — medo + urgência + solução profissional sem esforço.
LINK AGENDAMENTO (referência): {$linkAgendamento}
CAP;
}

function handleBlogAffiliateLinks(string $method): void {
    ensureCmsMigrated();
    $pdo = db();
    ensureBlogAffiliateLinksTable($pdo);

    if ($method === 'GET') {
        if (!isAdmin()) {
            jsonRespond(['error' => 'Acesso negado'], 403);
        }
        if (($_GET['stats'] ?? '') === '1') {
            jsonRespond(blogAffiliateSelectionStats($pdo));
        }
        if (($_GET['preview'] ?? '') === '1') {
            $params = [
                'title' => (string)($_GET['title'] ?? ''),
                'keyword' => (string)($_GET['keyword'] ?? ''),
                'category' => (string)($_GET['category'] ?? ''),
                'serviceId' => (string)($_GET['serviceId'] ?? $_GET['service_id'] ?? ''),
                'city' => (string)($_GET['city'] ?? ''),
                'slug' => (string)($_GET['slug'] ?? ''),
                'recordUsage' => false,
                'forceReselect' => true,
            ];
            $links = blogAffiliateLinksPickForPost($pdo, $params, sanInt($_GET['max'] ?? 4) ?: 4);
            jsonRespond([
                'context' => $GLOBALS['ALP_LAST_AFFILIATE_SELECTION']['ctx'] ?? blogAffiliateBuildSemanticContext($params),
                'log' => $GLOBALS['ALP_LAST_AFFILIATE_SELECTION']['log'] ?? null,
                'links' => array_map(static function (array $l): array {
                    unset($l['_reasons'], $l['_score']);
                    return $l;
                }, $links),
            ]);
        }
        if (($_GET['all'] ?? '') === '1') {
            $stmt = $pdo->query('SELECT * FROM blog_affiliate_links ORDER BY sort_order ASC, id ASC');
            $rows = array_map('decodeBlogAffiliateLink', $stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
            jsonRespond($rows);
        }
        jsonRespond(blogAffiliateLinksFetchAll($pdo, true));
    }

    requireCmsWrite();
    $b = jsonBody();
    $now = dbNow();

    if ($method === 'POST') {
        $title = san($b['title'] ?? null, 300);
        $anchor = san($b['anchorText'] ?? $b['anchor_text'] ?? null, 500);
        $url = san($b['url'] ?? null, 2000);
        if (!$title || !$anchor || !$url) {
            jsonRespond(['error' => 'Título, âncora e URL são obrigatórios'], 400);
        }
        $linkType = san($b['linkType'] ?? $b['link_type'] ?? 'affiliate', 30) ?? 'affiliate';
        if (!in_array($linkType, ['affiliate', 'local_service', 'booking', 'internal'], true)) {
            $linkType = 'affiliate';
        }
        $cities = $b['cities'] ?? [];
        if (!is_array($cities)) {
            $cities = array_filter(array_map('trim', explode(',', (string)$cities)));
        }
        $salePrice = isset($b['salePrice']) || isset($b['sale_price'])
            ? (is_numeric($b['salePrice'] ?? $b['sale_price'] ?? null) ? (float)($b['salePrice'] ?? $b['sale_price']) : null)
            : null;
        $originalPrice = isset($b['originalPrice']) || isset($b['original_price'])
            ? (is_numeric($b['originalPrice'] ?? $b['original_price'] ?? null) ? (float)($b['originalPrice'] ?? $b['original_price']) : null)
            : null;
        $rating = isset($b['rating']) && is_numeric($b['rating']) ? (float)$b['rating'] : null;
        $discount = isset($b['discountPercent']) || isset($b['discount_percent'])
            ? sanInt($b['discountPercent'] ?? $b['discount_percent'] ?? null)
            : null;
        $pdo->prepare(
            'INSERT INTO blog_affiliate_links
                (title, anchor_text, url, link_type, category, service_id, cities, keywords, context_hint,
                 image_url, sale_price, original_price, rating, discount_percent,
                 active, sort_order, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([
            $title,
            $anchor,
            $url,
            $linkType,
            san($b['category'] ?? null, 100),
            san($b['serviceId'] ?? $b['service_id'] ?? null, 80),
            json_encode(array_values($cities), JSON_UNESCAPED_UNICODE),
            san($b['keywords'] ?? null, 500),
            san($b['contextHint'] ?? $b['context_hint'] ?? null, 2000),
            san($b['imageUrl'] ?? $b['image_url'] ?? null, 2000),
            $salePrice,
            $originalPrice,
            $rating,
            $discount,
            sanBool($b['active'] ?? true) ? 1 : 0,
            sanInt($b['sortOrder'] ?? $b['sort_order'] ?? 0),
            $now,
            $now,
        ]);
        $id = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT * FROM blog_affiliate_links WHERE id = ?');
        $stmt->execute([$id]);
        jsonRespond(decodeBlogAffiliateLink($stmt->fetch(PDO::FETCH_ASSOC) ?: []));
    }

    if ($method === 'PUT') {
        $id = sanInt($_GET['id'] ?? $b['id'] ?? 0);
        if (!$id) {
            jsonRespond(['error' => 'ID obrigatório'], 400);
        }
        $cities = $b['cities'] ?? [];
        if (!is_array($cities)) {
            $cities = array_filter(array_map('trim', explode(',', (string)$cities)));
        }
        $linkType = san($b['linkType'] ?? $b['link_type'] ?? 'affiliate', 30) ?? 'affiliate';
        $salePrice = isset($b['salePrice']) || isset($b['sale_price'])
            ? (is_numeric($b['salePrice'] ?? $b['sale_price'] ?? null) ? (float)($b['salePrice'] ?? $b['sale_price']) : null)
            : null;
        $originalPrice = isset($b['originalPrice']) || isset($b['original_price'])
            ? (is_numeric($b['originalPrice'] ?? $b['original_price'] ?? null) ? (float)($b['originalPrice'] ?? $b['original_price']) : null)
            : null;
        $rating = isset($b['rating']) && is_numeric($b['rating']) ? (float)$b['rating'] : null;
        $discount = isset($b['discountPercent']) || isset($b['discount_percent'])
            ? sanInt($b['discountPercent'] ?? $b['discount_percent'] ?? null)
            : null;
        $pdo->prepare(
            'UPDATE blog_affiliate_links SET title=?, anchor_text=?, url=?, link_type=?, category=?, service_id=?, cities=?, keywords=?, context_hint=?,
             image_url=?, sale_price=?, original_price=?, rating=?, discount_percent=?, active=?, sort_order=?, updated_at=? WHERE id=?'
        )->execute([
            san($b['title'] ?? null, 300),
            san($b['anchorText'] ?? $b['anchor_text'] ?? null, 500),
            san($b['url'] ?? null, 2000),
            $linkType,
            san($b['category'] ?? null, 100),
            san($b['serviceId'] ?? $b['service_id'] ?? null, 80),
            json_encode(array_values($cities), JSON_UNESCAPED_UNICODE),
            san($b['keywords'] ?? null, 500),
            san($b['contextHint'] ?? $b['context_hint'] ?? null, 2000),
            san($b['imageUrl'] ?? $b['image_url'] ?? null, 2000),
            $salePrice,
            $originalPrice,
            $rating,
            $discount,
            sanBool($b['active'] ?? true) ? 1 : 0,
            sanInt($b['sortOrder'] ?? $b['sort_order'] ?? 0),
            $now,
            $id,
        ]);
        $stmt = $pdo->prepare('SELECT * FROM blog_affiliate_links WHERE id = ?');
        $stmt->execute([$id]);
        jsonRespond(decodeBlogAffiliateLink($stmt->fetch(PDO::FETCH_ASSOC) ?: []));
    }

    if ($method === 'DELETE') {
        requireCmsManage();
        $id = sanInt($_GET['id'] ?? 0);
        if (!$id) {
            jsonRespond(['error' => 'ID obrigatório'], 400);
        }
        $pdo->prepare('DELETE FROM blog_affiliate_links WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

/** URLs padrão dos datafeeds Shopee Affiliate (Auto Limpeza Pro). */
function shopeeAffiliateDefaultFeedUrls(): array {
    return [
        'https://affiliate.shopee.com.br/api/v1/datafeed/download?id=YWJjZGVmZ2hpamtsbW5vcPNcbnfdFhhQkoz1FtnUm6DtED25ejObtofpYLqHBC0h',
        'https://affiliate.shopee.com.br/api/v1/datafeed/download?id=YWJjZGVmZ2hpamtsbW5vcFMjz35zY_7hscVJ_4QLIFiIR3DQ9hsrLcX6rgIVVFkb',
    ];
}

/**
 * Baixa feeds Shopee para storage/shopee-feeds/ (cache 24h).
 * @return list<string> caminhos locais
 */
function shopeeAffiliateDownloadFeeds(array $urls, ?string $storageDir = null): array {
    $dir = $storageDir ?? (__DIR__ . '/storage/shopee-feeds');
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $paths = [];
    foreach ($urls as $i => $url) {
        $url = trim((string)$url);
        if ($url === '') {
            continue;
        }
        $hash = substr(md5($url), 0, 12);
        $path = $dir . '/feed-' . ($i + 1) . '-' . $hash . '.csv';
        $fresh = is_file($path) && (time() - filemtime($path)) < 86400;
        if (!$fresh) {
            $ctx = stream_context_create([
                'http' => ['timeout' => 600, 'follow_location' => 1],
                'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
            ]);
            $data = @file_get_contents($url, false, $ctx);
            if ($data === false || $data === '') {
                if (!is_file($path)) {
                    throw new RuntimeException('Falha ao baixar feed Shopee: ' . $url);
                }
            } else {
                file_put_contents($path, $data);
            }
        }
        if (is_file($path)) {
            $paths[] = $path;
        }
    }
    return $paths;
}

/** Reaplica links do banco (Shopee + CTA local) em um post/rascunho existente. */
function handleBlogApplyAffiliateLinks(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Método não permitido'], 405);
    }
    requireCmsWrite();
    $b = jsonBody();
    $slug = san($_GET['slug'] ?? $b['slug'] ?? null, 200);
    if (!$slug) {
        jsonRespond(['error' => 'Slug obrigatório'], 400);
    }
    $pdo = db();
    ensureBlogAffiliateLinksTable($pdo);
    blogAffiliateLinksEnsureShopeeSeed($pdo);

    $stmt = $pdo->prepare('SELECT * FROM blog_posts WHERE slug = ? LIMIT 1');
    $stmt->execute([$slug]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        jsonRespond(['error' => 'Post não encontrado'], 404);
    }
    $post = decodeBlogPost($row);
    $post['forceAffiliateReselect'] = true;
    $post['recordAffiliateUsage'] = true;
    $enriched = blogAffiliateLinksEnrichPost($pdo, $post);
    $now = dbNow();
    $content = (string)($enriched['content'] ?? '');
    if ($content === '' && function_exists('cmsBlocksToPlainText')) {
        $plain = cmsBlocksToPlainText($enriched['blocks'] ?? []);
        if ($plain !== '') {
            $content = $plain;
            $enriched['content'] = $plain;
        }
    }
    $pdo->prepare('UPDATE blog_posts SET blocks = ?, content = ?, updated_at = ? WHERE slug = ?')->execute([
        json_encode($enriched['blocks'] ?? [], JSON_UNESCAPED_UNICODE),
        $content,
        $now,
        $slug,
    ]);
    $linkECount = count(array_filter(
        is_array($enriched['blocks'] ?? null) ? $enriched['blocks'] : [],
        static fn($blk) => is_array($blk) && ($blk['type'] ?? '') === 'linkE'
    ));
    jsonRespond([
        'ok' => true,
        'slug' => $slug,
        'affiliateLinksApplied' => $enriched['affiliateLinksApplied'] ?? [],
        'linkECount' => $linkECount,
        'post' => $enriched,
    ]);
}

/**
 * Incrementa click_count de um link afiliado (público, rate-limited).
 * Aceita id numérico e/ou url exact match — nunca altera a URL cadastrada.
 */
function handleBlogAffiliateClick(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Método não permitido'], 405);
    }
    $b = jsonBody();
    $id = sanInt($b['id'] ?? $_GET['id'] ?? 0);
    $url = trim((string)($b['url'] ?? ''));
    if ($url !== '' && strlen($url) > 2000) {
        $url = substr($url, 0, 2000);
    }
    if (!$id && $url === '') {
        jsonRespond(['error' => 'id ou url obrigatório'], 400);
    }

    $pdo = db();
    ensureBlogAffiliateLinksTable($pdo);

    $row = null;
    if ($id > 0) {
        $stmt = $pdo->prepare('SELECT id, url, click_count FROM blog_affiliate_links WHERE id = ? AND active = 1 LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if (!$row && $url !== '') {
        $stmt = $pdo->prepare('SELECT id, url, click_count FROM blog_affiliate_links WHERE url = ? AND active = 1 LIMIT 1');
        $stmt->execute([$url]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if (!$row) {
        // Não 404 ruidoso: click em URL estática/legado ainda é válido no front
        jsonRespond(['ok' => true, 'tracked' => false, 'reason' => 'not_in_db']);
    }

    $pdo->prepare('UPDATE blog_affiliate_links SET click_count = click_count + 1, updated_at = ? WHERE id = ?')
        ->execute([dbNow(), (int)$row['id']]);

    jsonRespond([
        'ok' => true,
        'tracked' => true,
        'id' => (int)$row['id'],
        'clickCount' => (int)($row['click_count'] ?? 0) + 1,
    ]);
}

function handleBlogAffiliateLinksImportShopee(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Método não permitido'], 405);
    }
    requireCmsWrite();
    if (!function_exists('shopeeAffiliateImportToDatabase')) {
        require_once __DIR__ . '/shopee-affiliate-import.php';
    }

    $b = jsonBody();
    $max = sanInt($b['max'] ?? 100) ?: 100;
    $max = max(10, min(200, $max));
    $useCache = sanBool($b['useCache'] ?? true);
    $feedUrls = $b['feedUrls'] ?? $b['feed_urls'] ?? shopeeAffiliateDefaultFeedUrls();
    if (!is_array($feedUrls)) {
        $feedUrls = shopeeAffiliateDefaultFeedUrls();
    }

    $pdo = db();
    ensureBlogAffiliateLinksTable($pdo);

    try {
        $localFeeds = [];
        if (!empty($b['localFeeds']) && is_array($b['localFeeds'])) {
            foreach ($b['localFeeds'] as $p) {
                if (is_string($p) && is_file($p)) {
                    $localFeeds[] = $p;
                }
            }
        }
        if (!$localFeeds) {
            $localFeeds = shopeeAffiliateDownloadFeeds($feedUrls);
        } elseif (!$useCache) {
            $localFeeds = shopeeAffiliateDownloadFeeds($feedUrls);
        }

        $result = shopeeAffiliateImportToDatabase($pdo, $localFeeds, $max);
        jsonRespond([
            'ok' => true,
            'imported' => $result['imported'],
            'skipped' => $result['skipped'],
            'totalFiltered' => $result['total_filtered'],
            'feeds' => array_map('basename', $localFeeds),
            'sample' => array_slice($result['products'], 0, 10),
        ]);
    } catch (Throwable $e) {
        jsonRespond(['error' => $e->getMessage()], 500);
    }
}
