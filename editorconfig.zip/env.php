<?php
/**
 * Carrega variáveis de ambiente de forma segura.
 * Ordem: getenv / $_ENV → arquivo .env (se existir) → defaults do config.php.
 *
 * Nunca faça commit de .env com secrets. Use .env.example como modelo.
 */
function alpLoadEnvFile(?string $path = null): void {
    static $loaded = false;
    if ($loaded) return;
    $loaded = true;

    $path = $path ?? (dirname(__DIR__) . '/.env');
    // Em cPanel o .env fica ao lado de api.php (public_html)
    $candidates = array_unique(array_filter([
        $path,
        __DIR__ . '/.env',
        dirname(__DIR__) . '/.env',
    ]));

    foreach ($candidates as $file) {
        if (!is_file($file) || !is_readable($file)) continue;
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) continue;
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') continue;
            if (strpos($line, '=') === false) continue;
            [$key, $val] = explode('=', $line, 2);
            $key = trim($key);
            $val = trim($val);
            if ($key === '') continue;
            // Remove aspas simples/duplas
            if (
                (strlen($val) >= 2 && $val[0] === '"' && substr($val, -1) === '"')
                || (strlen($val) >= 2 && $val[0] === "'" && substr($val, -1) === "'")
            ) {
                $val = substr($val, 1, -1);
            }
            // Não sobrescreve variáveis já definidas no ambiente do servidor
            $existing = getenv($key);
            if ($existing !== false && $existing !== '') continue;
            putenv("$key=$val");
            $_ENV[$key] = $val;
            $_SERVER[$key] = $val;
        }
        break; // primeiro .env encontrado
    }
}

/**
 * Lê string do ambiente com default.
 */
function alpEnv(string $key, $default = null) {
    $v = getenv($key);
    if ($v === false || $v === '') {
        $v = $_ENV[$key] ?? $_SERVER[$key] ?? null;
    }
    if ($v === null || $v === '') return $default;
    return $v;
}

function alpEnvBool(string $key, bool $default = false): bool {
    $v = alpEnv($key, null);
    if ($v === null) return $default;
    $v = strtolower(trim((string)$v));
    return in_array($v, ['1', 'true', 'yes', 'on'], true);
}

function alpEnvInt(string $key, int $default = 0): int {
    $v = alpEnv($key, null);
    if ($v === null || $v === '') return $default;
    return (int)$v;
}
