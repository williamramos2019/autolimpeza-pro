<?php
/**
 * Web Push nativo (VAPID) — Notification Engine proprietário (RFC 8030).
 * Requer VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY e VAPID_SUBJECT em config.php
 * ou chaves em site_config (vapid_public_key / vapid_private_key).
 */

function ensurePushSubscriptionsTable(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `push_subscriptions` (
        `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `endpoint`      VARCHAR(768) NOT NULL,
        `endpoint_hash` CHAR(64)     NOT NULL,
        `p256dh`        VARCHAR(255) NOT NULL,
        `auth`          VARCHAR(255) NOT NULL,
        `owner_type`    VARCHAR(20)  NOT NULL DEFAULT 'visitor',
        `owner_id`      VARCHAR(64)  NOT NULL,
        `client_id`     INT UNSIGNED DEFAULT NULL,
        `user_agent`    VARCHAR(500) DEFAULT NULL,
        `browser`       VARCHAR(40)  DEFAULT NULL,
        `platform`      VARCHAR(40)  DEFAULT NULL,
        `device`        VARCHAR(40)  DEFAULT NULL,
        `language`      VARCHAR(20)  DEFAULT NULL,
        `timezone`      VARCHAR(60)  DEFAULT NULL,
        `last_seen`     DATETIME     DEFAULT NULL,
        `enabled`       TINYINT(1)   NOT NULL DEFAULT 1,
        `last_error`    VARCHAR(500) DEFAULT NULL,
        `created_at`    DATETIME     NOT NULL,
        `updated_at`    DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_endpoint_hash` (`endpoint_hash`),
        INDEX `idx_owner` (`owner_type`, `owner_id`, `enabled`),
        INDEX `idx_client` (`client_id`, `enabled`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Colunas aditivas (instalação antiga)
    foreach ([
        "ALTER TABLE push_subscriptions ADD COLUMN client_id INT UNSIGNED DEFAULT NULL AFTER owner_id",
        "ALTER TABLE push_subscriptions ADD COLUMN browser VARCHAR(40) DEFAULT NULL AFTER user_agent",
        "ALTER TABLE push_subscriptions ADD COLUMN platform VARCHAR(40) DEFAULT NULL AFTER browser",
        "ALTER TABLE push_subscriptions ADD COLUMN device VARCHAR(40) DEFAULT NULL AFTER platform",
        "ALTER TABLE push_subscriptions ADD COLUMN language VARCHAR(20) DEFAULT NULL AFTER device",
        "ALTER TABLE push_subscriptions ADD COLUMN timezone VARCHAR(60) DEFAULT NULL AFTER language",
        "ALTER TABLE push_subscriptions ADD COLUMN last_seen DATETIME DEFAULT NULL AFTER timezone",
    ] as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { /* já existe */ }
    }
}

/** Garante tabelas do Notification Engine (campanhas / envios / delivery logs). */
function ensureNotificationEngineTables(PDO $pdo): void {
    ensurePushSubscriptionsTable($pdo);
    $sqlFile = __DIR__ . '/migrations/notification_engine_v1.sql';
    if (is_file($sqlFile) && function_exists('alpRunSqlMigration')) {
        alpRunSqlMigration($pdo, $sqlFile);
        return;
    }
    // Fallback inline se migration helper ausente
    foreach ([
        "CREATE TABLE IF NOT EXISTS `notification_campaigns` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(200) NOT NULL,
            `description` TEXT DEFAULT NULL,
            `status` VARCHAR(30) NOT NULL DEFAULT 'draft',
            `segment` VARCHAR(80) NOT NULL DEFAULT 'all',
            `segment_json` JSON DEFAULT NULL,
            `template_id` INT UNSIGNED DEFAULT NULL,
            `title` VARCHAR(200) DEFAULT NULL,
            `body` TEXT DEFAULT NULL,
            `image` VARCHAR(500) DEFAULT NULL,
            `icon` VARCHAR(500) DEFAULT NULL,
            `url` VARCHAR(500) DEFAULT NULL,
            `tag` VARCHAR(80) DEFAULT NULL,
            `priority` VARCHAR(20) NOT NULL DEFAULT 'normal',
            `ttl` INT UNSIGNED NOT NULL DEFAULT 86400,
            `scheduled_at` DATETIME DEFAULT NULL,
            `sent_at` DATETIME DEFAULT NULL,
            `created_by` VARCHAR(120) DEFAULT NULL,
            `stats_json` JSON DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS `notification_engine_sends` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `campaign_id` INT UNSIGNED DEFAULT NULL,
            `title` VARCHAR(200) NOT NULL,
            `body` TEXT NOT NULL,
            `image` VARCHAR(500) DEFAULT NULL,
            `icon` VARCHAR(500) DEFAULT NULL,
            `url` VARCHAR(500) DEFAULT NULL,
            `tag` VARCHAR(80) DEFAULT NULL,
            `priority` VARCHAR(20) NOT NULL DEFAULT 'normal',
            `ttl` INT UNSIGNED NOT NULL DEFAULT 86400,
            `segment` VARCHAR(80) NOT NULL DEFAULT 'all',
            `status` VARCHAR(30) NOT NULL DEFAULT 'queued',
            `created_by` VARCHAR(120) DEFAULT NULL,
            `scheduled_at` DATETIME DEFAULT NULL,
            `sent_count` INT UNSIGNED NOT NULL DEFAULT 0,
            `fail_count` INT UNSIGNED NOT NULL DEFAULT 0,
            `click_count` INT UNSIGNED NOT NULL DEFAULT 0,
            `open_count` INT UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS `notification_delivery_logs` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `send_id` INT UNSIGNED DEFAULT NULL,
            `subscription_id` INT UNSIGNED DEFAULT NULL,
            `status` VARCHAR(30) NOT NULL DEFAULT 'pending',
            `http_code` INT DEFAULT NULL,
            `browser_response` TEXT DEFAULT NULL,
            `clicked` TINYINT(1) NOT NULL DEFAULT 0,
            `opened` TINYINT(1) NOT NULL DEFAULT 0,
            `delivered` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            KEY `idx_ndl_send` (`send_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ] as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { /* */ }
    }
}

/**
 * Gera par VAPID (P-256) e persiste em site_config.
 * @return array{public:string,private:string,subject:string}|null
 */
function webPushGenerateAndStoreKeys(PDO $pdo, ?string $subject = null): ?array {
    $key = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
    if ($key === false) return null;
    $details = openssl_pkey_get_details($key);
    if (!$details || empty($details['ec']['x']) || empty($details['ec']['y']) || empty($details['ec']['d'])) {
        return null;
    }
    $publicRaw = "\x04"
        . str_pad((string)$details['ec']['x'], 32, "\x00", STR_PAD_LEFT)
        . str_pad((string)$details['ec']['y'], 32, "\x00", STR_PAD_LEFT);
    $publicB64 = rtrim(strtr(base64_encode($publicRaw), '+/', '-_'), '=');

    // Export PKCS8 DER for private key (compatível com webPushCreateJwt)
    $pemOut = '';
    if (!openssl_pkey_export($key, $pemOut)) return null;
    $pemClean = preg_replace('/-----BEGIN [^-]+-----|-----END [^-]+-----|\s+/', '', $pemOut);
    $der = base64_decode((string)$pemClean, true);
    if ($der === false) return null;
    $privateB64 = rtrim(strtr(base64_encode($der), '+/', '-_'), '=');

    $subj = $subject ?: (defined('VAPID_SUBJECT') ? (string)VAPID_SUBJECT : 'mailto:contato@autolimpezapro.com.br');
    if (function_exists('siteConfigSet')) {
        siteConfigSet($pdo, 'vapid_public_key', $publicB64);
        siteConfigSet($pdo, 'vapid_private_key', $privateB64);
        siteConfigSet($pdo, 'vapid_subject', $subj);
    }
    return ['public' => $publicB64, 'private' => $privateB64, 'subject' => $subj];
}

function webPushConfig(PDO $pdo): array {
    $public  = defined('VAPID_PUBLIC_KEY') ? (string) VAPID_PUBLIC_KEY : '';
    $private = defined('VAPID_PRIVATE_KEY') ? (string) VAPID_PRIVATE_KEY : '';
    $subject = defined('VAPID_SUBJECT') ? (string) VAPID_SUBJECT : 'mailto:contato@autolimpezapro.com.br';

    if ($public === '' || $private === '') {
        try {
            $stmt = $pdo->prepare("SELECT key_name, value FROM site_config WHERE key_name IN ('vapid_public_key','vapid_private_key','vapid_subject')");
            $stmt->execute();
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                if ($row['key_name'] === 'vapid_public_key' && $public === '') $public = (string)($row['value'] ?? '');
                if ($row['key_name'] === 'vapid_private_key' && $private === '') $private = (string)($row['value'] ?? '');
                if ($row['key_name'] === 'vapid_subject' && ($subject === '' || $subject === 'mailto:contato@autolimpezapro.com.br')) {
                    $subject = (string)($row['value'] ?? $subject);
                }
            }
        } catch (Throwable $e) {
            // site_config pode não existir ainda
        }
    }

    return [
        'public'  => trim($public),
        'private' => trim($private),
        'subject' => trim($subject) ?: 'mailto:contato@autolimpezapro.com.br',
        'configured' => trim($public) !== '' && trim($private) !== '',
    ];
}

function webPushPublicKey(PDO $pdo): ?string {
    $cfg = webPushConfig($pdo);
    return $cfg['configured'] ? $cfg['public'] : null;
}

function webPushIsConfigured(PDO $pdo): bool {
    return webPushConfig($pdo)['configured'];
}

function webPushSaveSubscription(PDO $pdo, array $sub, string $ownerType, string $ownerId, array $meta = []): bool {
    ensurePushSubscriptionsTable($pdo);
    $endpoint = trim((string)($sub['endpoint'] ?? ''));
    $keys     = is_array($sub['keys'] ?? null) ? $sub['keys'] : [];
    $p256dh   = trim((string)($keys['p256dh'] ?? ''));
    $auth     = trim((string)($keys['auth'] ?? ''));
    if ($endpoint === '' || $p256dh === '' || $auth === '') return false;

    $hash = hash('sha256', $endpoint);
    $now  = dbNow();
    $ua   = isset($_SERVER['HTTP_USER_AGENT']) ? mb_substr((string)$_SERVER['HTTP_USER_AGENT'], 0, 500) : null;
    $browser  = san($meta['browser'] ?? null, 40);
    $platform = san($meta['platform'] ?? null, 40);
    $device   = san($meta['device'] ?? null, 40);
    $language = san($meta['language'] ?? null, 20);
    $timezone = san($meta['timezone'] ?? null, 60);
    $clientId = isset($meta['client_id']) ? (int)$meta['client_id'] : null;
    if ($clientId !== null && $clientId <= 0) $clientId = null;

    $pdo->prepare("
        INSERT INTO push_subscriptions (
            endpoint, endpoint_hash, p256dh, auth, owner_type, owner_id, client_id,
            user_agent, browser, platform, device, language, timezone, last_seen,
            enabled, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
        ON DUPLICATE KEY UPDATE
            p256dh = VALUES(p256dh),
            auth = VALUES(auth),
            owner_type = VALUES(owner_type),
            owner_id = VALUES(owner_id),
            client_id = COALESCE(VALUES(client_id), client_id),
            user_agent = VALUES(user_agent),
            browser = COALESCE(VALUES(browser), browser),
            platform = COALESCE(VALUES(platform), platform),
            device = COALESCE(VALUES(device), device),
            language = COALESCE(VALUES(language), language),
            timezone = COALESCE(VALUES(timezone), timezone),
            last_seen = VALUES(last_seen),
            enabled = 1,
            last_error = NULL,
            updated_at = VALUES(updated_at)
    ")->execute([
        $endpoint, $hash, $p256dh, $auth, $ownerType, $ownerId, $clientId,
        $ua, $browser, $platform, $device, $language, $timezone, $now, $now, $now,
    ]);

    if (function_exists('registerPushDevice')) {
        registerPushDevice($pdo, $ownerType, $ownerId, 'webpush', $ua, mb_substr($hash, 0, 64));
    }
    return true;
}

function webPushRemoveSubscription(PDO $pdo, string $endpoint): void {
    ensurePushSubscriptionsTable($pdo);
    $hash = hash('sha256', trim($endpoint));
    $pdo->prepare("UPDATE push_subscriptions SET enabled = 0, updated_at = ? WHERE endpoint_hash = ?")
        ->execute([dbNow(), $hash]);
}

function webPushBase64UrlDecode(string $data): string {
    $data = strtr($data, '-_', '+/');
    $pad  = strlen($data) % 4;
    if ($pad) $data .= str_repeat('=', 4 - $pad);
    $decoded = base64_decode($data, true);
    return $decoded === false ? '' : $decoded;
}

function webPushBase64UrlEncode(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function webPushCreateJwt(string $audience, string $subject, string $privateKeyB64): ?string {
    $header  = webPushBase64UrlEncode(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
    $payload = webPushBase64UrlEncode(json_encode([
        'aud' => $audience,
        'exp' => time() + 43200,
        'sub' => $subject,
    ]));
    $data = $header . '.' . $payload;

    $der = webPushBase64UrlDecode($privateKeyB64);
    if ($der === '') return null;

    // gen-vapid-keys.cjs exporta PKCS8; builds antigos podem usar SEC1 EC PRIVATE KEY
    $pemPkcs8 = "-----BEGIN PRIVATE KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PRIVATE KEY-----\n";
    $key = openssl_pkey_get_private($pemPkcs8);
    if ($key === false) {
        $pemEc = "-----BEGIN EC PRIVATE KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END EC PRIVATE KEY-----\n";
        $key = openssl_pkey_get_private($pemEc);
    }
    if ($key === false) return null;

    $signature = '';
    if (!openssl_sign($data, $signature, $key, OPENSSL_ALGO_SHA256)) return null;

    $sig = webPushDerSignatureToRaw($signature);
    if ($sig === null) return null;

    return $data . '.' . webPushBase64UrlEncode($sig);
}

function webPushDerSignatureToRaw(string $der): ?string {
    $pos = 0;
    if (ord($der[$pos++]) !== 0x30) return null;
    $len = ord($der[$pos++]);
    if ($len & 0x80) {
        $n = $len & 0x7f;
        $len = 0;
        for ($i = 0; $i < $n; $i++) $len = ($len << 8) | ord($der[$pos++]);
    }
    if (ord($der[$pos++]) !== 0x02) return null;
    $rLen = ord($der[$pos++]);
    $r = substr($der, $pos, $rLen);
    $pos += $rLen;
    if (ord($der[$pos++]) !== 0x02) return null;
    $sLen = ord($der[$pos++]);
    $s = substr($der, $pos, $sLen);
    $r = ltrim($r, "\x00");
    $s = ltrim($s, "\x00");
    return str_pad($r, 32, "\x00", STR_PAD_LEFT) . str_pad($s, 32, "\x00", STR_PAD_LEFT);
}

function webPushEncryptPayload(string $payload, string $p256dh, string $authSecret): ?string {
    $userPublic = webPushBase64UrlDecode($p256dh);
    $auth       = webPushBase64UrlDecode($authSecret);
    if ($userPublic === '' || $auth === '') return null;

    $localKey = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
    if ($localKey === false) return null;
    $localDetails = openssl_pkey_get_details($localKey);
    $x = str_pad((string)($localDetails['ec']['x'] ?? ''), 32, "\x00", STR_PAD_LEFT);
    $y = str_pad((string)($localDetails['ec']['y'] ?? ''), 32, "\x00", STR_PAD_LEFT);
    $localPublic  = "\x04" . $x . $y;

    $userPem = webPushPublicKeyToPem($userPublic);
    if ($userPem === null) return null;
    $userKey = openssl_pkey_get_public($userPem);
    if ($userKey === false) return null;

    $shared = openssl_pkey_derive($userKey, $localKey, 256);
    if ($shared === false) return null;

    $salt = random_bytes(16);
    $info = "WebPush: info\x00" . $userPublic . $localPublic;
    $ikm  = webPushHkdf($auth, $shared, $info, 32);
    $cekInfo  = "Content-Encoding: aes128gcm\x00";
    $nonceInfo = "Content-Encoding: nonce\x00";
    $cek   = webPushHkdf($salt, $ikm, $cekInfo, 16);
    $nonce = webPushHkdf($salt, $ikm, $nonceInfo, 12);

    $padLen = 0;
    $plaintext = $payload . chr(2) . str_repeat("\x00", $padLen);
    $tag = '';
    $ciphertext = openssl_encrypt($plaintext, 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);
    if ($ciphertext === false) return null;

    $record = $salt
        . pack('N', 4096)
        . chr(strlen($localPublic))
        . $localPublic
        . $ciphertext
        . $tag;

    return $record;
}

function webPushPublicKeyToPem(string $raw): ?string {
    if ($raw === '' || ord($raw[0]) !== 0x04) return null;
    $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $raw;
    return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
}

function webPushHkdf(string $salt, string $ikm, string $info, int $length): string {
    $prk = hash_hmac('sha256', $ikm, $salt, true);
    $t = '';
    $last = '';
    for ($i = 1; strlen($t) < $length; $i++) {
        $last = hash_hmac('sha256', $last . $info . chr($i), $prk, true);
        $t .= $last;
    }
    return substr($t, 0, $length);
}

function webPushSendToSubscription(PDO $pdo, array $row, string $title, string $body, ?string $url = null, array $extra = []): array {
    $cfg = webPushConfig($pdo);
    if (!$cfg['configured']) {
        return ['ok' => false, 'http_code' => 0, 'error' => 'vapid_not_configured'];
    }

    $ttl = (int)($extra['ttl'] ?? 86400);
    if ($ttl < 0) $ttl = 86400;
    $urgency = ($extra['severity'] ?? '') === 'error' || ($extra['priority'] ?? '') === 'high'
        ? 'high' : 'normal';

    $payloadArr = [
        'title' => $title,
        'body'  => $body,
        'url'   => $url,
        'icon'  => $extra['icon'] ?? '/icon-192.png',
        'badge' => $extra['badge'] ?? '/icon-192.png',
        'tag'   => $extra['tag'] ?? 'cleanpro-push',
        'severity' => $extra['severity'] ?? 'info',
        'vibrate' => ($extra['severity'] ?? '') === 'error' ? [200, 100, 200, 100, 200] : [100, 50, 100],
        'notification_id' => $extra['notification_id'] ?? null,
        'log_id' => $extra['log_id'] ?? null,
    ];
    if (!empty($extra['image'])) $payloadArr['image'] = $extra['image'];
    if (!empty($extra['actions']) && is_array($extra['actions'])) $payloadArr['actions'] = $extra['actions'];

    $payload = json_encode($payloadArr, JSON_UNESCAPED_UNICODE);

    $encrypted = webPushEncryptPayload($payload, $row['p256dh'], $row['auth']);
    if ($encrypted === null) {
        return ['ok' => false, 'http_code' => 0, 'error' => 'encrypt_failed'];
    }

    $endpoint = $row['endpoint'];
    $audience = parse_url($endpoint, PHP_URL_SCHEME) . '://' . parse_url($endpoint, PHP_URL_HOST);
    $jwt = webPushCreateJwt($audience, $cfg['subject'], $cfg['private']);
    if ($jwt === null) {
        return ['ok' => false, 'http_code' => 0, 'error' => 'jwt_failed'];
    }

    $headers = [
        'Content-Type: application/octet-stream',
        'Content-Encoding: aes128gcm',
        'Content-Length: ' . strlen($encrypted),
        'TTL: ' . $ttl,
        'Authorization: vapid t=' . $jwt . ', k=' . $cfg['public'],
        'Urgency: ' . $urgency,
    ];
    if (!empty($extra['topic'])) {
        $headers[] = 'Topic: ' . preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$extra['topic']);
    }

    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $encrypted,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $response = curl_exec($ch);
    $code     = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($code >= 200 && $code < 300) {
        return ['ok' => true, 'http_code' => $code, 'error' => null];
    }

    $err = $curlErr !== '' ? $curlErr : "HTTP {$code}";
    if ($code === 404 || $code === 410) {
        $pdo->prepare("UPDATE push_subscriptions SET enabled = 0, last_error = ?, updated_at = ? WHERE id = ?")
            ->execute([$err, dbNow(), $row['id']]);
    } else {
        $pdo->prepare("UPDATE push_subscriptions SET last_error = ?, updated_at = ? WHERE id = ?")
            ->execute([mb_substr($err, 0, 500), dbNow(), $row['id']]);
    }
    return ['ok' => false, 'http_code' => $code, 'error' => $err, 'response' => is_string($response) ? mb_substr($response, 0, 500) : null];
}

/**
 * @return array{sent:int,failed:int,total:int}
 */
function sendWebPushIfConfigured(PDO $pdo, string $title, string $body, ?string $url = null, array $opts = []): array {
    ensurePushSubscriptionsTable($pdo);
    if (!webPushIsConfigured($pdo)) {
        return ['sent' => 0, 'failed' => 0, 'total' => 0];
    }

    $sql = "SELECT id, endpoint, p256dh, auth, owner_type, owner_id, browser, platform, device FROM push_subscriptions WHERE enabled = 1";
    $params = [];
    if (!empty($opts['owner_type']) && !empty($opts['owner_id'])) {
        $sql .= " AND owner_type = ? AND owner_id = ?";
        $params = [$opts['owner_type'], $opts['owner_id']];
    } elseif (!empty($opts['owner_type'])) {
        $sql .= " AND owner_type = ?";
        $params[] = $opts['owner_type'];
    }
    if (!empty($opts['segment']) && $opts['segment'] !== 'all') {
        $seg = (string)$opts['segment'];
        if ($seg === 'admins') {
            $sql .= " AND owner_type = 'admin'";
        } elseif ($seg === 'clients' || $seg === 'clientes') {
            $sql .= " AND owner_type IN ('client','visitor')";
        } elseif ($seg === 'leads') {
            $sql .= " AND owner_type IN ('visitor','client')";
        }
    }
    if (!empty($opts['subscription_ids']) && is_array($opts['subscription_ids'])) {
        $ids = array_values(array_filter(array_map('intval', $opts['subscription_ids'])));
        if ($ids) {
            $in = implode(',', $ids);
            $sql .= " AND id IN ({$in})";
        }
    }
    $limit = min(2000, max(1, (int)($opts['limit'] ?? 500)));
    $sql .= " ORDER BY updated_at DESC LIMIT {$limit}";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $sent = 0;
    $failed = 0;
    $extra = [
        'severity' => $opts['severity'] ?? 'info',
        'priority' => $opts['priority'] ?? 'normal',
        'ttl' => $opts['ttl'] ?? 86400,
        'icon' => $opts['icon'] ?? null,
        'badge' => $opts['badge'] ?? null,
        'image' => $opts['image'] ?? null,
        'tag' => $opts['tag'] ?? null,
        'topic' => $opts['topic'] ?? null,
        'actions' => $opts['actions'] ?? null,
        'notification_id' => $opts['notification_id'] ?? null,
        'log_id' => $opts['log_id'] ?? null,
    ];

    $maxRetry = (int)($opts['retry'] ?? 1);
    $sendId = (int)($opts['notification_id'] ?? 0);
    $now = dbNow();
    foreach ($rows as $row) {
        $logId = 0;
        if ($sendId > 0) {
            try {
                ensureNotificationEngineTables($pdo);
                $pdo->prepare('INSERT INTO notification_delivery_logs (send_id, subscription_id, status, http_code, clicked, opened, delivered, created_at, updated_at) VALUES (?,?,?,?,0,0,0,?,?)')
                    ->execute([$sendId, (int)$row['id'], 'pending', null, $now, $now]);
                $logId = (int)$pdo->lastInsertId();
            } catch (Throwable $e) {
                $logId = 0;
            }
        }
        $extra['log_id'] = $logId > 0 ? $logId : null;

        $ok = false;
        $lastCode = 0;
        $lastErr = null;
        for ($attempt = 0; $attempt <= $maxRetry; $attempt++) {
            $result = webPushSendToSubscription($pdo, $row, $title, $body, $url, $extra);
            $lastCode = (int)($result['http_code'] ?? 0);
            $lastErr = $result['error'] ?? null;
            if (!empty($result['ok'])) {
                $ok = true;
                break;
            }
            if (in_array($lastCode, [404, 410, 401, 403], true)) break;
            if (in_array($lastCode, [429, 500, 502, 503, 504], true) && $attempt < $maxRetry) {
                usleep(300000 * ($attempt + 1));
                continue;
            }
            break;
        }
        if ($logId > 0) {
            try {
                $pdo->prepare('UPDATE notification_delivery_logs SET status = ?, http_code = ?, browser_response = ?, updated_at = ? WHERE id = ?')
                    ->execute([
                        $ok ? 'sent' : 'failed',
                        $lastCode ?: null,
                        $lastErr ? mb_substr((string)$lastErr, 0, 500) : null,
                        dbNow(),
                        $logId,
                    ]);
            } catch (Throwable $e) { /* */ }
        }
        if ($ok) $sent++;
        else $failed++;
    }

    if ($sent > 0 && function_exists('mailConfigSet')) {
        mailConfigSet($pdo, 'webpush_last_success_at', dbNow());
    }
    if ($failed > 0 && $sent === 0 && function_exists('mailConfigSet')) {
        mailConfigSet($pdo, 'webpush_last_error', "{$failed} falha(s) em " . count($rows) . " assinatura(s)");
        mailConfigSet($pdo, 'webpush_last_error_at', dbNow());
    }

    return ['sent' => $sent, 'failed' => $failed, 'total' => count($rows)];
}

function testWebPushConnection(PDO $pdo): array {
    if (!webPushIsConfigured($pdo)) {
        return ['ok' => false, 'error' => 'Chaves VAPID não configuradas — defina em config.php ou Comunicação'];
    }
    $count = (int)$pdo->query("SELECT COUNT(*) FROM push_subscriptions WHERE enabled = 1")->fetchColumn();
    return [
        'ok' => true,
        'message' => "VAPID OK — {$count} assinatura(s) ativa(s)",
        'subscriptions' => $count,
    ];
}

/**
 * Processa campanhas agendadas (status=scheduled, scheduled_at <= now).
 * @return array{processed:int,sent:int,failed:int}
 */
function processScheduledNotificationCampaigns(PDO $pdo, int $limit = 5): array {
    if (!function_exists('ensureNotificationEngineTables')) {
        return ['processed' => 0, 'sent' => 0, 'failed' => 0];
    }
    ensureNotificationEngineTables($pdo);
    $now = dbNow();
    $limit = max(1, min(20, $limit));
    $stmt = $pdo->prepare("SELECT * FROM notification_campaigns WHERE status = 'scheduled' AND scheduled_at IS NOT NULL AND scheduled_at <= ? ORDER BY scheduled_at ASC LIMIT {$limit}");
    $stmt->execute([$now]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $processed = 0;
    $sentTotal = 0;
    $failTotal = 0;
    foreach ($rows as $camp) {
        $processed++;
        $title = (string)($camp['title'] ?? $camp['name'] ?? 'Campanha');
        $body = (string)($camp['body'] ?? '');
        $url = $camp['url'] ?? '/';
        $segment = $camp['segment'] ?? 'all';
        $pdo->prepare("UPDATE notification_campaigns SET status = 'sending', updated_at = ? WHERE id = ?")->execute([$now, $camp['id']]);
        $pdo->prepare('INSERT INTO notification_engine_sends (campaign_id, title, body, image, icon, url, tag, priority, ttl, segment, status, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([
                (int)$camp['id'], $title, $body, $camp['image'] ?? null, $camp['icon'] ?? null, $url,
                $camp['tag'] ?? ('camp-' . $camp['id']), $camp['priority'] ?? 'normal', (int)($camp['ttl'] ?? 86400),
                $segment, 'sending', 'cron', $now, $now,
            ]);
        $sendId = (int)$pdo->lastInsertId();
        $result = sendWebPushIfConfigured($pdo, $title, $body, $url, [
            'segment' => $segment,
            'notification_id' => $sendId,
            'tag' => $camp['tag'] ?? ('camp-' . $camp['id']),
            'ttl' => (int)($camp['ttl'] ?? 86400),
            'icon' => $camp['icon'] ?? null,
            'image' => $camp['image'] ?? null,
            'retry' => 1,
        ]);
        $sentTotal += (int)($result['sent'] ?? 0);
        $failTotal += (int)($result['failed'] ?? 0);
        $status = ($result['sent'] ?? 0) > 0 ? 'sent' : 'failed';
        $pdo->prepare('UPDATE notification_engine_sends SET status = ?, sent_count = ?, fail_count = ?, updated_at = ? WHERE id = ?')
            ->execute([$status, (int)$result['sent'], (int)$result['failed'], $now, $sendId]);
        $pdo->prepare("UPDATE notification_campaigns SET status = ?, sent_at = ?, stats_json = ?, updated_at = ? WHERE id = ?")
            ->execute([
                $status === 'sent' ? 'sent' : 'failed',
                $now,
                json_encode($result, JSON_UNESCAPED_UNICODE),
                $now,
                $camp['id'],
            ]);
    }
    return ['processed' => $processed, 'sent' => $sentTotal, 'failed' => $failTotal];
}
