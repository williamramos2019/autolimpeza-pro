/* drilling-pwa-v2
 * Cache apenas de assets estáticos e da página pública offline.
 * Estrategia: cache-first para CSS/JS/ícones/manifest; network-only para o resto.
 * nao cachear HTML autenticado — dashboard, movimentações e pendências ficam fora.
 */
var CACHE_NAME = 'drilling-pwa-v2';
var PRECACHE = [
    '/css/app.css',
    '/css/pwa.css',
    '/js/app.js',
    '/js/pwa.js',
    '/js/offline-store.js',
    '/js/movimentacoes.js',
    '/js/conferencia.js',
    '/js/qr-scan.js',
    '/offline.html',
    '/manifest.webmanifest',
    '/manifest.json',
    '/icons/icon-192.png',
    '/icons/icon-512.png',
    '/icons/icon.svg'
];

self.addEventListener('install', function (event) {
    event.waitUntil(
        caches.open(CACHE_NAME).then(function (cache) {
            return cache.addAll(PRECACHE);
        })
    );
});

self.addEventListener('activate', function (event) {
    event.waitUntil(
        caches.keys().then(function (keys) {
            return Promise.all(keys.map(function (key) {
                if (key !== CACHE_NAME && key.indexOf('drilling-pwa-') === 0) {
                    return caches.delete(key);
                }
                return null;
            }));
        }).then(function () {
            return self.clients.claim();
        })
    );
});

self.addEventListener('message', function (event) {
    if (!event.data) {
        return;
    }
    if (event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
    if (event.data.type === 'SYNC' && self.clients && self.clients.matchAll) {
        event.waitUntil(
            self.clients.matchAll({ includeUncontrolled: true, type: 'window' }).then(function (clients) {
                clients.forEach(function (client) {
                    client.postMessage({ type: 'SYNC' });
                });
            })
        );
    }
});

self.addEventListener('sync', function (event) {
    if (event.tag === 'drilling-sync') {
        event.waitUntil(avisarClientes());
    }
});

function avisarClientes() {
    return self.clients.matchAll({ includeUncontrolled: true, type: 'window' }).then(function (clients) {
        clients.forEach(function (client) {
            client.postMessage({ type: 'SYNC' });
        });
    });
}

self.addEventListener('fetch', function (event) {
    var request = event.request;
    var url;

    try {
        url = new URL(request.url);
    } catch (e) {
        return;
    }

    if (request.method !== 'GET' || url.origin !== self.location.origin) {
        return;
    }

    if (url.pathname === '/pwa-ping.txt') {
        event.respondWith(fetch(request));
        return;
    }

    if (eAssetEstatico(url.pathname)) {
        event.respondWith(cacheFirst(request));
        return;
    }

    if (request.mode === 'navigate') {
        event.respondWith(
            fetch(request).catch(function () {
                return caches.match('/offline.html');
            })
        );
    }
});

function eAssetEstatico(pathname) {
    return PRECACHE.indexOf(pathname) !== -1
        || /\.(css|js|png|svg|webmanifest|json|woff2?)$/.test(pathname);
}

function cacheFirst(request) {
    return caches.match(request).then(function (cached) {
        if (cached) {
            return cached;
        }
        return fetch(request).then(function (response) {
            if (response && response.ok) {
                var copia = response.clone();
                caches.open(CACHE_NAME).then(function (cache) {
                    cache.put(request, copia);
                });
            }
            return response;
        });
    });
}
