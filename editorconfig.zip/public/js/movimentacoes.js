/**
 * Movimentação — melhorias de formulário sem framework e sem build.
 *
 * Nada aqui é obrigatório para o formulário funcionar: o servidor renderiza todas
 * as opções de local e pelo menos uma linha de item. O JS só melhora a experiência
 * no celular (filtrar locais pela obra, adicionar/remover itens, aceitar vírgula
 * como separador decimal, confirmar o envio).
 *
 * Sem Node, sem npm, sem Vite — arquivo estático servido pelo Apache.
 */
(function () {
    'use strict';

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        ligarFiltroDeLocais();
        ligarItens();
        ligarQuantidades();
        ligarConfirmacaoDeEnvio();
    }

    /**
     * Cada select de obra aponta, por data-locais-de, o select de local que ele
     * comanda. O conjunto completo de opções é guardado na memória e o select é
     * reconstruído a cada troca de obra.
     */
    function ligarFiltroDeLocais() {
        var selectsDeObra = document.querySelectorAll('select[data-locais-de]');

        Array.prototype.forEach.call(selectsDeObra, function (selectObra) {
            var selectLocal = document.getElementById(selectObra.getAttribute('data-locais-de'));

            if (!selectLocal) {
                return;
            }

            var todasAsOpcoes = Array.prototype.slice.call(selectLocal.options);

            function filtrar() {
                var obraId = selectObra.value;
                var selecionado = selectLocal.value;

                selectLocal.innerHTML = '';

                todasAsOpcoes.forEach(function (opcao) {
                    var obraDaOpcao = opcao.getAttribute('data-obra-id');

                    if (obraDaOpcao === null || obraDaOpcao === obraId) {
                        selectLocal.appendChild(opcao.cloneNode(true));
                    }
                });

                selectLocal.value = selecionado;

                // Local que não pertence mais à obra escolhida: limpa em vez de
                // mandar par obra/local inconsistente para o servidor.
                if (selectLocal.value !== selecionado) {
                    selectLocal.value = '';
                }
            }

            selectObra.addEventListener('change', filtrar);
            filtrar();
        });
    }

    /**
     * Adicionar/remover linhas de item clonando o <template> do formulário.
     *
     * Os índices removidos não são reaproveitados: `items[0]`, `items[2]` chega ao
     * PHP como lista válida, e renumerar arriscaria embaralhar o que o operador
     * digitou.
     */
    function ligarItens() {
        var lista = document.getElementById('itens-da-movimentacao');
        var molde = document.getElementById('molde-item-movimentacao');
        var botao = document.getElementById('adicionar-item');

        if (!lista || !molde || !botao) {
            return;
        }

        var proximoIndice = parseInt(lista.getAttribute('data-proximo-indice'), 10) || 0;

        botao.addEventListener('click', function () {
            var html = molde.innerHTML.split('__INDEX__').join(String(proximoIndice));
            var container = document.createElement('div');
            container.innerHTML = html;

            var linha = container.querySelector('[data-item-row]');

            if (linha) {
                lista.appendChild(linha);
                proximoIndice++;

                var primeiroCampo = linha.querySelector('select, input');
                if (primeiroCampo) {
                    primeiroCampo.focus();
                }
            }
        });

        lista.addEventListener('click', function (evento) {
            var alvo = evento.target;

            if (!alvo || !alvo.hasAttribute('data-remover-item')) {
                return;
            }

            var linhas = lista.querySelectorAll('[data-item-row]');

            // Sempre sobra uma linha: movimentação sem item nenhum é recusada no
            // servidor, e uma lista vazia deixaria a tela sem saída.
            if (linhas.length <= 1) {
                limparLinha(linhas[0]);
                return;
            }

            var linha = alvo.closest('[data-item-row]');
            if (linha) {
                linha.parentNode.removeChild(linha);
            }
        });
    }

    function limparLinha(linha) {
        if (!linha) {
            return;
        }

        Array.prototype.forEach.call(linha.querySelectorAll('input, select'), function (campo) {
            if (campo.type !== 'hidden') {
                campo.value = '';
            }
        });
    }

    /**
     * O teclado numérico do celular em pt-BR entrega vírgula. O banco é
     * decimal(12,3) e a validação exige ponto, então a conversão acontece aqui.
     */
    function ligarQuantidades() {
        document.addEventListener('change', function (evento) {
            var campo = evento.target;

            if (!campo || campo.getAttribute('inputmode') !== 'decimal') {
                return;
            }

            campo.value = String(campo.value).trim().replace(',', '.');
        });
    }

    /**
     * Envio é irreversível para a quantidade enviada: pede confirmação explícita.
     */
    function ligarConfirmacaoDeEnvio() {
        var formularios = document.querySelectorAll('form[data-confirmacao]');

        Array.prototype.forEach.call(formularios, function (formulario) {
            formulario.addEventListener('submit', function (evento) {
                if (!window.confirm(formulario.getAttribute('data-confirmacao'))) {
                    evento.preventDefault();
                    evento.stopImmediatePropagation();
                }
            });
        });
    }
})();
