/**
 * Materiais em Obras - Main JavaScript
 * No build tools required - vanilla JS for HostGator compatibility
 */

(function() {
    'use strict';

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        // Set up CSRF token for all AJAX requests
        setupCsrfToken();
        
        // Initialize active nav highlighting
        highlightActiveNav();
        
        // Set up form enhancements
        enhanceForms();
    }

    /**
     * Set up CSRF token for fetch/XMLHttpRequest
     */
    function setupCsrfToken() {
        const token = document.querySelector('meta[name="csrf-token"]');
        if (token) {
            window.csrfToken = token.getAttribute('content');
            
            // Add CSRF to all fetch requests
            const originalFetch = window.fetch;
            window.fetch = function(url, options = {}) {
                options.headers = options.headers || {};
                if (typeof options.headers.append === 'function') {
                    options.headers.append('X-CSRF-TOKEN', window.csrfToken);
                } else {
                    options.headers['X-CSRF-TOKEN'] = window.csrfToken;
                }
                return originalFetch(url, options);
            };
        }
    }

    /**
     * Highlight active navigation item based on current URL
     */
    function highlightActiveNav() {
        const currentPath = window.location.pathname;
        const navItems = document.querySelectorAll('.bottom-nav-item');
        
        navItems.forEach(function(item) {
            const href = item.getAttribute('href');
            if (href === currentPath) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
    }

    /**
     * Enhance forms with loading states and validation
     */
    function enhanceForms() {
        const forms = document.querySelectorAll('form[data-enhance]');
        
        forms.forEach(function(form) {
            form.addEventListener('submit', function(e) {
                const submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn && !submitBtn.disabled) {
                    submitBtn.disabled = true;
                    submitBtn.dataset.originalText = submitBtn.textContent;
                    submitBtn.textContent = 'Processando...';
                    
                    // Re-enable after 5 seconds as fallback
                    setTimeout(function() {
                        if (submitBtn.disabled) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = submitBtn.dataset.originalText;
                        }
                    }, 5000);
                }
            });
        });
    }

    // Utility function for showing notifications
    window.showNotification = function(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = 'notification notification-' + type;
        notification.textContent = message;
        notification.style.cssText = 'position:fixed;top:20px;right:20px;padding:16px 24px;background:#0f3d2e;color:white;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.2);z-index:9999;animation:slideIn 0.3s ease;';
        
        if (type === 'error') {
            notification.style.background = '#d32f2f';
        } else if (type === 'success') {
            notification.style.background = '#388e3c';
        }
        
        document.body.appendChild(notification);
        
        setTimeout(function() {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(function() {
                notification.remove();
            }, 300);
        }, 3000);
    };

    // Add slide animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);

})();
