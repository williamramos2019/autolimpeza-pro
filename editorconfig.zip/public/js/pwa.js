/**
 * Camada PWA: conectividade, fila, sync e instalação.
 * O servidor continua sendo a autoridade. Este arquivo só organiza o envio.
 */
(function () {
    'use strict';

    var store = null;
    var syncing = false;
    var installEvent = null;
    var waitingWorker = null;

    function $(id) {
        return document.getElementById(id);
    }

    function userId() {
        var meta = document.querySelector('meta[name="user-id"]');
        return meta ? meta.getAttribute('content') : '';
    }

    function csrf() {
        return window.csrfToken || (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
    }

    function setText(el, text) {
        if (el) {
            el.textContent = text;
        }
    }

    function confirmOnline() {
        if (typeof navigator !== 'undefined' && navigator.onLine === false) {
            return Promise.resolve(false);
        }
        var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        var timer = setTimeout(function () {
            if (ctrl) {
                ctrl.abort();
            }
        }, 3000);
        return fetch('/pwa-ping.txt?t=' + Date.now(), {
            cache: 'no-store',
            credentials: 'same-origin',
            signal: ctrl ? ctrl.signal : undefined
        }).then(function (res) {
            clearTimeout(timer);
            return res.ok;
        }).catch(function () {
            clearTimeout(timer);
            return false;
        });
    }

    function renderStatus(estado, extra) {
        var root = $('pwa-status');
        var label = $('pwa-status-label');
        var count = $('pwa-pending-count');
        if (root) {
            root.setAttribute('data-state', estado);
        }
        var textos = {
            online: 'ONLINE',
            offline: 'OFFLINE',
            syncing: 'Sincronizando...',
            waiting: 'Aguardando conexão',
            synced: 'Sincronizado',
            error: 'Falha na sincronização'
        };
        setText(label, extra || textos[estado] || estado);
        if (!store || !userId()) {
            setText(count, '0 operações pendentes');
            return;
        }
        store.listPendingForUser(userId()).then(function (ops) {
            setText(count, ops.length + ' operações pendentes');
        });
    }

    function backoffMs(attempts) {
        return Math.min(16000, 1000 * Math.pow(2, Math.max(0, attempts - 1)));
    }

    function compressImage(file) {
        return new Promise(function (resolve) {
            if (!file || !file.type || file.type.indexOf('image/') !== 0) {
                resolve(file);
                return;
            }
            var img = new Image();
            var url = URL.createObjectURL(file);
            img.onload = function () {
                var max = 1600;
                var w = img.width;
                var h = img.height;
                if (w > max || h > max) {
                    var ratio = Math.min(max / w, max / h);
                    w = Math.round(w * ratio);
                    h = Math.round(h * ratio);
                }
                var canvas = document.createElement('canvas');
                canvas.width = w;
                canvas.height = h;
                canvas.getContext('2d').drawImage(img, 0, 0, w, h);
                URL.revokeObjectURL(url);
                canvas.toBlob(function (blob) {
                    if (!blob || blob.size > 4 * 1024 * 1024) {
                        resolve(file.size <= 4 * 1024 * 1024 ? file : blob);
                        return;
                    }
                    resolve(blob);
                }, 'image/jpeg', 0.72);
            };
            img.onerror = function () {
                URL.revokeObjectURL(url);
                resolve(file);
            };
            img.src = url;
        });
    }

    function camposDoFormulario(form) {
        var dados = {};
        var fields = form.querySelectorAll('input, select, textarea');
        Array.prototype.forEach.call(fields, function (campo) {
            if (!campo.name || campo.type === 'file' || campo.type === 'password') {
                return;
            }
            if (campo.type === 'checkbox' || campo.type === 'radio') {
                if (campo.checked) {
                    dados[campo.name] = campo.value || '1';
                }
                return;
            }
            dados[campo.name] = campo.value;
        });
        delete dados._token;
        delete dados.password;
        return dados;
    }

    function geoDoFormulario(form) {
        var lat = form.querySelector('[name="latitude"]');
        var lng = form.querySelector('[name="longitude"]');
        if (!lat || !lat.value) {
            return null;
        }
        return {
            latitude: lat.value,
            longitude: lng ? lng.value : '',
            accuracy: (form.querySelector('#geo-accuracy') || {}).value || null,
            timestamp: (form.querySelector('#geo-timestamp') || {}).value || Date.now()
        };
    }

    function chaveEstavel(form) {
        var campo = form.querySelector('[name="idempotency_key"]');
        if (campo && campo.value) {
            return campo.value;
        }
        var gerada = (window.crypto && crypto.randomUUID)
            ? crypto.randomUUID()
            : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0;
                var v = c === 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        if (!campo) {
            campo = document.createElement('input');
            campo.type = 'hidden';
            campo.name = 'idempotency_key';
            form.appendChild(campo);
        }
        campo.value = gerada;
        return gerada;
    }

    function enfileirarFormulario(form, tipo) {
        var key = chaveEstavel(form);
        var payload = camposDoFormulario(form);
        payload.idempotency_key = key;
        return store.enqueue({
            type: tipo,
            url: form.getAttribute('action'),
            method: (form.getAttribute('method') || 'POST').toUpperCase(),
            payload: payload,
            userId: userId(),
            idempotencyKey: key,
            geo: geoDoFormulario(form),
            fingerprint: store.fingerprint({
                method: (form.getAttribute('method') || 'POST').toUpperCase(),
                url: form.getAttribute('action'),
                idempotencyKey: key,
                type: tipo
            })
        }).then(function (op) {
            renderStatus('waiting', 'Aguardando conexão');
            if (window.showNotification) {
                window.showNotification('Operação guardada na fila offline.', 'info');
            }
            return op;
        });
    }

    function enviarOperacao(op) {
        if (op.status === store.STATUSES.SYNCED) {
            return Promise.resolve(op);
        }
        return store.markStatus(op.id, 'start', { attempts: op.attempts + 1 }).then(function (atual) {
            var headers = { 'Accept': 'text/html,application/xhtml+xml' };
            if (csrf()) {
                headers['X-CSRF-TOKEN'] = csrf();
                headers['X-Requested-With'] = 'XMLHttpRequest';
            }
            if (atual.idempotencyKey) {
                headers['Idempotency-Key'] = atual.idempotencyKey;
            }

            var body;
            var init = { method: atual.method, headers: headers, credentials: 'same-origin', redirect: 'follow' };

            if (atual.type === 'receipt.photo') {
                return store.getPhoto(atual.photoId).then(function (photo) {
                    if (!photo || photo.uploaded) {
                        return store.markStatus(atual.id, photo && photo.uploaded ? 'success' : 'giveup', {
                            error: photo ? null : 'Foto local ausente'
                        });
                    }
                    var fd = new FormData();
                    fd.append('_token', csrf());
                    fd.append('photo', photo.blob, 'conferencia.jpg');
                    if (atual.idempotencyKey) {
                        fd.append('idempotency_key', atual.idempotencyKey);
                    }
                    if (atual.geo) {
                        if (atual.geo.latitude) fd.append('latitude', atual.geo.latitude);
                        if (atual.geo.longitude) fd.append('longitude', atual.geo.longitude);
                    }
                    var photoHeaders = {
                        'X-CSRF-TOKEN': csrf(),
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'text/html'
                    };
                    if (atual.idempotencyKey) {
                        photoHeaders['Idempotency-Key'] = atual.idempotencyKey;
                    }
                    return fetch(atual.url, { method: 'POST', headers: photoHeaders, body: fd, credentials: 'same-origin' }).then(function (response) {
                        if (!response.ok) {
                            throw { retryable: response.status >= 500, message: 'HTTP ' + response.status };
                        }
                        return store.markPhotoUploaded(photo.id).then(function () {
                            return store.markStatus(atual.id, 'success');
                        });
                    });
                });
            }

            var params = new URLSearchParams();
            params.set('_token', csrf());
            Object.keys(atual.payload || {}).forEach(function (k) {
                if (k !== '_token' && k !== 'password') {
                    params.set(k, atual.payload[k] == null ? '' : String(atual.payload[k]));
                }
            });
            if (atual.method === 'PUT' || atual.method === 'PATCH' || atual.method === 'DELETE') {
                if (!params.has('_method')) {
                    params.set('_method', atual.method);
                }
                init.method = 'POST';
            }
            body = params.toString();
            init.headers['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
            init.body = body;

            return fetch(atual.url, init).then(function (response) {
                if (!response.ok && response.status !== 302) {
                    throw { retryable: response.status >= 500, message: 'HTTP ' + response.status };
                }
                return store.markStatus(atual.id, 'success');
            });
        }).catch(function (err) {
            var retryable = err && err.retryable !== false && (!err.message || err.name === 'TypeError' || err.retryable);
            return store.getOperation(op.id).then(function (atual) {
                if (!atual) {
                    return null;
                }
                if (retryable && atual.attempts < store.MAX_ATTEMPTS) {
                    return store.markStatus(atual.id, 'retryable', { error: (err && err.message) || 'Falha de rede' });
                }
                return store.markStatus(atual.id, 'giveup', { error: (err && err.message) || 'Falha na sincronização' });
            });
        });
    }

    function syncNow() {
        if (syncing) {
            return Promise.resolve();
        }
        if (!store || !userId()) {
            renderStatus('online');
            return Promise.resolve();
        }
        return confirmOnline().then(function (online) {
            if (!online) {
                renderStatus('waiting', 'Aguardando conexão');
                return;
            }
            syncing = true;
            return store.listPendingForUser(userId()).then(function (ops) {
                var pendentes = ops.filter(function (op) {
                    return op.status === store.STATUSES.PENDING || op.status === store.STATUSES.FAILED;
                });
                renderStatus('syncing', 'Sincronizando ' + pendentes.length + ' operações...');
                var cadeia = Promise.resolve();
                var ok = 0;
                pendentes.forEach(function (op) {
                    cadeia = cadeia.then(function () {
                        return enviarOperacao(op).then(function (resultado) {
                            if (resultado && resultado.status === store.STATUSES.SYNCED) {
                                ok += 1;
                                return store.removeSynced(resultado.id);
                            }
                            return resultado;
                        });
                    });
                });
                return cadeia.then(function () {
                    renderStatus(ok === pendentes.length ? 'synced' : 'error', ok + ' operações sincronizadas.');
                });
            }).finally(function () {
                syncing = false;
            });
        });
    }

    function ligarFormularios() {
        document.addEventListener('submit', function (event) {
            var form = event.target;
            if (!form || !form.matches || !form.matches('form[data-offline-form]')) {
                return;
            }
            if (form.getAttribute('data-offline-sending') === '1' || event.defaultPrevented) {
                return;
            }
            event.preventDefault();
            confirmOnline().then(function (online) {
                if (online) {
                    form.setAttribute('data-offline-sending', '1');
                    form.submit();
                    return;
                }
                enfileirarFormulario(form, form.getAttribute('data-offline-form'));
            });
        });

        document.addEventListener('submit', function (event) {
            var form = event.target;
            if (!form || !form.matches || !form.matches('form[data-offline-photo]')) {
                return;
            }
            if (event.defaultPrevented) {
                return;
            }
            event.preventDefault();
            confirmOnline().then(function (online) {
                var input = form.querySelector('input[type="file"]');
                var arquivo = input && input.files && input.files[0];
                if (online) {
                    form.setAttribute('data-offline-sending', '1');
                    form.submit();
                    return;
                }
                if (!arquivo) {
                    return;
                }
                compressImage(arquivo).then(function (blob) {
                    return store.enqueuePhoto(blob, { type: blob.type }).then(function (photo) {
                        var key = chaveEstavel(form);
                        return store.enqueue({
                            type: 'receipt.photo',
                            url: form.getAttribute('action'),
                            method: 'POST',
                            userId: userId(),
                            photoId: photo.id,
                            geo: geoDoFormulario(form),
                            payload: { idempotency_key: key },
                            idempotencyKey: key,
                            fingerprint: 'photo|' + form.getAttribute('action') + '|' + photo.id
                        });
                    });
                }).then(function () {
                    renderStatus('waiting', 'Aguardando conexão');
                    if (window.showNotification) {
                        window.showNotification('Foto guardada na fila. Ainda não foi enviada.', 'info');
                    }
                });
            });
        });

        Array.prototype.forEach.call(document.querySelectorAll('form[data-offline-draft]'), function (form) {
            var chave = form.getAttribute('action') + '|' + userId();
            store.getDraft(chave).then(function (rascunho) {
                if (!rascunho || !rascunho.fields) {
                    return;
                }
                Object.keys(rascunho.fields).forEach(function (nome) {
                    var campo = form.querySelector('[name="' + nome + '"]');
                    if (campo && campo.type !== 'hidden' && !campo.value) {
                        campo.value = rascunho.fields[nome];
                    }
                });
            });
            form.addEventListener('change', function () {
                store.saveDraft(chave, camposDoFormulario(form));
            });
        });
    }

    function ligarFotoOnline() {
        var input = document.querySelector('form[data-offline-photo] input[type="file"]');
        if (!input) {
            return;
        }
        input.addEventListener('change', function () {
            if (!input.files || !input.files[0]) {
                return;
            }
            compressImage(input.files[0]).then(function (blob) {
                if (typeof DataTransfer === 'undefined') {
                    return;
                }
                var dt = new DataTransfer();
                dt.items.add(new File([blob], 'conferencia.jpg', { type: blob.type || 'image/jpeg' }));
                input.files = dt.files;
            });
        });
    }

    function ligarLogout() {
        document.addEventListener('submit', function (event) {
            var form = event.target;
            if (!form || !form.matches || !form.matches('form[data-pwa-logout]')) {
                return;
            }
            if (store) {
                store.lockSession();
            }
        }, true);
    }

    function ligarBarra() {
        var syncBtn = $('pwa-sync');
        if (syncBtn) {
            syncBtn.addEventListener('click', function () {
                syncNow();
            });
        }
        var retryBtn = $('pwa-retry');
        if (retryBtn) {
            retryBtn.addEventListener('click', function () {
                if (!store || !userId()) {
                    return;
                }
                store.listPendingForUser(userId()).then(function (ops) {
                    var cadeia = Promise.resolve();
                    ops.filter(function (op) { return op.status === store.STATUSES.FAILED; }).forEach(function (op) {
                        cadeia = cadeia.then(function () { return store.retryOperation(op.id); });
                    });
                    return cadeia.then(syncNow);
                });
            });
        }
        var installBtn = $('pwa-install');
        if (installBtn) {
            installBtn.addEventListener('click', function () {
                if (installEvent) {
                    installEvent.prompt();
                    return;
                }
                var dica = $('pwa-install-hint');
                if (dica) {
                    dica.hidden = false;
                }
            });
        }
        var updateBtn = $('pwa-update');
        if (updateBtn) {
            updateBtn.addEventListener('click', function () {
                if (waitingWorker) {
                    waitingWorker.postMessage({ type: 'SKIP_WAITING' });
                }
                window.location.reload();
            });
        }
        window.addEventListener('online', function () { syncNow(); });
        window.addEventListener('offline', function () { renderStatus('offline', 'OFFLINE'); });
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) {
                syncNow();
            }
        });
    }

    function registrarWorker() {
        if (!('serviceWorker' in navigator)) {
            return;
        }
        navigator.serviceWorker.register('/service-worker.js', { scope: '/' }).then(function (reg) {
            if (reg.waiting) {
                waitingWorker = reg.waiting;
                var banner = $('pwa-update-banner');
                if (banner) {
                    banner.hidden = false;
                }
            }
            reg.addEventListener('updatefound', function () {
                var novo = reg.installing;
                if (!novo) {
                    return;
                }
                novo.addEventListener('statechange', function () {
                    if (novo.state === 'installed' && navigator.serviceWorker.controller) {
                        waitingWorker = novo;
                        var banner = $('pwa-update-banner');
                        if (banner) {
                            banner.hidden = false;
                        }
                    }
                });
            });
            if (reg.sync && userId()) {
                reg.sync.register('drilling-sync').catch(function () {});
            }
        }).catch(function () {});
        navigator.serviceWorker.addEventListener('message', function (event) {
            if (event.data && event.data.type === 'SYNC') {
                syncNow();
            }
        });
        window.addEventListener('beforeinstallprompt', function (event) {
            event.preventDefault();
            installEvent = event;
            var btn = $('pwa-install');
            if (btn) {
                btn.hidden = false;
            }
        });
    }

    function init() {
        store = window.OfflineStore || null;
        if (store && userId()) {
            store.unlockSession();
        }
        ligarBarra();
        if (store) {
            setTimeout(function () {
                ligarFormularios();
                ligarFotoOnline();
            }, 0);
        }
        ligarLogout();
        registrarWorker();
        confirmOnline().then(function (online) {
            renderStatus(online ? 'online' : 'offline', online ? 'ONLINE' : 'OFFLINE');
            if (online) {
                syncNow();
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
