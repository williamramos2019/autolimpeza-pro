(function () {
    var lat = document.getElementById('latitude');
    var lng = document.getElementById('longitude');
    var acc = document.getElementById('geo-accuracy');
    var when = document.getElementById('geo-timestamp');
    var status = document.getElementById('geo-status');

    if (!lat || !lng || !navigator.geolocation) {
        return;
    }

    navigator.geolocation.getCurrentPosition(
        function (pos) {
            lat.value = pos.coords.latitude.toFixed(7);
            lng.value = pos.coords.longitude.toFixed(7);
            if (acc) {
                acc.value = pos.coords.accuracy != null ? String(pos.coords.accuracy) : '';
            }
            if (when) {
                when.value = String(pos.timestamp || Date.now());
            }
            if (status) {
                status.textContent = 'Localização capturada. Ela acompanha a fotografia.';
            }
        },
        function () {
            if (status) {
                status.textContent = 'Localização não autorizada. A fotografia será salva mesmo assim.';
            }
        },
        { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 }
    );
})();
