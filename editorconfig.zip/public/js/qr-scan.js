(function () {
    var video = document.getElementById('qr-camera');
    var startBtn = document.getElementById('qr-start');
    var cancelBtn = document.getElementById('qr-cancel');
    var feedback = document.getElementById('qr-feedback');
    var stream = null;
    var timer = null;
    var detector = null;

    if (!video || !startBtn) {
        return;
    }

    function dizer(texto, tipo) {
        if (!feedback) {
            return;
        }
        feedback.textContent = texto;
        feedback.className = 'qr-feedback' + (tipo ? ' qr-feedback--' + tipo : '');
    }

    function tokenDaLeitura(texto) {
        if (!texto) {
            return null;
        }
        var match = String(texto).match(/\/qr\/([A-Za-z0-9]{16,64})/);
        if (match) {
            return match[1];
        }
        if (/^[A-Za-z0-9]{16,64}$/.test(texto.trim())) {
            return texto.trim();
        }
        return null;
    }

    function irParaToken(token) {
        parar();
        dizer('QR lido. Abrindo movimentação…', 'ok');
        window.location.assign('/qr/' + encodeURIComponent(token));
    }

    function parar() {
        if (timer) {
            window.clearInterval(timer);
            timer = null;
        }
        if (stream) {
            stream.getTracks().forEach(function (track) {
                track.stop();
            });
            stream = null;
        }
        video.srcObject = null;
        startBtn.hidden = false;
        cancelBtn.hidden = true;
    }

    function varrer() {
        if (!detector || !video.videoWidth) {
            return;
        }
        detector.detect(video).then(function (codigos) {
            if (!codigos || !codigos.length) {
                return;
            }
            var token = tokenDaLeitura(codigos[0].rawValue);
            if (token) {
                irParaToken(token);
                return;
            }
            dizer('QR lido, mas não é uma movimentação. Tente de novo ou digite o código.', 'erro');
        }).catch(function () {
            // quadro ilegível — segue varrendo
        });
    }

    function iniciar() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            dizer('Este aparelho não oferece câmera. Digite o código do QR.', 'erro');
            return;
        }
        if (typeof BarcodeDetector === 'undefined') {
            dizer('A câmera deste navegador não decodifica QR. Use “Digitar código”.', 'erro');
            return;
        }

        detector = new BarcodeDetector({ formats: ['qr_code'] });
        dizer('Aponte a câmera para o QR.', 'info');

        navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: 'environment' } },
            audio: false
        }).then(function (midia) {
            stream = midia;
            video.srcObject = midia;
            startBtn.hidden = true;
            cancelBtn.hidden = false;
            timer = window.setInterval(varrer, 400);
        }).catch(function () {
            dizer('Não foi possível abrir a câmera. Verifique a permissão ou digite o código.', 'erro');
        });
    }

    startBtn.addEventListener('click', iniciar);
    cancelBtn.addEventListener('click', function () {
        parar();
        dizer('Leitura cancelada.', 'info');
    });
})();
