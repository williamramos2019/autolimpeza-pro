/**
 * IndexedDB do PWA. Sem regra de negócio: só fila, rascunho e fotos locais.
 * Funciona na página e no Service Worker (`self`).
 */
(function (global) {
    'use strict';

    var DB_NAME = 'drilling-offline';
    var DB_VERSION = 1;
    var MAX_ATTEMPTS = 5;
    var STATUSES = { PENDING: 'PENDING', SYNCING: 'SYNCING', SYNCED: 'SYNCED', FAILED: 'FAILED' };

    function openDb() {
        return new Promise(function (resolve, reject) {
            var req = indexedDB.open(DB_NAME, DB_VERSION);
            req.onerror = function () { reject(req.error); };
            req.onsuccess = function () { resolve(req.result); };
            req.onupgradeneeded = function (event) {
                var db = event.target.result;
                if (!db.objectStoreNames.contains('operations')) {
                    var ops = db.createObjectStore('operations', { keyPath: 'id' });
                    ops.createIndex('status', 'status', { unique: false });
                    ops.createIndex('userId', 'userId', { unique: false });
                    ops.createIndex('fingerprint', 'fingerprint', { unique: false });
                }
                if (!db.objectStoreNames.contains('drafts')) {
                    db.createObjectStore('drafts', { keyPath: 'key' });
                }
                if (!db.objectStoreNames.contains('photos')) {
                    db.createObjectStore('photos', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('meta')) {
                    db.createObjectStore('meta', { keyPath: 'key' });
                }
            };
        });
    }

    function txStore(store, mode) {
        return openDb().then(function (db) {
            return db.transaction(store, mode).objectStore(store);
        });
    }

    function reqToPromise(request) {
        return new Promise(function (resolve, reject) {
            request.onsuccess = function () { resolve(request.result); };
            request.onerror = function () { reject(request.error); };
        });
    }

    function uuid() {
        if (global.crypto && crypto.randomUUID) {
            return crypto.randomUUID();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0;
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    }

    function nextStatus(current, event) {
        if (current === STATUSES.SYNCED) {
            return STATUSES.SYNCED;
        }
        if (current === STATUSES.PENDING && event === 'start') {
            return STATUSES.SYNCING;
        }
        if (current === STATUSES.SYNCING && event === 'success') {
            return STATUSES.SYNCED;
        }
        if (current === STATUSES.SYNCING && event === 'giveup') {
            return STATUSES.FAILED;
        }
        if (current === STATUSES.SYNCING && event === 'retryable') {
            return STATUSES.PENDING;
        }
        if (current === STATUSES.FAILED && event === 'retry') {
            return STATUSES.PENDING;
        }
        return current;
    }

    function preservarIdempotencyKey(operacao, candidata) {
        if (operacao && operacao.idempotencyKey) {
            return operacao.idempotencyKey;
        }
        return candidata || null;
    }

    function fingerprint(dados) {
        return [dados.method || 'POST', dados.url || '', dados.idempotencyKey || '', dados.type || ''].join('|');
    }

    function alreadyQueued(lista, fp) {
        return lista.some(function (op) {
            return op.fingerprint === fp && (op.status === STATUSES.PENDING || op.status === STATUSES.SYNCING);
        });
    }

    function enqueue(dados) {
        var fp = dados.fingerprint || fingerprint(dados);
        return listByStatus([STATUSES.PENDING, STATUSES.SYNCING]).then(function (abertas) {
            if (alreadyQueued(abertas, fp)) {
                return abertas.filter(function (op) { return op.fingerprint === fp; })[0];
            }
            var op = {
                id: dados.id || uuid(),
                type: dados.type || 'unknown',
                url: dados.url,
                method: dados.method || 'POST',
                payload: dados.payload || {},
                timestamp: dados.timestamp || Date.now(),
                attempts: 0,
                status: STATUSES.PENDING,
                error: null,
                idempotencyKey: dados.idempotencyKey || null,
                userId: dados.userId || null,
                geo: dados.geo || null, // latitude, longitude, accuracy, timestamp
                fingerprint: fp,
                photoId: dados.photoId || null
            };
            return txStore('operations', 'readwrite').then(function (store) {
                return reqToPromise(store.put(op)).then(function () { return op; });
            });
        });
    }

    function getOperation(id) {
        return txStore('operations', 'readonly').then(function (store) {
            return reqToPromise(store.get(id));
        });
    }

    function listByStatus(statuses) {
        var wanted = Array.isArray(statuses) ? statuses : [statuses];
        return txStore('operations', 'readonly').then(function (store) {
            return reqToPromise(store.getAll());
        }).then(function (todas) {
            return (todas || []).filter(function (op) {
                return wanted.indexOf(op.status) !== -1;
            });
        });
    }

    function listPendingForUser(userId) {
        if (!userId) {
            return Promise.resolve([]);
        }
        return listByStatus([STATUSES.PENDING, STATUSES.SYNCING, STATUSES.FAILED]).then(function (ops) {
            return ops.filter(function (op) { return String(op.userId) === String(userId); });
        });
    }

    function updateOperation(id, patch) {
        return getOperation(id).then(function (op) {
            if (!op) {
                return null;
            }
            Object.keys(patch).forEach(function (k) { op[k] = patch[k]; });
            return txStore('operations', 'readwrite').then(function (store) {
                return reqToPromise(store.put(op)).then(function () { return op; });
            });
        });
    }

    function markStatus(id, event, extra) {
        return getOperation(id).then(function (op) {
            if (!op) {
                return null;
            }
            op.status = nextStatus(op.status, event);
            if (extra) {
                Object.keys(extra).forEach(function (k) { op[k] = extra[k]; });
            }
            return txStore('operations', 'readwrite').then(function (store) {
                return reqToPromise(store.put(op)).then(function () { return op; });
            });
        });
    }

    function retryOperation(id) {
        return getOperation(id).then(function (op) {
            if (!op) {
                return null;
            }
            op.status = nextStatus(op.status, 'retry');
            if (op.status === STATUSES.PENDING) {
                op.attempts = 0;
                op.error = null;
            }
            return txStore('operations', 'readwrite').then(function (store) {
                return reqToPromise(store.put(op)).then(function () { return op; });
            });
        });
    }

    function removeSynced(id) {
        return getOperation(id).then(function (op) {
            if (!op || op.status !== STATUSES.SYNCED) {
                return false;
            }
            return txStore('operations', 'readwrite').then(function (store) {
                return reqToPromise(store.delete(id)).then(function () { return true; });
            });
        });
    }

    function saveDraft(key, fields) {
        return txStore('drafts', 'readwrite').then(function (store) {
            return reqToPromise(store.put({ key: key, fields: fields, updatedAt: Date.now() }));
        });
    }

    function getDraft(key) {
        return txStore('drafts', 'readonly').then(function (store) {
            return reqToPromise(store.get(key));
        });
    }

    function clearDraft(key) {
        return txStore('drafts', 'readwrite').then(function (store) {
            return reqToPromise(store.delete(key));
        });
    }

    function enqueuePhoto(blob, meta) {
        var photo = {
            id: (meta && meta.id) || uuid(),
            blob: blob,
            uploaded: false,
            type: (meta && meta.type) || blob.type || 'image/jpeg',
            size: blob.size,
            createdAt: Date.now()
        };
        return txStore('photos', 'readwrite').then(function (store) {
            return reqToPromise(store.put(photo)).then(function () { return photo; });
        });
    }

    function getPhoto(id) {
        return txStore('photos', 'readonly').then(function (store) {
            return reqToPromise(store.get(id));
        });
    }

    function markPhotoUploaded(id) {
        return getPhoto(id).then(function (photo) {
            if (!photo) {
                return null;
            }
            photo.uploaded = true;
            return txStore('photos', 'readwrite').then(function (store) {
                return reqToPromise(store.put(photo)).then(function () { return photo; });
            });
        });
    }

    function lockSession() {
        return txStore('meta', 'readwrite').then(function (store) {
            return reqToPromise(store.put({ key: 'session', locked: true, lockedAt: Date.now() }));
        });
    }

    function unlockSession() {
        return txStore('meta', 'readwrite').then(function (store) {
            return reqToPromise(store.put({ key: 'session', locked: false, lockedAt: null }));
        });
    }

    global.OfflineStore = {
        DB_NAME: DB_NAME,
        MAX_ATTEMPTS: MAX_ATTEMPTS,
        STATUSES: STATUSES,
        openDb: openDb,
        uuid: uuid,
        nextStatus: nextStatus,
        preservarIdempotencyKey: preservarIdempotencyKey,
        fingerprint: fingerprint,
        alreadyQueued: alreadyQueued,
        enqueue: enqueue,
        getOperation: getOperation,
        listByStatus: listByStatus,
        listPendingForUser: listPendingForUser,
        updateOperation: updateOperation,
        markStatus: markStatus,
        retryOperation: retryOperation,
        removeSynced: removeSynced,
        saveDraft: saveDraft,
        getDraft: getDraft,
        clearDraft: clearDraft,
        enqueuePhoto: enqueuePhoto,
        getPhoto: getPhoto,
        markPhotoUploaded: markPhotoUploaded,
        lockSession: lockSession,
        unlockSession: unlockSession
    };
})(typeof self !== 'undefined' ? self : this);
