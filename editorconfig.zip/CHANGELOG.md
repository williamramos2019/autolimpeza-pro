﻿# CHANGELOG — CMS Editorial Premium

**Projeto:** Auto Limpeza Pro  
**Período:** 2026-06-22 → 2026-06-26  
**Princípio:** evolução incremental — sem reconstruir arquitetura

> **Convenção:** toda atualização importante deve gerar uma versão datada aqui (formato `AAAA-MM-DD`), do mais recente para o mais antigo. Ver regra em `.cursor/rules/versionamento-datado.mdc`.

---

## [v1.25.44] - 2026-08-11
### Alterado
- **Finanças (`/financas`):** layout alinhado a Agenda/Caixa — header sticky, botão voltar, saldo em card do tema. Removido o herói azul e o sino morto (FIN-006). Cores de entrada/saída passam a `--success` / `--destructive` (sem paleta fintech).
### Documentação
- `docs/RELATORIO-FINANCAS-UI-ALP-2026-08-11.md`.

## [v1.25.43] - 2026-08-11
### Alterado
- **Seleção de afiliados na geração de posts:** deixa de carregar o catálogo inteiro e de escolher sempre o mesmo SKU (`sort_order`/`id` + bônus de cidade). Motor semântico (nicho/subnicho/intent/keywords) consulta o banco, pontua relevância comercial (localização SEO isolada), aplica cooldown e rotaciona no TOP-K pelo menor uso — sem `ORDER BY RAND()` e sem a IA inventar URL.
- Injeção do card (`affiliateShelf` + CTA local) permanece igual; só muda **qual** produto entra no primeiro slot.
### Adicionado
- Tabela `blog_affiliate_link_usage`, colunas `use_count`/`last_used_at`, config `AFFILIATE_PRODUCT_*`, logs `affiliate_selection`, admin `?stats=1` / `?preview=1`.
### Documentação
- `docs/RELATORIO-AFILIADOS-SELECAO-INTELIGENTE-2026-08-11.md`.

## [v1.25.42] - 2026-08-11
### Adicionado
- **Slack Bot Token + Channel ID** como fallback de envio (`chat.postMessage`) quando não há Incoming Webhook.
- Matriz: Slack ligado por padrão em novo agendamento, cancelado, concluído, lead e alerta de sistema (só em config ainda não salva).
### Documentação
- `docs/INTEGRACAO-SLACK.md` e `docs/RELATORIO-INTEGRACAO-SLACK-2026-08-11.md`.

## [v1.25.41] - 2026-08-11
### Documentação
- Auditoria completa do módulo **Finanças Pessoais** (`/financas`): fluxos, APIs, persistência híbrida, bugs FIN-001…016.
- `docs/AUDITORIA-FINANCAS-PESSOAIS-2026-08-11.md`.

## [v1.25.40] - 2026-08-10
### Adicionado
- **Pinterest domain verify:** meta `p:domain_verify` no `<head>` do `index.html` para reivindicar `autolimpezapro.com.br` no Pinterest.
### Documentação
- `docs/RELATORIO-PINTEREST-DOMAIN-VERIFY-2026-08-10.md`.

## [v1.25.39] - 2026-08-10
### Corrigido
- **Blog IA — clichê «O Perigo Oculto»:** prompts Capitão Clean / `aiBuildBlogPrompt` proíbem H2s genéricos de medo; banlist + rewrite em `blogFixRedundantCopy` / `blogStripBannedCliches`; detector em `blogAnalyzeRepetition`; sanitização no preview pós-geração.
### Documentação
- `docs/RELATORIO-BLOG-IA-PERIGO-OCULTO-2026-08-10.md`.
- Nota: posts já publicados com a frase precisam edição manual no CMS (não há mass-rewrite automático de conteúdo antigo).

## [v1.25.38] - 2026-08-10
### Corrigido
- **Capa por URL externa (ChatGPT/CDN):** ao colar/publicar, o servidor baixa a imagem e grava em `/uploads/` (`media/import-url` + localize em `cmsBlogPostSetImageMeta`); publish rápido agora persiste `imageUrl`/`ogImage` (antes só mudava `status`).
- Download de URL: User-Agent + redirects HTTPS seguros; URLs longas de CDN não são truncadas antes da importação.
- **Capa IA fora do tema:** `coverImagePrompt` explícito tem prioridade (sem brief conflitante de sofá); fallback do brief usa o título do artigo; Pollinations com `enhance=false`.
### Alterado
- Prompt externo (Content Studio/CMS) reforça título + categoria + keyword; hint de que a URL é salva em `/uploads/`.
### Documentação
- `docs/RELATORIO-BLOG-CAPA-URL-EXTERNA-2026-08-10.md`.

## [v1.25.37] - 2026-08-10
### Corrigido
- **SEO shell blog:** soft-404 reforçado (catch + guarda `!$postFound` → HTTP 404 + `noindex`); strip de meta `robots`/`description`/`canonical` aceita `name=` em qualquer ordem (evita meta duplicada `index, follow` do `index.html`).
- Mesmo strip de `robots` em `landing-seo-shell.php`.
### Documentação
- Probe security/produção: `docs/audit/API-TEST-REPORT.md`, `ERROR-ROOT-CAUSE.md`, `CRON-AUDIT.md`; seeds SEC-001…004 no `BUG-TRACKER.md`.
- `docs/RELATORIO-SECURITY-PROBE-2026-08-10.md`.
- Consolidação Operação Zero Bug: `docs/audit/FINAL-TECHNICAL-AUDIT.md` (inventários, trace 0 ghosts, ZB/SEC, pendências deploy/cron).
### Nota deploy
- Feed `/feed/blog.xml`, `health.version=APP_VERSION` e soft-404 efetivo em prod ainda dependem de upload do pacote; cron stale é ação ops no cPanel.

## [v1.25.36] - 2026-08-10
### Corrigido
- `api.php?action=status|health` (`handleStatus`): campo `version` alinhado a `APP_VERSION` (antes fixo `"3.0"`).
- `robots.txt`: Disallow dos admin paths omitidos (`guardiao-admin`, `clima-admin`, `prospeccao-admin`, `sistema-admin`, `automacoes-central`).
### Documentação
- Zero Bug follow-up pós-inventário: `docs/audit/BUG-TRACKER.md` (ZB-007…ZB-013); `docs/audit/RELATORIO-ZERO-BUG-FOLLOWUP-2026-08-10.md`.
- PushAlert UI já no caminho VAPID (`notifications/*`); `auth=false`+mutação e `/lista-bairros-*` documentados como falso positivo / vanity existente.

## [v1.25.35] - 2026-08-10
### Adicionado
- Seed CMS em produção das landings finas: `higienizacao-confins`, `limpeza-sofas-residenciais`, `limpeza-estofados-comerciais`.
- `landingDefaults` locais enriquecidos (sofás residenciais / estofados comerciais) alinhados ao seed.
### Alterado
- Capas IA do blog: regeneração completa dos posts que ainda usavam `og-mascote.png` (0 restantes).
- Script `scripts/regen-blog-covers.ps1`: processa todos os remanescentes e retenta falhas 1×.
### Documentação
- `docs/RELATORIO-LANDINGS-E-CAPAS-2026-08-10.md`; wiki/CHANGELOG alinhados a v1.25.35.
- Nota: SSR/RSS de v1.25.34 ainda exige upload do ZIP se não estiver live.

## [v1.25.34] - 2026-08-09
### Adicionado
- **Landing SEO shell** (`landing-seo-shell.php`): meta/OG/canonical/JSON-LD/noscript para money pages (SJL, Vespasiano, Confins…).
- Conteúdo genuíno da LP **Confins** (FAQ + mapa + diferenciais).
- Docs missão SEO: `SEO-AUDIT-REPORT`, `SEO-FINAL-REPORT`, `KEYWORD-MAP`, `CONTENT-STRATEGY`, GSC checklist, GBP, COMPETITOR-GAP, SECURITY-FINDINGS, SEO-CHANGELOG.
### Alterado
- Home: title + H1 splash/React com intenção local; chips cidade → hubs.
- Landings: linkify de paths/URLs em blocos texto.
- `sitemap.xml`: removidas URLs fracas `/?servico=`.
- LocalBusiness `areaServed`: inclui Confins.
### Documentação
- Wiki/CHANGELOG alinhados a v1.25.34.

## [v1.25.33] - 2026-08-09
### Adicionado
- Shell SEO: soft-404/`noindex` para slug inválido ou rascunho; `X-Robots-Tag`; trecho `noscript` + `articleBody` para crawlers; BreadcrumbList + `article:*` meta.
- HTTP 301 via `cms_redirects` no `blog-seo-shell` (não só SPA); rename de slug no PUT blog registra redirect.
- Feed RSS `/feed/blog.xml`; alias `/blog` → `/dicas` 301.
- Admin **Blog SEO Audit** (`blog/seo-audit` + painel no CMS).
### Alterado
- Thresholds repetição: soft **21** / forte **41** / hard **61** (Content Studio).
- Cache API blog pública: `max-age=30` (menos HTML/JSON stale pós-publish).
- EditorialSeoSidebar: check de canonical.
### Documentação
- `docs/AUDITORIA-BLOG-INDEXACAO-SEO.md`, `docs/RELATORIO-BLOG-SEO-INDEXACAO.md`.

## [v1.25.32] - 2026-08-08
### Corrigido
- **Blog capa IA:** `getBlogImageSourcesForPost` volta a usar `imageUrl` (incl. `/uploads/blog/`) como primary; 404 cai no `BlogImage` onError → capa local → fallback (revert parcial do AUD-005 que escondia capas geradas).
### Adicionado
- **Validador de repetição híbrido:** `blogAnalyzeRepetition` — soft (≥45) no sync/preview; hard (≥70) só no Content Studio `publishMode=publish` → `publishBlocked` + rascunho.
- Regras anti-repetição no prompt base (`aiBuildBlogPrompt`); sanitizer colapsa frases idênticas consecutivas.
### Documentação
- Thresholds e fluxo: `docs/RELATORIO-BLOG-IA-CAPA-E-QUALIDADE-2026-08-08.md`.

## [v1.25.31] - 2026-08-07
### Segurança
- **AUD-001:** `schedule/availability` público deixa de expor `occupied[].client` (PII); só `time` / `duration` / `end`.
### Corrigido
- **AUD-004:** preços “a partir de” unificados (home × wizard × catálogo) via `bookableServicePricing.ts` (sofá R$120, cadeiras R$35, etc.).
- **AUD-003:** aliases de slug marketing → LP canônica (`higienizacao-de-sofas`, `colchoes`, …) no front e em `landing-handlers.php`.
- **AUD-005:** capas de blog com `/uploads/` órfão priorizam capa local / fallback estático.
- **AUD-007:** `api.php?action=manifest` passa a responder o PWA manifest (compat com probe).
- **AUD-008:** marquee de reviews: 2ª faixa com `aria-hidden`; dedupe em `getHomeReviews`.
### Alterado
- `APP_VERSION` → `2026.08.07-v1.25.31`.
### Documentação
- `docs/RELATORIO-CORRECOES-AUDITORIA-2026-08-07.md`.

## [v1.25.30] - 2026-08-07
### Adicionado
- **Slack Incoming Webhook** como canal paralelo da Central de Notificações (ops), espelhando Telegram: `slack-service.php`, matriz de eventos, UI em Comunicação → Canais, Test Center e health.
### Documentação
- `docs/INTEGRACAO-SLACK.md`, `docs/RELATORIO-INTEGRACAO-SLACK-2026-08-07.md`.

## [v1.25.29] - 2026-08-06
### Corrigido
- **FAB WhatsApp (blog):** `blog-responsive.css` deixava de usar `!important` com `bottom` baixo que anulava o clearance do componente; alinhado a `max(5.5rem, … + safe-area)`.
### QA
- Typecheck OK; checklist visual blog responsivo revalidado (grids, reco card, share colapsável, nav).

## [v1.25.28] - 2026-08-06
### Alterado
- **Blog responsivo (fase principal):** card de recomendação (aspect 4:3 mobile, CTA 48px, preços sem nowrap, shelf centrado); grids unificados 1→2@640→3@1024; sticky share colapsável; FAB WhatsApp com safe-area; nav CTA “Agendar” no mobile; footer de news card com wrap; comparison sem min-width 280.
### Documentação
- `docs/RELATORIO-BLOG-CARDS-RESPONSIVOS-2026-08-06.md`.

## [v1.25.27] - 2026-08-06
### Corrigido
- **React #185 (Maximum update depth exceeded):** loop de navegação SPA ao sair do admin / navegar no site público.
  - `Index` não reage mais ao próprio evento `alp:pathchange` (`source:index`).
  - `CmsPublicExtras`: corta ciclos de redirect CMS A→B→A; um canal só (sem `navigate`+event juntos).
  - `SeoVanityRedirect`: remove `popstate` sintético; usa `navigateTo` com limite de hops.
### Documentação
- Causa: feedback entre dual-router Index ↔ redirects CMS ↔ vanity SEO.

## [v1.25.26] - 2026-08-05
### Removido
- Pacotes ZIP obsoletos em `deploy/` (v1.18–v1.25.25 anteriores) e espelho stale `deploy/FINAL_CPANEL/`.
- Artefato de build de teste `dist-cpanel-test/` e logs `deploy/build-*.log`.
### Alterado
- `.gitignore`: `dist-cpanel-test/`, `deploy/FINAL_CPANEL/`.
- Guias HostGator em `deploy/LEIA-ME-*.md` e checklist de credenciais alinhados à versão atual.
### Documentação
- Wiki/versões apontam para v1.25.26 (pacote limpo para HostGator).

## [v1.25.25] - 2026-08-05
### Documentação
- Central de Documentação (CMS) sincronizada com entregas do dia: wiki, versões, status e índices das auditorias/relatórios.
- Índice em `docs/status/08-sincronizacao-docs-2026-08-05.md` (OG, auditoria de erros, Blog/IA/CRM/Afiliados, auth, deploy HostGator).
### Alterado
- `APP_VERSION` → `2026.08.05-v1.25.25` (catálogo ao vivo da Central lê a versão do CHANGELOG).

## [v1.25.24] - 2026-08-05
### Adicionado
- Tracking de clique afiliado: `POST blog/affiliate-links/click` incrementa `click_count`; front dispara em card e `linkE` Shopee (`trackAffiliateClick`).
- Atribuição de leads do blog: coluna `leads.attribution` (JSON) com `post_slug`, `page_path`, UTM e `affiliate_id`; portal/newsletter enviam origem.
### Corrigido
- Content Studio não sobrescreve mais artigo `published`/`scheduled` com o mesmo slug (gera sufixo `-ia-{timestamp}`).
- Autor padrão de artigos gerados: **Auto Limpeza Pro** (antes `IA Studio`).
### Documentação
- `docs/AUDITORIA-BLOG-IA-CRM-AFILIADOS-2026-08-05.md` — auditoria Blog · Gemini · CMS · CRM · Afiliados + matriz de integridade.

## [v1.25.23] - 2026-08-05
### Corrigido
- **Repair admin:** `install.php?step=repair&resync_master=1` agora chama `ensureMasterAdminUser($pdo, true)` — a senha master passa a ser sincronizada de fato (antes a UI mentia “sincronizada”).
- **Repair blog:** aplica colunas/migration de capa IA (`image_prompt` / `image_status` / …) no repair, não só no lazy path do blog API.
- **Sobre:** allowlist de hero padrão inclui `/og-mascote.png` (alinhado ao cutover OG v1.25.22).
- **Seo Center:** hint Open Graph home aponta para `og-mascote.png` (não mais `mascote-400.webp`).
### Documentação
- Auditoria completa: `docs/AUDITORIA-ERROS-2026-08-05.md`.
### Testes
- `tsc --noEmit`, `php -l install.php`, `validate-routes.php`, health/APIs produção (leitura), asset `og-mascote.png` 1200×630.

## [v1.25.22] - 2026-08-05
### Corrigido
- **Open Graph / Twitter Cards:** crawlers (WhatsApp, Facebook, Instagram, X, LinkedIn) passam a receber a capa do post em `/dicas/:slug` e o mascote 1200×630 na homepage.
- `blog-seo-shell.php` remove meta OG/Twitter genéricos do `index.html` antes de injetar (crawlers usavam o primeiro `og:image`).
- Imagens de share absolutas HTTPS; SVG rejeitado; fallback `/blog/covers/{slug}.jpg`; `twitter:card=summary_large_image`.
### Alterado
- Homepage: `og:image` / `twitter:image` → `og-mascote.png` (1200×630); `og:type=website`.
- Posts: `og:type=article` + título/descrição/capa do post (SSR shell + client `applyShareMeta`).
### Documentação
- `docs/RELATORIO-OG-TWITTER-SHARE-2026-08-05.md`.

## [v1.25.21] - 2026-08-05
### Alterado
- **Auth:** e-mail admin (`MASTER_ADMIN` / `admin_users`) no portal (Google ou e-mail+senha) emite sessão admin e redireciona para `/admin`; demais usuários seguem no Portal do Cliente.
- Senha master alinhada a `Liz@2023` (sync bcrypt no login).
### Segurança
- Rate limit fail-closed inclui `admin_google_login`; rejeita `google_sub` divergente no cliente.
### Documentação
- `docs/RELATORIO-AUTH-UNIFICADA-2026-08-05.md`.

## [v1.25.20] - 2026-08-04
### Adicionado
- **SEO Local:** hubs `/sao-jose-da-lapa` e `/vespasiano` + matriz LPs serviço×cidade (colchão SJL, impermeabilização, pós-obra, estética automotiva, limpeza de estofados).
- Footer grupo **Cidades Atendidas** e links money para LPs SJL/Vesp.
### Alterado
- LPs sofá SJL/Vesp e colchão Vespasiano: titles/H1/meta/FAQ locais (Helpful Content).
- SEO Hub `#sjl`/`#vesp`: prioriza LPs money (path) em vez de só vanity→blog.
### Corrigido
- Sitemap: removidas URLs thin `?cidade=` / `?bairro=` sem handler no frontend; inclusas LPs novas.
### Documentação
- `docs/RELATORIO-SEO-LOCAL-2026-08-04.md`.

## [v1.25.19] - 2026-08-01
### Adicionado
- **Blog / Content Studio:** capa IA obrigatória no fluxo de geração (texto → prompt → imagem → só então conclusão/publicação).
- Campos em `blog_posts`: `image_prompt`, `image_status` (`pending|generating|completed|failed`), `image_provider`, `image_generated_at`.
- Admin: indicadores Conteúdo/Imagem, botão **Gerar imagem novamente**, filtros (sem imagem / erro / aguardando), prompt profissional com negative prompt para plataforma externa.
### Alterado
- Pipeline e Image Gateway: retry automático; falha grava `image_status=failed` + log + prompt salvo (sem falha silenciosa).
- Publicação bloqueada sem `image_url` válida / capa pronta (`cmsBlogPostImageReady`).
### Documentação
- `docs/RELATORIO-CAPA-IA-OBRIGATORIA-2026-08-01.md`.

## [v1.25.18] - 2026-08-01
### Corrigido
- **Cron:** `job_queue` processada em `runCronJobs()` (`alpProcessJobQueue`).
- **Migrations:** falha SQL crítica não marca `schema_migrations` (retry no repair).
- **Uploads:** MIME só via finfo (client + vistoria) — sem spoof de `Content-Type`.
### Documentação
- Release Enterprise: `VERSION.md`, `RELEASE_NOTES.md`, `docs/release-v1.25.18/*`.
### Auditoria
- Gates agendamento/Care+/TS/cron/segurança código: PASS.

## [v1.25.17] - 2026-08-01
### Adicionado
- Centro de Conteúdo IA / CMS: **prompt profissional de capa** (EN) com botão copiar para Midjourney, Leonardo, Ideogram, Flux ou ChatGPT Image; campo para colar URL e **trocar a capa** se a imagem gerada não agradar.
- API: `externalImagePrompt` no `blog/generate` e no resultado do Content Studio.
### Documentação
- Fluxo documentado no CHANGELOG; helper `src/lib/blog/coverImagePrompt.ts`.

## [v1.25.16] - 2026-08-01
### Corrigido
- **Agendamento / Pós-obra:** removido tempo estimado por m² (extras 120–720 min) que gerava 600–960 min e “não cabe no dia” / falso dia preenchido; slot neutro 150 min (preço por m² mantido).
- Mensagem de dia vazio: prioriza `duration_or_hours` quando nenhum horário cabe na duração (evita “todos reservados” falso).
- Reagendamento portal: envia `services` do registro na validação (antes falhava com “Informe ao menos um serviço”).
### Documentação
- [`docs/RELATORIO-FIX-AGENDAMENTO-POS-OBRA-2026-08-01.md`](docs/RELATORIO-FIX-AGENDAMENTO-POS-OBRA-2026-08-01.md)

## [v1.25.15] - 2026-08-01
### Adicionado
- Portal **Minha Casa** + hub **Central Care+** (`/conta/care-plus`) como jornada (Diagnosticar → Proteger → Acompanhar → Relacionar).
- Eventos `careplus_action` / `analytics.custom` para GA4 + engagement.
- Entregáveis de auditoria em `docs/entregaveis/` (01–10).
### Alterado
- Home: seção Tecnologia Exclusiva com naming Care+ (reuso de rotas).
- CRM: rótulo **Customer Success** (módulo pós-venda).
- Nav portal: grupos Minha Casa / Acompanhar / Relacionar.
### Corrigido
- Dual-router: `PremiumNavBar` evita double navigation (flash/remount).
- Trailing slash no `parsePath` + 301 Apache; gate planos sem pintar Home.
- Portal: `sessionChecked` antes de Outlet; spa depth só em `useEffect`.
### Segurança
- `.htaccess` bloqueia `CREDENCIAIS-DEPLOY.txt`.
### Documentação
- [`docs/RELATORIO-AUDITORIA-CARE-PLUS-2026-08-01.md`](docs/RELATORIO-AUDITORIA-CARE-PLUS-2026-08-01.md)
- [`docs/entregaveis/`](docs/entregaveis/)

## [v1.25.14] - 2026-08-01
### Adicionado
- Banner Web Push na home + onboarding PWA; toggle Push do Perfil liga/desliga inscrição VAPID.
- YouTube admin: botão **Atualizar feed** (`POST youtube/refresh`) limpa cache RSS.
### Alterado
- Home YouTube: destaca o **vídeo mais recente** (não aleatório); Shorts só com `#shorts`.
- Analytics Ops recebe `sales` do estado admin; `ALLOW_STATIC_ADMIN_TOKEN=false` (repair via ADMIN_TOKEN).
### Documentação
- [`docs/RELATORIO-CONSOLIDACAO-V1.25.14-2026-08-01.md`](docs/RELATORIO-CONSOLIDACAO-V1.25.14-2026-08-01.md)

## [v1.25.13] - 2026-07-31
### Corrigido
- **Analytics audit:** CWV (`meta`/`metadata`), allowlist idle/rage/js/404, double-count WA, daily range, LIMIT visits.
- UTM ensure no boot; GA/GTM/Clarity semeados de `config.php` → `site_config`.
- Painel: label WA, sem GA hardcoded, `onNavigate` executivo, poll realtime, geo enrichment, skip admin no tracker.
### Segurança
- Validação de IDs GA/GTM/Clarity antes de injetar scripts; allowlist em `conversion/event`.
### Documentação
- [`docs/RELATORIO-AUDITORIA-CORRECAO-ANALYTICS-2026-07-31.md`](docs/RELATORIO-AUDITORIA-CORRECAO-ANALYTICS-2026-07-31.md)

## [v1.25.12] - 2026-07-31
### Adicionado
- **Analytics Intelligence Center** em `/analytics`: abas (tráfego, funil, conversões, ops, executivo, SEO/GBP, marketing, técnico, insights, realtime).
- Facade `analyticsApi` + tipos; export CSV; realtime 15 min; funil comercial; série diária/origens.
- Atribuição UTM/gclid/fbclid no ingest; loaders Clarity/GTM; eventos idle/rage/js_error/404; CWV no painel.
- Insights determinísticos (alertas de conversão, vídeo, mobile, LCP, etc.).
### Alterado
- `engagement/stats` enriquecido; `ConversionDashboard`/`ExecutiveDashboardApp` aceitam `embedded`.
### Documentação
- [`docs/RELATORIO-ANALYTICS-INTELLIGENCE-CENTER-2026-07-31.md`](docs/RELATORIO-ANALYTICS-INTELLIGENCE-CENTER-2026-07-31.md)
- Auditoria prévia: [`docs/RELATORIO-AUDITORIA-ANALYTICS-INTELLIGENCE-2026-07-31.md`](docs/RELATORIO-AUDITORIA-ANALYTICS-INTELLIGENCE-2026-07-31.md)

## [v1.25.11] - 2026-07-31
### Alterado
- **Portal Dicas — regra de ouro de recomendação:** sanitize pública remove Afiliado/Shopee/Amazon/Comissão/Parceiro/Propaganda; shelf com 1 card; DE:/POR:, desconto, ★ e imagem.
- Prompt Capitão Clean e injeção PHP alinhados às diretrizes (sem marketplace na copy).
- CMS: rótulos neutros (“Recomendações de produto”).
### Documentação
- [`docs/RELATORIO-BLOG-RECOMENDACAO-PRODUTO-2026-07-31.md`](docs/RELATORIO-BLOG-RECOMENDACAO-PRODUTO-2026-07-31.md)

## [v1.25.10] - 2026-07-31
### Corrigido
- **`install.php?step=repair`:** aceita `ADMIN_TOKEN` sempre (header / POST / query), independente de `ALLOW_STATIC_ADMIN_TOKEN` — corrige 401 “Autenticação obrigatória” no deploy.
- Formulário POST na página 401 para colar o token sem vazar em access logs.
### Adicionado
- Pacote com credenciais inclui `CREDENCIAIS-DEPLOY.txt` (tokens + URL de repair).
### Documentação
- [`docs/RELATORIO-REPAIR-ADMIN-TOKEN-2026-07-31.md`](docs/RELATORIO-REPAIR-ADMIN-TOKEN-2026-07-31.md)

## [v1.25.9] - 2026-07-31
### Alterado
- **Cards e botões (Mapa / Blog / GMB):** camada `cards-buttons-polish.css` com hover elevação, sombra primary, entrada staggered e chevron animado; touch targets em chips de bairro; `prefers-reduced-motion` respeitado.
- Sem mudança de funcionalidades.

## [v1.25.8] - 2026-07-31
### Alterado
- **UI/UX — features novas alinhadas ao design system:** GBP Performance (`AdminKpiCard`, cores semânticas, touch targets, erros no compact); Mapa do Site (`portal-btn`/`portal-focus`, WA brand); card de produto (CTA primary, tokens success); formulário Google Meu Negócio (Input + tabs).
- Sem mudança de funcionalidades, rotas ou APIs.

## [v1.25.7] - 2026-07-31
### Adicionado
- **Google Business Profile Performance API** (server-side): métricas 30/60/90 dias (impressões Maps/Search, ligações, site, rotas) + palavras-chave; comparação vs período anterior.
- Cache em `alpCache` + MySQL `google_gbp_api_cache` (TTL 12h); renovação OAuth via refresh token.
- UI: aba **Performance** em Google Meu Negócio + strip no Dashboard Inteligente.
- Doc: [`docs/google-api.md`](docs/google-api.md).
### Alterado
- Credenciais OAuth atualizadas em `config.local.php` / `google-oauth-client.json` (Client ID do projeto GCP Performance).

## [v1.25.6] - 2026-07-31
### Alterado
- **Mapa do Site (`/mapa-do-site`):** layout em abas (Serviços, SEO Local, Problemas, FAQ/Sobre) no lugar da rolagem contínua; busca rápida e CTAs preservados.
- Listas de bairros em accordion fechado por padrão (“Ver N bairros atendidos em…”).
- Grid compacta 3 colunas para categorias de serviço; `forceMount` nas abas para manter todos os links SEO no DOM.

## [v1.25.5] - 2026-07-31
### Alterado
- **Portal Dicas — UI/UX profunda:** tipografia e densidade do artigo, empty/error states, capa sticky, cards da listagem e hierarquia de seções.
- **Card de recomendação de produto:** `ProductRecommendationCard` com preço DE/POR, desconto, avaliação, imagem e CTA neutro (“Conferir Oferta”, “Ver na Loja”, etc.).
- **Copy pública do shelf:** sem nomes de marketplace, “Parceiros”, “afiliado” ou badges de loja; título “Dica para Manutenção em Casa” / “Recomendação do Especialista”.
- PHP de injeção (`blog-affiliate-links.php`): badge e título do shelf alinhados à copy neutra (funcionalidade de links inalterada).
### Documentação
- Relatório técnico + arquitetura do fluxo Blog/Dicas e do card de produto.

## [v1.25.4] - 2026-07-31
### Alterado
- **Portal Dicas — polish visual:** camada `blog-ui-polish.css` para cards, chips, CTAs, FAB WhatsApp e shelf de afiliados (hover elevação, sombra, CTA em pill).
- Motion só com `transform`/`filter`/`box-shadow`; `prefers-reduced-motion` respeitado.
- Removidos chips soltos da home (`HOME_SERVICE_CHIPS`).

## [v1.25.3] - 2026-07-31
### Alterado
- **Portal Dicas — cards estilo portal de notícias:** thumb 16:9 no topo, categoria + data, título sanitizado, excerpt `line-clamp-2`, rodapé com tempo de leitura + “Ler o guia →”; grid 1/2/3 colunas.
- **Afiliados nos posts:** seção “Produtos Recomendados / Ferramentas Úteis”; fallback de produtos injetados pelo PHP (não só `afiliados-db.json`); `rel="sponsored noopener noreferrer"` + `target="_blank"`.
### Adicionado
- `BlogNewsCard` + `sanitizeBlogTitle()` (remove sufixos `(cópia)` / draft).

## [v1.25.2] - 2026-07-29
### Corrigido
- **Agendamento — horários “indisponíveis” sem reserva:** a regra de almoço bloqueava qualquer job que *atravessasse* 12h–13h. Com slots fixos de 2h30, o horário **10:30** (sofá 150 min → 13:00) era rejeitado como se estivesse ocupado.
- Mensagens distintas: expediente / almoço / já reservado / hoje sem horários futuros / duração não cabe.
- Validação de data passada usa `America/Sao_Paulo` (não só timezone do PHP).
### Alterado
- `fixedSlotStarts` padrão sem `18:00` (não cabia no `workEnd` 18:00).
- API `schedule/availability` passa a expor `conflictReason` e `emptyReason`.

## [v1.25.1] - 2026-07-29
### Documentação
- Wiki técnica completa do Portal Dicas: [`docs/wiki/modulo-portal-dicas.md`](docs/wiki/modulo-portal-dicas.md).
- FAQ dedicado: [`docs/wiki/problemas-frequentes-portal-dicas.md`](docs/wiki/problemas-frequentes-portal-dicas.md).
- Atualizados: `modulos.md`, `00-visao-geral.md`, `manutencao.md`, `transicoes-pagina.md`, `audit/09-modulos.md`.

## [v1.25.0] - 2026-07-29
### Alterado
- **Performance — otimização profunda:** corpus blog em code-split (`blog-data` chunk); `useBlogPosts` sem import sync ~180KB; fetch duplo eliminado em `BlogPostPage`; prefetch home conservador (sem `/dicas` automático, respeita saveData); dedup `verifyAdminSession`; `BlogImage` com `fetchPriority`/`sizes`; import direto `BlogBlockRenderer`.
### Documentação
- [`docs/audit/PERFORMANCE-V1.25.0-2026-07-29.md`](docs/audit/PERFORMANCE-V1.25.0-2026-07-29.md).

## [v1.24.9] - 2026-07-29
### Alterado
- **UI/UX módulo blog — varredura premium:** tokens CSS unificados (`blog-list.css` → variáveis do portal); badges de categoria centralizados (`BlogCategoryBadge`); selo “Novo” consistente (`BlogNewBadge`); FAB WhatsApp unificado (`BlogFloatingWhatsApp`).
- Feed `/dicas`: padding duplicado removido; chips/filtros alinhados ao design system; microinterações de hover refinadas nos cards.
- Tipografia do artigo (`BlogBlockRenderer`) alinhada aos tokens `portal-lede` / `portal-section-title`.
- Estados vazios/erro: retry na listagem, artigo e comentários; `aria-busy` no `<main>` da listagem.
### Documentação
- Relatório [`docs/audit/UI-UX-BLOG-V1.24.9-2026-07-29.md`](docs/audit/UI-UX-BLOG-V1.24.9-2026-07-29.md).

## [v1.24.8] - 2026-07-29
### Adicionado
- **Transições avançadas — módulo blog:** `BlogContentTransition` para troca de filtro na grade `/dicas`; stagger leve na listagem; parallax mobile sem blur (GPU).
### Alterado
- Auto-efeitos do portal: post→post `zoom-in`; lista→post `cover` em mobile; home→`/dicas` `cover`; parallax reservado ao desktop.
- Hero do artigo deixa de duplicar fade Framer — entrada coberta pelo `PageTransition` de rota.
### Documentação
- Wiki [`docs/wiki/transicoes-pagina.md`](docs/wiki/transicoes-pagina.md) §9.1 atualizada; relatório [`docs/RELATORIO-TRANSICOES-BLOG-2026-07-29.md`](docs/RELATORIO-TRANSICOES-BLOG-2026-07-29.md).

## [v1.24.7] - 2026-07-29
### Alterado
- **Módulo Blog — responsividade:** camada `blog-responsive.css`; touch targets ≥48px; drawer full-width mobile; grid 2 col tablet; containers ultrawide; prose sem overflow; carrosséis com scroll snap.
### Adicionado
- Relatório [`docs/audit/RESPONSIVIDADE-BLOG-2026-07-29.md`](docs/audit/RESPONSIVIDADE-BLOG-2026-07-29.md).

## [v1.24.6] - 2026-07-29
### Corrigido
- **Afiliados no blog:** `affiliateShelf` sumia silenciosamente — catálogo `afiliados-db.json` expandido para 100 produtos (seed Shopee); matching por chave `shopId:itemId` nas URLs; IDs numéricos do MySQL ignorados na validação.
- Fallback editorial (CTA serviço profissional) quando nenhum produto valida no JSON, em vez de bloco vazio.
- Script `scripts/sync-afiliados-db-from-seed.mjs` para re-sincronizar JSON após atualizar seed SQL.

## [v1.24.5] - 2026-07-29
### Adicionado
- **Design system mobile-first:** carrossel nativo de acessos rápidos (scroll snap CSS) na home; layout premium do blog (`blog-grid`, `blog-card`, filtros por tema).
- **`src/data/afiliados-db.json`:** fonte da verdade de produtos Shopee/Amazon para cards de afiliado nos artigos.
- **`src/lib/affiliates/afiliadosDb.ts`:** validação de URLs/preços antes de renderizar afiliados no blog.
- CSS `mobile-native.css`: card de afiliado sutil (`.affiliate-native-card`) — uso exclusivo em posts.
### Alterado
- **Segregação de negócio:** home/landing/serviços permanecem 100% focados em venda do serviço; afiliados só dentro dos artigos do blog (máx. 2 cards sutis por bloco).
- Bloco `affiliateShelf` substituído visualmente por anúncio nativo validado contra `afiliados-db.json` (sem vitrine agressiva de 3 cards).
- Chips de categoria da home movidos para a seção Serviços; filtros do portal `/dicas` reposicionados após destaques.
### Corrigido
- Área de toque mínima 48px em chips, cards e CTAs mobile; `box-sizing: border-box` global reforçado.

## [v1.24.4] - 2026-07-28
### Adicionado
- **Agendamento multi-serviço:** no wizard, dá para somar vários itens (ex.: cadeiras + colchão + lavagem), ver total estimado (valor + duração) e seguir com um único horário; API/WhatsApp/Agenda recebem a lista completa.
- Alias de rota API `status` (= `health` / `handleStatus`).
- Migração `2026-07-28-shopee_affiliate_commerce_placeholders.sql`: preços placeholder na vitrine de afiliados seed (image_url null).
- Redirect de vanity SEO (`seoPath`) para o alvo real (serviço/blog/mapa); âncoras `#sjl` / `#vesp` no mapa.
- Placeholders before/after (`placeholder-before.svg` / `placeholder-after.svg`).
### Alterado
- Rascunho local do booking persiste o carrinho; PWA cache `v14`; `APP_VERSION` / manifest `2026.07.28-v1.24.4`.
- Appointment PUT: `duration` omitida/≤0 defaulta para 150 (igual ao POST); POST rejeita `services` vazios.
- Métricas: parse de `R$` em serviços string antes do fallback 150.
- Booking: migração de rascunho sem cart; flush só avança com item válido; duração por opção (sem N×piso); atalho PWA `action=`; FAQ → `/ajuda`; busca/sino no header mobile; SW não ignora mais URLs com `action=`.
- Notificação cliente de lavagem usa tipo `automotive_wash_confirm`.
### Segurança
- Validação de agendamento exige ao menos um serviço na lista.

## [v1.24.3] - 2026-07-28
### Alterado
- **Home mobile (app-style):** header compacto (logo + WhatsApp); hero sem marca duplicada; mascote em destaque; chips Estofados/Automotiva/Pós-Obra; CTA WhatsApp “Orçamento Grátis”; bloco redes + logo/slogan no rodapé.
- **PWA:** service worker `v13` (cache bump); manifest theme `#00d2ff` / fundo `#050811`; atalho Orçamento WhatsApp; `APP_VERSION` v1.24.3.

## [v1.24.2] - 2026-07-28
### Alterado
- **Portal Dicas:** preset `BLOG_PAGE_TRANSITION` + auto-efeitos lista↔post (parallax/slide-right) e post→post (`soft`); a11y Framer (`MotionConfig` / `useReducedMotion`) no shell e primitives.
### Documentação
- Seção Portal Dicas em `docs/wiki/transicoes-pagina.md`

## [v1.24.1] - 2026-07-28
### Adicionado
- **Prateleira de afiliados no post:** bloco `affiliateShelf` com até **3 cards** (foto, título, preço de/por, % off, rating, badge Shopee) no estilo vitrine — não só link de texto.
- Colunas de comércio em `blog_affiliate_links`: `image_url`, `sale_price`, `original_price`, `rating`, `discount_percent`.
### Alterado
- Import Shopee grava/atualiza imagem e preços; reinjeção substitui `linkE` Shopee antigos pela prateleira.
- Painel CMS de afiliados edita campos de vitrine.
### Documentação
- `docs/RELATORIO-AFILIADOS-VITRINE-2026-07-28.md`

## [v1.24.0] - 2026-07-28
### Adicionado
- **Perfil admin na API:** tabela `user_settings`, rotas `admin/profile` e `api/v1/profile` (GET/PUT), FE com sync + cache localStorage offline.
- **Env loader:** `env.php` + `.env.example`; `config.php` sem secrets (só `alpEnv` + `config.local.php`).
- **Escala:** `redis-cache.php`, `object-storage.php` (local/S3), `job-queue.php` + `system/queue-process`.
### Alterado
- Build padrão **sem** `-IncludeCredentials` (ZIP limpo); IncludeCredentials marcado como legado.
### Documentação
- `docs/PLANO-ESCALA-V1.24.0-2026-07-28.md`, `docs/PREFLIGHT-PRODUCAO-V1.24.0.md`

## [v1.23.29] - 2026-07-28
### Corrigido
- **QA 5 ondas:** logout cliente com `token_hash`; upload de fotos com feedback de erro; foto do agendamento persiste em `photo_urls`/`quote_photos`; `/?agendar=1` reage a mudança de rota; chat visitante Capitão Clean no HelpFab; financeiro hidrata do servidor.
### Documentação
- `docs/RELATORIO-QA-5-ONDAS-FIX-2026-07-28.md`

## [v1.23.28] - 2026-07-28
### Corrigido
- **QA cliques:** lead modal fora da home, `/?agendar=1`, blog→`/conta`, portal lead/newsletter reais, Ver no Google, FAB quote/compare/share, Legal/Antes-e-Depois lead, área cliente agendar, CTAs `#agendar` mortos, feedback de artigo, links Google vazios.
### Documentação
- `docs/RELATORIO-QA-BOTOES-CLIQUES-2026-07-28.md`

## [v1.23.27] - 2026-07-28
### Corrigido
- **QA varredura:** login técnico (`?op=`), leads GET + CRM columns, WA engagement→conversão, foto agendamento (HEIC), views blog sem double-count, `sw.js` cache, Web Push EC pad + segmento clients, SW navigate fallback.
### Documentação
- `docs/RELATORIO-VARREDURA-QA-2026-07-28.md`

## [v1.23.26] - 2026-07-28
### Adicionado
- **Engagement Tracker:** scroll 25/50/75/100%, vídeo home (play/50%/100%), WhatsApp automático, `POST blog/view` + badge de visualizações no artigo.
- Tabelas `blog_post_views`, `blog_post_view_visitors`, `engagement_events`; rotas `engagement/event`, `engagement/stats`, `blog/view`.
### Alterado
- **Painel Analytics** reformulado (dark `#0b0f17`, acento `#0284C7`, conversão `#10B981`) com KPIs, funil de vídeo, tabela de páginas e geo sobre únicos.
- Geolocalização: % sobre visitantes únicos do período.

## [v1.23.25] - 2026-07-28
### Alterado
- **Painel `/admin`:** hub redesenhado no design system Premium Escuro (`#0B0F17`, cyan/violet, glass, acordeão de módulos) — mesmo visual do CMS Premium.
### Adicionado
- Regra Cursor `.cursor/rules/ui-premium-dark-menus.mdc`.

## [v1.23.24] - 2026-07-28
### Adicionado
- **Selo "Novo"** em dicas/blog/posts publicados há até 14 dias (`BlogNewBadge` + `isNewBlogPost`), com data de publicação (Portal Dicas, artigo, home, cards, CMS).
- Regra Cursor `.cursor/rules/blog-selo-novo.mdc` para manter o padrão em novas superfícies.

## [v1.23.23] - 2026-07-28
### Corrigido
- **Telegram no publish:** feedback no Gerador de Artigos + CMS; Content Studio não engole mais falhas de multicanal.
- **Afiliados no save CMS:** `blogEnrichPostForSeo` só reinjeta `linkE` com `applyAffiliateLinks` (evita reaparecer links após o editor apagar).
- **Premium CMS sidebar:** ícones Lucide com `className` (não `style`) — typecheck OK.
- **Toast Telegram:** ausência de `multichannelResult` agora avisa (não finge sucesso).
### Alterado
- `APP_VERSION` / frontend alinhados a `2026.07.28-v1.23.23`.

## [v1.23.22] - 2026-07-28
### Alterado
- **Capas do blog:** prompt de imagem amarrado ao tema exato do post (sofá, carro, colchão, tapete, pós-obra) via `aiImageVisualBriefFromArticle`; usa `coverImagePrompt` da IA; seed determinístico por slug (não aleatório).

## [v1.23.21] - 2026-07-28
### Adicionado
- **Shopee Affiliate:** importação automática de 2 datafeeds Shopee; filtro por nicho (estofados, automotivo, impermeabilização, pós-obra, equipamentos); 100 produtos seed em `blog_affiliate_links`; API `POST blog/affiliate-links/import-shopee`; script CLI `scripts/import-shopee-affiliates.php`.

## [v1.23.20] - 2026-07-28
### Alterado
- **Capitão Clean v2:** prompt de blog com gatilhos de medo (ácaros/mofo/desvalorização) + escassez de agenda local; CTA "ALERTA DE AGENDA"; campo `coverImagePrompt` (inglês) para capa IA; prompt de imagem dramático antes/depois.

## [v1.23.19] - 2026-07-28
### Adicionado
- **Meta Pixel Facebook** (`1301066345201510`): script no `index.html`, config `meta_pixel_id` na API, painel em Perfil → Meta Pixel.
- Eventos automáticos: PageView, Contact (WhatsApp), InitiateCheckout, Lead, Purchase via `analytics.ts`.

## [v1.23.18] - 2026-07-28
### Adicionado
- **Blog — links de afiliados:** tabela `blog_affiliate_links`, CRUD admin (`blog/affiliate-links`), módulo CMS "Links de afiliados".
- **Capitão Clean:** prompt de geração IA com lista dinâmica de URLs do banco; pós-processamento injeta CTA local (quote + linkE) e afiliados contextuais em todo save/geração.
- Bloco editorial `linkE` no portal `/dicas` para links externos com âncora persuasiva.
### Alterado
- `aiBuildBlogPrompt` e `blogEnrichPostForSeo` integrados ao banco de links.
### Documentação
- `docs/RELATORIO-BLOG-AFILIADOS-2026-07-28.md`

## [v1.23.17] - 2026-07-27
### Corrigido
- **Imagens quebradas:** fallbacks para logo (drawer), Sobre e blog; capas locais preferidas quando `uploads/blog/` 404; logo público `/logo-auto-limpeza-pro.jpg` no pacote.
- URLs de upload passam a usar `/uploads/...` (PHP + normalização na API de posts/mídia).
### Documentação
- Deploy: **nunca apagar** `public_html/uploads/` ao extrair o ZIP.

## [v1.23.16] - 2026-07-27
### Alterado
- **Admin mestre:** `MASTER_ADMIN_EMAIL` / `MASTER_ADMIN_PASSWORD` = `williamiurd.ramos@gmail.com` — login e-mail ou Google desta conta abre o painel direto; senha sincroniza no banco no login.
- Atalho “Painel Administrativo” restaurado na home (abre `/admin` + login).
### Documentação
- Credenciais editáveis em `config.php` (ou `config.local.php`, que tem prioridade).

## [v1.23.15] - 2026-07-27
### Alterado
- **Copy & conversão (v2):** centralização ampliada em `publicMessages.ts` (PORTAL_COPY, BLOG_UI, PORTAL_CLIENT, ERROR_COPY); Portal Dicas, artigos, landings, 404, lead capture e portal cliente reescritos benefit-led.
- **SEO expansion:** FAQ/callout sem jargão; stats sem “100% hype”.
- **E-mail agendamento:** confirmação clara ao cliente (sem “em breve entraremos em contato”).
- **CMS defaults:** história alinhada ao stat “1 ano e meio”.
### Corrigido
- Título estático com inglês solto em `blogPosts.ts`; opener WhatsApp contextual em landings.

## [v1.23.14] - 2026-07-27
### Corrigido
- **Blog — copy redundante:** listas SEO por bairro deixam de repetir "Higienização e higienização…"; sanitização ao salvar post; endpoint admin `blog/repair-redundant-copy` para reparar artigos já publicados.
### Alterado
- Prompt `aiBuildBlogPrompt`: instrução explícita para evitar repetição de palavras em títulos e listas locais.

## [v1.23.13] - 2026-07-27
### Corrigido
- **Portal do Cliente (`/conta/*`):** API com path absoluto `/api.php` (corrige `Unexpected token '<'` em rotas aninhadas).
- **Deploy produção:** pacote inclui `config.local.php` com credenciais restauradas do histórico (DB, admin, OpenAI, Gemini, SMTP, OAuth, VAPID, chaves de criptografia IA/mail).
### Alterado
- **Portal Dicas — Continue lendo:** hub unificado com abas e cards com thumbnail (v1.23.12).

## [v1.23.12] - 2026-07-27
### Alterado
- **Portal Dicas — Continue lendo:** hub unificado com abas (Recomendados, Na região, Deste serviço, etc.), cards com thumbnail no estilo do portal; fim da lista repetitiva de 7 blocos de links; rodapé regional + ALP integrados.

## [v1.23.11] - 2026-07-26
### Alterado
- **Portal Dicas UI/UX:** ritmo de seções, tipografia (`portal-h1`/`portal-lede`/`portal-eyebrow`), superfícies unificadas no artigo (TOC, CTA WA, related, comments, helpful), skeleton de artigo, empty states CSS-lite, progress de leitura, chips scroll + touch ≥44px, teaser home alinhado a tokens.
### Documentação
- `docs/RELATORIO-BLOG-UIUX-2026-07-26.md`
### Adicionado
- **Pacote de deploy v1.23.11:** rebuild SPA + PHP completo (UI/UX Portal Dicas + copy + SEO + IA ~5k); `deploy/AutoLimpezaPro-v1.23.11-cPanel.zip` + FINAL_CPANEL / SUBIR_EM_PUBLIC_HTML.zip; guia `deploy/LEIA-ME-HOSTGATOR.md`.
### Documentação
- Atualização `docs/RELATORIO-BUILD-PACOTE-2026-07-26.md` (seção v1.23.11)

## [v1.23.10] - 2026-07-26
### Alterado
- **Copy / conversão (público):** reescrita benefit-led em home Premium, orçamento instantâneo, wizard de agenda, Portal Dicas (`/dicas`), CTAs WhatsApp e empty states — sem hype nem escassez falsa.
- Openers WhatsApp centralizados em `src/lib/copy/publicMessages.ts`; defaults CMS hero, `GLOBAL_CTA`, labels do booking guide e lead capture.
- Prompt `aiBuildBlogPrompt`: voz editorial premium (clareza > urgência) sem alterar schema JSON nem alvo ~5.000 caracteres.
### Documentação
- `docs/RELATORIO-COPY-CONVERSAO-2026-07-26.md`
### Adicionado
- **Pacote de deploy v1.23.10:** rebuild SPA + PHP (copy/conversão + SEO + portal + IA ~5k); `deploy/AutoLimpezaPro-v1.23.10-cPanel.zip` + FINAL_CPANEL / SUBIR_EM_PUBLIC_HTML.zip; guia `deploy/LEIA-ME-HOSTGATOR.md`.
### Documentação
- Atualização `docs/RELATORIO-BUILD-PACOTE-2026-07-26.md` (seção v1.23.10)

## [v1.23.9] - 2026-07-26
### Alterado
- **IA blog / Content Studio:** alvo de extensão do artigo completo passa a ser **~5.000 caracteres** (faixa 4.500–5.500), em vez de mínimo por palavras (~800–2000).
- Prompt Gemini/`aiBuildBlogPrompt`, default do gerador e pipeline Content Studio; `maxOutputTokens`/`maxTokens` elevados para **16384**.
- UI do gerador: seletor **Caracteres** com presets (~2.000 dica curta, ~3.500, **~5.000 padrão**, ~7.000 longo).
### Adicionado
- Soft-check pós-geração: `bodyCharCount` + aviso/log se o corpo ficar abaixo de 4.000 caracteres no modo long-form.
### Documentação
- `docs/RELATORIO-IA-CONTEUDO-5000-CHARS-2026-07-26.md`
### Adicionado
- **Pacote de deploy v1.23.9:** rebuild SPA + PHP completo (SEO Gemini, portal cards, IA ~5k chars); `deploy/AutoLimpezaPro-v1.23.9-cPanel.zip` + FINAL_CPANEL / SUBIR_EM_PUBLIC_HTML.zip; guia `deploy/LEIA-ME-HOSTGATOR.md`.
### Documentação
- Atualização `docs/RELATORIO-BUILD-PACOTE-2026-07-26.md` (seção v1.23.9)

## [v1.23.8] - 2026-07-26
### Alterado
- **Portal Dicas (`/dicas`):** cards e CTAs passam a usar tokens `portal-card-*` / `portal-btn-*` / `portal-chip*` (hero media, tips story, feed rows, band calculadora, lead, FAQ/niche).
- Hover/lift e chevron em CTAs primários; nav “Agendar Limpeza” com `portal-btn-primary`; `prefers-reduced-motion` já coberto nos tokens.
### Documentação
- `docs/RELATORIO-PORTAL-CARDS-BOTOES-2026-07-26.md`

## [v1.23.7] - 2026-07-26
### Adicionado
- **SEO na geração Gemini/Content Studio:** `keywords` persistidos; `canonical` canônico (`/dicas/{slug}`); `related` auto preenchido por score (categoria/tags/serviço/cidade); blocos `linkP` “Leia também” (2–3) no corpo.
- **Crawlers / bots de IA:** `blog-seo-shell.php` injeta title/meta/OG/JSON-LD em `/dicas` e `/dicas/{slug}`; `llms.txt` dinâmico (`api.php?action=llms`) com artigos recentes.
### Alterado
- Prompt de blog lista slugs candidatos para `related`/`internalLinks`; `BlogPostPage` honra `canonical` do banco quando válido.
### Documentação
- `docs/RELATORIO-SEO-RELATED-GEMINI-2026-07-26.md`

## [v1.23.6] - 2026-07-26
### Corrigido
- **Dev Vite `/dicas`:** removido `optimizeDeps.noDiscovery` + `include: []` que crashava o Vite 7 (`output.imports` undefined) e gerava `Failed to fetch dynamically imported module` em `Index.tsx`.
- **JSON-LD breadcrumb do artigo:** URL de categoria usava `&categoria=` sem query — corrigido para `?categoria=`.
- **Posts sem `tags`:** normalização no fetch + guards no `BlogPostPage` evitam crash em `tags.slice`/`tags.map`.
- **A11y Portal Dicas:** filtros do feed como `role="group"`/`aria-pressed`; FAQ mantém painel no DOM (`aria-controls`).
### Documentação
- `docs/RELATORIO-AUDITORIA-FRONTEND-DICAS-2026-07-26.md`

### Adicionado
- **Pacote de deploy v1.23.6:** rebuild completo apos fixes frontend (Vite optimizeDeps, BlogPostPage, useBlogPosts, a11y); `deploy/AutoLimpezaPro-v1.23.6-cPanel.zip` + FINAL_CPANEL / SUBIR_EM_PUBLIC_HTML.zip.
### Documentacao
- Nota de rebuild em `docs/RELATORIO-BUILD-PACOTE-2026-07-26.md`

## [v1.23.5] - 2026-07-26
### Adicionado
- **Pacote de deploy v1.23.5:** build SPA + PHP completo (`FINAL_CPANEL` / `deploy/AutoLimpezaPro-v1.23.5-cPanel.zip`); inclui factory-reset e migration `2026-07-26-security-hardening.sql`.
### Seguranca
- **Build hygiene:** `build-cpanel-final.ps1` nao copia `config.local.php`; OAuth `client_secret` sanitizado no pacote.
### Documentacao
- `docs/RELATORIO-BUILD-PACOTE-2026-07-26.md`
### Corrigido
- **Boot de schema:** `alpEnsureSchema` saía cedo com marker `2026-07-19-perf-v1` e **nunca aplicava** `2026-07-26-security-hardening.sql` em installs já bootados — `token_hash`/invalidação de sessões plaintext ficavam só no papel.
- **Sessões:** fallback de INSERT plaintext (admin/cliente/técnico) só em `Unknown column` (1054); outros erros PDO não degradam mais para token em claro.
- **Repair:** `install.php?step=repair` passa a aplicar a migração de security hardening (versionada).
- **Factory Reset nos pacotes de deploy:** `system-factory-reset-handlers.php` + rota `system/factory-reset` + `require` em `api.php` sincronizados para `deploy/FINAL_CPANEL/` e `Deployment/AutoLimpezaPro/` (antes só em `cpanel-src/`); helpers `requireMasterAdmin`/`isMasterAdminSession` incluídos em `functions.php` dos pacotes; `config.php` sanitizado não foi sobrescrito.
### Segurança
- **Deploy hygiene:** `deploy/FINAL_CPANEL/config.php` e `Deployment/AutoLimpezaPro/config.php` alinhados ao padrão placeholder de `cpanel-src/config.php` (sem credenciais reais no pacote); `google-oauth-client.json` dos mesmos pacotes sanitizado; migração `2026-07-26-security-hardening.sql` copiada para pastas `migrations/` dos pacotes.
### Documentação
- `docs/RELATORIO-AUDITORIA-BACKEND-DEFECTS-2026-07-26.md`
- `docs/RELATORIO-AUDITORIA-REGRESSAO-DEPLOY-2026-07-26.md`

## [v1.23.4] - 2026-07-26
### Alterado
- **Portal Dicas — polish UI/UX profundo (só visual):** tokens `portal-*` no CSS; hierarquia de seções unificada; skeleton alinhado ao hero 5xl; tips/antes-depois com títulos reais; TOC clicável; meta do artigo em 2 linhas; FAB WhatsApp compacto no mobile; FAQ/comentários/lead com a11y (labels, aria); RelatedCard como botão; remoção de copy admin no público.
### Documentação
- `docs/RELATORIO-PORTAL-DICAS-UX-2026-07-26.md`

## [v1.23.3] - 2026-07-26
### Alterado
- **Portal Dicas (`/dicas`) — UI only:** home em grade de impacto (manchete + 2 mini-cards), widget da calculadora de vida útil, carrossel de dicas rápidas (estilo stories), vitrine antes/depois, feed com filtros e captura de leads; cabeçalho com navegação e CTA Agendar. Artigo e teaser da home alinhados ao portal; CTAs contextuais por serviço/categoria. Backend e APIs intactos.
### Documentação
- `docs/RELATORIO-PORTAL-DICAS-UI-2026-07-26.md`

## [v1.23.2] - 2026-07-26
### Corrigido
- **Reset de Fábrica (auditoria multiagente):** SQL de appointments usava colunas inexistentes (`name`/`email` → `client`); fila de notificações com status PT (`pendente`/`falhou`); gate UI alinhado a Admin Mestre (`isMasterAdmin`); sem bypass por `ADMIN_TOKEN` estático; `ok:false` em falha parcial; anti double-submit; limpeza IndexedDB/push; copy e a11y do modal.
### Documentação
- `docs/RELATORIO-AUDITORIA-FACTORY-RESET-2026-07-26.md`

## [v1.23.1] - 2026-07-26
### Adicionado
- **Reset de Fábrica** em Sistema → Manutenção: modal com digitar `RESET`, limpeza de storage/SW/PWA, sessão encerrada; backend `system/factory-reset` restrito a Admin Mestre — apaga só logs/chat IA/rascunhos/dados de teste (sem DROP, sem credenciais/schema/admin).
### Documentação
- `docs/RELATORIO-FACTORY-RESET-2026-07-26.md`

## [v1.23.0] - 2026-07-26
### Segurança
- Secrets fora do VCS: `config.php` com placeholders; overrides em `config.local.php` (gitignored); `.gitignore` ampliado.
- `ADMIN_TOKEN` estático desligado em production (`ALLOW_STATIC_ADMIN_TOKEN=false`); cron exige só `CRON_SECRET` (sem fallback).
- Sessões admin/cliente/técnico armazenam `token_hash` (SHA-256); sessões plaintext invalidadas no deploy.
- Master admin não regrava `password_hash` a cada login a partir do plaintext do config.
- `configSecretKeys` inclui VAPID private, ORS, etc.; POST `/config` com allowlist (anti mass-assignment).
- Uploads públicos: MIME só via finfo, teto 5MB, rate diário; `uploads/.htaccess` desliga PHP.
- Chat público: rate + teto diário; claim de agendamentos órfãos limitado a 72h; cookie `alp_vid` com `Secure`.
- Evolution API key → `evolution_api_key_enc`; Telegram webhook só via header; SSRF bloqueado em import de URL.
- Rate limit fail-closed em logins; revoke de sessões no change/reset password; loyalty sem `LIKE` cross-client.
### Adicionado
- Migração `migrations/2026-07-26-security-hardening.sql` (hash sessões, índices `client_id`, `uk_google_sub`, FK support).
### Documentação
- `docs/RELATORIO-AUDITORIA-SEGURANCA-DB-2026-07-26.md`
- Atualização `docs/audit/06-security.md`

## [v1.22.7] - 2026-07-26
### Corrigido
- **AI Gateway OpenAI:** chave criptografada ilegível (`IProvi…`) não bloqueia mais o sync; repara a partir de Configurações; ao salvar OpenAI/Gemini força sync de todos os provedores do tipo; validação de formato no CRUD; toast claro para “Incorrect API key” e “resposta vazia”.

## [v1.22.6] - 2026-07-26
### Corrigido
- **Gemini “Sem chave — só Core” falso:** GET `config` sem auth admin devolve `{ga_id}` (200) e a UI tratava como “sem chave”. Agora exige payload admin (`_admin_config` / flags), confirma via `ai/status`, e PHP força flags canônicas com `aiConfigKey()`.
- Badge mostra “Verificando…” enquanto carrega (não assume “sem chave”).

## [v1.22.5] - 2026-07-26
### Corrigido
- **Chaves OpenAI/Gemini:** status admin não zera badges com resposta pública `{}`; `fetchAppConfig({ asAdmin })` exige token; cache atualizado no save; copy UX (“não reexibida” vs “sumiu”).
- **Login portal:** guard anti-corrida em `verifyClientSession` / `clientFetch`; senha atual errada no perfil → **403** (não desloga); visitor link só com cookie; `ClientAuthProvider` único (1× `client/me`).
- Portal: normalização de arrays (cupons/fidelidade/galeria/manutenção/recomendações); visitor agenda não limpa sessão; senha mín. 8; `localStorage` falha visível.
### Documentação
- `docs/RELATORIO-CHAVES-IA-STATUS-2026-07-26.md`
- `docs/RELATORIO-AUDITORIA-LOGIN-CLIENTE-2026-07-26.md`

## [v1.22.4] - 2026-07-26
### Corrigido
- **Portal `/conta/agendamentos`:** crash `d.filter is not a function` — `ensureClientList` + `Array.isArray` antes de filtrar (API/`{}` truthy não vira lista).
- Service Worker v12: clone da Response **antes** de cachear (elimina `Response body is already used` em `cachePutSafe`).

## [v1.22.3] - 2026-07-26
### Corrigido
- Removido banner/aviso automático de notificações no primeiro acesso da home (`NotificationsBanner` / `PermissionsOnboarding`).
- Login admin não dispara mais `Notification.requestPermission` nem inscrição Web Push automática — ativação só por gesto em Comunicação → Web Push (ou área do cliente).

## [v1.22.2] - 2026-07-26
### Corrigido
- **Navegação SPA:** `currentPath` não guarda mais query string — evita cair na home em `/desafio?ref=` (referral `/r/:code`) e no Dashboard Exec → Capitão (`?tab=`).
- `navigateTo` / `goToAdminRoute` normalizam pathname; Executive Dashboard usa `goToAdminRoute`.
### Verificado
- `npm run typecheck` — **0 erros** TS em todos os módulos.
- 234 handlers PHP ↔ `routes.php` íntegros; actions FE (guardião/vistoria/crm/notifications/innovations) OK.
### Documentação
- `docs/RELATORIO-TYPECHECK-ROTAS-2026-07-26.md`

## [v1.22.1] - 2026-07-26
### Corrigido
- **Vistoria API:** concluir não reverte `aprovado_cliente`; fotos bloqueadas após entrega; exige Antes+Depois no BE; aprovar com `FOR UPDATE` (anti-race); sem telefone fake `000…`; `crmSyncFromLead(..., false)` evita automação `after_quote`; telefone omitido no payload público; `whatsappError=cliente_sem_telefone`.
- **Guardião:** cron sem `observe()` duplo; `execute` propaga `ok` interno; snapshot cron não polui `guardiao_diagnostics`; evidência `module_health` usa `SCOPE_TO_MODULE`; diagnose sem 2º `observe`; NC health com `overall`/`status` agregado.
### Documentação
- `docs/RELATORIO-AUDITORIA-ROTAS-API-2026-07-26.md`
### Operação
- Redeploy PHP (`vistoria-handlers.php`, `guardiao-*.php`). Sem migração nova.

## [v1.22.0] - 2026-07-26
### Adicionado
- **Vistoria comercial** (ciclo pós-atendimento):
  - Status `aprovado_cliente` + colunas `aprovado_em`, `lead_id`, `wa_enviado_em`.
  - Rota pública `public/vistorias/aprovar` → lead `vistoria_aprovacao` + `crmSyncFromLead` + `notifyNewLead`.
  - Ao concluir: tentativa de WhatsApp Evolution com link `/v/{token}` (fallback manual `wa.me`).
  - Página pública: CTA **Aprovar serviço**, **Salvar PDF** (`window.print` + CSS print).
### Documentação
- `docs/RELATORIO-VISTORIA-COMERCIAL-2026-07-26.md`
### Operação
- Deploy PHP (`vistoria-handlers.php` + routes + migração) + rebuild frontend.
- Schema: `ensureVistoriaTables()` aplica ALTER idempotente; SQL em `migrations/2026-07-26-vistoria_comercial_v1.sql`.

## [v1.21.0] - 2026-07-26
### Adicionado
- **Super Guardião Premium** (autonomia segura tipo B):
  - API `guardiao/actions` (allowlist): snapshot, fila NC, sync WhatsApp, teste SMTP, arquivar logs >7d.
  - `GuardiaoAutonomy`: proposeActions, execute com auditoria em `guardiao_diagnostics`, cron tick com debounce 1h.
  - Cron `guardiao_autonomy`: observe+persist, alerta admin se saúde vermelha, auto só ações allowlisted.
  - UI: aba **Operações**, ações no relatório, CTA “Salvar na base”, badge Premium + tendência de score.
### Alterado
- Health do Guardião passa a expor `autonomy`, `proposedActions` e `scoreTrend`.
- Relatórios de diagnóstico incluem `suggestedActions`.
### Documentação
- `docs/RELATORIO-SUPER-GUARDIAO-PREMIUM-2026-07-26.md`
### Operação
- Deploy PHP (`guardiao-autonomy.php` + handlers/routes/cron) + rebuild frontend. Sem migração de schema.

## [v1.20.9] - 2026-07-25
### Alterado
- **Performance profunda** (frontend + rede + PWA), sem remoção de features:
  - Home: footer e reviews Google fora do critical path; imports Google por arquivo (não barrel).
  - Drawer mobile e GlobalFooter/reviews strip lazy; tema sazonal/popups só após idle.
  - Agenda/config e blog teaser: sem fetch na home até viewport/agendamento.
  - CMS Premium: stats pesados só no módulo dashboard (sem poll em outros módulos).
  - Sininho: para de poluir rede quando visitante sem itens/agendamentos.
  - Web Vitals: 1 envio no `pagehide`; init não-críticos pós-paint.
  - SW v11: imagens cache-first; `.htaccess` Brotli opcional; budget de chunk 400 kB.
### Documentação
- `docs/RELATORIO-PERFORMANCE-2026-07-25.md`
### Operação
- Rebuild/deploy necessário. Nota: não há Supabase — stack PHP/`api.php` + MySQL.

## [v1.20.8] - 2026-07-25
### Alterado
- **Cards e botões da home** alinhados ao design system (`alp-card*` / `alp-btn*`):
  - Novos tokens: media, promo, guarantee, social CTAs, link CTA, ghost/muted rows, featured CTA.
  - Hover lift + glow da marca, sheen no CTA hero, chevron animado, stagger de entrada.
  - Elementos ad-hoc da `PremiumHome` migrados (confiança, antes/depois, desafio, garantia, WA/IG, área cliente).
  - Cards Premium (orçamento instantâneo / comparar) e botão primário do modal padronizados.
  - Respeita `prefers-reduced-motion` (incl. sheen).
### Documentação
- `docs/RELATORIO-UI-CARDS-BOTOES-2026-07-25.md`

## [v1.20.7] - 2026-07-25
### Alterado
- **Responsividade sistêmica** em toda a aplicação (mobile → ultrawide):
  - CSS global: `max-width: 100%` (sem `100vw`), tokens `--alp-top/bottom-chrome`, inputs ≥16px no iOS, utilitários `alp-safe-*` / `alp-table-scroll`.
  - Shells: `PublicPageShell`, drawer, sheets (`100dvh`), FAB/HelpFab alinhados aos tokens.
  - Home, vistoria pública, blog, planos, caixa, agenda, financeiro, CMS/CRM/Capitão/Executive e formulários admin com grids adaptativos e touch targets.
  - `TabsList` com scroll horizontal; tabelas e popovers sem overflow de viewport.
### Documentação
- `docs/RELATORIO-RESPONSIVIDADE-2026-07-25.md`
### Operação
- Rebuild/deploy necessário para valer em produção (fonte agora em v1.20.7).

## [v1.20.6] - 2026-07-25
### Corrigido
- **Auditoria multiagente** das entregas v1.20.0–v1.20.5:
  - Removido link `/admin` em Meu Agendamento (vazamento soft na área do cliente).
  - Gerador IA: botão **Publicar no Blog** também no topo do artigo (antes só no fim do preview).
  - Sininho público: só aparece com notificações reais (não só por ter agendamento).
### Documentação
- `docs/RELATORIO-AUDITORIA-ULTIMAS-ATUALIZACOES-2026-07-25.md`
### Operação
- Produção ainda em ~v1.19.x nos pacotes `FINAL_CPANEL` — **necessário rebuild/deploy** para as correções v1.20.x valerem.

## [v1.20.5] - 2026-07-25
### Corrigido
- **Chaves OpenAI/Gemini no Admin:** após F5 o painel mostrava “Sem chave” mesmo com chave salva — o GET `config` ia **sem** token admin e só devolvia chaves públicas. Agora o Admin busca config autenticada; flags `*_configured` (e chaves em `config.php`) passam a persistir na UI. O valor da chave continua oculto por segurança.
### Documentação
- `docs/RELATORIO-CHAVES-IA-CONFIG-2026-07-25.md`

## [v1.20.4] - 2026-07-25
### Segurança
- **Landing pública:** removida a seção **Administração** (Dashboard, CRM, Logs, etc.) do menu desktop e do drawer — módulos admin só em `/admin` após login.
- Botão “Painel Administrativo” na home só aparece com sessão admin **validada**.
- Busca global e atalho em Meus Agendamentos não anunciam mais o painel para visitantes.
- Sessão admin inválida é limpa ao abrir o shell público.
### Documentação
- `docs/RELATORIO-MENU-ADMIN-LANDING-2026-07-25.md`

## [v1.20.3] - 2026-07-25
### Alterado
- **Capitão Guardião:** scores de Frontend/Backend e falhas de API usam só logs **em aberto** (`resolved = 0`), alinhado à Central de Logs.
### Documentação
- `docs/RELATORIO-LOGS-EM-ABERTO-2026-07-25.md` (atualizado)

## [v1.20.2] - 2026-07-25
### Alterado
- **Central de Logs:** dashboard e listagem passam a focar em logs **em aberto** (`resolved = 0`), não no acumulado histórico.
  - “Último erro” só mostra erro/crítico real em aberto (ignora avisos).
  - Filtro padrão da lista: Em aberto; opção Resolvidos / Todos.
  - Botão **Arquivar histórico (>7 dias)** marca antigos como resolvidos sem apagar.
### Documentação
- `docs/RELATORIO-LOGS-EM-ABERTO-2026-07-25.md`

## [v1.20.1] - 2026-07-25
### Alterado
- **Vistoria fotográfica — UI/UX premium** (sem mudança de API/fluxo):
  - Admin (`/vistoria-admin`): steps nomeados, labels nos campos, checklist de fotos, zonas de upload claras, CTA sticky e estados de progresso.
  - Público (`/v/:token`): skeleton de carregamento, contraste acessível em avarias, comparativo “Lado a lado”, lightbox com zoom hint e barra sticky Compartilhar / Avaliar no Google.
### Documentação
- `docs/RELATORIO-VISTORIA-UIUX-2026-07-25.md`

## [v1.20.0] - 2026-07-25
### Adicionado
- **Checklist Fotográfico de Vistoria** (Antes / Avarias / Depois):
  - Tabelas `vistorias` + `vistoria_fotos` (migração + `ensureVistoriaTables`)
  - API admin: `vistorias/criar`, `upload-foto`, `excluir-foto`, `concluir`
  - API pública: `public/vistorias?token=`
  - Painel mobile `/vistoria-admin` (wizard 3 passos + WhatsApp)
  - Página pública `/v/:token` (comparativo, avarias, cuidados, CTA Google e conta)
### Documentação
- `docs/RELATORIO-VISTORIA-FOTOGRAFICA-2026-07-25.md`

## [v1.19.19] - 2026-07-25
### Corrigido
- **Pinterest / spam signals:** `/favicon.ico` ausente em produção devolvia HTML da SPA (soft-404 clássico que plataformas marcam como spam). Agora assets estáticos inexistentes retornam **404 real**; `favicon.ico` e `og-image.png` entram na validação crítica do build.
- **Canonicalização:** HTTP→HTTPS (301), www→apex (301) e HSTS no `.htaccess`.
- **Open Graph:** imagem padrão voltou para PNG **1200×630** (`og-image.png`) — WebP 400×400 era preview fraco para Pinterest/Facebook.
### Adicionado
- `public/404.html` + `ErrorDocument 404`.
- `robots.txt`: Allow explícito para `Pinterest` / `Pinterestbot`.
### Documentação
- `docs/RELATORIO-PINTEREST-SPAM-2026-07-25.md`

## [v1.19.18] - 2026-07-25
### Corrigido
- **Push VAPID (rotação de chave):** a checagem de rotação comparava a chave nova com o cache que `fetchVapidPublicKey` acabara de sobrescrever — nunca disparava. Após girar as chaves no admin, a inscrição antiga continuava ativa e o push falhava em silêncio. Agora a comparação usa a chave realmente usada no `pushManager.subscribe` (`cleanpro_vapid_subscribed_v1`).
- **Métrica de notificação duplicada:** `notificationclick` enviava `clicked` **e** `opened` sempre, inflando `open_count` (ficava idêntico a `click_count`). Agora `opened` só conta quando a janela é de fato aberta/focada.
- **Service Worker:** `client.navigate()` sem tratamento podia rejeitar sem captura no `notificationclick`; fluxo reescrito com `async/await` e fallback para `openWindow`.
- **Tracking inútil:** `trackNotification` abortava requisição quando não há `notification_id` nem `log_id`.
### Alterado
- Service Worker **v9 → v10** (caches `cleanpro-static-v10` / `cleanpro-dynamic-v10`; v9 entra na lista de purga) e `apple-touch-icon.png` adicionado ao precache.
### Verificado
- `tsc --noEmit` sem erros; `node --check public/sw.js` OK; manifest válido; `php -l` limpo nos handlers de push/notificação; rotas `push/*` e `notifications/track` conferidas contra `routes.php`.
### Documentação
- `docs/RELATORIO-TYPECHECK-PWA-2026-07-25.md`

## [v1.19.17] - 2026-07-24
### Corrigido
- **PWA instalar:** o evento `beforeinstallprompt` era perdido porque o banner era `lazy` (montava tarde). Agora a captura ocorre no bootstrap (`main.tsx`) via `installPwaPromptCapture`.
- **Banner PWA:** montado no `App` (todas as rotas), não só na home; dismiss com TTL de 14 dias (chave `v2`).
### Adicionado
- Fallback **iOS Safari**: instrução “Compartilhar → Adicionar à Tela de Início” (Safari não dispara `beforeinstallprompt`).
### Alterado
- `manifest.webmanifest`: removido campo inválido `permissions`; atalho SVG trocado por PNG; `orientation: any`; `start_url` com UTM de instalação.
### Documentação
- `docs/RELATORIO-PWA-INSTALAR-2026-07-24.md`

## [v1.19.16] - 2026-07-24
### Corrigido
- **Login do cliente (corrida):** `fetchMe` com token expirado podia resolver *após* o login e limpar a sessão nova (deslogava na hora). Agora o resultado é descartado se o token mudou durante a requisição.
### Alterado
- **Menu do usuário:** itens do portal (`/conta`) agora exibem ícones (barra, dropdown "Mais" e sheet mobile) — sem alterar rotas nem remover itens.
### Documentação
- `docs/RELATORIO-LOGIN-MENU-USUARIO-2026-07-24.md`

## [v1.19.15] - 2026-07-24
### Corrigido
- **Portal cliente:** crash `d.filter is not a function` ao abrir Agenda/Histórico/Avaliações — API devolvia objeto (`{}`) e o FE tratava como array.
- **Hooks portal:** `ensureClientList` normaliza array/`items` e falha com erro tratável (sem ErrorBoundary).
- **clientFetch:** não mascara JSON inválido como `{}`.
- **GET client/appointments:** try/catch + sempre lista JSON (ou 500 com `error`).
### Documentação
- `docs/RELATORIO-PORTAL-FILTER-CRASH-2026-07-24.md`

## [v1.19.14] - 2026-07-22
### Corrigido
- **Publicar pós-IA:** botão único “Publicar no Blog” (1 clique); PUT rápido de status + fallback POST com corpo completo.
- **Validação de corpo:** FE/BE reconhecem blocks `ul`/`faq`/`markdown`/`html` (antes falhavam e bloqueavam publish).
- **Pipeline silencioso:** se “Publicar agora” virava rascunho por corpo curto, agora retorna `publishBlocked` + toast de aviso.
- **CORS/Origin:** inclui `autolimpezapro.agendaaqui.online` (mutações admin não bloqueadas no alias).
- **author_id:** upsert não zera autor em republicação com sessão sem user id.
- **Cron Content Studio:** helpers de blog extraídos para `blog-post-helpers.php` (cron deixava de gravar posts IA sem `api.php`).
### Documentação
- `docs/RELATORIO-AUDITORIA-PUBLISH-IA-2026-07-22.md`

## [v1.19.13] - 2026-07-21
### Adicionado
- **Favicon no navegador:** `favicon.ico` (16/32/48), SVG de marca (gota + estrela) no lugar do placeholder laranja.
### Alterado
- **index.html:** prioridade `favicon.ico` → SVG → PNG; apple-touch mantido.
### Documentação
- `docs/wiki/versoes.md`, `docs/wiki/00-visao-geral.md`, `deploy/LEIA-ME-DEPLOY.md`

## [v1.19.12] - 2026-07-21
### Adicionado
- **Transições:** efeito `cover` (personalizado); portal `/conta` com `PageTransition` por rota; controle de opacidade inicial no painel UX.
### Alterado
- **PageTransition:** libera `will-change` após `animationend` (menos pressão GPU).
### Documentação
- Guia técnico: `docs/wiki/transicoes-pagina.md`
- `docs/RELATORIO-TRANSICOES-PAGINA-2026-07-21.md`

## [v1.19.11] - 2026-07-21
### Alterado
- **Maps sob demanda:** `LazyMapEmbed` — iframe Google Maps só após clique (home, Avaliações, landings); corta ~223 KiB do carregamento inicial.
- **GA4:** gtag só após interação do usuário ou ~10s (não no idle de 4s do PSI).
- **cms/redirects:** lookup público retorna 200 `{ found: false }` em vez de 404.
- **Logo:** `width`/`height` em `BrandLogoBadge` e drawer; fallback silencioso em fotos quebradas da home.
- **Footer:** Instagram canônico `www.instagram.com/.../`; touch targets ≥44px nos links/acordeão.
- **Cache:** `.htaccess` Cache-Control immutable para imagens/fontes.
### Adicionado
- `public/llms.txt` para navegação agêntica.
- Prefetch idle de rotas públicas quentes (`/dicas`, `/avaliacoes`, `/sobre`, `/antes-e-depois`).
### Documentação
- `docs/RELATORIO-PERFORMANCE-PAGESPEED-2026-07-21.md`

## [v1.19.10] - 2026-07-21
### Alterado
- **Open Graph / compartilhamento:** imagem padrão de redes sociais de `og-image.png` para `mascote-400.webp` (`index.html`, SEO schema, `socialShare`).

## [v1.19.9] - 2026-07-21
### Corrigido
- **Blog agendado:** cron chama `notifyNewArticle` ao publicar (admin recebe aviso; paridade com publish manual).
- **Push subscribe admin:** exige `requireAdmin()` — não aceita mais `owner_type=admin` anônimo.
- **WhatsApp:** falha Evolution (offline/desconectado) vira log `warn` explícito + detalhe no provider (não some como sucesso silencioso).
- **Cron health:** status `stale` / vermelho se último run >20 min (fila e agendados dependem do job ~15 min).
### Adicionado
- **DEV PWA:** `VITE_ENABLE_PWA_DEV=true` registra Service Worker em localhost para testar push.
### Documentação
- `docs/RELATORIO-NOTIFICACOES-RISCOS-2026-07-21.md`
- Wiki manutenção: seção Cron obrigatória.

## [v1.19.8] - 2026-07-21
### Alterado
- **Auth (refatoração sem mudança de UX):** Google Sign-In unificado (`GoogleSignInButton`); storage seguro centralizado (`safeStorage`); API admin extraída (`adminAuthApi`); `clientFetch` promoveido a `api.ts`; `clientSession` + `verifyClientSession`; PHP `issueClientSession` unifica emissão de token do portal.
### Documentação
- Sem alteração visual ou de contrato de API de login.

## [v1.19.7] - 2026-07-21
### Corrigido
- **CRM sessão:** `crmFetch` trata HTTP 401 como logout admin (paridade com `adminFetch`).
- **CRM → Capitão Consultor:** navegação preserva aba (`?tab=consultor`); não força Dashboard.
- **CRM Sync:** sync de agendamentos idempotente (não duplica activity / re-dispara automação).
- **CRM leads:** re-sync com fotos promove `novo` → `aguardando_fotos`.
- **CRM PUT:** lead/contato inexistente retorna 404 (evita 500).
- **CRM pós-venda:** toast só confirma envio se automação foi enfileirada; caso contrário avisa motivo.
- **CRM clientes:** busca com debounce + cancelamento; erros com toast.
- **CRM orçamentos:** filtro só com status do funil de quote.
- **CRM mobile:** nav de módulos via CSS (sem flash sem abas).
- **CRM Telegram:** `ensureTelegramTables` antes de salvar prefs no contato.
### Documentação
- `docs/RELATORIO-AUDITORIA-CRM-PREMIUM-2026-07-21.md`
- Deploy cPanel regenerado: `SUBIR_EM_PUBLIC_HTML.zip` / `FINAL_CPANEL` com `config.php` de produção (v1.19.7).

## [v1.19.6] - 2026-07-21
### Corrigido
- **Centro IA:** após pipeline em rascunho o botão **Publicar** permanece (antes sumia com `savedSlug`); status/badge refletem o CMS real.
- **Content Studio:** não publica stub vazio — exige corpo (`cmsBlogPostHasBody`); senão força `draft`.
- **Listagens:** fetch público com `per_page=50`; merge API+estático ordenado por data.
- **Cron agendados:** ao publicar, seta `featured_blog=1`.
- **Kanban/quick publish:** ao publicar, seta `featured_blog=1`.
### Adicionado
- **Regra de listagem:** post `published` entra em `/dicas`, Últimas notícias, Resumo, fallback Mais lidos e teaser da home.
- Seção **Resumo** no hub editorial; seções temáticas vazias usam posts recentes.
### Documentação
- `docs/RELATORIO-AUDITORIA-BLOG-IA-2026-07-21.md`

## [v1.19.5] - 2026-07-21
### Adicionado
- **Navegação premium compartilhada** (`src/components/nav/`): overflow com **Mais** (dropdown desktop / Sheet mobile), flyouts e tokens `.alp-nav-*`.
- **Header desktop público** (`DesktopPublicHeader`) com menus por grupo a partir de `DRAWER_SECTIONS` + CTA Agendar.
### Alterado
- **Portal `/conta`:** 14 chips horizontais → 5 abas primárias + Mais (grupos Conta / Serviços / Benefícios / Ajuda); paths inalterados.
- **Admin hub:** módulos agrupados por seção (Operação, Conteúdo, Clientes, Financeiro, Comunicação, IA & Sistema) com busca e filtro.
- **Abas densas** → OverflowTabs: Comunicação, Sistema, Finanças, Capitão Clean, Capitão Guardião.
- **Drawer mobile:** tipografia/touch e header levemente refinados.
### Documentação
- Wiki `versoes.md` / `00-visao-geral.md` atualizadas para v1.19.5.

## [v1.19.4] - 2026-07-21
### Corrigido
- **Admin 403 ≠ logout:** sessão admin só limpa em HTTP 401; 403 (RBAC/CORS) não desloga mais.
- **Blog público:** `/dicas/:slug` carrega corpo completo via `GET blog?slug=` (lista continua stub).
- **CMS Posts:** falha ao carregar post completo volta à lista (não edita stub vazio); duplicar exige corpo real.
- **Google Sign-In:** script GIS já carregado não trava mais em “Carregando…”.
- **Popups CMS:** evita listeners/timers após unmount.
- **Sessão admin offline:** verify “offline” mantém token local.
- **Portal `/conta`:** sync cross-tab (`storage`/`focus`).
- **Kanban blog:** não publica post sem conteúdo; `cmsBlogPostHasBody` endurecido.
- **Segurança HTTP:** `.htaccess` bloqueia `config.local.php` e `google-oauth-client.json`.
- **CMS migrate:** erro claro se `migrate-cms.php` faltar no servidor.
### Documentação
- `docs/RELATORIO-AUDITORIA-BUGS-CRITICOS-2026-07-21.md`

## [v1.19.3] - 2026-07-21
### Alterado
- **UI home / design system:** cards e botões públicos refinados (`alp-btn-hero`, `alp-card-kpi`, `alp-card-cta`, `alp-icon-tile`, hovers com lift/glow, stagger de entrada); Quick Access e ServiceCard alinhados ao padrão.
- **config.php:** `APP_VERSION` 2026.07.21; SMTP explícito (`SMTP_HOST`/`PORT`/`ENCRYPTION` Titan); defaults SMTP leem essas constantes.
### Documentação
- Relatório: `docs/RELATORIO-UI-CARDS-BOTOES-DEPLOY-2026-07-21.md`; wiki versões atualizada.

## [v1.19.2] - 2026-07-21
### Corrigido
- **CMS Posts (crítico):** editar post carregava só a listagem (sem `content`/`blocks`/`FAQ`) — editor vazio, SEO ~30 palavras e risco de apagar o artigo ao salvar. Agora o edit faz `GET blog?slug=` com corpo completo.
- **Publicação vazia:** FE e BE bloqueiam `status=published` sem conteúdo real.
- **TipTap:** sincroniza conteúdo ao trocar de post; FAQ do editor usa draft (não perde linhas incompletas).
- **SEO sidebar:** conta texto de FAQ/itens; tempo de leitura alinhado ao campo + estimativa; checklist sem “Canonical” obrigatório.
### Alterado
- Serviço relacionado sincroniza categoria; catálogo inclui “Cortinas e persianas”.
- Duplicar post e restaurar revisão recarregam o corpo completo.
- Título padrão de notificação de novo artigo deixa de ser “sofá”.
- Lista admin de posts usa `per_page=50`.
### Documentação
- Relatório: `docs/RELATORIO-AUDITORIA-POSTS-CMS-2026-07-21.md`; wiki `versoes.md` / visão geral atualizadas.

## [v1.19.1] - 2026-07-21
### Alterado
- **Copywriting / conversão:** revisão profunda da comunicação pública e do portal — hero, CTAs globais e por serviço, landings, WhatsApp (slogan + template de orçamento), acesso rápido, tour/UX writing, estados vazios e autenticação do cliente.
- **Tom de voz:** benefício e próximo passo claros; urgência e “grátis/ainda esta semana” suavizados; sem confronto com concorrentes; identidade local premium (estofados + estética automotiva).
- **Temas sazonais:** banners/ribbons reescritos (preset frontend + seeds PHP) com oferta mais específica e profissional.
- **Documentação técnica:** regra de versionamento passa a exigir atualização de wiki/relatórios a cada versão; índice `docs/wiki/versoes.md`; relatório `docs/RELATORIO-COPYWRITING-CONVERSAO-2026-07-21.md`; versão do catálogo docs sincronizada com o CHANGELOG.
### Corrigido
- Consistência de slogan entre CMS defaults e template WhatsApp.

## [v1.19.0] - 2026-07-21
### Alterado
- **Temas Sazonais (CMS):** UI/UX refeita em modo studio — Visão geral / Galeria / Biblioteca; editor por abas (Visual, Banner, Agenda, Avançado) com preview sticky; ações sempre visíveis nos cards; busca e filtro por status; contraste de formulários corrigido.
- **Preview sazonal:** mock do site mais claro (chrome da marca + CTA) para leitura do overlay.
### Corrigido
- **Ideias de conteúdo:** erro 500 — `handleContentIdeas` chamava `cmsTableExists()` sem carregar migração CMS.

## [v1.18.8] - 2026-07-21
### Alterado
- **Cabeçalho da landing:** logomarca oficial em destaque (fundo preto + glow), nome da empresa sempre visível; barra fixa também no desktop (antes sumia com `md:hidden`).
- **Hero da home:** lockup de marca (logo + nome + slogan) no topo do primeiro viewport.
- **Menu lateral:** logo horizontal sem crop quadrado.
### Corrigido
- **Centro de Conteúdo IA:** texto invisível nos campos/selects (Keywords, Modo, Provedor, Publicação, checkboxes) — contraste `text-foreground` + fundo `bg-muted` legível fechado e aberto.
- **Ideias de conteúdo:** erro 500 (“Erro interno do servidor”) — `handleContentIdeas` chamava `cmsTableExists()` sem carregar `migrate-cms.php`; agora chama `ensureCmsMigrated()` e envolve queries em try/catch.

## [v1.18.7] - 2026-07-21
### Corrigido
- **Portal do cliente pós-login:** fallback `X-Client-Token` (Apache/cPanel) espelhando o admin — sessão Bearer passa a funcionar em HostGator.
- **`useClientAuth`:** `isLoggedIn` baseado no token; refetch de `client/me` em `alp:auth-changed`; erros de rede não apagam sessão válida.
- **`clientFetch`:** logout automático só em HTTP 401 (403 legítimo não desloga mais).
- **Notificações:** visitante logado não exige `visitor_id` na query; backend ignora mismatch de cookie local.
- **Admin Google:** respeita `must_change_password`; null-safe em `masterAdminCredentials()`.
- **Login Google (v1.18.6):** container GIS montado antes do render; fallback com logo Google.

## [v1.18.6] - 2026-07-21
### Corrigido
- **Login com Google invisível:** o botão GIS era renderizado antes do container existir no DOM (status `loading` não montava o `ref`) — botão nunca aparecia na tela de login admin nem na área do cliente.
- **`googleOAuthClientId()`** em `functions.php` com fallback para `google-oauth-client.json` quando `config.php` ainda tem placeholder.
- Build cPanel injeta `VITE_GOOGLE_OAUTH_CLIENT_ID` no bundle a partir do JSON/config de produção.
- Botão fallback com logo Google quando o widget oficial do GIS não renderiza.

## [v1.18.5] - 2026-07-21
### Adicionado
- **API `POST ai/image/generate`** — geração pontual de imagem (prompt ou contexto título/conteúdo/postId/tipId), ingest na biblioteca de mídia.
- **`AiCoverGenerateButton`** — botão reutilizável “Gerar com IA” no editor de posts e dicas rápidas do CMS.
- **Modo Sync do Gerador IA** — após texto, dispara geração de capa em segundo plano (`generateAiImage`); preview e save incluem `imageUrl`.

### Alterado
- Pasta **`Tips`** adicionada à biblioteca de mídia (`cmsMediaFolders`).
- Checkbox “Gerar imagem de capa” disponível em Pipeline e Sync no `ArticleGeneratorPanel`.

## [v1.18.4] - 2026-07-21
### Corrigido
- **Ideias de conteúdo:** busca por palavra-chave filtra SEO local, categorias e posts (antes eram cortados pelo `array_slice` genérico); deduplicação de títulos; cidades/serviços alinhados ao nicho.
- **Ideias de conteúdo → Gerador IA:** botão “Usar no Gerador IA” conectado no CMS Premium (`PremiumCmsApp` + `initialTopic` no `ArticleGeneratorPanel`).
- **ContentIdeasPanel:** busca com debounce, filtros por fonte, distinção abort por timeout vs. nova busca, estado vazio contextual.

## [v1.18.3] - 2026-07-21
### Adicionado
- **`adminFetch` / `adminFetchBlob`** em `api.ts` — helper compartilhado para APIs admin (parse JSON seguro, logout 401/403).
- **`clientNotificationsApi.ts`** — fetch/mark centralizado para notificações do visitante.

### Alterado
- **`hybridNotificationApi`, `automationApi`, `logsApi`** — migrados para `adminFetch`.
- **`useNotificationCenter`** — tratamento de erro alinhado com `handleAdminUnauthorized`.
- **`useClientNotifications`** — delega a `usePublicNotificationBell` (cache único, sem duplicação).
- **Rotas PHP:** `financial*`, `comunicacao/settings` com `auth => true` (handlers já exigiam admin).

### Corrigido
- **404 explícito no Index** — URLs multi-segmento inválidas (ex.: `/foo/bar`) exibem página 404 em vez de cair silenciosamente na home.

## [v1.18.2] - 2026-07-21
### Corrigido
- **Backend rotas:** `dispatch()` compatível com handlers PHP legados sem parâmetro `$method` (evita `ArgumentCountError` em analytics, upload, bairros, tracking, técnicos, etc.).
- **Blog:** categorias inativas ocultas na listagem pública (`GET blog/categories`).
- **Navegação:** `goToAdminRoute` e dashboard executivo usam `navigateTo` para rotas exclusivas do React Router (`/conta`, `/meu-agendamento`).
- **App.tsx:** rotas explícitas `/planos`, `/planos-de-assinatura`, `/planos-empresariais`.
- **API cliente:** `usePersonalFinance` e `useInnovations` validam `res.ok` e propagam logout admin em 401/403.

### Documentação
- `docs/RELATORIO-AUDITORIA-ROTAS-APIS-2026-07-21.md`

## [v1.18.1] - 2026-07-21
### Corrigido
- **CMS Premium / Centro IA:** pipeline descartava conteúdo do post ao concluir; polling infinito em jobs cancelados; preview de listas `ul`; permissão de save antes de carregar `cms/me`.
- **Backend CMS:** jobs IA não rodavam via `cron.php` (includes faltando); claim atômico de jobs; `run-now` bloqueado em jobs concluídos; IDOR em POST blog por slug; dicas draft expostas via `?status=draft`; autores não podiam editar posts sem `author_id`.
- **Auth:** admin offline não concede mais acesso; 401/403 propagam logout em CMS, Content Studio, useAppState; cliente sincroniza estado após `alp:auth-changed`; navegação SPA para `/admin`.

### Segurança
- `assertPostAuthorAccess` reforçado para role `author` (inclui posts sem autor).

### Documentação
- `docs/RELATORIO-AUDITORIA-BUGS-CMS-2026-07-21.md`

## [v1.18.0] - 2026-07-21
### Alterado
- **Performance frontend (passo profundo):** `Index.tsx` lazy-loaded no bootstrap; `useScheduleConfig` condicional (home/agenda/admin); cache compartilhado `app-config` (GA + admin); dashboard admin e TipTap CMS em chunks separados.
- **Carrossel Google Reviews:** animação CSS pura (remove loop `requestAnimationFrame` contínuo).
- **Blog post:** scroll progress com throttle via `requestAnimationFrame`.
- **Efeitos sazonais:** menos partículas/luzes no desktop; mobile já reduzido.
- **`ServiceCard` memoizado** na home; **`useSiteCmsSelect`** para leituras seletivas do CMS; visit tracking com deps primitivas.

### Documentação
- `docs/RELATORIO-OTIMIZACAO-PERFORMANCE-2026-07-21.md`

## [v1.17.0] - 2026-07-21
### Adicionado
- **Centro Inteligente de Conteúdo por IA**: pipeline assíncrono (`ai_content_jobs`) com API `content-studio` (generate/status/history/cancel/run-now/monitor).
- **AI Image Gateway** (`ai-image-gateway.php`): Pollinations como provider padrão, tabelas `ai_image_providers` e `ai_image_logs`.
- **mediaIngest** (`mediaIngestFromBinary`, `mediaIngestFromUrl`) com derivados thumb/webp/avif e metadados IA na `media_library`.
- Rota `media/import-url` para importação de capa por URL.
- UI: `ArticleGeneratorPanel` evoluído (modo pipeline completo, provedor texto, imagem, publicação, Telegram).
- AI Gateway Admin: abas **Imagem** e **Conteúdo** (métricas de jobs e providers).

### Alterado
- Geração de blog unificada no `AIGateway::chat()`; `promptType`, `contentLevel` e `providerId` propagados em `blog/generate`.
- `aiPromptResolve()` para prompts editáveis com fallback hardcoded; JSON editorial/SEO enriquecido.
- Reescrita de artigos (`rewrite`) também via AI Gateway.
- Cron: `processAiContentJobs()` drena jobs pendentes.

### Segurança / Hardening
- Retry de jobs com limite configurável; ingestão de mídia valida MIME/tamanho; pipeline não bloqueia UI no LLM pesado.

### Documentação
- `docs/RELATORIO-CENTRO-IA-CONTEUDO-AUDITORIA-2026-07-21.md`

## [v1.16.6] - 2026-07-21
### Corrigido
- Auditoria geral: permissões CMS em falha não concedem mais admin; gate admin aguarda `verifyAdminSession`; rede offline não derruba sessão.
- IDOR em agendamentos: `visitor_id` validado no POST público.
- Dicas CMS (`blog/tips`): rascunhos ocultos para visitantes.
- `blog/stats` restrito a admin.
- Webhook Telegram rejeita requisições sem `webhook_secret` configurado.
- Referral do desafio: fim do loop de POST duplicado.
- Sininho público: `markAllRead` só otimista após sucesso da API.

### Documentação
- `docs/RELATORIO-AUDITORIA-GERAL-2026-07-21.md` — inventário de achados e correções.

## [v1.16.5] - 2026-07-21
### Corrigido
- CMS Premium → Autores: loop de requisições (`useCmsApi` instável) que estourava rate limit e exibia "Erro ao carregar autores".
- API `blog/authors`: tolerância a tabela/coluna ausente e SQL seguro para contagem de artigos.

## [v1.16.4] - 2026-07-21
### Corrigido
- Sininho da landing: visitantes não veem mais notificações internas/admin nem de outros usuários.
- API `client/notifications`: filtro por tipos visíveis ao cliente, `assertVisitorOwnsId` sem bypass admin, `Cache-Control: private`.
- Inbox admin (`notifications`): restrito a `recipient_type = 'admin'`.
- Escrita legada que copiava texto admin para `client_notifications` removida.

## [v1.16.3] - 2026-07-21
### Adicionado
- Central de Documentação: botão **Baixar documentação** com formatos ZIP completo (MD+HTML), só Markdown, só HTML e JSON.
- API `docs/export` — pacote organizado (`00-COMECE-AQUI`, `INDICE`, pastas `01`–`06`, `catalogo.json`).

## [v1.16.2] - 2026-07-21
### Documentação
- Varredura multi-agente dos módulos 🟡/⚠: `docs/status/01-status-modulos.md` atualizado (Push/PWA → ✅; WhatsApp/Analytics corrigidos).
- Sequência de finalização: `docs/status/07-sequencia-modulos-amarelos-2026-07-21.md`.

## [v1.16.1] - 2026-07-21
### Alterado
- Planos de assinatura: lavagem interna de carro explícita e alinhada a `AUTO_WASH_*` (R$ 250 / 280 / 320).
- Comparativo residencial com linhas “Lavagem carro” + nota de escopo; Família Gold com badge e WhatsApp detalhado.
- Planos empresariais com desconto/frota na mesma tabela de preços.

## [v1.16.0] - 2026-07-20
### Alterado
- Responsividade incremental: utilitários `.alp-tab-strip`, `.alp-kpi-grid`, `.alp-calendar-scroll`; calendários, KPIs densos, mega-abas e tabelas adaptados ao mobile.
- FAB com clearance maior da bottom nav; sheets/modais com `dvh` e scroll interno.
### Documentação
- `docs/RELATORIO-RESPONSIVIDADE-2026-07-20.md`

## [v1.15.2] - 2026-07-20
### Alterado
- Credenciais de produção reaplicadas no pacote atualizado (`config.php` em cpanel-src, Deployment e FINAL_CPANEL); suporte a `config.local.php` para rotação futura.
- `GA_MEASUREMENT_ID` reutilizado do histórico do projeto.
### Documentação
- `docs/RELATORIO-CREDENCIAIS-REUSO-2026-07-20.md` — inventário mascarado + plano de rotação.
- Wiki (`integracoes`, `modulos`, `manutencao`, `problemas-frequentes`): Telegram/blog multicanal, install reusando banco, `config.local.php`.

## [v1.15.1] - 2026-07-20
### Corrigido
- Cron carrega `telegram-service.php` — a fila async (posts do blog e eventos) consegue entregar Telegram.
- `NotificationCenter`: `force_telegram` respeitado em `hasExternalChannel`; lazy-load do serviço no `deliverTelegram`.
- BlogAdminPanel: checkboxes multicanal alinhados ao CMS (stubs “em breve”).

## [v1.15.0] - 2026-07-20
### Adicionado
- Publicação multicanal do Blog (MVP): ao publicar, opção “Publicar também em” com Telegram real (fila NotificationCenter) e stubs para Facebook/LinkedIn/GBP/Instagram/YouTube/Pinterest.
- Config `blog_multichannel_config` + campo **Chat ID do blog** no CRM → Telegram.
- Caption Telegram com template estático e tentativa opcional via AI Gateway.
### Observação
- Blog/SEO/CRUD inalterados; falha de distribuição não reverte a publicação. Demais redes aguardam OAuth/API.

## [v1.14.0] - 2026-07-20
### Adicionado
- **Central de Documentação Técnica** no CMS Premium (menu Sistema): wiki pesquisável, categorias, links internos.
- API admin `docs/catalog|file|apis|schema|search` (`docs-handlers.php`) — catálogo a partir de `docs/`, APIs ao vivo (`ROUTES`) e dicionário MySQL.
- Wiki curada em `docs/wiki/` (visão geral, integrações, FAQ, manutenção, módulos, segurança).
- Build cPanel passa a incluir `docs/` (wiki/audit/status) + `CHANGELOG.md` no pacote.
### Observação
- Documentação “automática” = catálogo de arquivos + rotas/schema gerados em tempo real; textos curados em Markdown. Edição WYSIWYG de wiki fica para fase 2.

## [v1.13.1] - 2026-07-20
### Corrigido
- Telegram: token sempre criptografado via `encryptMailSecret` (sem fallback base64 inseguro); webhook usa `secret_token` / header `X-Telegram-Bot-Api-Secret-Token` (sem secret na query).
- NotificationCenter: fim do log duplicado em falhas de canal; `legacy_parallel` também registra `notification_logs`.
- Portal cliente: valida `client/me` ao montar e limpa sessão se 401/403.
- `scripts/build-cpanel.sh` marcado deprecated (gerava API incompleta) — usar `npm run build` / `build-cpanel-final.ps1`.
### Alterado
- Comunicação: nota de UX sobre WhatsApp/Telegram exigirem vínculo no CRM.

## [v1.13.0] - 2026-07-20
### Adicionado
- Canal **Telegram** (MVP): provider no Communication Hub, envio paralelo via `NotificationCenter`, config CRM (`crm/telegram`), webhook público (`telegram/webhook`), vínculo `/start c{id}`.
- Campos em `crm_contacts`: `telegram_chat_id`, `telegram_username`, `telegram_notify`, `notify_pref` (whatsapp|telegram|both).
- UI: painel CRM Telegram, toggles Telegram/WhatsApp na Comunicação, preferências no detalhe do cliente, teste no Hub.
### Alterado
- Toggles de canal por evento incluem `telegram` (default off) sem mudar comportamento WhatsApp.
### Segurança
- Bot token criptografado (`encryptMailSecret`); webhook protegido por `secret` na query.
### Observação
- Comandos do bot só respondem com links para o portal (sem agendamento conversacional nesta entrega).

## [v1.12.4] - 2026-07-20
### Corrigido
- Banco: `db()` com retry único em falhas transitórias (too many connections / gone away / timeout) e log `db_connect_failed` com rate-limit (120s) + host/dbname no contexto (sem senha).
- Notificações: `notification_channel_issue` passa a usar `appLogRateLimited` (300s) para não inundar o log.
- Blog / IA de Conteúdo: `handleBlogGenerate` com try/catch e mensagem acionável quando a chave/provedor falta (HTTP 503).
- Calendário editorial: exibe erro e botão “Tentar de novo” quando a API `blog` falha (ex.: DB 503).
### Observação operacional
- `crm_evolution_http` já era rate-limited; logs 401/403/404 ficam em nível `info`. Falhas reais costumam ser URL/porta/chave Evolution na HostGator (portas ≠ 80/443).

## [v1.12.3] - 2026-07-20
### Corrigido
- AI Gateway: TypeError `AIProviderAdapter::complete(): Argument #2 ($apiKey) must be of type string, null given` — `sanSecret()` devolve `null` e o fallback da chave criptografada nunca rodava no teste de provedor. Novo helper `aiGatewayNormalizeApiKey()` + defesa em `complete()`.
- Criador IA / Communication Hub: erros sem chave retornam JSON `{ok:false}` com mensagem acionável (não HTTP 500).
- Portal `/conta`: deep-links protegidos (ex. `/conta/perfil`) redirecionam para o login quando não autenticado; menus sensíveis só após login.
### Segurança
- Validação robusta de `$apiKey` (nunca null) em todos os call sites do adapter.

## [v1.12.2] - 2026-07-20
### Alterado
- Login admin persiste em `localStorage` (antes era `sessionStorage` e sumia ao fechar a aba); migração automática da sessão antiga.
- Sessão admin no servidor: TTL de 24h → **30 dias**, com renovação automática em `admin/me`.
- Sessão cliente: renovação sliding em `client/me` (continua em `localStorage`, TTL 30 dias).
### Corrigido
- Admin não precisa mais logar a cada fechamento de aba/navegador.

## [v1.12.1] - 2026-07-19
### Corrigido
- WhatsApp Evolution: conexão nunca completava — o polling pedia um QR novo a cada 4s, invalidando o código antes do pareamento e esgotando o limite de QRs da instância. Agora o backend reusa o QR vigente (~25s, coluna `qr_generated_at`) e `fetchInstances`/`create` só rodam no connect explícito.
- Poll do painel WhatsApp com guarda de requisição em voo (5s); erros cURL de porta bloqueada ganham dica de diagnóstico (HostGator bloqueia portas fora de 80/443).
### Adicionado
- Migração `cpanel-src/migrations/2026-07-19-whatsapp-evolution-qr-cache.sql`; testes standalone `scripts/test-evolution-parsers.php` (16/16 PASS); relatório `docs/RELATORIO-AUDITORIA-WHATSAPP-EVOLUTION-2026-07-19.md`.

## [v1.12.0] - 2026-07-19
### Adicionado
- Chunking Vite unificado (`vite.manualChunks.ts`): vendor mínimo (React/Router/Query); charts/icons fora do preload inicial.
- Modulepreload filtrado: apenas `vendor` no `index.html` (charts/editor/motion on-demand).
- Gate de schema (`schema_migrations` / `2026-07-19-perf-v1`) para pular ensures pesados no hot path da API.
- Blog listagem leve com paginação; ETag/`unchanged` em `tracking/ops`.
- Componente `AppImage` (lazy/decoding/dimensões/WebP); coleta opcional de Web Vitals (LCP/INP/CLS) via analytics.
- SW v9 com LRU + TTL dinâmico e prompt de “nova versão”; budgets de chunk no build.
### Alterado
- Home pública: `useAppState` só em rotas admin; `PremiumHome` memoizado; prefetch de booking só em hover/focus/`saveData`.
- Portal: invalidação React Query por chave específica; sininhos admin/cliente em `useQuery` compartilhado.
- Agenda/wizard: abort+debounce de availability; countdown isolado; CRM/finanças com teto/`useMemo`/paginação.
- `.htaccess`: assets imutáveis; HTML/SW sem cache longo; `docs/` fora do ZIP de produção.
### Corrigido
- Spinners de tracking/ops alinhados a `isPending`; polls CRM WhatsApp respeitam `visibilityState`.
### Segurança
- Sem alteração de segredos nesta entrega (rotação de `config.php` / token admin permanece entrega separada).

## [v1.11.1] - 2026-07-18
### Alterado
- Live Service simplificado para o fluxo diário: ingestão de GPS unificada em lote único (payload legado vira lote de 1 ponto via `trackingIngestLocationBatch`).
- Mensagens de tracking agora são determinísticas com placeholders (`{{cliente}}`, `{{tecnico}}`, `{{eta_text}}`); Gemini saiu do hot path de notificações.
- Central operacional enxuta: mapa, contadores do dia e lista de ordens com filtros de data/status; rankings, métricas agregadas e filtros de cidade/bairro/equipe removidos do polling.
- Frota (equipe/veículo) fora do caminho quente: snapshot e ops não fazem SELECTs extras; atribuição volta a ser só por técnico. Tabelas/colunas permanecem no schema.
- Capitão Clean monitora apenas GPS stale/internet perdida e atraso; anomalias extras (parada >5 min, velocidade/precisão, atendimento longo) removidas para reduzir ruído.
- Purge de GPS simplificado: DELETE direto de pontos >30 dias de sessões encerradas, sem arquivamento JSON no cron.
### Removido
- Scaffolding de chat (`ready=false`) do payload live e da UI do cliente; rota `tracking/resources` (CRUD de frota sem consumidor).

## [v1.11.0] - 2026-07-18
### Adicionado
- Live Service 2.0: equipes, veículos, múltiplas cidades, GPS com altitude/movimento/paradas, ingestão em lote idempotente, fila IndexedDB com Background Sync e arquivo de percurso após 30 dias.
- Área técnica mobile-first com pausa real de deslocamento, checklist, fotos, observações, ocorrências, atraso, impedimento, retorno e assinatura do cliente.
- Central operacional multi-equipe com polling 2/5/30 s, filtros, rankings, métricas reais e estado “Sem dados”.
- Backend de chat preparado (`ready=0`) com attachments, typing, delivered/read.
- Relatórios `RELATORIO-AUDITORIA-LIVE-TRACKING-2026-07-18.md` e `RELATORIO-LIVE-SERVICE-2-0-2026-07-18.md`.
### Alterado
- ORS/Nominatim saíram do polling live; rota/ETA são amostrados e cacheados. Gemini passou a cachear templates por evento com placeholders validados.
- Communication Hub recebeu eventos operacionais, aliases compatíveis, destinatários completos e entrega painel/in-app válida sem DLQ falso.
- Capitão Clean passou a receber contexto operacional e monitorar atraso, GPS/internet, precisão, velocidade, paradas e tempos excessivos.
- Build cPanel agora inclui a documentação técnica completa.
### Corrigido
- Removido GPS bruto da timeline pública, inclusive para eventos legados; localização encerra automaticamente em chegada, cancelamento, conclusão ou logout.
- Sessão ativa de tracking agora é única e transacional; pausa não retrocede a OS para `confirmed`.
- Mudança de status pelo técnico atualiza o estado local imediatamente e invalida a Agenda.
### Segurança
- Ownership reforçado em tracking, checklist e uploads; pontos offline são aceitos somente na janela da sessão e replays são deduplicados.

## [v1.10.0] - 2026-07-18
### Adicionado
- **Acompanhamento em tempo real** sobre `appointments` (sem módulo paralelo): contas de técnico, GPS seguro durante deslocamento, mapa OSM/Leaflet, ETA/rota (ORS opcional + Haversine), timeline operacional, painel “Operação ao vivo” na Agenda e card ao vivo no Portal do Cliente.
- Schema aditivo (`tracking_realtime_v1.sql` / `ensureTrackingTables`): `technicians`, sessões, `appointment_events`, tracking sessions/points, checklist e analytics diário.
- APIs: `tracking/live`, `tracking/timeline`, `tracking/ops`, `appointments/assign`, `technicians`, `technician/*` (auth, appointments, location, checklist, note).
- Eventos do Communication Hub: `DriverStarted`, `DriverLocationUpdated`, `DriverNear`, `DriverArrived`, `ServiceStarted`, `ServicePaused`, `ServiceFinished` — com mensagens naturais via Gemini e fallback determinístico.
- Monitor do Capitão Clean no cron (`captain_tracking`): GPS stale, atraso e purge de pontos.
- Documentação: `docs/RELATORIO-ACOMPANHAMENTO-REALTIME-2026-07-18.md`.
### Alterado
- Máquina de status ampliada com `arrived` e `paused`; bloqueio de agenda e labels TS/PHP alinhados.
- Push/deep links de status apontam para `/conta/agendamentos?live=ID`.
- Providers desacoplados de polling/rota/geocoding/tiles (preparados para WebSocket futuro).

## [v1.9.2] - 2026-07-18
### Corrigido
- **Tema claro/escuro não funcionava**: o modo do tema vivia em `useState` isolado dentro de cada instância de `useThemeMode` (Index, ThemeToggle do site, Toaster). Alternar o tema em um lugar deixava os demais com valor antigo — em Perfil → Tema a seleção exibida ficava errada e os botões "Claro/Escuro" pareciam não responder. O modo agora é estado global de módulo: todas as instâncias leem/escrevem o mesmo valor, são notificadas na mudança e abas abertas sincronizam via evento `storage`.
- **Toggle de tema do CMS Premium nunca aplicava o modo claro**: `PremiumCmsSidebar` tinha lógica própria que só alternava a classe `dark` (sem adicionar a `.light` exigida pelo CSS, cujo `:root` padrão é escuro) e gravava em outra chave (`alp-cms-theme`). Podia inclusive deixar `light` e `dark` juntas no `<html>`. Substituído pelo mesmo hook global `useThemeMode`.

## [v1.9.1] - 2026-07-18
### Corrigido
- **AI Gateway — TypeError "api key must be of type string, null given"** (diagnóstico do Capitão Clean): `sanSecret()` devolve `null` quando o campo `api_key` vem vazio, mas `ai-gateway-handlers.php` comparava com `=== ''` (estrito). Consequências: no **Testar**, o fallback para a chave gravada no banco nunca disparava e `null` chegava tipado em `AIProviderAdapter::complete()` (erro crítico recorrente); no **criar/editar** provedor sem redigitar a chave, `encryptAiSecret(null)` estourava HTTP 500. Normalizado com `?? ''` nos três pontos.

## [v1.9.0] - 2026-07-18
### Alterado
- **Temas Sazonais — redesign completo do painel** (`SeasonalThemesPanel`), preservando 100% das funcionalidades e a identidade visual da marca (azul #1FB1F9 / ciano #06C6E0):
  - Hero com faixa em degradê da marca, glows decorativos e CTA "Criar novo tema" em destaque.
  - Tema ativo em card spotlight: preview grande ao lado, badge "No ar agora" com pulso, chips de métricas (views/cliques/conversões) e ações rápidas (preview, editar, desativar).
  - Cards de métricas com ícone em chip gradiente e microinteração de hover (elevação + escala).
  - Galeria com hover-lift e ações contextuais animadas no card focado ("Usar no editor" / "Ampliar").
  - Lista de temas com badge de status colorido (Ativo com pulso, Agendado âmbar, Rascunho neutro), swatch maior e botões de ação com estados de hover/focus.
  - Editor reorganizado em seções nomeadas (Identidade, Overlay, Banner, Agendamento, Efeitos, CSS): opacidade virou slider com % visível, cores mostram o hex, checkboxes viraram switches acessíveis (role=switch), efeitos com rótulos em pt-BR e check visual; preview lateral fica fixo no scroll (sticky).
  - Estado vazio ilustrado na lista, modal de preview com cabeçalho (nome/status) e animação de entrada, `focus-visible` em todos os controles.

## [v1.8.9] - 2026-07-18
### Corrigido
- **Ideias de conteúdo demoravam para aparecer**: `ContentIdeasPanel` dependia do objeto retornado por `useCmsApi`, recriado a cada render. Isso recriava o callback de carga e disparava um ciclo contínuo de requisições. O painel agora depende da função memoizada, cancela consultas anteriores, ignora respostas obsoletas e aplica timeout de 10 segundos.
- **Pesquisa por palavra-chave não aparecia nos resultados**: as sugestões pesquisadas eram adicionadas após até 42 pautas genéricas e eliminadas pelo limite de 40 itens. Agora autosuggest e perguntas relacionadas à palavra-chave têm prioridade no início da resposta.
### Alterado
- Adicionados skeletons durante a primeira carga, erro visível com opção de tentar novamente e cache privado curto para reabrir pesquisas recentes com maior rapidez.

## [v1.8.8] - 2026-07-18
### Corrigido
- **Agendamento em horário já reservado**: o wizard exibia a grade local de horários quando a API devolvia lista vazia (dia lotado), deixando o cliente escolher horário ocupado e só descobrir o conflito ao confirmar. `resolveAvailableDaySlots` agora trata a resposta do servidor como autoritativa (array vazio = dia cheio); a grade local só é usada offline.
- **Conflito na confirmação sem alternativas**: ao receber 409 no "Confirmar Agendamento", o wizard agora volta automaticamente ao passo de horário, recarrega a disponibilidade real e mostra as sugestões do servidor como botões clicáveis (antes só exibia um toast genérico e mantinha o usuário na tela final).
- **Corrida de double-booking no backend**: `POST /appointments` revalida o conflito após o `INSERT` (ainda na transação, com `SELECT ... FOR UPDATE` excluindo o próprio registro) — fecha a janela em que dois clientes simultâneos passavam pela validação inicial em um dia vazio.
- **Reagendamento sem validação de conflito**: `client/appointments action=reschedule` gravava qualquer data/horário sem checar a agenda. Agora usa a mesma validação do agendamento novo e devolve 409 com sugestões.
- **Textos corrompidos (mojibake)** em `src/pages/Index.tsx` e `seasonal-theme.css`: toasts do fluxo de agendamento exibiam "PrÃ³ximas opÃ§Ãµes" etc.; bytes reparados para UTF-8 correto.

## [v1.8.7] - 2026-07-18
### Adicionado
- Identidade visual da marca nos conteúdos gerados por IA: helper central `alpBrand()` (paleta azul #1FB1F9 / ciano #06C6E0, tipografia Plus Jakarta Sans — mesma do frontend) usado em e-mails e prompts.
- Template de e-mail (`mailWrapHtml`) redesenhado no padrão da marca: faixa em degradê azul→ciano, tipografia com fallbacks seguros para clientes de e-mail, links e rodapé na cor primária. Novo helper `mailBrandButton()` para CTAs.
- Criador IA (Communication Hub): preview do conteúdo gerado com a identidade visual — mock de e-mail (template claro da marca) e mock de notificação (card com degradê da marca).
### Alterado
- Prompt da Notification AI passa a incluir as regras de identidade visual: paleta e tipografia oficiais, CTA de e-mail como botão no padrão da marca, `suggested_image` alinhada à paleta azul/ciano; proibido definir fontes/cores fora da identidade.

## [v1.8.6] - 2026-07-18
### Corrigido
- Communication Hub: abas **Criador IA** e **Providers** quebravam ao abrir. Causa comum: objeto renderizado como React child — sugestões da Notification AI chegam como `{title, detail}` (frontend esperava strings) e estatísticas da fila chegam como `{byStatus: {...}, dlq}` (frontend esperava mapa plano). Tipos e renderização corrigidos; resultado do LLM agora passa por coerção defensiva (`asText`, `Array.isArray`).
- Providers: falha de API agora mostra erro com "Tentar novamente" (antes ficava tela vazia); backend `CommunicationProviderRegistry::status()` blindado para provider defeituoso não gerar HTTP 500.
- Endpoints de IA do Hub (`communication/ai` e teste gemini do Test Center) com `set_time_limit(120)` — evita "Erro interno do servidor" por limite de 30s da hospedagem compartilhada.
- `communication/captain`: `tool=summary` normaliza sugestões para strings; `tool=devices` garante tabela `push_subscriptions`.
### Adicionado
- Auditoria completa módulo a módulo das 13 abas do Communication Hub — relatório em `docs/RELATORIO-AUDITORIA-COMMUNICATION-HUB-2026-07-18.md`.

## [v1.8.5] - 2026-07-18
### Corrigido
- Botão "Testar" do AI Gateway retornava "Erro interno do servidor" para Gemini: o teste varria toda a cadeia de fallback (até 5 modelos × 3 tentativas com timeout de 25s cada), estourando o `max_execution_time` (~30s) da hospedagem compartilhada. Agora o teste usa modo `single_model` (1 modelo só, timeout 15s), eleva `set_time_limit(120)` e captura qualquer exceção retornando a mensagem real em JSON em vez de 500.
- Teste de provedor passa a usar o modelo e `base_url` realmente gravados no provedor (antes ignorava e usava o default do tipo).

## [v1.8.4] - 2026-07-18
### Corrigido
- Build de deploy (`build-cpanel-final.ps1`) não empacotava a pasta `communication/` do Communication Hub — o pacote cPanel subia sem o backend do hub (rotas `communication/*` quebrariam em produção). Agora a pasta é copiada e os requires com subdiretório criam o destino automaticamente.
- Portal do Cliente: menu completo (Histórico, Fidelidade, Perfil etc.) só aparece após o login; deslogado mostra apenas Início e Agenda (que funcionam por aparelho, sem conta).
### Adicionado
- Pacotes de deploy gerados e validados: `SUBIR_EM_PUBLIC_HTML.zip` (pronto para cPanel/HostGator, config.php template sem segredos) e `CODIGO_FONTE_AutoLimpezaPro.zip` (código-fonte sem node_modules/builds/credenciais).

## [v1.8.3] - 2026-07-18
### Alterado
- Integração pública do YouTube migrada para o canal `AutoLimpezaPro` (`@AutoLimpezaPro`, ID `UCM0LECJOYdp9R9J4XJYcRQg`).
- Feed RSS, página de vídeos, painel administrativo, rodapé, JSON-LD, sitemap de vídeos e métricas do Capitão Clean agora usam a nova conta.
- Configuração do canal centralizada no frontend (`YOUTUBE`) e backend (`YOUTUBE_CHANNEL_ID`, `YOUTUBE_HANDLE`, `SOCIAL_YOUTUBE`).
### Corrigido
- Cache de estatísticas do YouTube do Capitão Clean passa a incluir o ID do canal na chave, invalidando automaticamente dados da conta anterior.

## [v1.8.2] - 2026-07-18
### Alterado
- Cadeia de modelos Gemini atualizada para versões ativas: `gemini-3.5-flash` → `gemini-3.1-flash-lite` → `gemini-2.5-flash` → `gemini-2.5-flash-lite` → `gemini-2.5-pro` (padrão agora `gemini-3.5-flash` em `GEMINI_MODEL`, `geminiModels()` e defaults do gateway).
- OpenRouter: modelo padrão trocado de `google/gemini-2.0-flash-exp:free` (desligado) para `openrouter/free` (roteador de modelos gratuitos ativos).
### Removido
- Modelos Gemini descontinuados pelo Google removidos de todos os fallbacks: família 1.5 (desligada em 2025) e família 2.0 (desligada em 01/06/2026).
### Corrigido
- `aiGatewayRetireDeadModels()`: migração idempotente que limpa modelos mortos gravados no banco (`ai_providers.model` e `site_config.gemini_model`), substituindo por equivalentes ativos.
- Validação ao vivo (18/07/2026): `gemini-3.5-flash`, `gemini-3.1-flash-lite`, `gemini-2.5-flash` e `gemini-2.5-flash-lite` respondem HTTP 200 com a chave do projeto; `gemini-2.5-pro` retorna 429 (limite de cota do plano — failover cobre).

## [v1.8.1] - 2026-07-18
### Corrigido
- DELETE de endereço do portal em modo cPanel (`apiUrl` com `params` separados — antes a query string entrava no `action` e 404ava).
- Web Push do cliente: `push/subscribe` e `push/devices` passam a enviar Bearer de sessão; backend aceita `owner_type=client` autenticado.
- Passaporte de higiene público mascara `clientName` (LGPD).
- AI Gateway: sync config→banco não sobrescreve mais chave já definida no painel; edição no painel espelha para `site_config`.
- Lista/badge de notificações do cliente unificados (`visitor_id` OR `client_id`); catch-all 404 em `/conta/*` desconhecido.

## [v1.8.0] - 2026-07-18
### Adicionado
- **Communication Hub** (refatoração incremental da Central de Notificações, 100% aditiva):
  - Event Bus canônico (`communication_events`) com registry de eventos; `dispatchNotificationEvent()` virou adaptador compatível do bus.
  - Provider Registry plugável (Internal, Push VAPID, Email Titan, WhatsApp Evolution/manual, SMS/Webhook stubs desabilitados).
  - QueueAdapter: MySQL padrão + Redis opcional com fallback automático; retry com backoff exponencial (`next_retry_at`), lease de worker e Dead Letter Queue (`notification_queue_dlq`).
  - Notification AI via AI Gateway (`module: notification_ai`): gerar/melhorar/resumir/adaptar conteúdo por canal + sugestões estratégicas + rascunho de campanha (nunca envia sem aprovação); log auditado em `communication_ai_log`.
  - Ferramentas do Capitão Clean com confirmação explícita e trilha de auditoria (`communication_captain_actions`).
  - SegmentResolver com preview de alcance (cidade, serviço, atividade, fidelidade, dispositivo, plataforma, idioma etc.).
  - 12 rotas novas `communication/*` (snapshot, overview, events, timeline, providers, segments, ai, campaigns, dlq, test, analytics, captain) — rotas legadas intactas.
  - Frontend: shell Communication Hub mobile-first com 13 abas lazy (Visão Geral, Campanhas, Criador IA, Segmentos, Timeline, Analytics, Providers/DLQ, Test Center + abas preservadas), cliente tipado `communicationHubApi` com TanStack Query e animações leves.
  - Automações do Hub (boas-vindas, cupom para inativos, aniversário) como regras desabilitadas por padrão e idempotentes, processadas no cron.
  - Migração aditiva `cpanel-src/migrations/communication_hub_v1.sql` + relatório `docs/status/RELATORIO-COMMUNICATION-HUB-ENTREGA-2026-07-18.md` (com runbook de rollback).
### Alterado
- `notification_queue`/`notification_logs`/`notification_campaigns` ganham colunas aditivas (event_id, canal_entregue, lock/retry, channels, paused_at, duplicated_from, ai_generated).
- Campanhas ganham ações de ciclo de vida: duplicar, pausar, retomar, agendar, cancelar.
### Corrigido
- `automation-handlers.php`: checagem incorreta `function_exists('NotificationCenter')` → `class_exists` (automações do Capitão voltam a usar o NotificationCenter).
### Segurança
- Snapshot/health sem valores de secrets (apenas flags "configurado"); nenhuma credencial lida ou movida.
- Ações mutáveis do Capitão exigem `confirm: true` e ficam auditadas (bloqueios inclusive).

## [v1.7.0] - 2026-07-18
### Adicionado
- **Portal do Cliente SPA** em `/conta/*` (shell, dashboard, agendamentos+timeline, histórico/prontuário, galeria, avaliações, fidelidade logada, cupons, manutenção, recomendações, notificações, perfil, endereços, suporte, assistente IA).
- Redirect permanente `/meu-agendamento` → `/conta/agendamentos` (compatibilidade menu/PWA/links).
- Backend portal: `portal-handlers.php`, migração `portal_cliente_v1.sql`, rotas `client/dashboard|loyalty|reviews|addresses|coupons|support|ai|maintenance|recommendations|gallery|upload`.
- Cancelar/reagendar via `PUT client/appointments` com posse + `BOOKING_CANCEL_HOURS`.
- `PUT client/me` (nome, telefone, avatar, senha ≥8).
- Relatório: `docs/status/RELATORIO-PORTAL-CLIENTE-ENTREGA-2026-07-18.md`.
### Alterado
- Navegação (MobileNav, drawer, quick access, navConfig, siteNavigation) usa rotas `/conta` sem `window.location.href`.
- Prefetch de `/conta` em `prefetchChunks.ts`; fetches da área migrados para React Query.
### Segurança
- Garantia digital pública mascara nome/telefone (LGPD).
- Login Google em conta com senha exige confirmação antes de vincular (`needsPasswordConfirm`).
- `push/subscribe` com `owner_type=client` exige sessão de cliente.
- Upload do portal autenticado (`client/upload`) — sem reabrir upload anônimo.
### Notas
- Financeiro fora de escopo nesta etapa. Token cliente em `localStorage` permanece como dívida documentada.

## [v1.6.6] - 2026-07-18
### Alterado
- Histórico de conversas da IA Atendente: lista ordenada por atividade mais recente (`updated_at`) no topo; ao abrir um thread, a tela rola automaticamente até a última mensagem (botão "Ir ao fim").
- Consultor do Capitão Clean: scroll reforçado para sempre manter a mensagem mais recente visível.

## [v1.6.5] - 2026-07-18
### Adicionado
- Login social Google na **Área do Cliente** (antes só o painel admin tinha): botão "Entrar com Google" no `ClientAuthPanel`, componente `GoogleClientSignIn`, método `loginWithGoogle` em `useClientAuth`.
- Backend: rotas `client/google-config` (GET) e `client/google-login` (POST) em `client-handlers.php`, reaproveitando `verifyGoogleIdToken` do admin. Login via Google encontra o cliente pelo e-mail ou cria a conta automaticamente (senha aleatória) e emite sessão de 30 dias.
### Alterado
- `config.php` / `config.php.example`: `GOOGLE_OAUTH_CLIENT_ID` agora habilita o login Google do admin **e** do cliente. Os botões aparecem sozinhos ao preencher o Client ID — sem recompilar o frontend (o Client ID é lido em runtime via endpoint de config).
### Notas
- Enquanto `GOOGLE_OAUTH_CLIENT_ID` estiver vazio, os botões (admin e cliente) ficam ocultos automaticamente — nada quebra. Ver guia `docs/build-final/GUIA-GOOGLE-LOGIN.md`.

## [v1.6.4] - 2026-07-18
### Adicionado
- Reparo de banco reforçado em `install.php?step=repair`: recria tabelas base ausentes (schema de `install-tables.php`), roda todos os `ensure*Tables`/migrações e agora executa `CHECK TABLE` em todas as tabelas com `REPAIR TABLE` automático quando o engine suportar (MyISAM/Aria); corrupção InnoDB é reportada com orientação.
- `config.php` de produção pré-preenchido incluído no pacote de deploy (`Deployment/AutoLimpezaPro.zip`), reutilizando credenciais do config antigo (banco, admin, cron, OpenAI, Gemini, SMTP Titan).
- Par de chaves VAPID real gerado (`scripts/gen-vapid-keys.cjs`); chave pública embutida no build do frontend (`VITE_VAPID_PUBLIC_KEY`) e par completo no `config.php` — Web Push funcional após deploy.
### Segurança
- `ADMIN_TOKEN` deixou de reutilizar a senha do admin: substituído por token aleatório de 40 caracteres (o config antigo usava a mesma string nos dois).
- Chaves VAPID placeholder/inválidas do config antigo descartadas.
### Alterado
- Instalação sem digitação: basta subir o ZIP, extrair e acessar `install.php` (config já configurado para `https://autolimpezapro.com.br`).

## [v1.6.3] - 2026-07-18
### Corrigido (QA — testes de fluxo + correções paralelas)
#### Agendamento / área do cliente
- Timer de 5 min do wizard não fecha mais a tela de sucesso nem mostra "tempo esgotado" após confirmação.
- Deep link `?servico=` é limpo da URL após abrir o wizard (sem reabrir no reload).
- Validação de telefone (dígitos) e e-mail (formato, se preenchido) no step 3 do wizard.
- Logout do cliente agora revoga a sessão no servidor antes de limpar o storage.
- Erro 500/503 em `client/appointments` não desloga mais o cliente (só 401 limpa sessão).
- Fidelidade sem pontos deixa de mostrar "undefined% de desconto" (`discountPercent` na resposta vazia + guard no front).
- Registro de push com `credentials: "include"` e só em modo cPanel.
#### Auth / navegação / PWA
- Google Sign-In não reinicializa mais a cada tecla (callback via ref — evita flicker/429).
- Contador de tentativas do login admin zera após cooldown de 60s.
- Acessos a `sessionStorage` no AdminLogin/`adminMustChangePassword` protegidos com try/catch.
- `adminLogout` envia `adminHeaders()` (inclui `X-Admin-Token`).
- `navigateTo` / `alp:pathchange` normalizam pathname — `/meu-agendamento?…` não cai mais na home.
- Listener `appinstalled` e timer do `PWAInstallBanner` com cleanup correto.
- Menu "Ajuda" aponta para `/ajuda`.
#### Painel admin
- Analytics avisa quando a amostra atinge o limite de 2000 visitas (totais podem estar incompletos).
- Paginação Anterior/Próxima nos logs do AI Gateway e da Central de Logs.
- Sync do Google Reviews remove reviews ausentes via DELETE.
### Documentação
- Relatório de testes em `docs/status/RELATORIO-TESTES-QA-2026-07-18.md`.

---

## [v1.6.2] - 2026-07-18
### Corrigido
- **Voltar agora respeita o histórico:** botões "Voltar" deixam de pular sempre para a home (o que reiniciava a tela principal). Passam a retornar à página anterior até chegar na home.
- Navegação para `/meu-agendamento` usa React Router (sem reload completo da página).
### Adicionado
- Botão Voltar flutuante em todas as rotas internas (exceto a home), além dos botões já existentes no header.
- Utilitário `navHistory` para controlar a profundidade da navegação SPA.

---

## [v1.6.1] - 2026-07-18
### Pacote Oficial de Deploy (cPanel)
- Nova pasta `Deployment/` com pacote profissional completo: `AutoLimpezaPro.zip`, `README.md`, `README_INSTALACAO.md/.html/.pdf` (manual passo a passo para leigos, 16 passos), `CHECKLIST_POS_INSTALACAO.md`, `ATUALIZACAO.md` (fluxo backup → migração → validação → rollback), `VERSAO.txt`, `config.php.example` e `database.sql`.
- `database.sql` de referência gerado automaticamente do código (`scripts/export-schema.php`) — 77 tabelas idempotentes; instalação oficial continua via `install.php`.
### Segurança
- **`config.php.example` sanitizado:** removidas credenciais reais (banco, admin master, tokens, OpenAI/Gemini, SMTP) — agora só placeholders `SUBSTITUA_*`. Pacotes gerados a partir de agora não carregam segredos (varredura automatizada confirmou pacote limpo). **Recomendado rotacionar** as senhas/chaves que constavam no example antigo, pois foram distribuídas em ZIPs anteriores.
- `install.php`: sem fallback de credenciais fixas — se `config.php` não definir admin master, gera senha aleatória exibida uma única vez; alerta de `ADMIN_TOKEN` agora exige 16+ caracteres e detecta placeholders.
- `install.php`: verificação de requisitos ampliada — extensões `curl`, `json`, `mbstring`, `openssl` (obrigatórias) e `gd` (recomendada) + checagem de escrita em `uploads/`, `storage/` e `logs/`.
### Build
- `scripts/build-cpanel-final.ps1` passa a incluir `database.sql` no pacote.
- Novo `scripts/wrap-manual-html.ps1` (manual HTML estilizado → PDF via Edge headless).

---

## [v1.6.0] - 2026-07-18
### Segurança
- **Crítico:** consulta pública de fidelidade (`innovations/loyalty`) não expõe mais PII — nome vem mascarado ("Primeiro S.") e datas de serviço ocultas, salvo para o próprio cliente autenticado ou admin; adicionado rate limit à consulta.
- **IDOR:** `visitor-location` e `push/devices` (POST) agora validam a posse do `visitor_id` via `assertVisitorAccess`; registro de dispositivo de tipo não-visitante exige admin.
- Rate limit por arquivo agora é atômico (`flock` cobrindo read-modify-write) — sem lost updates sob concorrência.
- Estatísticas de conversão (`quote-handlers.php`) passaram a usar placeholders para o cutoff de datas (higiene anti-SQLi).
### Corrigido
- **Crash iOS:** página do cliente (`/meu-agendamento`) não quebra mais no Safari iPhone — acesso a `Notification.permission` protegido por guard de existência da API.
- **Rota fantasma:** busca global, sininho e menus que navegavam para `/meu-agendamento` via roteamento interno caíam em "página não encontrada"; navegação centralizada (`navigateTo`) usa navegação real para rotas exclusivas do React Router.
- **Menu congelado:** `useNavRole` agora é reativo (useSyncExternalStore + evento `alp:auth-changed`) — papel visitante/cliente/admin atualiza após login/logout sem recarregar.
- **Menus com destino errado:** Clientes → CRM, Logs → Sistema; removidos itens sem página (Favoritos, Backups, Usuários, Permissões, Funcionários duplicado).
- **Lembretes do cron:** janela do lembrete de 1h ampliada (5–70 min, dedupe garante envio único) — não é mais pulado com cron de 15 min; claim de envio agora é liberado (retry) se o dispatch falhar; datas dos lembretes calculadas no timezone do site (não no CURDATE() do MySQL).
- **Safari privado:** todo acesso a localStorage/sessionStorage de sessão (admin/cliente) e tema protegido com try/catch — login não quebra mais com storage bloqueado.
- **Race condition:** carregamento de agendamentos do cliente usa guard de sequência — resposta antiga não sobrescreve mais a mais recente.
- **Splash em deep links:** caminhos do mascote no `index.html` passaram de relativos para absolutos (não quebra em `/dicas/slug`).
- **Uploads silenciosos no CMS:** falhas de upload em massa agora são reportadas (contagem + nomes dos arquivos).
- Closure obsoleta no auto-agendamento via `?servico=` corrigida com ref.
### Acessibilidade e responsividade
- Modais custom (`LeadCaptureModal`, popup CMS, wizard de agendamento) com `role="dialog"`/`aria-modal`; LeadCaptureModal fecha com Esc.
- Popup público do CMS com `max-h-[85dvh]` + scroll interno (não estoura em telas baixas).
- Touch targets ≥44px: itens do FAB, ícones sociais do rodapé, pílula WhatsApp do hero.
- Ações de mídia do CMS, excluir bloco do Page Builder e favoritos da sidebar deixaram de ser hover-only — visíveis/focáveis no touch.
- Pipeline editorial ganhou seletor de status por card (alternativa ao drag para touch/teclado).
- Header do cliente com truncamento (`min-w-0` + `truncate`) para nomes longos.
### Validação
- `tsc --noEmit` OK · build Vite/cPanel OK (FINAL_CPANEL regenerado) · `php -l` OK nos 6 arquivos PHP alterados · lints OK.

---

## [v1.5.2] - 2026-07-17
### Removido
- **Código morto (aprovado):** pasta `src/components/dashboard/` (5 componentes órfãos de template — `QuickActions`, `QuickStats`, `RecentTransactions`, `DailyGoal`, `CashStatus`), `src/components/layout/NotificationBellButton.tsx` (deprecated) e `src/data/lavaJatoPricing.ts` (deprecated).
### Alterado
- Migrada a constante `LAVA_JATO_PRICE_TEXT` de `lavaJatoPricing.ts` para `@/data/automotiveWash`; import em `lib/blog/seoExpansion.ts` atualizado.
### Observações
- Validado: sem erros de lint e **0 referências** remanescentes aos arquivos removidos.
- `dist-cpanel-test/` (artefato de build) marcado para remoção manual — shell indisponível no momento da execução; não afeta o app.

---

## [v1.5.1] - 2026-07-17
### Alterado
- **Limpeza da documentação:** removidas todas as referências a módulos de projetos antigos (ERP/marketplace/estoque/etc.) dos documentos de auditoria e status, que haviam sido herdadas do prompt original. Documentação passa a refletir **apenas** o sistema atual.
### Adicionado
- `docs/status/06-limpeza-codigo-morto.md` — relatório de código morto: pasta órfã `src/components/dashboard/` (5 componentes de template), `NotificationBellButton` deprecated, `dist-cpanel-test/` versionado, e mapeamento de referências reais vs falsos positivos.
### Observações
- Nenhum código foi excluído — apenas relatado (aguardando aprovação para remoção).

---

## [v1.5.0] - 2026-07-17
### Adicionado
- **Auditoria técnica completa** em `docs/audit/` (12 documentos + índice): arquitetura, frontend, backend, banco (97 tabelas), APIs (187 rotas), segurança, performance, UX/UI, módulos, rotas, IA e deploy, com diagramas Mermaid.
- **Auditoria de evolução/status** em `docs/status/` (6 documentos): dashboard executivo (~80%), status de 38 módulos, integrações, inventário técnico, bugs e dívida técnica, e roadmap (Sprints 1–5).
- **Regra de versionamento datado** (`.cursor/rules/versionamento-datado.mdc`): registrar versão com data a cada atualização importante.
### Observações
- Auditorias somente de documentação — nenhuma regra de negócio ou código de aplicação foi alterado.

---

## Resumo

Evolução do CMS existente (`PremiumCmsApp` + `CmsAdminPanel`) para experiência editorial premium, preservando React/PHP/MySQL/cPanel e todas as funcionalidades operacionais (agendamento, orçamento, login, área cliente).

---

## Frontend

### Dashboard editorial (`PremiumCmsDashboard` + `usePremiumCmsStats`)
- Métricas: rascunhos, agendados, arquivados, lixeira, comentários pendentes
- Posts mais lidos / destaques
- SEO Score e IA Score estimados

### Posts (`CmsAdminPanel`)
- Duplicar post (salva como rascunho)
- Status: `archived`, `trash` (via campo `status` existente)
- Preview desktop/tablet/mobile (`PostPreviewModal`)
- Painel SEO lateral em tempo real (`EditorialSeoSidebar`)
- Histórico de versões (`PostRevisionsPanel`)
- Reescritor IA inline (Melhorar, Expandir, Humanizar, PT-BR, SEO Local, FAQ, CTA)
- Editor dual: blocos (`CmsRichEditor`) + TipTap

### Portal editorial (`/dicas`)
- `BlogPortalEditorialHub` — Mais lidos, Últimas notícias, Guias, Casos reais, FAQ
- `BlogInternalLinksSection` — 10+ links internos por artigo (Leia também, categoria, região, serviço, populares, recentes)

### Novos módulos CMS Premium
- **Autores** (`AuthorsAdminPanel`) — CRUD com foto, bio, especialidade
- **Ideias de conteúdo** (`ContentIdeasPanel`) — sugestões SEO local, categorias, autosuggest, PAA, posts existentes

### Navegação
- `cmsNavigation.ts` — módulos `authors` (live), `content-ideas` (live)
- `PremiumCmsApp.tsx` — roteamento dos novos painéis

### Hooks / libs
- `useCms.ts` — `listRevisions`, `restoreRevision`, `listAuthors`, `saveAuthor`, `listContentIdeas`, `rewriteArticle`
- `internalLinks.ts` — agrupamento inteligente de links internos
- `PostStatus` estendido: `archived` | `trash`

---

## Backend (aditivo)

### Migrações (`migrations/cms_v2.sql` + `migrate-cms.php`)
- Tabela `blog_post_revisions` — versionamento sem alterar `blog_posts`
- Tabela `blog_authors` — autores editoriais
- Seed padrão: William Coelho, Equipe Auto Limpeza Pro, Especialista em Estofados, Redação

### APIs novas (`routes.php`)
| Action | Métodos | Função |
|--------|---------|--------|
| `blog/revisions` | GET, POST | Listar / restaurar versões |
| `blog/authors` | CRUD | Autores |
| `blog/content-ideas` | GET | Sugestões de pauta |

### APIs estendidas
- `blog` PUT — salva revisão automática antes de atualizar (`cmsSavePostRevision`)
- `blog/generate` POST — `mode: rewrite` + `action` (improve, expand, humanize, grammar, seo-local, faq, cta…)
- `ai-handlers.php` — `aiRewriteBlogArticle()` com fallback Gemini → OpenRouter → DeepSeek → HuggingFace → OpenAI

### Cron (`cron-jobs.php`)
- `processScheduledBlogPosts()` — publica posts com `status=scheduled` e `scheduled_at <= NOW()`

### Comentários
- Status adicionais na moderação: `pinned`, `highlighted`, `spam`, `blocked`

---

## Deploy

### `scripts/build-cpanel-final.ps1`
- Inclui `google-reviews-handlers.php`, `migrate-cms.php`
- Copia pasta `migrations/` para `public_html`

---

## Compatibilidade preservada

Não alterados (apenas integrações aditivas):
- Login, cadastro, área cliente, painel admin operacional
- Agendamento, orçamento, landing pages, SEO base, vídeos, antes/depois, avaliações, analytics, WhatsApp
- URLs do blog (`/dicas`, slugs existentes)
- Tabela principal `blog_posts`

---

## Validação

- `tsc --noEmit` — OK
- `vite build` — OK
- Build cPanel — via `scripts/sync-cpanel-release.ps1`

---

## [2026-06-22] Build Final — Passos 8–10

### Performance (Passo 8)
- Code-splitting Vite (`vendor`, `motion`, `editor`, `charts`)
- Bundle inicial ~423 KB; lazy-load home, PushAlert, YouTube proxy PHP
- Lighthouse local: SEO 100, A11y 100, Best Practices 96, Performance 71

### Segurança (Passo 9)
- `assertVisitorAccess()` — anti-IDOR em agendamentos e notificações
- Upload desafio com validação MIME (`finfo`)
- `POST admin/logout` — revoga sessão admin
- `sanitizeHtml()` no preview CMS

### Build Final (Passo 10)
- `npm run build` → gera `FINAL_CPANEL/` na raiz do workspace
- `config.php.example` (sem credenciais reais no pacote)
- Docs na raiz: `README_INSTALACAO.md`, `RESPONSIVIDADE.md`, `AUDITORIA_FINAL.md`, `CHANGELOG.md`
- ZIP: `SUBIR_EM_PUBLIC_HTML.zip`

---

## Pendências conhecidas (próximas iterações)

- Editor blocos com drag-and-drop nativo (PageBuilder ainda sem persistência API)
- WebP automático no upload de mídia
- Comentários públicos no frontend do blog (backend pronto)
- Lighthouse 90+ — auditoria sistemática de responsividade
- SEO local automático por cidade (geração em massa de landings — requer política explícita)
