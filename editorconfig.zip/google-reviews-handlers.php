<?php
/**
 * Migração aditiva — tabela google_reviews
 */

function runGoogleReviewsMigration(PDO $pdo): array {
    $results = [];
    $sql = "CREATE TABLE IF NOT EXISTS `google_reviews` (
        `id` VARCHAR(64) NOT NULL PRIMARY KEY,
        `author` VARCHAR(255) NOT NULL DEFAULT '',
        `rating` TINYINT UNSIGNED NOT NULL DEFAULT 5,
        `photo` VARCHAR(512) DEFAULT NULL,
        `review` TEXT NOT NULL,
        `owner_reply` TEXT DEFAULT NULL,
        `created_at` DATE DEFAULT NULL,
        `published` TINYINT(1) NOT NULL DEFAULT 1,
        `city` VARCHAR(120) DEFAULT NULL,
        `category` VARCHAR(64) DEFAULT 'geral',
        `pinned` TINYINT(1) NOT NULL DEFAULT 0,
        `featured` TINYINT(1) NOT NULL DEFAULT 0,
        `updated_at` DATETIME DEFAULT NULL,
        INDEX `idx_google_reviews_published` (`published`),
        INDEX `idx_google_reviews_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    $pdo->exec($sql);
    $results[] = 'google_reviews';
    return $results;
}

function googleReviewRowToArray(array $row): array {
    return [
        'id'         => $row['id'],
        'author'     => $row['author'],
        'rating'     => (int)$row['rating'],
        'photo'      => $row['photo'] ?? '',
        'review'     => $row['review'],
        'ownerReply' => $row['owner_reply'] ?? '',
        'createdAt'  => $row['created_at'] ?? '',
        'published'  => (bool)(int)($row['published'] ?? 1),
        'city'       => $row['city'] ?? '',
        'category'   => $row['category'] ?? 'geral',
        'pinned'     => (bool)(int)($row['pinned'] ?? 0),
        'featured'   => (bool)(int)($row['featured'] ?? 0),
    ];
}

function handleGoogleReviews(string $method): void {
    $pdo = db();

    if ($method === 'GET') {
        $publishedOnly = true;
        if (isset($_GET['admin'])) {
            requireAdmin();
            $publishedOnly = false;
        }
        $sql = $publishedOnly
            ? "SELECT * FROM google_reviews WHERE published = 1 ORDER BY created_at DESC"
            : "SELECT * FROM google_reviews ORDER BY created_at DESC";
        $stmt = $pdo->query($sql);
        $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
        if ($publishedOnly) {
            header('Cache-Control: public, max-age=120, stale-while-revalidate=300');
        } else {
            header('Cache-Control: private, no-store');
        }
        jsonRespond(array_map('googleReviewRowToArray', $rows ?: []));
    }

    requireAdmin();

    $b = jsonBody();

    if ($method === 'POST' && isset($b['bulk']) && is_array($b['bulk'])) {
        $now = dbNow();
        $stmt = $pdo->prepare("
            INSERT INTO google_reviews (id, author, rating, photo, review, owner_reply, created_at, published, city, category, pinned, featured, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                author = VALUES(author), rating = VALUES(rating), photo = VALUES(photo),
                review = VALUES(review), owner_reply = VALUES(owner_reply),
                created_at = VALUES(created_at), published = VALUES(published),
                city = VALUES(city), category = VALUES(category),
                pinned = VALUES(pinned), featured = VALUES(featured),
                updated_at = VALUES(updated_at)
        ");
        foreach ($b['bulk'] as $item) {
            if (!is_array($item) || empty($item['id'])) continue;
            $stmt->execute([
                $item['id'],
                $item['author'] ?? '',
                (int)($item['rating'] ?? 5),
                $item['photo'] ?? null,
                $item['review'] ?? '',
                $item['ownerReply'] ?? null,
                $item['createdAt'] ?? date('Y-m-d'),
                !isset($item['published']) || $item['published'] !== false ? 1 : 0,
                $item['city'] ?? null,
                $item['category'] ?? 'geral',
                !empty($item['pinned']) ? 1 : 0,
                !empty($item['featured']) ? 1 : 0,
                $now,
            ]);
        }
        jsonRespond(['ok' => true, 'count' => count($b['bulk'])]);
    }

    if ($method === 'DELETE' && !empty($b['id'])) {
        $pdo->prepare("DELETE FROM google_reviews WHERE id = ?")->execute([$b['id']]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => lang('method_not_allowed')], 405);
}
