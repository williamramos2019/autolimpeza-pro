<?php
/**
 * Helpers de blog_posts — compartilhados entre api.php e cron (Content Studio).
 * Depende de functions.php (san, cmsJsonEncode, sanitizeCmsHtml, slugify, cmsTableExists, dbNow).
 */

function cmsBlogPostParams(array $b, string $slug, string $now, ?int $uid, ?string $authorName, bool $allowJs): array {
    $p = cmsBlogPostUpdateParams($b, $now, $uid, $authorName, $allowJs);
    return array_merge([$slug], $p, [$now]);
}

/**
 * Extrai texto plano de blocos do editor/IA (h2/p/ul/faq/markdown/html…).
 * Usado para validar publicação e montar `content` quando a IA só envia blocks.
 */
function cmsBlocksToPlainText($blocks): string {
    if (is_string($blocks)) {
        $decoded = json_decode($blocks, true);
        $blocks = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($blocks) || count($blocks) === 0) {
        return '';
    }
    $parts = [];
    foreach ($blocks as $block) {
        if (!is_array($block)) continue;
        $type = (string)($block['type'] ?? '');
        foreach (['text', 'content', 'title', 'question', 'answer', 'body', 'caption', 'markdown', 'html', 'htmlContent'] as $k) {
            if (!empty($block[$k]) && is_string($block[$k])) {
                $t = trim(strip_tags($block[$k]));
                if ($t !== '') $parts[] = $t;
            }
        }
        if (!empty($block['items']) && is_array($block['items'])) {
            foreach ($block['items'] as $item) {
                if (is_string($item) && trim($item) !== '') {
                    $parts[] = trim($item);
                    continue;
                }
                if (!is_array($item)) continue;
                foreach (['q', 'a', 'text', 'label', 'title', 'content'] as $ik) {
                    if (!empty($item[$ik]) && is_string($item[$ik])) {
                        $t = trim(strip_tags($item[$ik]));
                        if ($t !== '') $parts[] = $t;
                    }
                }
            }
        }
        // list / checklist / steps sem items tipados
        if (in_array($type, ['ul', 'ol', 'list', 'checklist', 'steps'], true) && !empty($block['items']) && is_array($block['items'])) {
            // já coberto acima; noop para legibilidade
        }
    }
    return trim(preg_replace('/\s+/u', ' ', implode(' ', $parts)) ?? '');
}

function cmsBlogPostHasBody(array $b): bool {
    $html = trim(strip_tags((string)($b['content'] ?? '')));
    $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $html = preg_replace('/\s+/u', ' ', $html ?? '') ?? '';
    if (mb_strlen($html) >= 40) return true;

    $joined = cmsBlocksToPlainText($b['blocks'] ?? []);
    return mb_strlen($joined) >= 40;
}

/** Garante colunas de meta de imagem IA (idempotente). */
function ensureBlogPostImageColumns(?PDO $pdo = null): void {
    static $done = false;
    if ($done) return;
    $pdo = $pdo ?: db();
    if (!function_exists('cmsTableExists') || !cmsTableExists($pdo, 'blog_posts')) {
        return;
    }
    $alters = [
        'image_prompt' => "ALTER TABLE blog_posts ADD COLUMN image_prompt MEDIUMTEXT NULL",
        'image_status' => "ALTER TABLE blog_posts ADD COLUMN image_status VARCHAR(20) NULL DEFAULT NULL",
        'image_provider' => "ALTER TABLE blog_posts ADD COLUMN image_provider VARCHAR(80) NULL",
        'image_generated_at' => "ALTER TABLE blog_posts ADD COLUMN image_generated_at DATETIME NULL",
    ];
    foreach ($alters as $col => $sql) {
        if (function_exists('cmsColumnExists') && cmsColumnExists($pdo, 'blog_posts', $col)) {
            continue;
        }
        try {
            $pdo->exec($sql);
        } catch (Throwable $e) {
            if (!function_exists('alpIsIdempotentMigrationError') || !alpIsIdempotentMigrationError($e)) {
                if (function_exists('appLog')) {
                    appLog('warn', 'blog_image_col_ensure', ['col' => $col, 'err' => $e->getMessage()]);
                }
            }
        }
    }
    $done = true;
}

/** URL de capa válida (http(s), /path ou uploads/). */
function cmsBlogPostHasCover(array $b): bool {
    $url = trim((string)($b['imageUrl'] ?? $b['image_url'] ?? ''));
    if ($url === '') return false;
    return (bool)preg_match('#^(https?://|/|uploads/)#i', $url);
}

/**
 * Capa pronta para publicação.
 * Legado: tem image_url e status vazio → ok.
 * Novo: exige image_status = completed.
 */
function cmsBlogPostImageReady(array $b): bool {
    if (!cmsBlogPostHasCover($b)) return false;
    $st = strtolower(trim((string)($b['imageStatus'] ?? $b['image_status'] ?? '')));
    if ($st === '' || $st === 'completed') return true;
    return false;
}

/** Status permitidos: pending|generating|completed|failed */
function cmsNormalizeImageStatus(?string $status): string {
    $st = strtolower(trim((string)$status));
    $allowed = ['pending', 'generating', 'completed', 'failed'];
    return in_array($st, $allowed, true) ? $st : 'pending';
}

/**
 * Atualiza meta de imagem no post (após INSERT/UPDATE clássico).
 * @param array{imageUrl?:?string,imagePrompt?:?string,imageStatus?:?string,imageProvider?:?string,imageGeneratedAt?:?string,ogImage?:?string} $meta
 */
function cmsBlogPostSetImageMeta(PDO $pdo, string $slug, array $meta): void {
    ensureBlogPostImageColumns($pdo);
    $slug = trim($slug, '-');
    if ($slug === '') return;

    $sets = [];
    $vals = [];
    if (array_key_exists('imageUrl', $meta) || array_key_exists('image_url', $meta)) {
        // Aceita URL longa (CDN ChatGPT); localiza https → /uploads/ antes de truncar VARCHAR(500)
        $rawUrl = trim((string)($meta['imageUrl'] ?? $meta['image_url'] ?? ''));
        $rawUrl = $rawUrl !== '' ? mb_substr(strip_tags($rawUrl), 0, 2500) : '';
        $url = $rawUrl !== '' ? cmsPublicMediaUrl($rawUrl) : null;
        if ($url && function_exists('cmsLocalizeExternalMediaUrl') && preg_match('#^https://#i', $url)) {
            try {
                $url = cmsLocalizeExternalMediaUrl($pdo, $url, [
                    'folder' => 'Blog',
                    'title' => san($meta['title'] ?? 'Capa do post', 200) ?? 'Capa do post',
                    'provider' => san($meta['imageProvider'] ?? $meta['image_provider'] ?? 'external_url', 60),
                ]);
            } catch (Throwable $e) {
                if (function_exists('appLog')) {
                    appLog('warn', 'blog_cover_localize_failed', [
                        'slug' => $slug,
                        'err' => $e->getMessage(),
                        'host' => parse_url($url, PHP_URL_HOST),
                    ]);
                }
                // Não gravar URL externa que expira/hotlink — deixa null e marca failed abaixo
                $url = null;
                if (!array_key_exists('imageStatus', $meta) && !array_key_exists('image_status', $meta)) {
                    $meta['imageStatus'] = 'failed';
                }
            }
        } elseif ($url) {
            $url = cmsPublicMediaUrl(san($url, 500));
        }
        $sets[] = 'image_url = ?';
        $vals[] = $url ? san($url, 500) : null;
        if (!empty($meta['syncOg']) || !empty($meta['ogImage']) || array_key_exists('imageUrl', $meta)) {
            $ogRaw = trim((string)($meta['ogImage'] ?? $url ?? ''));
            $og = $ogRaw !== '' ? cmsPublicMediaUrl(mb_substr(strip_tags($ogRaw), 0, 2500)) : null;
            if ($og && function_exists('cmsLocalizeExternalMediaUrl') && preg_match('#^https://#i', $og)) {
                try {
                    $og = cmsLocalizeExternalMediaUrl($pdo, $og, [
                        'folder' => 'Blog',
                        'title' => san($meta['title'] ?? 'OG image', 200) ?? 'OG image',
                        'provider' => 'external_url',
                    ]);
                } catch (Throwable $e) {
                    $og = $url; // fallback para capa já localizada
                }
            }
            $og = $og ? san(cmsPublicMediaUrl($og) ?? $og, 500) : null;
            $sets[] = 'og_image = ?';
            $vals[] = $og;
        }
    }
    if (array_key_exists('imagePrompt', $meta) || array_key_exists('image_prompt', $meta)) {
        $prompt = $meta['imagePrompt'] ?? $meta['image_prompt'] ?? null;
        $sets[] = 'image_prompt = ?';
        $vals[] = is_string($prompt) ? mb_substr($prompt, 0, 65000) : null;
    }
    if (array_key_exists('imageStatus', $meta) || array_key_exists('image_status', $meta)) {
        $sets[] = 'image_status = ?';
        $vals[] = cmsNormalizeImageStatus((string)($meta['imageStatus'] ?? $meta['image_status'] ?? 'pending'));
    }
    if (array_key_exists('imageProvider', $meta) || array_key_exists('image_provider', $meta)) {
        $sets[] = 'image_provider = ?';
        $vals[] = san($meta['imageProvider'] ?? $meta['image_provider'] ?? null, 80);
    }
    if (array_key_exists('imageGeneratedAt', $meta) || array_key_exists('image_generated_at', $meta)
        || (($meta['imageStatus'] ?? $meta['image_status'] ?? '') === 'completed')) {
        $at = $meta['imageGeneratedAt'] ?? $meta['image_generated_at'] ?? null;
        if (($meta['imageStatus'] ?? $meta['image_status'] ?? '') === 'completed' && !$at) {
            $at = function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s');
        }
        $sets[] = 'image_generated_at = ?';
        $vals[] = $at ? san((string)$at, 32) : null;
    }
    if (!$sets) return;
    $sets[] = 'updated_at = ?';
    $vals[] = function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s');
    $vals[] = $slug;
    try {
        $pdo->prepare('UPDATE blog_posts SET ' . implode(', ', $sets) . ' WHERE slug = ?')->execute($vals);
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('error', 'blog_set_image_meta', ['slug' => $slug, 'err' => $e->getMessage()]);
        }
    }
}

/**
 * Thresholds de repetição artificial (documentados — escala híbrida 2026-08-09):
 * - 0–20  (ok):     normal, sem aviso
 * - 21–40 (soft):   aviso no sync/preview (BLOG_REPETITION_SOFT_SCORE)
 * - 41–60 (strong): aviso forte (BLOG_REPETITION_STRONG_SCORE)
 * - 61–100 (hard):  Content Studio "Publicar agora" → draft + publishBlocked
 */
if (!defined('BLOG_REPETITION_SOFT_SCORE')) {
    define('BLOG_REPETITION_SOFT_SCORE', 21);
}
if (!defined('BLOG_REPETITION_STRONG_SCORE')) {
    define('BLOG_REPETITION_STRONG_SCORE', 41);
}
if (!defined('BLOG_REPETITION_HARD_SCORE')) {
    define('BLOG_REPETITION_HARD_SCORE', 61);
}

/**
 * Clichês de medo genéricos que a IA tendia a repetir em TODOS os artigos
 * (ex.: H2 "O Perigo Oculto") — banidos no prompt + strip no save/preview.
 * @return list<string>
 */
function blogBannedClichePhrases(): array {
    return [
        'o perigo oculto',
        'o perigo escondido',
        'o risco oculto',
        'o perigo invisível',
        'o perigo invisivel',
        'a ameaça invisível',
        'a ameaça invisivel',
        'o inimigo oculto',
        'o inimigo invisível',
        'o inimigo invisivel',
    ];
}

/** Reescreve clichês banidos para copy específica (não remove sentido). */
function blogStripBannedCliches(?string $text): ?string {
    if ($text === null || $text === '') {
        return $text;
    }
    $map = [
        '/\bo\s+perigo\s+oculto\b/iu' => 'o risco que fica nas fibras',
        '/\bo\s+perigo\s+escondido\b/iu' => 'o que a limpeza superficial não remove',
        '/\bo\s+risco\s+oculto\b/iu' => 'o risco que fica nas fibras',
        '/\bo\s+perigo\s+invis[ií]vel\b/iu' => 'a contaminação que não se vê',
        '/\ba\s+amea[cç]a\s+invis[ií]vel\b/iu' => 'a contaminação que não se vê',
        '/\bo\s+inimigo\s+oculto\b/iu' => 'o acúmulo profundo nas fibras',
        '/\bo\s+inimigo\s+invis[ií]vel\b/iu' => 'o acúmulo profundo nas fibras',
    ];
    $fixed = $text;
    foreach ($map as $re => $repl) {
        $fixed = preg_replace($re, $repl, $fixed) ?? $fixed;
    }
    return $fixed;
}

/** Corrige repetições como "Higienização e higienização de colchões…". */
function blogFixRedundantCopy(?string $text): ?string {
    if ($text === null || $text === '') {
        return $text;
    }
    $fixed = preg_replace('/\bHigienização e higienização\b/iu', 'Higienização', $text);
    $fixed = preg_replace('/\bhigienização e higienização\b/iu', 'higienização', $fixed ?? $text);
    // Frases idênticas consecutivas (eco de geração)
    $fixed = preg_replace('/([^.!?\n]{20,}[.!?])(\s+\1)+/u', '$1', $fixed ?? $text);
    $fixed = blogStripBannedCliches($fixed ?? $text);
    return $fixed ?? $text;
}

/** Normaliza texto para comparação de repetição. */
function blogRepetitionNormalize(string $text): string {
    $t = mb_strtolower(strip_tags($text), 'UTF-8');
    $t = preg_replace('/\s+/u', ' ', $t) ?? $t;
    return trim($t);
}

/**
 * Analisa repetição artificial no corpo do post.
 * @return array{score:int,level:string,warnings:string[],details:array}
 */
function blogAnalyzeRepetition(array $post, ?string $keyword = null): array {
    $warnings = [];
    $details = [
        'duplicateSentences' => 0,
        'adjacentDupSentences' => 0,
        'denseTrigrams' => 0,
        'introConclusionOverlap' => 0.0,
        'keywordDensity' => 0.0,
        'keywordHits' => 0,
        'wordCount' => 0,
    ];
    $score = 0;

    $body = trim(strip_tags((string)($post['content'] ?? '')));
    if ($body === '' && function_exists('cmsBlocksToPlainText')) {
        $body = cmsBlocksToPlainText($post['blocks'] ?? []);
    }
    $body = blogRepetitionNormalize($body);
    if ($body === '') {
        return [
            'score' => 0,
            'level' => 'ok',
            'warnings' => [],
            'details' => $details,
        ];
    }

    // Sentenças
    $parts = preg_split('/(?<=[.!?])\s+/u', $body) ?: [];
    $sentences = [];
    foreach ($parts as $p) {
        $p = trim($p);
        if (mb_strlen($p) >= 28) {
            $sentences[] = $p;
        }
    }
    $seen = [];
    $dupExact = 0;
    $adjDup = 0;
    $prev = null;
    foreach ($sentences as $s) {
        if ($prev !== null && $s === $prev) {
            $adjDup++;
        }
        if (isset($seen[$s])) {
            $dupExact++;
        } else {
            $seen[$s] = true;
        }
        $prev = $s;
    }
    $details['duplicateSentences'] = $dupExact;
    $details['adjacentDupSentences'] = $adjDup;
    if ($adjDup > 0) {
        $score += min(35, $adjDup * 18);
        $warnings[] = "Frases idênticas em sequência ({$adjDup}).";
    }
    if ($dupExact > 0) {
        $score += min(30, $dupExact * 12);
        $warnings[] = "Frases repetidas no corpo ({$dupExact}).";
    }

    // Trigramas densos (padrão artificial)
    $words = preg_split('/\s+/u', $body) ?: [];
    $words = array_values(array_filter($words, static fn($w) => mb_strlen($w) >= 3));
    $details['wordCount'] = count($words);
    $trigrams = [];
    $n = count($words);
    for ($i = 0; $i < $n - 2; $i++) {
        $tg = $words[$i] . ' ' . $words[$i + 1] . ' ' . $words[$i + 2];
        $trigrams[$tg] = ($trigrams[$tg] ?? 0) + 1;
    }
    $dense = 0;
    foreach ($trigrams as $count) {
        if ($count >= 4) {
            $dense++;
        }
    }
    $details['denseTrigrams'] = $dense;
    if ($dense > 0) {
        $score += min(25, $dense * 8);
        $warnings[] = "Trechos de 3 palavras repetidos demais ({$dense}).";
    }

    // Intro vs conclusão (primeiros/últimos ~400 chars)
    $len = mb_strlen($body);
    if ($len > 600) {
        $intro = mb_substr($body, 0, 400);
        $concl = mb_substr($body, max(0, $len - 400));
        $iw = array_unique(array_filter(preg_split('/\s+/u', $intro) ?: [], static fn($w) => mb_strlen($w) >= 4));
        $cw = array_unique(array_filter(preg_split('/\s+/u', $concl) ?: [], static fn($w) => mb_strlen($w) >= 4));
        $inter = count(array_intersect($iw, $cw));
        $union = max(1, count(array_unique(array_merge($iw, $cw))));
        $j = $inter / $union;
        $details['introConclusionOverlap'] = round($j, 3);
        if ($j >= 0.55) {
            $score += 20;
            $warnings[] = 'Introdução e conclusão muito parecidas.';
        } elseif ($j >= 0.42) {
            $score += 10;
            $warnings[] = 'Introdução e conclusão com sobreposição alta.';
        }
    }

    // Keyword stuffing (só se densidade artificialmente alta)
    $kw = blogRepetitionNormalize((string)($keyword ?? $post['keyword'] ?? ''));
    if ($kw !== '' && mb_strlen($kw) >= 3 && $details['wordCount'] > 80) {
        $hits = 0;
        if (mb_strpos($kw, ' ') !== false) {
            $hits = substr_count($body, $kw);
        } else {
            $hits = preg_match_all('/\b' . preg_quote($kw, '/') . '\b/u', $body) ?: 0;
        }
        $density = ($hits / max(1, $details['wordCount'])) * 100;
        $details['keywordHits'] = $hits;
        $details['keywordDensity'] = round($density, 2);
        // Natural: sofá pode aparecer muitas vezes; só pune densidade extrema + volume
        if ($hits >= 12 && $density >= 4.5) {
            $score += 25;
            $warnings[] = "Possível keyword stuffing («{$kw}» ~{$details['keywordDensity']}% das palavras).";
        } elseif ($hits >= 10 && $density >= 2.8) {
            $score += 12;
            $warnings[] = "Palavra-chave «{$kw}» muito frequente ({$hits}×).";
        }
    }

    // H2 duplicados nos blocks
    $h2 = [];
    $h2Dup = 0;
    if (!empty($post['blocks']) && is_array($post['blocks'])) {
        foreach ($post['blocks'] as $block) {
            if (!is_array($block)) continue;
            $type = strtolower((string)($block['type'] ?? ''));
            if ($type === 'h2' || $type === 'heading') {
                $t = blogRepetitionNormalize((string)($block['text'] ?? $block['content'] ?? $block['title'] ?? ''));
                if ($t === '') continue;
                if (isset($h2[$t])) {
                    $h2Dup++;
                } else {
                    $h2[$t] = true;
                }
            }
        }
    }
    if ($h2Dup > 0) {
        $score += min(20, $h2Dup * 10);
        $warnings[] = "Subtítulos (H2) repetidos ({$h2Dup}).";
        $details['duplicateHeadings'] = $h2Dup;
    }

    // Clichês de medo genéricos (ex.: "O Perigo Oculto" em todo artigo)
    $bannedHits = [];
    $scanBlob = $body;
    foreach (['title', 'subtitle', 'excerpt', 'metaTitle', 'metaDescription', 'meta_title', 'meta_description'] as $fk) {
        if (!empty($post[$fk]) && is_string($post[$fk])) {
            $scanBlob .= ' ' . blogRepetitionNormalize($post[$fk]);
        }
    }
    if (!empty($post['blocks']) && is_array($post['blocks'])) {
        foreach ($post['blocks'] as $block) {
            if (!is_array($block)) continue;
            foreach (['text', 'content', 'title'] as $bk) {
                if (!empty($block[$bk]) && is_string($block[$bk])) {
                    $scanBlob .= ' ' . blogRepetitionNormalize($block[$bk]);
                }
            }
        }
    }
    foreach (blogBannedClichePhrases() as $phrase) {
        $p = blogRepetitionNormalize($phrase);
        if ($p !== '' && mb_strpos($scanBlob, $p) !== false) {
            $bannedHits[] = $phrase;
        }
    }
    $details['bannedClicheHits'] = $bannedHits;
    if ($bannedHits) {
        $score += min(35, count($bannedHits) * 15);
        $warnings[] = 'Clichê de medo genérico detectado («' . $bannedHits[0] . '»). Use subtítulo específico ao tema.';
    }

    $score = max(0, min(100, $score));
    $level = 'ok';
    if ($score >= BLOG_REPETITION_HARD_SCORE) {
        $level = 'high';
    } elseif ($score >= BLOG_REPETITION_STRONG_SCORE) {
        $level = 'strong';
    } elseif ($score >= BLOG_REPETITION_SOFT_SCORE) {
        $level = 'medium';
    }

    return [
        'score' => $score,
        'level' => $level,
        'warnings' => $warnings,
        'details' => $details,
    ];
}

function blogRepetitionIsSoftWarn(array $analysis): bool {
    return (int)($analysis['score'] ?? 0) >= BLOG_REPETITION_SOFT_SCORE;
}

function blogRepetitionIsStrongWarn(array $analysis): bool {
    return (int)($analysis['score'] ?? 0) >= BLOG_REPETITION_STRONG_SCORE;
}

function blogRepetitionIsHardBlock(array $analysis): bool {
    return (int)($analysis['score'] ?? 0) >= BLOG_REPETITION_HARD_SCORE;
}

/**
 * Registra 301 em cms_redirects (from_path → to_url) se a tabela existir.
 */
function blogRegisterSlugRedirect(PDO $pdo, string $oldSlug, string $newSlug): bool {
    $oldSlug = trim($oldSlug, '/');
    $newSlug = trim($newSlug, '/');
    if ($oldSlug === '' || $newSlug === '' || $oldSlug === $newSlug) {
        return false;
    }
    if (!function_exists('cmsTableExists') || !cmsTableExists($pdo, 'cms_redirects')) {
        return false;
    }
    $from = '/dicas/' . $oldSlug;
    $to = rtrim(function_exists('blogCanonicalUrl') ? blogCanonicalUrl($newSlug) : (rtrim(defined('SITE_URL') ? SITE_URL : '', '/') . '/dicas/' . $newSlug), '/');
    $now = function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s');
    try {
        $chk = $pdo->prepare('SELECT id FROM cms_redirects WHERE from_path = ? LIMIT 1');
        $chk->execute([$from]);
        $id = $chk->fetchColumn();
        if ($id) {
            $pdo->prepare('UPDATE cms_redirects SET to_url=?, status_code=301, active=1, notes=?, updated_at=? WHERE id=?')
                ->execute([$to, 'blog slug rename', $now, (int)$id]);
        } else {
            $pdo->prepare('INSERT INTO cms_redirects (from_path, to_url, status_code, hits, active, notes, created_at, updated_at) VALUES (?,?,301,0,1,?,?,?)')
                ->execute([$from, $to, 'blog slug rename', $now, $now]);
        }
        return true;
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('warn', 'blog_slug_redirect', ['err' => $e->getMessage(), 'from' => $from]);
        }
        return false;
    }
}

/**
 * Auditoria SEO de posts publicados (admin).
 * @return array{total:int,indexable:int,issues:array,summary:array}
 */
function blogSeoAuditPublished(PDO $pdo): array {
    $issues = [];
    $summary = [
        'missingCanonical' => 0,
        'missingImage' => 0,
        'missingMetaDescription' => 0,
        'missingMetaTitle' => 0,
        'thinContent' => 0,
        'missingOgImage' => 0,
        'noRelated' => 0,
    ];
    $rows = [];
    try {
        $rows = $pdo->query(
            "SELECT slug, title, excerpt, content, blocks, meta_title, meta_description, canonical,
                    image_url, og_image, image_status, related, status, updated_at, published_at
             FROM blog_posts
             WHERE status = 'published' OR status IS NULL
             ORDER BY published_at DESC
             LIMIT 500"
        )->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return ['total' => 0, 'indexable' => 0, 'issues' => [], 'summary' => $summary, 'error' => $e->getMessage()];
    }
    $indexable = 0;
    foreach ($rows as $r) {
        $slug = (string)($r['slug'] ?? '');
        $postIssues = [];
        $canon = trim((string)($r['canonical'] ?? ''));
        $expected = function_exists('blogCanonicalUrl') ? blogCanonicalUrl($slug) : '';
        if ($canon === '') {
            // vazio é ok — shell normaliza; não conta como erro crítico
        } elseif ($expected && function_exists('blogNormalizeCanonical') && blogNormalizeCanonical($canon, $slug) !== $expected) {
            $postIssues[] = 'canonical_mismatch';
            $summary['missingCanonical']++;
        }
        $img = trim((string)($r['image_url'] ?? ''));
        $og = trim((string)($r['og_image'] ?? ''));
        if ($img === '') {
            $postIssues[] = 'missing_image';
            $summary['missingImage']++;
        }
        if ($og === '' && $img === '') {
            $postIssues[] = 'missing_og_image';
            $summary['missingOgImage']++;
        }
        if (trim((string)($r['meta_description'] ?? '')) === '' && trim((string)($r['excerpt'] ?? '')) === '') {
            $postIssues[] = 'missing_meta_description';
            $summary['missingMetaDescription']++;
        }
        if (trim((string)($r['meta_title'] ?? '')) === '' && trim((string)($r['title'] ?? '')) === '') {
            $postIssues[] = 'missing_meta_title';
            $summary['missingMetaTitle']++;
        }
        $bodyLen = mb_strlen(trim(strip_tags((string)($r['content'] ?? ''))));
        if ($bodyLen < 40 && function_exists('cmsBlocksToPlainText')) {
            $bodyLen = mb_strlen(cmsBlocksToPlainText(json_decode((string)($r['blocks'] ?? '[]'), true) ?: []));
        }
        if ($bodyLen < 300) {
            $postIssues[] = 'thin_content';
            $summary['thinContent']++;
        }
        $related = json_decode((string)($r['related'] ?? '[]'), true);
        if (!is_array($related) || count($related) < 1) {
            $postIssues[] = 'no_related';
            $summary['noRelated']++;
        }
        $ready = cmsBlogPostImageReady([
            'imageUrl' => $img,
            'imageStatus' => $r['image_status'] ?? 'completed',
        ]);
        if ($ready && $bodyLen >= 40) {
            $indexable++;
        } else {
            $postIssues[] = 'not_index_ready';
        }
        if ($postIssues) {
            $issues[] = [
                'slug' => $slug,
                'title' => $r['title'] ?? '',
                'issues' => $postIssues,
                'updatedAt' => $r['updated_at'] ?? null,
            ];
        }
    }
    return [
        'total' => count($rows),
        'indexable' => $indexable,
        'blocked' => max(0, count($rows) - $indexable),
        'issues' => $issues,
        'summary' => $summary,
        'auditedAt' => date('c'),
    ];
}

/** Sanitiza strings em blocos (ul/faq/h2/p…) contra copy redundante. */
function blogSanitizeBlocksRedundantCopy($blocks): array {
    if (is_string($blocks)) {
        $decoded = json_decode($blocks, true);
        $blocks = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($blocks)) {
        return [];
    }
    $stringKeys = ['text', 'content', 'title', 'caption', 'markdown', 'html', 'htmlContent'];
    $itemKeys = ['q', 'a', 'text', 'label', 'title', 'content'];
    foreach ($blocks as &$block) {
        if (!is_array($block)) {
            continue;
        }
        foreach ($stringKeys as $k) {
            if (!empty($block[$k]) && is_string($block[$k])) {
                $block[$k] = blogFixRedundantCopy($block[$k]);
            }
        }
        if (!empty($block['items']) && is_array($block['items'])) {
            foreach ($block['items'] as &$item) {
                if (is_string($item)) {
                    $item = blogFixRedundantCopy($item);
                    continue;
                }
                if (!is_array($item)) {
                    continue;
                }
                foreach ($itemKeys as $ik) {
                    if (!empty($item[$ik]) && is_string($item[$ik])) {
                        $item[$ik] = blogFixRedundantCopy($item[$ik]);
                    }
                }
            }
            unset($item);
        }
    }
    unset($block);
    return $blocks;
}

/**
 * Repara posts existentes com copy redundante (título, meta, excerpt, content, blocks).
 *
 * @return array{scanned:int,updated:int,slugs:string[]}
 */
function blogRepairPostsRedundantCopy(PDO $pdo, bool $dryRun = false): array {
    $pattern = '%igienização e higienização%';
    $st = $pdo->prepare(
        "SELECT slug, title, excerpt, content, blocks, meta_title, meta_description
         FROM blog_posts
         WHERE title LIKE ? OR excerpt LIKE ? OR content LIKE ? OR blocks LIKE ?
            OR meta_title LIKE ? OR meta_description LIKE ?"
    );
    $st->execute([$pattern, $pattern, $pattern, $pattern, $pattern, $pattern]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    $updated = 0;
    $slugs = [];
    foreach ($rows as $row) {
        $slug = (string)($row['slug'] ?? '');
        if ($slug === '') {
            continue;
        }
        $title = blogFixRedundantCopy((string)($row['title'] ?? ''));
        $excerpt = blogFixRedundantCopy((string)($row['excerpt'] ?? ''));
        $content = blogFixRedundantCopy((string)($row['content'] ?? ''));
        $metaTitle = blogFixRedundantCopy((string)($row['meta_title'] ?? ''));
        $metaDesc = blogFixRedundantCopy((string)($row['meta_description'] ?? ''));
        $blocksRaw = $row['blocks'] ?? '[]';
        $blocksArr = is_string($blocksRaw) ? json_decode($blocksRaw, true) : $blocksRaw;
        $blocksArr = blogSanitizeBlocksRedundantCopy(is_array($blocksArr) ? $blocksArr : []);
        $blocksJson = cmsJsonEncode($blocksArr, '[]');
        $changed = $title !== (string)($row['title'] ?? '')
            || $excerpt !== (string)($row['excerpt'] ?? '')
            || $content !== (string)($row['content'] ?? '')
            || $metaTitle !== (string)($row['meta_title'] ?? '')
            || $metaDesc !== (string)($row['meta_description'] ?? '')
            || $blocksJson !== (string)$blocksRaw;
        if (!$changed) {
            continue;
        }
        $slugs[] = $slug;
        if ($dryRun) {
            $updated++;
            continue;
        }
        $up = $pdo->prepare(
            'UPDATE blog_posts SET title=?, excerpt=?, content=?, blocks=?, meta_title=?, meta_description=?, updated_at=? WHERE slug=?'
        );
        $up->execute([$title, $excerpt, $content, $blocksJson, $metaTitle, $metaDesc, dbNow(), $slug]);
        $updated++;
    }
    return ['scanned' => count($rows), 'updated' => $updated, 'slugs' => $slugs];
}

function cmsBlogPostUpdateParams(array $b, string $now, ?int $uid, ?string $authorName, bool $allowJs): array {
    $rawContent = $b['content'] ?? null;
    if ((!is_string($rawContent) || trim(strip_tags((string)$rawContent)) === '') && !empty($b['blocks'])) {
        // Artigos IA às vezes vêm só com blocks — monta content textual completo
        $fromBlocks = cmsBlocksToPlainText($b['blocks']);
        if ($fromBlocks !== '') {
            $rawContent = $fromBlocks;
        }
    }
    $content = is_string($rawContent) ? sanitizeCmsHtml(blogFixRedundantCopy($rawContent) ?? $rawContent, $allowJs) : null;

    $blocksIn = blogSanitizeBlocksRedundantCopy($b['blocks'] ?? []);
    if (is_array($blocksIn) && count($blocksIn) > 120) {
        $blocksIn = array_slice($blocksIn, 0, 120);
    }
    $blocks = cmsJsonEncode($blocksIn, '[]');
    // Host compartilhado: evita packet too large
    if (strlen($blocks) > 900000) {
        $blocks = cmsJsonEncode(array_slice(is_array($blocksIn) ? $blocksIn : [], 0, 40), '[]');
    }

    // "" quebra DATE/DATETIME em MySQL strict → PDOException → "Erro interno do servidor"
    $publishedAt = $b['publishedAt'] ?? null;
    if (!is_string($publishedAt) || trim($publishedAt) === '') {
        $publishedAt = date('Y-m-d');
    } else {
        $publishedAt = substr(trim($publishedAt), 0, 10);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $publishedAt)) {
            $publishedAt = date('Y-m-d');
        }
    }

    $scheduledAt = $b['scheduledAt'] ?? null;
    if (!is_string($scheduledAt) || trim($scheduledAt) === '') {
        $scheduledAt = null;
    } else {
        $scheduledAt = str_replace('T', ' ', trim($scheduledAt));
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $scheduledAt)) {
            $scheduledAt .= ' 00:00:00';
        }
    }

    $tags = $b['tags'] ?? [];
    if (is_string($tags)) {
        $tags = array_values(array_filter(array_map('trim', explode(',', $tags))));
    }
    if (!is_array($tags)) $tags = [];

    $related = $b['related'] ?? [];
    if (is_string($related)) {
        $related = array_values(array_filter(array_map('trim', explode(',', $related))));
    }
    if (!is_array($related)) $related = [];

    $metaDescription = $b['metaDescription'] ?? null;
    if (is_string($metaDescription)) {
        $metaDescription = blogFixRedundantCopy(mb_substr(trim(strip_tags($metaDescription)), 0, 2000));
        if ($metaDescription === '') $metaDescription = null;
    } else {
        $metaDescription = null;
    }

    $title = blogFixRedundantCopy(san($b['title'] ?? null, 500)) ?? '';
    if ($title === '') {
        $title = 'Artigo sem título';
    }

    return [
        $title,
        blogFixRedundantCopy(san($b['excerpt'] ?? null, 2000)),
        $content,
        san($b['category'] ?? 'Outros', 100),
        san($b['iconName'] ?? 'BookOpen', 50),
        max(1, min(60, sanInt($b['readMinutes'] ?? 5))),
        $publishedAt,
        cmsJsonEncode($tags, '[]'),
        san($b['serviceId'] ?? null, 100),
        cmsPublicMediaUrl(san($b['imageUrl'] ?? null, 500)),
        cmsJsonEncode($related, '[]'),
        $blocks,
        blogFixRedundantCopy(san($b['metaTitle'] ?? null, 500)),
        $metaDescription,
        san($b['canonical'] ?? null, 500),
        cmsPublicMediaUrl(san($b['ogImage'] ?? ($b['imageUrl'] ?? null), 500)),
        san(($b['status'] ?? '') !== '' ? $b['status'] : 'published', 20),
        sanBool($b['featuredHome'] ?? false) ? 1 : 0,
        sanBool($b['featuredBlog'] ?? false) ? 1 : 0,
        $uid,
        $authorName,
        cmsJsonEncode(is_array($b['gallery'] ?? null) ? $b['gallery'] : [], '[]'),
        $scheduledAt,
        sanInt($b['categoryId'] ?? 0) ?: null,
        san($b['city'] ?? null, 100),
        san($b['neighborhood'] ?? null, 100),
        san(($b['contentLevel'] ?? '') !== '' ? $b['contentLevel'] : 'basico', 20),
        cmsJsonEncode(is_array($b['productsCited'] ?? null) ? $b['productsCited'] : [], '[]'),
        san($b['videoUrl'] ?? null, 500),
        san($b['keywords'] ?? null, 500),
        cmsJsonEncode(is_array($b['faqSchema'] ?? null) ? $b['faqSchema'] : [], '[]'),
        cmsJsonEncode(is_array($b['ctaConfig'] ?? null) ? $b['ctaConfig'] : (isset($b['ctaText']) ? ['text' => $b['ctaText']] : []), '{}'),
        $now,
    ];
}

function cmsSyncPostTags(PDO $pdo, string $slug, $tags): void {
    if (!is_array($tags)) {
        if (is_string($tags) && $tags !== '') {
            $tags = array_values(array_filter(array_map('trim', explode(',', $tags))));
        } else {
            $tags = [];
        }
    }
    if (!cmsTableExists($pdo, 'blog_post_tags') || !cmsTableExists($pdo, 'blog_tags')) {
        return;
    }
    $pdo->prepare('DELETE FROM blog_post_tags WHERE post_slug = ?')->execute([$slug]);
    foreach ($tags as $tag) {
        $name = is_string($tag) ? trim($tag) : '';
        if ($name === '') continue;
        $tslug = slugify($name);
        if ($tslug === '') continue;
        try {
            $pdo->prepare('INSERT IGNORE INTO blog_tags (slug, name, created_at) VALUES (?, ?, ?)')
                ->execute([$tslug, mb_substr($name, 0, 200), dbNow()]);
            $tid = $pdo->prepare('SELECT id FROM blog_tags WHERE slug = ?');
            $tid->execute([$tslug]);
            $tagId = $tid->fetchColumn();
            if ($tagId) {
                $pdo->prepare('INSERT IGNORE INTO blog_post_tags (post_slug, tag_id) VALUES (?, ?)')
                    ->execute([$slug, $tagId]);
            }
        } catch (Throwable $e) {
            appLog('warn', 'cms_sync_post_tags', ['err' => $e->getMessage(), 'slug' => $slug, 'tag' => $name]);
        }
    }
}

function decodeBlogPost(array $r): array {
    return [
        'slug'            => $r['slug'],
        'title'           => $r['title'],
        'excerpt'         => $r['excerpt'],
        'content'         => $r['content'],
        'category'        => $r['category'],
        'iconName'        => $r['icon_name'],
        'readMinutes'     => (int)$r['read_minutes'],
        'publishedAt'     => $r['published_at'],
        'tags'            => json_decode($r['tags'] ?? '[]', true) ?: [],
        'serviceId'       => $r['service_id'],
        'imageUrl'        => cmsPublicMediaUrl($r['image_url'] ?? null),
        'imagePrompt'     => $r['image_prompt'] ?? null,
        'imageStatus'     => $r['image_status'] ?? (trim((string)($r['image_url'] ?? '')) !== '' ? 'completed' : null),
        'imageProvider'   => $r['image_provider'] ?? null,
        'imageGeneratedAt'=> $r['image_generated_at'] ?? null,
        'related'         => json_decode($r['related'] ?? '[]', true) ?: [],
        'blocks'          => json_decode($r['blocks'] ?? '[]', true) ?: [],
        'metaTitle'       => $r['meta_title'] ?? null,
        'metaDescription' => $r['meta_description'] ?? null,
        'canonical'       => $r['canonical'] ?? null,
        'ogImage'         => cmsPublicMediaUrl($r['og_image'] ?? null),
        'status'          => $r['status'] ?? 'published',
        'featuredHome'    => (bool)($r['featured_home'] ?? 0),
        'featuredBlog'    => (bool)($r['featured_blog'] ?? 0),
        'authorId'        => isset($r['author_id']) ? (int)$r['author_id'] : null,
        'authorName'      => $r['author_name'] ?? null,
        'gallery'         => json_decode($r['gallery'] ?? '[]', true) ?: [],
        'scheduledAt'     => $r['scheduled_at'] ?? null,
        'categoryId'      => isset($r['category_id']) ? (int)$r['category_id'] : null,
        'city'            => $r['city'] ?? null,
        'neighborhood'    => $r['neighborhood'] ?? null,
        'contentLevel'    => $r['content_level'] ?? 'basico',
        'productsCited'   => json_decode($r['products_cited'] ?? '[]', true) ?: [],
        'videoUrl'          => $r['video_url'] ?? null,
        'keywords'          => $r['keywords'] ?? null,
        'faqSchema'         => json_decode($r['faq_schema'] ?? '[]', true) ?: [],
        'ctaConfig'         => json_decode($r['cta_config'] ?? '{}', true) ?: [],
        'isApiPost'       => true,
    ];
}

/** Base canônica do site (sem barra final). */
function blogSiteBaseUrl(): string {
    if (defined('SITE_URL') && is_string(SITE_URL) && trim(SITE_URL) !== '') {
        return rtrim(trim(SITE_URL), '/');
    }
    return 'https://autolimpezapro.com.br';
}

function blogCanonicalUrl(string $slug): string {
    $slug = trim($slug, '/');
    return blogSiteBaseUrl() . '/dicas/' . $slug;
}

/**
 * Canonical canônico — ignora URL inventada pela IA se inválida ou de outro host.
 */
function blogNormalizeCanonical(?string $canonical, string $slug): string {
    $expected = blogCanonicalUrl($slug);
    if (!is_string($canonical) || trim($canonical) === '') {
        return $expected;
    }
    $c = trim($canonical);
    if (!preg_match('#^https?://#i', $c)) {
        return $expected;
    }
    $host = parse_url($c, PHP_URL_HOST);
    $baseHost = parse_url(blogSiteBaseUrl(), PHP_URL_HOST);
    if (!$host || !$baseHost || strcasecmp((string)$host, (string)$baseHost) !== 0) {
        return $expected;
    }
    if (!preg_match('#/dicas/' . preg_quote($slug, '#') . '/?$#i', $c)) {
        return $expected;
    }
    return rtrim($c, '/');
}

/** Score espelhando src/lib/blog/nicheConfig.ts scoreRelatedPost */
function blogScoreRelatedPost(array $base, array $candidate): int {
    $baseSlug = (string)($base['slug'] ?? '');
    $candSlug = (string)($candidate['slug'] ?? '');
    if ($baseSlug === '' || $candSlug === '' || $baseSlug === $candSlug) {
        return -1;
    }
    $score = 0;
    if (($candidate['category'] ?? '') !== '' && ($candidate['category'] ?? '') === ($base['category'] ?? '')) {
        $score += 3;
    }
    if (!empty($base['city']) && ($candidate['city'] ?? '') === $base['city']) {
        $score += 4;
    }
    if (!empty($base['serviceId']) && ($candidate['serviceId'] ?? '') === $base['serviceId']) {
        $score += 3;
    }
    $baseTags = is_array($base['tags'] ?? null) ? $base['tags'] : [];
    $candTags = is_array($candidate['tags'] ?? null) ? $candidate['tags'] : [];
    foreach ($candTags as $t) {
        if (is_string($t) && in_array($t, $baseTags, true)) {
            $score += 2;
        }
    }
    return $score;
}

/**
 * Top-N slugs relacionados entre posts publicados (exclui o próprio).
 * @return list<array{slug:string,title:string,score:int}>
 */
function blogSuggestRelatedPosts(PDO $pdo, array $post, int $limit = 5): array {
    $limit = max(1, min(10, $limit));
    $slug = trim((string)($post['slug'] ?? ''), '-');
    if ($slug === '') {
        return [];
    }
    $base = [
        'slug' => $slug,
        'category' => (string)($post['category'] ?? ''),
        'tags' => is_array($post['tags'] ?? null) ? $post['tags'] : [],
        'serviceId' => $post['serviceId'] ?? null,
        'city' => $post['city'] ?? null,
    ];
    try {
        $st = $pdo->query(
            "SELECT slug, title, category, tags, service_id, city
             FROM blog_posts
             WHERE status = 'published' AND slug <> " . $pdo->quote($slug) . "
             ORDER BY published_at DESC
             LIMIT 80"
        );
        $rows = $st ? $st->fetchAll(PDO::FETCH_ASSOC) : [];
    } catch (Throwable $e) {
        appLog('warn', 'blog_suggest_related', ['err' => $e->getMessage()]);
        return [];
    }
    $scored = [];
    foreach ($rows as $r) {
        $cand = [
            'slug' => (string)$r['slug'],
            'category' => (string)($r['category'] ?? ''),
            'tags' => json_decode($r['tags'] ?? '[]', true) ?: [],
            'serviceId' => $r['service_id'] ?? null,
            'city' => $r['city'] ?? null,
        ];
        $score = blogScoreRelatedPost($base, $cand);
        if ($score <= 0) {
            continue;
        }
        $scored[] = [
            'slug' => $cand['slug'],
            'title' => (string)($r['title'] ?? $cand['slug']),
            'score' => $score,
        ];
    }
    usort($scored, static function ($a, $b) {
        return $b['score'] <=> $a['score'];
    });
    return array_slice($scored, 0, $limit);
}

function blogSuggestRelatedSlugs(PDO $pdo, array $post, int $limit = 5): array {
    return array_values(array_map(
        static fn(array $row): string => $row['slug'],
        blogSuggestRelatedPosts($pdo, $post, $limit)
    ));
}

/** Lista curta de slugs candidatos para o prompt da IA. */
function blogCandidateSlugsForPrompt(PDO $pdo, int $limit = 25): array {
    try {
        $st = $pdo->query(
            "SELECT slug, title, category FROM blog_posts
             WHERE status = 'published'
             ORDER BY published_at DESC
             LIMIT " . (int)max(5, min(40, $limit))
        );
        $rows = $st ? $st->fetchAll(PDO::FETCH_ASSOC) : [];
    } catch (Throwable $e) {
        return [];
    }
    $out = [];
    foreach ($rows as $r) {
        $s = trim((string)($r['slug'] ?? ''));
        if ($s === '') continue;
        $out[] = $s . '|' . mb_substr((string)($r['title'] ?? $s), 0, 80);
    }
    return $out;
}

/**
 * Anexa blocos linkP "Leia também" (2–3) se ainda não existirem no corpo.
 * @param list<array{slug:string,title:string}> $relatedPosts
 */
function blogAppendRelatedLinkBlocks(array $blocks, array $relatedPosts): array {
    if (!is_array($blocks)) {
        $blocks = [];
    }
    $existingSlugs = [];
    foreach ($blocks as $b) {
        if (!is_array($b)) continue;
        if (($b['type'] ?? '') === 'linkP' && !empty($b['slug'])) {
            $existingSlugs[(string)$b['slug']] = true;
        }
    }
    $toAdd = [];
    foreach ($relatedPosts as $row) {
        $s = is_array($row) ? (string)($row['slug'] ?? '') : (string)$row;
        $title = is_array($row) ? (string)($row['title'] ?? $s) : $s;
        if ($s === '' || isset($existingSlugs[$s])) {
            continue;
        }
        $toAdd[] = ['slug' => $s, 'title' => $title !== '' ? $title : $s];
        if (count($toAdd) >= 3) {
            break;
        }
    }
    if (!$toAdd) {
        return $blocks;
    }
    $hasHeading = false;
    foreach ($blocks as $b) {
        if (is_array($b) && ($b['type'] ?? '') === 'h2' && preg_match('/leia\s+tamb[eé]m/iu', (string)($b['text'] ?? ''))) {
            $hasHeading = true;
            break;
        }
    }
    if (!$hasHeading) {
        $blocks[] = ['type' => 'h2', 'text' => 'Leia também'];
    }
    foreach ($toAdd as $item) {
        $blocks[] = [
            'type' => 'linkP',
            'text' => 'Continue explorando: {{slug}}.',
            'slug' => $item['slug'],
            'linkLabel' => $item['title'],
        ];
    }
    return $blocks;
}

/**
 * Normaliza SEO + related + blocos internos no payload antes do save.
 * Mutates and returns $b.
 */
function blogEnrichPostForSeo(PDO $pdo, array $b): array {
    $slug = trim((string)($b['slug'] ?? ''), '-');
    if ($slug === '' && !empty($b['title'])) {
        $slug = slugify((string)$b['title']);
        $b['slug'] = $slug;
    }
    if ($slug === '') {
        return $b;
    }

    // keywords: tags como fallback
    $kw = $b['keywords'] ?? null;
    if ((!is_string($kw) || trim($kw) === '') && !empty($b['tags']) && is_array($b['tags'])) {
        $b['keywords'] = implode(', ', array_slice(array_values(array_filter(array_map('strval', $b['tags']))), 0, 12));
    }

    $b['canonical'] = blogNormalizeCanonical(
        isset($b['canonical']) && is_string($b['canonical']) ? $b['canonical'] : null,
        $slug
    );

    $related = $b['related'] ?? [];
    if (is_string($related)) {
        $related = array_values(array_filter(array_map('trim', explode(',', $related))));
    }
    if (!is_array($related)) {
        $related = [];
    }
    $related = array_values(array_filter(array_map('strval', $related), static fn($s) => $s !== '' && $s !== $slug));

    $suggested = blogSuggestRelatedPosts($pdo, array_merge($b, ['slug' => $slug]), 5);
    $found = [];
    if (count($related) === 0) {
        $related = array_map(static fn($r) => $r['slug'], $suggested);
    } else {
        // Filtra slugs inventados que não existem
        try {
            $placeholders = implode(',', array_fill(0, count($related), '?'));
            $st = $pdo->prepare("SELECT slug, title FROM blog_posts WHERE status = 'published' AND slug IN ($placeholders)");
            $st->execute($related);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $found[(string)$row['slug']] = (string)$row['title'];
            }
            $valid = [];
            foreach ($related as $s) {
                if (isset($found[$s])) {
                    $valid[] = $s;
                }
            }
            $related = $valid;
        } catch (Throwable $e) {
            /* mantém related da IA */
        }
        if (count($related) < 3) {
            foreach ($suggested as $row) {
                if (!in_array($row['slug'], $related, true)) {
                    $related[] = $row['slug'];
                }
                if (count($related) >= 5) {
                    break;
                }
            }
        }
    }
    $b['related'] = array_values(array_slice($related, 0, 5));

    // Monta lista title+slug para linkP
    $relatedForBlocks = [];
    $titleBySlug = $found;
    foreach ($suggested as $row) {
        if (!isset($titleBySlug[$row['slug']])) {
            $titleBySlug[$row['slug']] = $row['title'];
        }
    }
    // Busca títulos faltantes
    $needTitles = array_values(array_filter($b['related'], static fn($s) => !isset($titleBySlug[$s])));
    if ($needTitles) {
        try {
            $ph = implode(',', array_fill(0, count($needTitles), '?'));
            $st = $pdo->prepare("SELECT slug, title FROM blog_posts WHERE slug IN ($ph)");
            $st->execute($needTitles);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $titleBySlug[(string)$row['slug']] = (string)$row['title'];
            }
        } catch (Throwable $e) {
            /* ignore */
        }
    }
    foreach ($b['related'] as $s) {
        $relatedForBlocks[] = [
            'slug' => $s,
            'title' => $titleBySlug[$s] ?? $s,
        ];
    }

    $blocks = $b['blocks'] ?? [];
    if (is_string($blocks)) {
        $decoded = json_decode($blocks, true);
        $blocks = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($blocks)) {
        $blocks = [];
    }
    $b['blocks'] = blogAppendRelatedLinkBlocks($blocks, $relatedForBlocks);

    // Afiliados: só quando pedido explicitamente (IA / botão "Injetar links").
    // Evita reinserir linkE em todo save do CMS após o editor remover o bloco.
    if (!empty($b['applyAffiliateLinks']) && function_exists('blogAffiliateLinksEnrichPost')) {
        $b = blogAffiliateLinksEnrichPost($pdo, $b);
    }

    return $b;
}
