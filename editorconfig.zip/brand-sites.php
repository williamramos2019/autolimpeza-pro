<?php
/**
 * Sites da marca Auto Limpeza Pro — allowlist de hostnames.
 * Fonte PHP (SEO/sitemap/leads). Espelhar hosts e paths em src/sites/.
 */
declare(strict_types=1);

function alpBrandSitesCatalog(): array
{
    static $catalog = null;
    if ($catalog !== null) {
        return $catalog;
    }

    $phone = '5531980252882';
    $email = 'contato@autolimpezapro.com.br';
    $og = '/og-mascote.png?v=1';

    $catalog = [
        'principal' => [
            'id' => 'principal',
            'label' => 'principal',
            'name' => 'Auto Limpeza Pro',
            'tagline' => 'Higienização de estofados e estética automotiva',
            'origin' => 'https://autolimpezapro.com.br',
            'hosts' => [
                'autolimpezapro.com.br',
                'www.autolimpezapro.com.br',
            ],
            'ogImage' => $og,
            'whatsapp' => $phone,
            'email' => $email,
            'waDefault' => 'Olá! Quero um orçamento de higienização de estofados ou estética automotiva com a Auto Limpeza Pro.',
        ],
        'telhados' => [
            'id' => 'telhados',
            'label' => 'telhados',
            'name' => 'Auto Limpeza Pro — Telhados',
            'tagline' => 'Limpeza de telhados e placas solares em São José da Lapa e Vespasiano',
            'origin' => 'https://telhados.autolimpezapro.com.br',
            'hosts' => [
                'telhados.autolimpezapro.com.br',
                'telhados.localhost',
                'telhados.local',
            ],
            'ogImage' => $og,
            'whatsapp' => $phone,
            'email' => $email,
            'waDefault' => 'Olá! Quero um orçamento de limpeza de telhado ou de placas solares com a Auto Limpeza Pro (site de telhados).',
        ],
    ];
    return $catalog;
}

function alpNormalizeSiteId(?string $raw): ?string
{
    $id = strtolower(trim((string)$raw));
    if ($id === 'telhado' || $id === 'solar' || $id === 'placas' || $id === 'placas-solares') {
        $id = 'telhados';
    }
    if ($id === 'main' || $id === 'default') {
        $id = 'principal';
    }
    $catalog = alpBrandSitesCatalog();
    return isset($catalog[$id]) ? $id : null;
}

function alpRequestHost(): string
{
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    $host = preg_replace('/:\d+$/', '', $host) ?? $host;
    return $host;
}

function alpAllowSiteOverride(): bool
{
    if (defined('APP_DEBUG') && APP_DEBUG) {
        return true;
    }
    $host = alpRequestHost();
    return $host === 'localhost' || $host === '127.0.0.1' || str_ends_with($host, '.localhost');
}

function alpCurrentSiteId(): string
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }

    if (alpAllowSiteOverride()) {
        $q = alpNormalizeSiteId($_GET['site'] ?? null);
        if ($q) {
            $cached = $q;
            return $cached;
        }
    }

    $header = alpNormalizeSiteId($_SERVER['HTTP_X_BRAND_SITE'] ?? null);
    if ($header && alpAllowSiteOverride()) {
        $cached = $header;
        return $cached;
    }

    $host = alpRequestHost();
    foreach (alpBrandSitesCatalog() as $id => $site) {
        foreach ($site['hosts'] as $allowed) {
            if ($host === strtolower((string)$allowed)) {
                $cached = $id;
                return $cached;
            }
        }
    }

    $cached = 'principal';
    return $cached;
}

function alpCurrentBrandSite(): array
{
    $catalog = alpBrandSitesCatalog();
    $id = alpCurrentSiteId();
    return $catalog[$id] ?? $catalog['principal'];
}

function alpSiteOrigin(?string $siteId = null): string
{
    $id = alpNormalizeSiteId($siteId) ?? alpCurrentSiteId();
    $site = alpBrandSitesCatalog()[$id] ?? alpBrandSitesCatalog()['principal'];
    return rtrim((string)$site['origin'], '/');
}

function alpTelhadosPublicPages(): array
{
    $name = 'Auto Limpeza Pro — Telhados';
    return [
        '/' => [
            'title' => 'Limpeza de telhados e placas solares em São José da Lapa e Vespasiano | ' . $name,
            'description' => 'Orçamento de limpeza de telhado e de placas solares em São José da Lapa e Vespasiano, MG. Avaliação no local. Sem fotos de obras inventadas.',
            'index' => true,
            'priority' => '1.0',
            'h1' => 'Limpeza de telhados e placas solares na região norte da Grande BH',
            'body' => 'A Auto Limpeza Pro atende limpeza de telhados e de placas solares em São José da Lapa e Vespasiano. O valor depende da área, do acesso, do tipo de cobertura e da quantidade de placas — o orçamento sai após avaliação (Sob avaliação). Este site não trata de sofás, estofados nem estética automotiva: isso fica em autolimpezapro.com.br. Não prometemos ganho percentual de geração solar.',
        ],
        '/servicos' => [
            'title' => 'Serviços: telhado e placas solares | ' . $name,
            'description' => 'Limpeza de telhado e limpeza de placas solares em São José da Lapa e Vespasiano. Orçamento após visita ou fotos do local. Valor sob avaliação.',
            'index' => true,
            'priority' => '0.9',
            'h1' => 'Serviços de telhado e placas solares',
            'body' => 'Dois serviços neste site: limpeza de telhado e limpeza de placas solares. Não listamos produtos químicos nem métodos não confirmados pela operação. Na visita alinhamos o que será feito, o acesso e o valor (Sob avaliação) antes de começar.',
        ],
        '/servicos/limpeza-de-telhado' => [
            'title' => 'Limpeza de telhado residencial e comercial | ' . $name,
            'description' => 'Limpeza de telhado em São José da Lapa e Vespasiano. Avaliação no local, orçamento antes do serviço. Atendimento pela Auto Limpeza Pro.',
            'index' => true,
            'priority' => '0.9',
            'h1' => 'Limpeza de telhado',
            'body' => 'Limpamos coberturas residenciais e comerciais na região. Cada telhado é diferente (inclinação, telha, altura, vegetação). Não prometemos resultado padronizado nem publicamos fotos de trabalhos que não estejam no acervo da empresa. Peça orçamento com endereço, cidade e, se possível, fotos.',
        ],
        '/servicos/limpeza-de-placas-solares' => [
            'title' => 'Limpeza de placas solares | ' . $name,
            'description' => 'Limpeza de placas solares em São José da Lapa e Vespasiano. Orçamento após avaliação no local. Sem promessa de ganho percentual de geração.',
            'index' => true,
            'priority' => '0.9',
            'h1' => 'Limpeza de placas solares',
            'body' => 'Limpamos módulos fotovoltaicos residenciais e comerciais na região quando o acesso for seguro. Quantidade de placas, altura, inclinação e sujeira mudam o trabalho. O valor fica Sob avaliação até a visita. Não prometemos percentual de geração extra nem métodos que a operação não confirmou.',
        ],
        '/faq' => [
            'title' => 'Perguntas frequentes — limpeza de telhado | ' . $name,
            'description' => 'Dúvidas frequentes sobre orçamento, cidades atendidas e como solicitar limpeza de telhado em São José da Lapa e Vespasiano.',
            'index' => true,
            'priority' => '0.7',
            'h1' => 'Perguntas frequentes',
            'body' => 'Respondemos com o que a operação confirma hoje: atendimento nas cidades listadas, orçamento após entender o telhado, pagamento combinado na proposta. Não há depoimentos fictícios nesta página.',
        ],
        '/contato' => [
            'title' => 'Contato — limpeza de telhados | ' . $name,
            'description' => 'Fale no WhatsApp ou envie nome, telefone e cidade para orçamento de limpeza de telhado em São José da Lapa ou Vespasiano.',
            'index' => true,
            'priority' => '0.8',
            'h1' => 'Pedir orçamento de limpeza de telhado',
            'body' => 'WhatsApp (31) 98025-2882. Informe cidade, tipo de imóvel e, se puder, fotos do telhado. As solicitações deste site são identificadas como origem telhados.',
        ],
        '/sao-jose-da-lapa' => [
            'title' => 'Limpeza de telhado em São José da Lapa, MG | ' . $name,
            'description' => 'Limpeza de telhado em São José da Lapa, na Região Metropolitana de Belo Horizonte. Como pedir orçamento e o que informar antes da visita.',
            'index' => true,
            'priority' => '0.85',
            'h1' => 'Limpeza de telhado e placas solares em São José da Lapa',
            'body' => 'São José da Lapa concentra casas e sobrados na porção norte da RMBH. Folhas, poeira e períodos secos deixam a cobertura e os módulos aparentes — o que precisa ser feito só é definido na visita. Esta página não é a landing de sofá do site principal.',
        ],
        '/vespasiano' => [
            'title' => 'Limpeza de telhado e placas solares em Vespasiano, MG | ' . $name,
            'description' => 'Limpeza de telhado e de placas solares em Vespasiano, MG. Orçamento local. Informe acesso, quantidade de placas e fotos se possível.',
            'index' => true,
            'priority' => '0.85',
            'h1' => 'Limpeza de telhado em Vespasiano',
            'body' => 'Vespasiano tem malha urbana mais densa e mistura de residências com imóveis comerciais. Acesso por rua, altura e tipo de telha mudam o tempo de serviço. Esta página é só sobre telhado em Vespasiano; estofados e estética automotiva continuam em autolimpezapro.com.br.',
        ],
        '/dicas' => [
            'title' => 'Dicas de limpeza de telhado | ' . $name,
            'description' => 'Artigos sobre como solicitar limpeza de telhado em São José da Lapa e Vespasiano. Sem misturar conteúdo do blog de estofados.',
            'index' => true,
            'priority' => '0.6',
            'h1' => 'Blog de telhados',
            'body' => 'Aqui entram só textos deste site. Artigos incompletos ficam fora do sitemap e com noindex.',
        ],
        '/dicas/orcamento-limpeza-de-telhado' => [
            'title' => 'Como pedir orçamento de limpeza de telhado | ' . $name,
            'description' => 'O que informar no WhatsApp para orçar limpeza de telhado em São José da Lapa e Vespasiano: cidade, acesso, fotos e tipo de imóvel.',
            'index' => true,
            'priority' => '0.7',
            'h1' => 'Como pedir orçamento de limpeza de telhado',
            'body' => 'Envie cidade (São José da Lapa ou Vespasiano), se é casa ou comércio, se há acesso seguro e fotos gerais da cobertura. Não precisamos de “diagnóstico caseiro”. O valor sai depois que entendemos o telhado. Não descrevemos produtos nem técnicas não confirmadas.',
        ],
        '/dicas/orcamento-limpeza-de-placas-solares' => [
            'title' => 'Como pedir orçamento de limpeza de placas solares | ' . $name,
            'description' => 'O que informar para orçar limpeza de placas solares: cidade, quantidade aproximada de módulos, acesso e fotos. Sem promessa de ganho percentual.',
            'index' => true,
            'priority' => '0.7',
            'h1' => 'Como pedir orçamento de limpeza de placas solares',
            'body' => 'Informe a cidade, a quantidade aproximada de placas, se o acesso ao telhado é seguro e envie fotos gerais. O valor fica Sob avaliação. Não prometemos ganho percentual de geração solar.',
        ],
        '/ajuda' => [
            'title' => 'Ajuda | ' . $name,
            'description' => 'Central de ajuda do site de limpeza de telhados da Auto Limpeza Pro.',
            'index' => true,
            'priority' => '0.4',
            'h1' => 'Ajuda',
            'body' => 'Para orçamento de telhado use Contato ou WhatsApp. O site principal de estofados é autolimpezapro.com.br.',
        ],
        '/politica-privacidade' => [
            'title' => 'Política de privacidade | ' . $name,
            'description' => 'Como tratamos dados enviados neste site de limpeza de telhados (nome, telefone, cidade e fotos).',
            'index' => true,
            'priority' => '0.3',
            'h1' => 'Privacidade',
            'body' => 'Solicitações deste domínio são da Auto Limpeza Pro, identificadas como origem telhados. Usamos nome, telefone, endereço e fotos só para orçar e atender o serviço. Contato: contato@autolimpezapro.com.br.',
        ],
        '/termos' => [
            'title' => 'Termos de uso | ' . $name,
            'description' => 'Termos de uso do site de limpeza de telhados da Auto Limpeza Pro.',
            'index' => true,
            'priority' => '0.3',
            'h1' => 'Termos',
            'body' => 'O conteúdo descreve serviços de limpeza de telhado. Orçamento não é contrato até confirmação. Preços não listados nesta página exigem avaliação.',
        ],
        '/lgpd' => [
            'title' => 'LGPD | ' . $name,
            'description' => 'Informações LGPD para dados coletados no site de telhados.',
            'index' => true,
            'priority' => '0.3',
            'h1' => 'LGPD',
            'body' => 'Você pode pedir acesso ou exclusão dos dados da solicitação pelo WhatsApp ou e-mail contato@autolimpezapro.com.br.',
        ],
        '/cookies' => [
            'title' => 'Cookies | ' . $name,
            'description' => 'Uso de cookies neste site de limpeza de telhados.',
            'index' => true,
            'priority' => '0.2',
            'h1' => 'Cookies',
            'body' => 'Usamos cookies técnicos de sessão e, se configurado, medição. Não vendemos listas de contato.',
        ],
    ];
}

function alpNormalizePublicPath(string $path): string
{
    $path = '/' . trim($path, '/');
    if ($path === '/') {
        return '/';
    }
    return rtrim($path, '/') ?: '/';
}

function alpTelhadosPageMeta(string $path): ?array
{
    $pages = alpTelhadosPublicPages();
    $norm = alpNormalizePublicPath($path);
    return $pages[$norm] ?? null;
}

function alpIsTelhadosPublicPath(string $path): bool
{
    return alpTelhadosPageMeta($path) !== null;
}

function alpPrincipalForbiddenOnTelhados(string $path): bool
{
    $norm = alpNormalizePublicPath($path);
    // Só landings SEO do site de estofados — o painel e as funções do app são as mesmas nos dois hosts.
    if (preg_match('#^/(higienizacao|impermeabilizacao|estetica|promocao)(-|$)#', $norm)) {
        return true;
    }
    $blocked = [
        '/higienizacao-sao-jose-da-lapa',
        '/higienizacao-vespasiano',
        '/higienizacao-colchoes-sao-jose-da-lapa',
        '/higienizacao-colchoes-vespasiano',
        '/estetica-automotiva-vespasiano',
        '/impermeabilizacao-vespasiano',
        '/limpeza-pos-obra-vespasiano',
        '/limpeza-sofas-residenciais',
        '/limpeza-estofados-comerciais',
    ];
    return in_array($norm, $blocked, true);
}

/** Cláusula SQL para posts do site atual (principal inclui NULL legado). */
function alpBlogSiteWhere(string $alias = ''): array
{
    $col = ($alias !== '' ? $alias . '.' : '') . 'site_id';
    $id = alpCurrentSiteId();
    if ($id === 'telhados') {
        return ["{$col} = ?", ['telhados']];
    }
    return ["({$col} IS NULL OR {$col} = '' OR {$col} = 'principal')", []];
}

function alpEnsureBrandSiteColumns(?PDO $pdo = null): void
{
    try {
        $pdo = $pdo ?? db();
    } catch (Throwable $e) {
        return;
    }
    $adds = [
        ['leads', 'site_id', "ALTER TABLE leads ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal'"],
        ['appointments', 'site_id', "ALTER TABLE appointments ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal'"],
        ['blog_posts', 'site_id', "ALTER TABLE blog_posts ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal'"],
        ['visits', 'site_id', "ALTER TABLE visits ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal'"],
        ['analytics', 'site_id', "ALTER TABLE analytics ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal'"],
        ['conversion_events', 'site_id', "ALTER TABLE conversion_events ADD COLUMN site_id VARCHAR(32) NOT NULL DEFAULT 'principal'"],
    ];
    foreach ($adds as [$table, $col, $sql]) {
        try {
            if (!function_exists('cmsTableExists') || !cmsTableExists($pdo, $table)) {
                continue;
            }
            $st = $pdo->query("SHOW COLUMNS FROM `{$table}` LIKE " . $pdo->quote($col));
            if ($st && $st->fetch()) {
                continue;
            }
            $pdo->exec($sql);
        } catch (Throwable $e) {
            if (function_exists('appLog')) {
                appLog('warn', 'brand_site_column', ['table' => $table, 'err' => $e->getMessage()]);
            }
        }
    }
}

/** Filtro de listagem admin: null = todos os sites. Público: hostname. */
function alpSiteListClause(string $col = 'site_id'): array
{
    $admin = function_exists('isAdmin') && isAdmin();
    if ($admin) {
        $raw = strtolower(trim((string)($_GET['site_id'] ?? '')));
        if ($raw === '' || $raw === 'all') {
            return ['1=1', []];
        }
        $id = alpNormalizeSiteId($raw);
        if (!$id) {
            return ['1=1', []];
        }
        if ($id === 'principal') {
            return ["({$col} IS NULL OR {$col} = '' OR {$col} = 'principal')", []];
        }
        return ["{$col} = ?", [$id]];
    }
    $id = alpCurrentSiteId();
    if ($id === 'telhados') {
        return ["{$col} = ?", ['telhados']];
    }
    return ["({$col} IS NULL OR {$col} = '' OR {$col} = 'principal')", []];
}

/**
 * Gravação de site_id.
 * Público (produção): só hostname. Admin autenticado: body site_id permitido.
 */
function alpResolveWriteSiteId(array $body = []): string
{
    $fromBody = alpNormalizeSiteId($body['site_id'] ?? $body['siteId'] ?? null);
    if (function_exists('isAdmin') && isAdmin() && $fromBody) {
        return $fromBody;
    }
    if (alpAllowSiteOverride() && $fromBody) {
        return $fromBody;
    }
    return alpCurrentSiteId();
}

function alpAppendSiteClause(string $sql, array $params, string $col = 'site_id'): array
{
    [$clause, $extra] = alpSiteListClause($col);
    if (preg_match('/\bwhere\b/i', $sql)) {
        $sql .= ' AND ' . $clause;
    } else {
        $sql .= ' WHERE ' . $clause;
    }
    return [$sql, array_merge($params, $extra)];
}

/** Rotas de app compartilhadas no subdomínio — 200 + noindex (não entram no sitemap). */
function alpTelhadosPrivatePrefixes(): array
{
    return [
        '/admin', '/agenda', '/caixa', '/vendas', '/perfil', '/financas', '/analytics',
        '/conversao', '/crm-admin', '/capitao-clean', '/guardiao-admin', '/clima-admin',
        '/prospeccao-admin', '/automacoes-central', '/dashboard-exec', '/blog-admin',
        '/cms-admin', '/article-generator', '/ai-chat', '/push-admin', '/comunicacao-admin',
        '/desafio-admin', '/inovacoes', '/vistoria-admin', '/ux-admin', '/sistema-admin',
        '/site-admin', '/conta', '/v', '/desafio', '/hall-da-fama', '/r',
        '/diagnostico-manchas', '/calculadora-vida-util', '/passaporte', '/garantia',
        '/fidelidade', '/planos-de-assinatura', '/planos-empresariais',
        '/avaliacoes', '/videos', '/antes-e-depois', '/transformacoes',
        '/mapa-do-site', '/sobre', '/sobre-a-auto-limpeza-pro', '/meu-agendamento',
    ];
}
