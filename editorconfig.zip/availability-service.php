<?php
/**
 * AvailabilityService — fonte única de disponibilidade (Agenda, Widget, CRM, API).
 * Usa appointments + schedule_config (working hours, fixed slots, conflitos).
 */
require_once __DIR__ . '/schedule-handlers.php';

/** Duração em minutos para um serviço (ou fallback). */
function availabilityServiceDuration(PDO $pdo, ?string $serviceId, int $fallback = 150): int {
    if ($serviceId === null || $serviceId === '') {
        return max(1, $fallback);
    }
    $cfg = getScheduleConfig($pdo);
    return max(1, (int) ($cfg['serviceDurations'][$serviceId] ?? $fallback));
}

/** Horários livres em um dia — mesma lógica da Agenda e do wizard. */
function availabilityServiceDaySlots(PDO $pdo, string $date, int $duration, ?string $excludeId = null): array {
    return generateAvailableSlots($pdo, $date, $duration, $excludeId);
}

/** Próximos N slots (data+hora) a partir de hoje. */
function availabilityServiceNextSlots(PDO $pdo, int $duration, int $max = 3, ?string $serviceId = null): array {
    if ($serviceId !== null && $serviceId !== '') {
        $duration = availabilityServiceDuration($pdo, $serviceId, $duration);
    }
    return collectNextAvailableSlots($pdo, $duration, $max);
}

/** Snapshot de disponibilidade para uma data (API schedule/availability). */
function availabilityServiceSnapshot(
    PDO $pdo,
    string $date,
    int $duration,
    ?string $excludeId = null,
    ?string $time = null,
): array {
    $available = availabilityServiceDaySlots($pdo, $date, $duration, $excludeId);
    $blocking = getBlockingAppointmentsForDate($pdo, $date, $excludeId);
    // Público: nunca expor nome/telefone/e-mail do cliente (só janela ocupada).
    $occupied = array_map(static function ($row) {
        $start = $row['time'];
        $endMin = appointmentEndMinutes($row);
        return [
            'time'     => $start,
            'duration' => (int) $row['duration'],
            'end'      => scheduleMinutesToTime($endMin),
        ];
    }, $blocking);

    $conflict = false;
    $conflictReason = null;
    $suggestions = [];
    if ($time) {
        $conflictReason = appointmentSlotBlockReason($pdo, $date, $time, $duration, $excludeId);
        $conflict = $conflictReason !== null;
        if ($conflict) {
            $suggestions = suggestAlternativeSlots($pdo, $date, $time, $duration, 4, $excludeId);
        }
    }

    $emptyReason = null;
    if (count($available) === 0) {
        $cfg = getScheduleConfig($pdo);
        $candidateStarts = $cfg['fixedSlotStarts'] ?? ['08:00', '10:30', '13:00', '15:30'];
        $hoursBlocked = 0;
        $feasible = 0;
        $feasibleBooked = 0;
        foreach ($candidateStarts as $slot) {
            $r = appointmentSlotBlockReason($pdo, $date, $slot, $duration, $excludeId);
            if ($r === 'outside_hours' || $r === 'lunch') {
                $hoursBlocked++;
                continue;
            }
            // Cabe no expediente (livre ou só ocupado)
            $feasible++;
            if ($r === 'booked') {
                $feasibleBooked++;
            }
        }
        // Nenhum início cabe na duração → não é “dia lotado”
        if ($feasible === 0 || $hoursBlocked >= count($candidateStarts)) {
            $emptyReason = 'duration_or_hours';
        } elseif ($feasible > 0 && $feasibleBooked >= $feasible) {
            $emptyReason = 'fully_booked';
        } elseif (count($occupied) > 0 && $feasibleBooked > 0) {
            $emptyReason = 'fully_booked';
        } else {
            $emptyReason = 'no_slots';
        }
    }

    return [
        'date'            => $date,
        'duration'        => $duration,
        'available'       => $available,
        'occupied'        => $occupied,
        'conflict'        => $conflict,
        'conflictReason'  => $conflictReason,
        'suggestions'     => $suggestions,
        'emptyReason'     => $emptyReason,
        'config'          => getScheduleConfig($pdo),
    ];
}
