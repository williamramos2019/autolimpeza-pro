<?php
/**
 * Slack Incoming Webhooks — canal paralelo da Central de Notificações (MVP).
 * Falha no Slack nunca bloqueia push / e-mail / WhatsApp / Telegram.
 */

function slackEnsureConfigTable(PDO $pdo): void {
    static $done = false;
    if ($done) return;

    $pdo->exec("CREATE TABLE IF NOT EXISTS `notification_slack_config` (
        `id` TINYINT UNSIGNED NOT NULL DEFAULT 1,
        `enabled` TINYINT(1) NOT NULL DEFAULT 0,
        `webhook_url_enc` TEXT DEFAULT NULL,
        `bot_token_enc` TEXT DEFAULT NULL,
        `default_channel_id` VARCHAR(80) DEFAULT NULL,
        `workspace_label` VARCHAR(120) DEFAULT NULL,
        `default_channel_label` VARCHAR(120) DEFAULT NULL,
        `bot_username` VARCHAR(80) DEFAULT NULL,
        `icon_emoji` VARCHAR(40) DEFAULT NULL,
        `min_priority` VARCHAR(20) NOT NULL DEFAULT 'info',
        `environment` VARCHAR(20) NOT NULL DEFAULT 'production',
        `webhooks_by_topic` JSON DEFAULT NULL,
        `auto_send` TINYINT(1) NOT NULL DEFAULT 1,
        `connection_status` VARCHAR(30) NOT NULL DEFAULT 'disconnected',
        `last_test_at` DATETIME DEFAULT NULL,
        `last_test_status` VARCHAR(20) DEFAULT NULL,
        `last_test_error` VARCHAR(500) DEFAULT NULL,
        `last_test_duration_ms` INT UNSIGNED DEFAULT NULL,
        `last_error` VARCHAR(500) DEFAULT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    slackEnsureBotColumns($pdo);

    $row = $pdo->query("SELECT id FROM notification_slack_config WHERE id = 1")->fetch();
    if (!$row) {
        $env = defined('APP_ENV') ? (string)APP_ENV : 'production';
        if (!in_array($env, ['development', 'staging', 'production'], true)) {
            $env = 'production';
        }
        $pdo->prepare("INSERT INTO notification_slack_config
            (id, enabled, auto_send, min_priority, environment, connection_status, updated_at)
            VALUES (1, 0, 1, 'info', ?, 'disconnected', ?)")
            ->execute([$env, function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s')]);
    }

    $done = true;
}

/** Colunas Bot Token + Channel ID (fallback da Web API). */
function slackEnsureBotColumns(PDO $pdo): void {
    static $colsDone = false;
    if ($colsDone) return;
    $add = static function (PDO $pdo, string $name, string $ddl): void {
        try {
            $st = $pdo->query("SHOW COLUMNS FROM notification_slack_config LIKE " . $pdo->quote($name));
            if ($st && $st->fetch()) return;
            $pdo->exec("ALTER TABLE notification_slack_config ADD COLUMN {$ddl}");
        } catch (Throwable $e) {
            if (function_exists('appLog')) {
                appLog('warning', 'slack_alter_column', ['col' => $name, 'err' => $e->getMessage()]);
            }
        }
    };
    $add($pdo, 'bot_token_enc', '`bot_token_enc` TEXT DEFAULT NULL AFTER `webhook_url_enc`');
    $add($pdo, 'default_channel_id', '`default_channel_id` VARCHAR(80) DEFAULT NULL AFTER `bot_token_enc`');
    $colsDone = true;
}

/** Alias usado pelo ensure schema / repair */
function ensureSlackTables(PDO $pdo): void {
    slackEnsureConfigTable($pdo);
}

function slackEncryptSecret(string $plain): string {
    if (!function_exists('encryptMailSecret')) {
        require_once __DIR__ . '/mail-handlers.php';
    }
    return encryptMailSecret($plain);
}

function slackDecryptSecret(string $stored): string {
    if ($stored === '') return '';
    if (!function_exists('decryptMailSecret')) {
        require_once __DIR__ . '/mail-handlers.php';
    }
    $dec = decryptMailSecret($stored);
    if ($dec !== '') return $dec;
    // Legado / fallback: URL plaintext ou base64 simples
    if (preg_match('#^https://hooks\.slack\.com/#i', $stored)) {
        return $stored;
    }
    $raw = base64_decode($stored, true);
    if (is_string($raw) && preg_match('#^https://hooks\.slack\.com/#i', $raw)) {
        return $raw;
    }
    return '';
}

/** @return array<string,mixed> */
function slackGetConfigRow(PDO $pdo): array {
    slackEnsureConfigTable($pdo);
    return $pdo->query("SELECT * FROM notification_slack_config WHERE id = 1")->fetch(PDO::FETCH_ASSOC) ?: [];
}

function slackGetWebhookUrl(PDO $pdo): string {
    $cfg = slackGetConfigRow($pdo);
    return slackDecryptSecret((string)($cfg['webhook_url_enc'] ?? ''));
}

function slackGetBotToken(PDO $pdo): string {
    $cfg = slackGetConfigRow($pdo);
    $tok = slackDecryptSecret((string)($cfg['bot_token_enc'] ?? ''));
    if ($tok === '' && preg_match('#^xoxb-#', (string)($cfg['bot_token_enc'] ?? ''))) {
        $tok = (string)$cfg['bot_token_enc'];
    }
    return $tok;
}

function slackGetChannelId(PDO $pdo): string {
    $cfg = slackGetConfigRow($pdo);
    return trim((string)($cfg['default_channel_id'] ?? ''));
}

function slackWebhookConfigured(PDO $pdo): bool {
    $url = slackGetWebhookUrl($pdo);
    return $url !== '' && (bool)preg_match('#^https://hooks\.slack\.com/#i', $url);
}

function slackBotConfigured(PDO $pdo): bool {
    $tok = slackGetBotToken($pdo);
    $ch = slackGetChannelId($pdo);
    return $tok !== '' && (bool)preg_match('#^xoxb-#', $tok) && $ch !== '';
}

function slackIsConfigured(PDO $pdo): bool {
    return slackWebhookConfigured($pdo) || slackBotConfigured($pdo);
}

function slackIsEnabled(PDO $pdo): bool {
    $cfg = slackGetConfigRow($pdo);
    return !empty($cfg['enabled']) && slackIsConfigured($pdo);
}

function slackAutoSend(PDO $pdo): bool {
    $cfg = slackGetConfigRow($pdo);
    return !empty($cfg['auto_send']);
}

function slackEnvironmentAllowed(PDO $pdo): bool {
    $cfg = slackGetConfigRow($pdo);
    $want = strtolower(trim((string)($cfg['environment'] ?? 'production')));
    if ($want === '') $want = 'production';
    $app = defined('APP_ENV') ? strtolower((string)APP_ENV) : 'production';
    return $want === $app;
}

/**
 * Config pública (sem webhook em claro).
 * @return array<string,mixed>
 */
function slackGetConfigPublic(PDO $pdo): array {
    $cfg = slackGetConfigRow($pdo);
    $topics = $cfg['webhooks_by_topic'] ?? null;
    if (is_string($topics)) {
        $decoded = json_decode($topics, true);
        $topics = is_array($decoded) ? $decoded : null;
    }
    return [
        'enabled' => !empty($cfg['enabled']),
        'auto_send' => !empty($cfg['auto_send']),
        'webhook_configured' => slackWebhookConfigured($pdo),
        'bot_configured' => slackBotConfigured($pdo),
        'default_channel_id' => slackGetChannelId($pdo),
        'workspace_label' => (string)($cfg['workspace_label'] ?? ''),
        'default_channel_label' => (string)($cfg['default_channel_label'] ?? ''),
        'bot_username' => (string)($cfg['bot_username'] ?? ''),
        'icon_emoji' => (string)($cfg['icon_emoji'] ?? ''),
        'min_priority' => (string)($cfg['min_priority'] ?? 'info'),
        'environment' => (string)($cfg['environment'] ?? 'production'),
        'webhooks_by_topic_keys' => is_array($topics) ? array_keys($topics) : [],
        'connection_status' => (string)($cfg['connection_status'] ?? 'disconnected'),
        'last_test_at' => $cfg['last_test_at'] ?? null,
        'last_test_status' => $cfg['last_test_status'] ?? null,
        'last_test_error' => $cfg['last_test_error'] ?? null,
        'last_test_duration_ms' => isset($cfg['last_test_duration_ms']) ? (int)$cfg['last_test_duration_ms'] : null,
        'last_error' => $cfg['last_error'] ?? null,
        'updated_at' => $cfg['updated_at'] ?? null,
    ];
}

/**
 * @param array<string,mixed> $input
 * @return array<string,mixed>
 */
function slackSaveConfig(PDO $pdo, array $input): array {
    slackEnsureConfigTable($pdo);
    $cfg = slackGetConfigRow($pdo);

    $enabled = array_key_exists('enabled', $input) ? (!empty($input['enabled']) ? 1 : 0) : (int)!empty($cfg['enabled']);
    $autoSend = array_key_exists('auto_send', $input) ? (!empty($input['auto_send']) ? 1 : 0) : (int)!empty($cfg['auto_send']);

    $workspace = array_key_exists('workspace_label', $input)
        ? mb_substr(trim((string)$input['workspace_label']), 0, 120)
        : (string)($cfg['workspace_label'] ?? '');
    $channelLabel = array_key_exists('default_channel_label', $input)
        ? mb_substr(trim((string)$input['default_channel_label']), 0, 120)
        : (string)($cfg['default_channel_label'] ?? '');
    $botUser = array_key_exists('bot_username', $input)
        ? mb_substr(trim((string)$input['bot_username']), 0, 80)
        : (string)($cfg['bot_username'] ?? '');
    $emoji = array_key_exists('icon_emoji', $input)
        ? mb_substr(trim((string)$input['icon_emoji']), 0, 40)
        : (string)($cfg['icon_emoji'] ?? '');

    $minPriority = strtolower(trim((string)($input['min_priority'] ?? $cfg['min_priority'] ?? 'info')));
    if (!in_array($minPriority, ['info', 'warning', 'critical'], true)) {
        $minPriority = 'info';
    }
    $environment = strtolower(trim((string)($input['environment'] ?? $cfg['environment'] ?? 'production')));
    if (!in_array($environment, ['development', 'staging', 'production'], true)) {
        $environment = 'production';
    }

    $webhookEnc = (string)($cfg['webhook_url_enc'] ?? '');
    if (array_key_exists('webhook_url', $input)) {
        $url = trim((string)$input['webhook_url']);
        if ($url !== '') {
            if (!preg_match('#^https://hooks\.slack\.com/#i', $url)) {
                throw new RuntimeException('Webhook Slack inválido — use uma URL https://hooks.slack.com/...');
            }
            if (function_exists('requireDedicatedEncryptionKey')) {
                requireDedicatedEncryptionKey('mail');
            }
            $webhookEnc = slackEncryptSecret($url);
        }
        // string vazia = manter o atual
    }

    $botEnc = (string)($cfg['bot_token_enc'] ?? '');
    if (array_key_exists('bot_token', $input)) {
        $tok = trim((string)$input['bot_token']);
        if ($tok !== '') {
            if (!preg_match('#^xoxb-#', $tok)) {
                throw new RuntimeException('Bot Token Slack inválido — use um token xoxb-...');
            }
            if (function_exists('requireDedicatedEncryptionKey')) {
                requireDedicatedEncryptionKey('mail');
            }
            $botEnc = slackEncryptSecret($tok);
        }
    }

    $channelId = (string)($cfg['default_channel_id'] ?? '');
    if (array_key_exists('default_channel_id', $input)) {
        $cid = trim((string)$input['default_channel_id']);
        if ($cid !== '') {
            if (!preg_match('#^[CGD#][A-Za-z0-9_-]{1,31}$#', $cid) && !preg_match('#^#[\w.-]{1,80}$#', $cid)) {
                throw new RuntimeException('Channel ID inválido — use C… / G… ou #canal');
            }
            $channelId = mb_substr($cid, 0, 80);
        }
    }

    $topicsJson = $cfg['webhooks_by_topic'] ?? null;
    if (array_key_exists('webhooks_by_topic', $input) && is_array($input['webhooks_by_topic'])) {
        $topicsJson = json_encode($input['webhooks_by_topic'], JSON_UNESCAPED_UNICODE);
    }

    $now = function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s');
    $pdo->prepare("UPDATE notification_slack_config SET
        enabled = ?, auto_send = ?, webhook_url_enc = ?, bot_token_enc = ?, default_channel_id = ?,
        workspace_label = ?, default_channel_label = ?,
        bot_username = ?, icon_emoji = ?, min_priority = ?, environment = ?, webhooks_by_topic = ?,
        updated_at = ?
        WHERE id = 1")
        ->execute([
            $enabled, $autoSend, $webhookEnc !== '' ? $webhookEnc : null,
            $botEnc !== '' ? $botEnc : null,
            $channelId !== '' ? $channelId : null,
            $workspace !== '' ? $workspace : null,
            $channelLabel !== '' ? $channelLabel : null,
            $botUser !== '' ? $botUser : null,
            $emoji !== '' ? $emoji : null,
            $minPriority, $environment, $topicsJson, $now,
        ]);

    return slackGetConfigPublic($pdo);
}

function slackSanitizeText(string $text): string {
    $text = preg_replace('/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/', '[CPF]', $text) ?? $text;
    $text = preg_replace('/\b(Bearer\s+)[A-Za-z0-9._\-]{8,}/i', '$1[REDACTED]', $text) ?? $text;
    $text = preg_replace('/\b(token|senha|password|secret|api[_-]?key)\s*[:=]\s*\S+/i', '$1=[REDACTED]', $text) ?? $text;
    $text = preg_replace('#https://hooks\.slack\.com/\S+#i', '[SLACK_WEBHOOK]', $text) ?? $text;
    $text = preg_replace('#\bxoxb-[A-Za-z0-9-]+\b#', '[SLACK_BOT_TOKEN]', $text) ?? $text;
    return trim($text);
}

/**
 * Template textual profissional para alertas internos.
 * @param array<string,mixed> $meta
 */
function slackFormatInternalAlert(string $title, string $body, array $meta = [], ?string $actionUrl = null): string {
    $title = slackSanitizeText($title);
    $body = slackSanitizeText($body);
    $lines = [];
    if ($title !== '') $lines[] = '*' . $title . '*';
    if ($body !== '') $lines[] = $body;
    $type = (string)($meta['type'] ?? ($meta['event'] ?? ''));
    if ($type !== '') $lines[] = '_Evento:_ `' . slackSanitizeText($type) . '`';
    if ($actionUrl) {
        $base = defined('SITE_URL') ? rtrim((string)SITE_URL, '/') : '';
        $url = $actionUrl;
        if ($base && strpos($actionUrl, 'http') !== 0) {
            $url = $base . '/' . ltrim($actionUrl, '/');
        }
        // Sem tokens na URL
        $url = preg_replace('/([?&])(token|admin_token|key)=[^&]*/i', '$1$2=[redacted]', $url) ?? $url;
        $lines[] = '<' . $url . '|Abrir no painel>';
    }
    $lines[] = '_Auto Limpeza Pro · Central de Notificações_';
    return implode("\n", $lines);
}

function slackPriorityRank(string $priority): int {
    $p = strtolower(trim($priority));
    if (in_array($p, ['critical', 'error', 'high'], true)) return 3;
    if (in_array($p, ['warning', 'warn'], true)) return 2;
    return 1; // info
}

function slackEventPriority(string $type, array $opts = []): string {
    if (!empty($opts['priority'])) {
        $p = strtolower((string)$opts['priority']);
        if (in_array($p, ['info', 'warning', 'critical', 'error', 'high', 'warn'], true)) {
            if ($p === 'error' || $p === 'high') return 'critical';
            if ($p === 'warn') return 'warning';
            return $p;
        }
    }
    $critical = ['system_alert', 'GpsStale', 'InternetLost', 'DriverOffline'];
    $warning = ['appointment_cancelled', 'DriverDelayed', 'DriverStopped'];
    if (in_array($type, $critical, true)) return 'critical';
    if (in_array($type, $warning, true)) return 'warning';
    return 'info';
}

function slackMeetsMinPriority(PDO $pdo, string $eventPriority): bool {
    $cfg = slackGetConfigRow($pdo);
    $min = (string)($cfg['min_priority'] ?? 'info');
    return slackPriorityRank($eventPriority) >= slackPriorityRank($min);
}

/** Rate-limit leve: mesmo fingerprint ≤ 1× / 15 min. */
function slackAllowFingerprint(PDO $pdo, string $fingerprint): bool {
    $fingerprint = substr(hash('sha256', $fingerprint), 0, 32);
    $key = 'slack_rl_' . $fingerprint;
    try {
        $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = ? LIMIT 1");
        $stmt->execute([$key]);
        $prev = $stmt->fetchColumn();
        if ($prev && (time() - (int)$prev) < 900) {
            return false;
        }
        $pdo->prepare("INSERT INTO site_config (key_name, value, updated_at) VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)")
            ->execute([$key, (string)time(), function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s')]);
    } catch (Throwable $e) {
        return true; // se site_config falhar, não bloqueia envio
    }
    return true;
}

/**
 * @param array<string,mixed> $opts username, icon_emoji, topic, skip_rate_limit, skip_env_gate
 * @return array{sent:bool,http:int,error:?string,duration_ms:int,skipped:?string}
 */
function slackSendMessage(PDO $pdo, string $text, array $opts = []): array {
    $start = microtime(true);
    $empty = static function (?string $err, ?string $skipped = null) use ($start): array {
        return [
            'sent' => false,
            'http' => 0,
            'error' => $err,
            'duration_ms' => (int)((microtime(true) - $start) * 1000),
            'skipped' => $skipped,
        ];
    };

    try {
        if (!slackIsConfigured($pdo)) {
            return $empty('Slack não configurado (webhook ou Bot Token + canal)');
        }
        if (empty($opts['force']) && !slackIsEnabled($pdo)) {
            return $empty('Slack desativado', 'disabled');
        }
        if (empty($opts['skip_env_gate']) && !slackEnvironmentAllowed($pdo)) {
            return $empty('Ambiente Slack ≠ APP_ENV', 'env_mismatch');
        }
        if (empty($opts['skip_auto']) && empty($opts['force']) && !slackAutoSend($pdo)) {
            return $empty('Auto-envio Slack desligado', 'auto_send_off');
        }

        $text = slackSanitizeText($text);
        if ($text === '') {
            return $empty('Mensagem vazia');
        }

        $fp = (string)($opts['fingerprint'] ?? ('msg:' . md5($text)));
        if (empty($opts['skip_rate_limit']) && !slackAllowFingerprint($pdo, $fp)) {
            return $empty('Rate limit Slack (15 min)', 'rate_limited');
        }

        $cfg = slackGetConfigRow($pdo);
        $url = slackGetWebhookUrl($pdo);
        // Preparado: webhooks_by_topic (v1 usa só padrão se tópico não mapeado)
        $topic = (string)($opts['topic'] ?? '');
        if ($topic !== '' && !empty($cfg['webhooks_by_topic'])) {
            $map = is_string($cfg['webhooks_by_topic'])
                ? json_decode((string)$cfg['webhooks_by_topic'], true)
                : $cfg['webhooks_by_topic'];
            if (is_array($map) && !empty($map[$topic]) && is_string($map[$topic])) {
                $alt = slackDecryptSecret((string)$map[$topic]);
                if ($alt !== '' && preg_match('#^https://hooks\.slack\.com/#i', $alt)) {
                    $url = $alt;
                }
            }
        }

        $payload = ['text' => $text];
        $username = trim((string)($opts['username'] ?? ($cfg['bot_username'] ?? '')));
        if ($username !== '') $payload['username'] = $username;
        $emoji = trim((string)($opts['icon_emoji'] ?? ($cfg['icon_emoji'] ?? '')));
        if ($emoji !== '') $payload['icon_emoji'] = $emoji;

        $useWebhook = $url !== '' && (bool)preg_match('#^https://hooks\.slack\.com/#i', $url);
        $raw = false;
        $http = 0;
        $cerr = '';
        if ($useWebhook) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
                CURLOPT_HTTPHEADER => ['Content-Type: application/json; charset=utf-8'],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 8,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_SSL_VERIFYPEER => true,
            ]);
            $raw = curl_exec($ch);
            $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $cerr = curl_error($ch);
            curl_close($ch);
        } else {
            $token = slackGetBotToken($pdo);
            $channel = slackGetChannelId($pdo);
            $apiPayload = array_merge($payload, ['channel' => $channel]);
            $ch = curl_init('https://slack.com/api/chat.postMessage');
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($apiPayload, JSON_UNESCAPED_UNICODE),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json; charset=utf-8',
                    'Authorization: Bearer ' . $token,
                ],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 8,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_SSL_VERIFYPEER => true,
            ]);
            $raw = curl_exec($ch);
            $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $cerr = curl_error($ch);
            curl_close($ch);
        }
        $ms = (int)((microtime(true) - $start) * 1000);

        $ok = false;
        if ($useWebhook) {
            $ok = $http >= 200 && $http < 300 && is_string($raw) && stripos($raw, 'ok') !== false;
        } elseif (is_string($raw)) {
            $decoded = json_decode($raw, true);
            $ok = $http >= 200 && $http < 300 && is_array($decoded) && !empty($decoded['ok']);
            if (!$ok && is_array($decoded) && !empty($decoded['error'])) {
                $cerr = $cerr !== '' ? $cerr : ('slack:' . (string)$decoded['error']);
            }
        }
        $errMsg = null;
        if (!$ok) {
            $errMsg = $cerr !== '' ? $cerr : ('HTTP ' . $http . ' ' . mb_substr((string)$raw, 0, 120));
            $errMsg = slackSanitizeText($errMsg);
            try {
                $pdo->prepare("UPDATE notification_slack_config SET last_error = ?, connection_status = 'error', updated_at = ? WHERE id = 1")
                    ->execute([mb_substr($errMsg, 0, 500), function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s')]);
            } catch (Throwable $e) { /* ignore */ }
            if (function_exists('appLogRateLimited')) {
                appLogRateLimited('warn', 'slack_webhook_fail', ['http' => $http, 'err' => $errMsg], 300);
            }
        } else {
            try {
                $pdo->prepare("UPDATE notification_slack_config SET last_error = NULL, connection_status = 'open', updated_at = ? WHERE id = 1")
                    ->execute([function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s')]);
            } catch (Throwable $e) { /* ignore */ }
        }

        return [
            'sent' => $ok,
            'http' => $http,
            'error' => $errMsg,
            'duration_ms' => $ms,
            'skipped' => null,
        ];
    } catch (Throwable $e) {
        return $empty(slackSanitizeText($e->getMessage()));
    }
}

/**
 * @return array{ok:bool,error:?string,duration_ms:int,http:int,config:array}
 */
function slackTestConnection(PDO $pdo): array {
    slackEnsureConfigTable($pdo);
    $start = microtime(true);
    if (!slackIsConfigured($pdo)) {
        $ms = (int)((microtime(true) - $start) * 1000);
        $pdo->prepare("UPDATE notification_slack_config SET last_test_at = ?, last_test_status = 'fail', last_test_error = ?, last_test_duration_ms = ?, updated_at = ? WHERE id = 1")
            ->execute([
                function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s'),
                'Slack não configurado',
                $ms,
                function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s'),
            ]);
        return ['ok' => false, 'error' => 'Slack não configurado (cole o Incoming Webhook ou Bot Token + Channel ID)', 'duration_ms' => $ms, 'http' => 0, 'config' => slackGetConfigPublic($pdo)];
    }

    $text = slackFormatInternalAlert(
        'Teste Slack — Auto Limpeza Pro',
        'Conexão Incoming Webhook OK em ' . date('d/m/Y H:i:s') . '.',
        ['type' => 'slack_test'],
        '/comunicacao-admin'
    );
    $res = slackSendMessage($pdo, $text, [
        'force' => true,
        'skip_rate_limit' => true,
        'skip_env_gate' => true,
        'skip_auto' => true,
        'fingerprint' => 'slack_test_' . date('YmdHi'),
    ]);

    $ok = !empty($res['sent']);
    $err = $res['error'] ?? ($res['skipped'] ?? null);
    $pdo->prepare("UPDATE notification_slack_config SET
        last_test_at = ?, last_test_status = ?, last_test_error = ?, last_test_duration_ms = ?,
        connection_status = ?, updated_at = ?
        WHERE id = 1")
        ->execute([
            function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s'),
            $ok ? 'ok' : 'fail',
            $err ? mb_substr((string)$err, 0, 500) : null,
            (int)($res['duration_ms'] ?? 0),
            $ok ? 'open' : 'error',
            function_exists('dbNow') ? dbNow() : date('Y-m-d H:i:s'),
        ]);

    return [
        'ok' => $ok,
        'error' => $ok ? null : (string)($err ?? 'Falha'),
        'duration_ms' => (int)($res['duration_ms'] ?? 0),
        'http' => (int)($res['http'] ?? 0),
        'config' => slackGetConfigPublic($pdo),
    ];
}

/** @return array<string,mixed> */
function slackMapStatus(PDO $pdo): array {
    $pub = slackGetConfigPublic($pdo);
    return [
        'configured' => !empty($pub['webhook_configured']) || !empty($pub['bot_configured']),
        'webhookConfigured' => !empty($pub['webhook_configured']),
        'botConfigured' => !empty($pub['bot_configured']),
        'enabled' => !empty($pub['enabled']),
        'autoSend' => !empty($pub['auto_send']),
        'connectionStatus' => $pub['connection_status'] ?? 'disconnected',
        'workspace' => $pub['workspace_label'] ?? '',
        'channel' => $pub['default_channel_label'] ?? '',
        'environment' => $pub['environment'] ?? 'production',
        'minPriority' => $pub['min_priority'] ?? 'info',
        'lastError' => $pub['last_error'] ?? null,
        'lastTestAt' => $pub['last_test_at'] ?? null,
        'lastTestStatus' => $pub['last_test_status'] ?? null,
    ];
}
