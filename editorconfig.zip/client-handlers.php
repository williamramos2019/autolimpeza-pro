<?php
/**
 * Autenticação de clientes — cadastro, login e área do cliente.
 */

function ensureClientTables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `clients` (
        `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `email`         VARCHAR(255) NOT NULL,
        `phone`         VARCHAR(50)  DEFAULT NULL,
        `name`          VARCHAR(200) NOT NULL,
        `password_hash` VARCHAR(255) NOT NULL,
        `visitor_id`    VARCHAR(64)  DEFAULT NULL,
        `active`        TINYINT(1)   NOT NULL DEFAULT 1,
        `created_at`    DATETIME     NOT NULL,
        `updated_at`    DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_email` (`email`),
        INDEX `idx_visitor` (`visitor_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `client_sessions` (
        `token`      VARCHAR(64)  NOT NULL,
        `client_id`  INT UNSIGNED NOT NULL,
        `expires_at` DATETIME     NOT NULL,
        `created_at` DATETIME     NOT NULL,
        PRIMARY KEY (`token`),
        INDEX `idx_client` (`client_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    try {
        $pdo->exec("ALTER TABLE appointments ADD COLUMN `client_id` INT UNSIGNED DEFAULT NULL");
    } catch (PDOException $e) { /* exists */ }
    try {
        $pdo->exec("ALTER TABLE appointments ADD INDEX `idx_client_id` (`client_id`)");
    } catch (PDOException $e) { /* exists */ }
    try {
        $pdo->exec("ALTER TABLE clients ADD COLUMN `password_set` TINYINT(1) NOT NULL DEFAULT 1");
    } catch (PDOException $e) { /* exists */ }
    try {
        $pdo->exec("ALTER TABLE clients ADD COLUMN `google_sub` VARCHAR(64) DEFAULT NULL");
    } catch (PDOException $e) { /* exists */ }
    try {
        $pdo->exec("ALTER TABLE clients ADD COLUMN `avatar_url` VARCHAR(500) DEFAULT NULL");
    } catch (PDOException $e) { /* exists */ }
}

function clientSessionClientId(): ?int {
    $auth = getAuthorizationHeader();
    if (strpos($auth, 'Bearer ') !== 0) return null;
    $token = trim(substr($auth, 7));
    if ($token === '') return null;
    $h = hashSessionToken($token);
    try {
        $stmt = db()->prepare(
            'SELECT s.client_id FROM client_sessions s
             INNER JOIN clients c ON c.id = s.client_id
             WHERE (s.token_hash = ? OR (s.token_hash IS NULL AND s.token = ?))
               AND s.expires_at > NOW()
               AND s.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
               AND c.active = 1
             LIMIT 1'
        );
        $stmt->execute([$h, $token]);
        $row = $stmt->fetch();
        return $row ? (int)$row['client_id'] : null;
    } catch (PDOException $e) {
        try {
            $stmt = db()->prepare(
                'SELECT s.client_id FROM client_sessions s
                 INNER JOIN clients c ON c.id = s.client_id
                 WHERE s.token = ? AND s.expires_at > NOW() AND c.active = 1 LIMIT 1'
            );
            $stmt->execute([$token]);
            $row = $stmt->fetch();
            return $row ? (int)$row['client_id'] : null;
        } catch (PDOException $e2) {
            return null;
        }
    }
}

function requireClient(): int {
    $id = clientSessionClientId();
    if (!$id) jsonRespond(['error' => 'Sessão de cliente inválida ou expirada'], 401);
    return $id;
}

/** Emite sessão Bearer de 30 dias — usado em register / login / google-login. */
function issueClientSession(PDO $pdo, int $clientId): array {
    $token   = generateToken(32);
    $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
    $now     = dbNow();
    $hash    = hashSessionToken($token);
    $prefix  = sessionTokenPrefix($token);
    try {
        $pdo->prepare(
            'INSERT INTO client_sessions (token, token_hash, token_prefix, client_id, expires_at, created_at)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([$hash, $hash, $prefix, $clientId, $expires, $now]);
    } catch (PDOException $e) {
        if (!function_exists('pdoIsUnknownColumn') || !pdoIsUnknownColumn($e)) {
            throw $e;
        }
        $pdo->prepare('INSERT INTO client_sessions (token, client_id, expires_at, created_at) VALUES (?, ?, ?, ?)')
            ->execute([$token, $clientId, $expires, $now]);
    }
    return ['token' => $token, 'expiresAt' => $expires];
}

/** Revoga sessões do cliente exceto a atual (opcional). */
function revokeClientSessions(PDO $pdo, int $clientId, ?string $keepToken = null): void {
    try {
        if ($keepToken) {
            $h = hashSessionToken($keepToken);
            $pdo->prepare(
                'DELETE FROM client_sessions WHERE client_id = ? AND token_hash IS NOT NULL AND token_hash != ?'
            )->execute([$clientId, $h]);
            $pdo->prepare(
                'DELETE FROM client_sessions WHERE client_id = ? AND (token_hash IS NULL OR token_hash = "") AND token != ?'
            )->execute([$clientId, $keepToken]);
        } else {
            $pdo->prepare('DELETE FROM client_sessions WHERE client_id = ?')->execute([$clientId]);
        }
    } catch (PDOException $e) {
        try {
            $pdo->prepare('DELETE FROM client_sessions WHERE client_id = ?')->execute([$clientId]);
        } catch (PDOException $e2) { /* ignore */ }
    }
}

/** visitor_id do cookie alp_vid (mesmo dispositivo). */
function visitorCookieId(): ?string {
    $id = san($_COOKIE['alp_vid'] ?? null, 64);
    if (!$id) return null;
    if (!preg_match('/^(v_[a-z0-9]+_[a-z0-9]+|anon_[0-9]+)$/i', $id)) return null;
    return $id;
}

function visitorIdFromClientSession(): ?string {
    $clientId = clientSessionClientId();
    if (!$clientId) return null;
    try {
        $stmt = db()->prepare('SELECT visitor_id FROM clients WHERE id = ? AND active = 1 LIMIT 1');
        $stmt->execute([$clientId]);
        $v = $stmt->fetchColumn();
        return ($v !== false && $v !== null && $v !== '') ? (string)$v : null;
    } catch (PDOException $e) {
        return null;
    }
}

/** Impede IDOR: só admin, cookie do dispositivo ou sessão de cliente vinculada. */
function assertVisitorAccess(string $visitorId): void {
    if ($visitorId === '') {
        jsonRespond(['error' => 'visitor_id obrigatório'], 400);
    }
    if (isAdmin()) return;
    assertVisitorOwnsId($visitorId);
}

/**
 * Acesso estrito ao inbox do visitante/cliente — sem bypass de admin.
 * Usado em client/notifications para evitar vazamento entre contas.
 */
function assertVisitorOwnsId(string $visitorId): void {
    if ($visitorId === '') {
        jsonRespond(['error' => 'visitor_id obrigatório'], 400);
    }
    $cookie = visitorCookieId();
    if ($cookie !== null && hash_equals($cookie, $visitorId)) return;
    $sessionVid = visitorIdFromClientSession();
    if ($sessionVid !== null && hash_equals($sessionVid, $visitorId)) return;
    rateLimit('visitor_forbidden', 10);
    jsonRespond(['error' => lang('unauthorized')], 403);
}

function linkVisitorAppointmentsToClient(PDO $pdo, int $clientId, ?string $visitorId): void {
    if (!$visitorId) return;
    try {
        ensureClientTables($pdo);
        // Só reivindica órfãos criados nas últimas 72h no mesmo visitor (mitiga cookie plantado)
        $pdo->prepare(
            'UPDATE appointments SET client_id = ?
             WHERE visitor_id = ?
               AND (client_id IS NULL OR client_id = 0)
               AND created_at >= DATE_SUB(NOW(), INTERVAL 72 HOUR)'
        )->execute([$clientId, $visitorId]);
        // Não sobrescreve visitor_id se o cliente já tiver outro vinculado
        $pdo->prepare(
            'UPDATE clients SET visitor_id = COALESCE(NULLIF(visitor_id, ""), ?), updated_at = ?
             WHERE id = ?'
        )->execute([$visitorId, dbNow(), $clientId]);
    } catch (Throwable $e) {
        appLog('warn', 'linkVisitorAppointmentsToClient', ['err' => $e->getMessage(), 'clientId' => $clientId]);
    }
}

/**
 * Só vincula agendamentos órfãos ao visitor do cookie (alp_vid).
 * Body visitorId sozinho NÃO é confiável (reivindicação indevida).
 */
function resolveTrustedVisitorIdForLink(?string $fromBody): ?string {
    $cookie = function_exists('visitorCookieId') ? visitorCookieId() : null;
    if ($cookie === null || $cookie === '') {
        return null;
    }
    $body = $fromBody !== null && $fromBody !== '' ? $fromBody : null;
    if ($body !== null && !hash_equals($cookie, $body)) {
        appLog('warn', 'visitor_link_body_mismatch', ['cookie_prefix' => substr($cookie, 0, 8)]);
        return $cookie;
    }
    return $cookie;
}

function decodeClient(array $r): array {
    return [
        'id'          => (int)$r['id'],
        'email'       => $r['email'],
        'phone'       => $r['phone'],
        'name'        => $r['name'],
        'visitorId'   => $r['visitor_id'],
        'avatarUrl'   => $r['avatar_url'] ?? null,
        'passwordSet' => isset($r['password_set']) ? (bool)(int)$r['password_set'] : true,
        'googleLinked'=> !empty($r['google_sub']),
    ];
}

function handleClientRegister(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('client_register', 10);

    $b        = jsonBody();
    $email    = strtolower(trim(san($b['email'] ?? '', 255) ?? ''));
    $password = (string)($b['password'] ?? '');
    $name     = trim(san($b['name'] ?? '', 200) ?? '');
    $phone    = san($b['phone'] ?? null, 50);
    $visitorId = san($b['visitorId'] ?? $b['visitor_id'] ?? null, 64);
    $city      = san($b['city'] ?? null, 100);
    $state     = san($b['state'] ?? null, 100);
    $address   = san($b['address'] ?? null, 500);
    $neighborhood = san($b['neighborhood'] ?? null, 120);
    $zipCode   = san($b['zip_code'] ?? $b['zipCode'] ?? null, 20);
    $lat       = sanFloat($b['latitude'] ?? null);
    $lon       = sanFloat($b['longitude'] ?? null);

    if (!isEmail($email)) jsonRespond(['error' => 'E-mail inválido'], 400);
    if (strlen($password) < 8) jsonRespond(['error' => 'Senha deve ter no mínimo 8 caracteres'], 400);
    if ($name === '') jsonRespond(['error' => 'Nome obrigatório'], 400);

    $pdo = db();
    ensureClientTables($pdo);
    ensureClientAddressColumns($pdo);

    if (function_exists('emailIsAdminAccount') && emailIsAdminAccount($pdo, $email)) {
        respondAdminAccountRedirect(
            $email,
            'Este e-mail é de administrador. Cadastro de cliente não permitido — entre em /admin.'
        );
    }

    $exists = $pdo->prepare('SELECT id FROM clients WHERE email = ? LIMIT 1');
    $exists->execute([$email]);
    if ($exists->fetch()) jsonRespond(['error' => 'E-mail já cadastrado. Faça login.'], 409);

    $now  = dbNow();
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $linkVisitorId = resolveTrustedVisitorIdForLink($visitorId);
    try {
        $pdo->prepare(
            'INSERT INTO clients (email, phone, name, password_hash, password_set, visitor_id, city, state, address, neighborhood, zip_code, latitude, longitude, created_at, updated_at)
             VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$email, $phone, $name, $hash, $linkVisitorId, $city, $state, $address, $neighborhood, $zipCode, $lat, $lon, $now, $now]);
    } catch (PDOException $e) {
        $pdo->prepare(
            'INSERT INTO clients (email, phone, name, password_hash, visitor_id, city, state, address, neighborhood, zip_code, latitude, longitude, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$email, $phone, $name, $hash, $linkVisitorId, $city, $state, $address, $neighborhood, $zipCode, $lat, $lon, $now, $now]);
    }
    $clientId = (int)$pdo->lastInsertId();

    linkVisitorAppointmentsToClient($pdo, $clientId, $linkVisitorId);

    try {
        if (function_exists('dispatchNotificationEvent')) {
            dispatchNotificationEvent($pdo, 'new_client', 'Novo cliente cadastrado', "{$name} ({$email}) criou conta.", [
                'client_id' => $clientId, 'email' => $email, 'name' => $name,
            ], ['action_url' => '/admin', 'priority' => 'medium']);
        }
    } catch (Throwable $e) {
        appLog('warn', 'client_register_notification', ['err' => $e->getMessage()]);
    }

    $session = issueClientSession($pdo, $clientId);
    $token   = $session['token'];
    $expires = $session['expiresAt'];

    $stmt = $pdo->prepare('SELECT * FROM clients WHERE id = ?');
    $stmt->execute([$clientId]);
    $row = $stmt->fetch();
    if (!$row) jsonRespond(['error' => 'Erro ao criar conta. Tente novamente.'], 500);

    jsonRespond([
        'ok'        => true,
        'token'     => $token,
        'expiresAt' => $expires,
        'client'    => decodeClient($row),
    ]);
}

function handleClientLogin(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('client_login', 15);

    $b        = jsonBody();
    $email    = strtolower(trim(san($b['email'] ?? '', 255) ?? ''));
    $password = (string)($b['password'] ?? '');
    $visitorId = san($b['visitorId'] ?? $b['visitor_id'] ?? null, 64);

    if ($email === '' || $password === '') {
        jsonRespond(['error' => 'E-mail e senha são obrigatórios'], 400);
    }

    $pdo = db();
    ensureClientTables($pdo);

    // E-mail admin → autentica no painel (mesmo fluxo do portal = mesma senha)
    if (function_exists('emailIsAdminAccount') && emailIsAdminAccount($pdo, $email)) {
        try {
            $adminUser = authenticateAdminByPassword($pdo, $email, $password);
            if ($adminUser) {
                appLog('info', 'client_login_routed_to_admin', ['email' => $email]);
                jsonRespond(buildAdminSessionResponse($adminUser, true));
            }
        } catch (Throwable $e) {
            appLog('error', 'client_login_admin_route', ['err' => $e->getMessage()]);
        }
        respondAdminAccountRedirect(
            $email,
            'Este e-mail é de administrador. Use a senha do Painel Admin ou entre em /admin.'
        );
    }

    $stmt = $pdo->prepare('SELECT * FROM clients WHERE email = ? AND active = 1 LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || empty($user['password_hash']) || !password_verify($password, $user['password_hash'])) {
        // Conta só Google (password_set=0) — orientar
        if ($user && isset($user['password_set']) && (int)$user['password_set'] === 0) {
            jsonRespond([
                'error' => 'Esta conta usa login com Google. Entre com Google ou defina uma senha no perfil.',
            ], 401);
        }
        jsonRespond(['error' => 'Credenciais inválidas'], 401);
    }

    $clientId = (int)$user['id'];
    linkVisitorAppointmentsToClient($pdo, $clientId, resolveTrustedVisitorIdForLink($visitorId));

    $session = issueClientSession($pdo, $clientId);

    jsonRespond([
        'ok'        => true,
        'token'     => $session['token'],
        'expiresAt' => $session['expiresAt'],
        'client'    => decodeClient($user),
    ]);
}

/** Client ID OAuth 2.0 (mesmo do admin — vale para todo o domínio). */
function clientGoogleClientId(): string {
    if (function_exists('googleOAuthClientId')) {
        return googleOAuthClientId();
    }
    return defined('GOOGLE_OAUTH_CLIENT_ID') ? trim((string) GOOGLE_OAUTH_CLIENT_ID) : '';
}

/** Informa ao frontend se o login social do cliente está habilitado. */
function handleClientGoogleConfig(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $clientId = clientGoogleClientId();
    jsonRespond([
        'enabled'  => $clientId !== '',
        'clientId' => $clientId !== '' ? $clientId : null,
    ]);
}

/**
 * Login/cadastro de cliente via Google Sign-In.
 * Valida o ID token, encontra o cliente pelo e-mail (ou cria um novo) e
 * emite uma sessão. Contas criadas por aqui usam senha aleatória — o acesso
 * é sempre via Google (ou redefinição de senha, se implementada).
 */
function handleClientGoogleLogin(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('client_google_login', 15);

    if (clientGoogleClientId() === '') {
        jsonRespond(['error' => 'Login com Google não configurado. Defina GOOGLE_OAUTH_CLIENT_ID no config.php'], 503);
    }
    if (!function_exists('verifyGoogleIdToken')) {
        jsonRespond(['error' => 'Verificação Google indisponível no servidor'], 500);
    }

    $b          = jsonBody();
    $credential = trim((string) ($b['credential'] ?? $b['idToken'] ?? ''));
    $visitorId  = san($b['visitorId'] ?? $b['visitor_id'] ?? null, 64);
    if ($credential === '') jsonRespond(['error' => 'Token Google ausente'], 400);

    $claims = verifyGoogleIdToken($credential);
    if (!$claims) {
        appLog('warn', 'client_google_invalid_token', []);
        jsonRespond(['error' => 'Token Google inválido ou expirado'], 401);
    }

    $email = strtolower(trim((string) $claims['email']));
    $name  = trim((string) ($claims['name'] ?? $claims['given_name'] ?? ''));
    $googleSub = trim((string) ($claims['sub'] ?? ''));
    if (!isEmail($email)) jsonRespond(['error' => 'E-mail Google inválido'], 400);
    if ($name === '') $name = explode('@', $email)[0];

    $pdo = db();
    ensureClientTables($pdo);

    // Admin (master ou admin_users) → sessão admin + redirect /admin
    if (function_exists('resolveAdminUserForGoogleEmail')) {
        try {
            $adminUser = resolveAdminUserForGoogleEmail($pdo, $email, $name);
            if ($adminUser) {
                appLog('info', 'client_google_routed_to_admin', ['email' => $email]);
                jsonRespond(buildAdminSessionResponse($adminUser, true));
            }
        } catch (Throwable $e) {
            appLog('error', 'client_google_admin_route', ['err' => $e->getMessage()]);
        }
    }

    $linkVisitorId = resolveTrustedVisitorIdForLink($visitorId);

    $stmt = $pdo->prepare('SELECT * FROM clients WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    $now = dbNow();
    if (!$user) {
        $randomHash = password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT);
        try {
            $pdo->prepare(
                'INSERT INTO clients (email, phone, name, password_hash, password_set, google_sub, visitor_id, active, created_at, updated_at)
                 VALUES (?, NULL, ?, ?, 0, ?, ?, 1, ?, ?)'
            )->execute([$email, san($name, 200), $randomHash, $googleSub !== '' ? $googleSub : null, $linkVisitorId, $now, $now]);
        } catch (PDOException $e) {
            $pdo->prepare(
                'INSERT INTO clients (email, phone, name, password_hash, visitor_id, active, created_at, updated_at)
                 VALUES (?, NULL, ?, ?, ?, 1, ?, ?)'
            )->execute([$email, san($name, 200), $randomHash, $linkVisitorId, $now, $now]);
        }
        $clientId = (int) $pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT * FROM clients WHERE id = ?');
        $stmt->execute([$clientId]);
        $user = $stmt->fetch();
        if (!$user) jsonRespond(['error' => 'Erro ao criar conta. Tente novamente.'], 500);
        try {
            if (function_exists('dispatchNotificationEvent')) {
                dispatchNotificationEvent($pdo, 'new_client', 'Novo cliente (Google)', "{$name} ({$email}) entrou com Google.", [
                    'client_id' => $clientId, 'email' => $email, 'name' => $name,
                ], ['action_url' => '/admin', 'priority' => 'medium']);
            }
        } catch (Throwable $e) {
            appLog('warn', 'client_google_notification', ['err' => $e->getMessage()]);
        }
    } else {
        if (!(int) $user['active']) jsonRespond(['error' => 'Conta desativada. Fale com o suporte.'], 403);
        $clientId = (int) $user['id'];
        $passwordSet = !isset($user['password_set']) || (int)$user['password_set'] === 1;
        $existingSub = trim((string)($user['google_sub'] ?? ''));

        if ($existingSub !== '' && $googleSub !== '' && !hash_equals($existingSub, $googleSub)) {
            jsonRespond(['error' => 'Esta conta Google não corresponde ao vínculo salvo. Fale com o suporte.'], 403);
        }

        // Conta com senha própria ainda sem Google vinculado → exigir confirmação
        if ($passwordSet && $existingSub === '') {
            $confirmPassword = (string)($b['password'] ?? '');
            if ($confirmPassword === '') {
                jsonRespond([
                    'needsPasswordConfirm' => true,
                    'email' => $email,
                    'message' => 'Confirme sua senha para vincular o Google a esta conta.',
                ], 409);
            }
            if (!password_verify($confirmPassword, $user['password_hash'])) {
                jsonRespond(['error' => 'Senha incorreta para vincular o Google'], 403);
            }
            if ($googleSub !== '') {
                try {
                    $pdo->prepare('UPDATE clients SET google_sub = ?, updated_at = ? WHERE id = ?')
                        ->execute([$googleSub, $now, $clientId]);
                    $user['google_sub'] = $googleSub;
                } catch (PDOException $e) { /* coluna pode não existir em legado */ }
            }
        } elseif ($existingSub === '' && $googleSub !== '') {
            try {
                $pdo->prepare('UPDATE clients SET google_sub = ?, updated_at = ? WHERE id = ?')
                    ->execute([$googleSub, $now, $clientId]);
                $user['google_sub'] = $googleSub;
            } catch (PDOException $e) { /* ignore */ }
        }
    }

    linkVisitorAppointmentsToClient($pdo, $clientId, $linkVisitorId);

    $session = issueClientSession($pdo, $clientId);

    appLog('info', 'client_google_login_ok', ['client_id' => $clientId, 'email' => $email]);
    jsonRespond([
        'ok'        => true,
        'token'     => $session['token'],
        'expiresAt' => $session['expiresAt'],
        'client'    => decodeClient($user),
    ]);
}

function handleClientMe(string $method): void {
    $clientId = requireClient();
    $pdo = db();
    ensureClientTables($pdo);

    if ($method === 'GET') {
        // Sliding renewal com teto absoluto created_at+30d
        $auth = getAuthorizationHeader();
        if (strpos($auth, 'Bearer ') === 0) {
            $token = trim(substr($auth, 7));
            if ($token !== '') {
                try {
                    $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
                    $h = hashSessionToken($token);
                    $pdo->prepare(
                        'UPDATE client_sessions SET expires_at = LEAST(?, DATE_ADD(created_at, INTERVAL 30 DAY))
                         WHERE (token_hash = ? OR token = ?) AND expires_at > NOW()
                           AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)'
                    )->execute([$expires, $h, $token]);
                } catch (Throwable $e) {
                    try {
                        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
                        $pdo->prepare(
                            'UPDATE client_sessions SET expires_at = ? WHERE token = ? AND expires_at > NOW()'
                        )->execute([$expires, $token]);
                    } catch (Throwable $e2) { /* best-effort */ }
                }
            }
        }
        $stmt = $pdo->prepare('SELECT * FROM clients WHERE id = ? LIMIT 1');
        $stmt->execute([$clientId]);
        $user = $stmt->fetch();
        if (!$user) jsonRespond(['error' => 'Cliente não encontrado'], 404);
        jsonRespond(decodeClient($user));
    }

    if ($method === 'PUT') {
        rateLimit('client_me_put', 20);
        $b = jsonBody();
        $stmt = $pdo->prepare('SELECT * FROM clients WHERE id = ? LIMIT 1');
        $stmt->execute([$clientId]);
        $user = $stmt->fetch();
        if (!$user) jsonRespond(['error' => 'Cliente não encontrado'], 404);

        $name  = array_key_exists('name', $b) ? trim(san($b['name'] ?? '', 200) ?? '') : null;
        $phone = array_key_exists('phone', $b) ? san($b['phone'] ?? null, 50) : null;
        $avatar = array_key_exists('avatarUrl', $b) || array_key_exists('avatar_url', $b)
            ? san($b['avatarUrl'] ?? $b['avatar_url'] ?? null, 500)
            : null;
        $newPassword = (string)($b['password'] ?? $b['newPassword'] ?? '');
        $currentPassword = (string)($b['currentPassword'] ?? $b['current_password'] ?? '');

        $sets = [];
        $params = [];
        if ($name !== null) {
            if ($name === '') jsonRespond(['error' => 'Nome inválido'], 400);
            $sets[] = 'name = ?';
            $params[] = $name;
        }
        if ($phone !== null) {
            $sets[] = 'phone = ?';
            $params[] = $phone;
        }
        if ($avatar !== null) {
            $sets[] = 'avatar_url = ?';
            $params[] = $avatar;
        }
        if ($newPassword !== '') {
            if (strlen($newPassword) < 8) jsonRespond(['error' => 'Nova senha deve ter no mínimo 8 caracteres'], 400);
            $passwordSet = !isset($user['password_set']) || (int)$user['password_set'] === 1;
            if ($passwordSet) {
                if ($currentPassword === '' || !password_verify($currentPassword, $user['password_hash'])) {
                    jsonRespond(['error' => 'Senha atual incorreta'], 403);
                }
            }
            $sets[] = 'password_hash = ?';
            $params[] = password_hash($newPassword, PASSWORD_DEFAULT);
            $sets[] = 'password_set = 1';
            $passwordChanged = true;
        }
        if (!$sets) jsonRespond(['error' => 'Nada para atualizar'], 400);
        $sets[] = 'updated_at = ?';
        $params[] = dbNow();
        $params[] = $clientId;
        $pdo->prepare('UPDATE clients SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);

        if (!empty($passwordChanged)) {
            $auth = getAuthorizationHeader();
            $keep = (strpos($auth, 'Bearer ') === 0) ? trim(substr($auth, 7)) : null;
            revokeClientSessions($pdo, $clientId, $keep !== '' ? $keep : null);
        }

        $stmt = $pdo->prepare('SELECT * FROM clients WHERE id = ? LIMIT 1');
        $stmt->execute([$clientId]);
        jsonRespond(['ok' => true, 'client' => decodeClient($stmt->fetch())]);
    }

    jsonRespond(['error' => 'Use GET ou PUT'], 405);
}

function clientOwnsAppointment(PDO $pdo, int $clientId, array $row): bool {
    if ((int)($row['client_id'] ?? 0) === $clientId) return true;
    $stmt = $pdo->prepare('SELECT visitor_id FROM clients WHERE id = ?');
    $stmt->execute([$clientId]);
    $vid = $stmt->fetchColumn();
    if ($vid && empty($row['client_id']) && hash_equals((string)$vid, (string)($row['visitor_id'] ?? ''))) {
        return true;
    }
    return false;
}

function clientAppointmentWithinCancelWindow(array $row): bool {
    $hours = defined('BOOKING_CANCEL_HOURS') ? (int)BOOKING_CANCEL_HOURS : 24;
    $date = (string)($row['date'] ?? '');
    $time = (string)($row['time'] ?? '08:00');
    $ts = strtotime($date . ' ' . $time);
    if ($ts === false) return false;
    return ($ts - time()) >= ($hours * 3600);
}

function enrichClientAppointment(PDO $pdo, array $row): array {
    $a = decodeAppointment($row);
    if (!empty($row['photo_urls'])) {
        $photos = is_string($row['photo_urls'])
            ? (json_decode($row['photo_urls'], true) ?: [])
            : $row['photo_urls'];
        if (is_array($photos)) $a['photoUrls'] = $photos;
    }
    if (function_exists('weatherGetMonitor')) {
        $w = weatherGetMonitor($pdo, $a['id']);
        if ($w) $a['weather'] = $w;
    }
    return $a;
}

function handleClientAppointments(string $method): void {
    $clientId = requireClient();
    $pdo = db();
    ensureClientTables($pdo);

    if ($method === 'GET') {
        try {
            $stmt = $pdo->prepare('SELECT visitor_id FROM clients WHERE id = ?');
            $stmt->execute([$clientId]);
            $client = $stmt->fetch();
            $visitorId = $client['visitor_id'] ?? null;

            $sql = "SELECT * FROM appointments WHERE client_id = ?";
            $params = [$clientId];
            if ($visitorId) {
                $sql .= " OR (client_id IS NULL AND visitor_id = ?)";
                $params[] = $visitorId;
            }
            $sql .= " ORDER BY date DESC, time ASC";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $out = [];
            foreach ($rows as $row) {
                try {
                    $out[] = enrichClientAppointment($pdo, $row);
                } catch (Throwable $e) {
                    appLog('warn', 'client_appointment_enrich', ['err' => $e->getMessage(), 'id' => $row['id'] ?? null]);
                }
            }
            jsonRespond($out);
        } catch (Throwable $e) {
            appLog('error', 'client_appointments_get', ['err' => $e->getMessage(), 'clientId' => $clientId]);
            jsonRespond(['error' => 'Não foi possível carregar agendamentos'], 500);
        }
    }

    if ($method === 'PUT') {
        rateLimit('client_appointments_put', 20);
        $b = jsonBody();
        $id = san($b['id'] ?? null, 64);
        $action = san($b['action'] ?? null, 20);
        if (!$id || !$action) jsonRespond(['error' => 'id e action obrigatórios'], 400);

        $stmt = $pdo->prepare('SELECT * FROM appointments WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row || !clientOwnsAppointment($pdo, $clientId, $row)) {
            jsonRespond(['error' => 'Agendamento não encontrado'], 404);
        }

        $status = normalizeAppointmentStatus((string)($row['status'] ?? 'pending'));
        if (!in_array($status, ['pending', 'confirmed'], true)) {
            jsonRespond(['error' => 'Só é possível alterar agendamentos pendentes ou confirmados'], 409);
        }
        if (!clientAppointmentWithinCancelWindow($row)) {
            $h = defined('BOOKING_CANCEL_HOURS') ? (int)BOOKING_CANCEL_HOURS : 24;
            jsonRespond(['error' => "Alterações só são permitidas com pelo menos {$h}h de antecedência"], 409);
        }

        if ($action === 'cancel') {
            $pdo->prepare('UPDATE appointments SET status = ?, updated_at = ?, client_id = COALESCE(client_id, ?) WHERE id = ?')
                ->execute(['cancelled', dbNow(), $clientId, $id]);
            jsonRespond(['ok' => true, 'status' => 'cancelled']);
        }

        if ($action === 'reschedule') {
            $date = san($b['date'] ?? null, 10);
            $time = san($b['time'] ?? null, 8);
            if (!$date || !$time) jsonRespond(['error' => 'date e time obrigatórios para reagendar'], 400);
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) jsonRespond(['error' => 'Data inválida'], 400);

            // Mesma validação de conflito do agendamento novo (excluindo o próprio registro):
            // sem isso o reagendamento sobrepunha horário já ocupado (double-booking).
            $duration = (int)($row['duration'] ?? 0);
            if ($duration <= 0) $duration = 150;
            $services = function_exists('decodeJsonOrArray')
                ? decodeJsonOrArray($row['services'] ?? '[]')
                : (json_decode((string)($row['services'] ?? '[]'), true) ?: []);
            if (!is_array($services) || count(array_filter($services, static fn($s) => is_string($s) && trim($s) !== '')) < 1) {
                $svcName = trim((string)($row['service'] ?? $row['service_name'] ?? ''));
                $services = $svcName !== '' ? [$svcName] : ['Serviço'];
            }
            $err = validateAppointmentPayload($pdo, [
                'date' => $date,
                'time' => $time,
                'duration' => $duration,
                'services' => $services,
            ], $id);
            if ($err) {
                jsonRespond([
                    'error' => $err,
                    'code' => 'conflict',
                    'suggestions' => suggestAlternativeSlots($pdo, $date, $time, $duration, 4, $id),
                ], 409);
            }

            $pdo->prepare('UPDATE appointments SET date = ?, time = ?, status = ?, updated_at = ?, client_id = COALESCE(client_id, ?) WHERE id = ?')
                ->execute([$date, $time, $status === 'confirmed' ? 'confirmed' : 'pending', dbNow(), $clientId, $id]);
            jsonRespond(['ok' => true, 'status' => $status === 'confirmed' ? 'confirmed' : 'pending', 'date' => $date, 'time' => $time]);
        }

        jsonRespond(['error' => 'action deve ser cancel ou reschedule'], 400);
    }

    jsonRespond(['error' => 'Use GET ou PUT'], 405);
}

function handleClientUpload(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    $clientId = requireClient();
    rateLimit('client_upload', 20);

    if (empty($_FILES['file'])) jsonRespond(['error' => 'Arquivo obrigatório'], 400);
    $file = $_FILES['file'];
    if ($file['error'] !== UPLOAD_ERR_OK) jsonRespond(['error' => 'Erro no upload'], 400);

    $maxMb = defined('MAX_UPLOAD_MB') ? (int)MAX_UPLOAD_MB : 20;
    if ($file['size'] > $maxMb * 1024 * 1024) {
        jsonRespond(['error' => "Arquivo excede {$maxMb}MB"], 413);
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    if (!is_string($mime) || $mime === '') {
        jsonRespond(['error' => 'Não foi possível validar o tipo do arquivo'], 415);
    }
    $allowed = [
        'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp',
        'image/heic' => 'heic', 'image/heif' => 'heif',
    ];
    if (!isset($allowed[$mime])) {
        jsonRespond(['error' => 'Formato não permitido. Use JPG, PNG ou WEBP.'], 415);
    }

    $dir = defined('UPLOADS_DIR_API') ? UPLOADS_DIR_API . '/client' : __DIR__ . '/uploads/client';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $ext = $allowed[$mime];
    $filename = 'client_' . $clientId . '_' . uniqid('', true) . '.' . $ext;
    $dest = $dir . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        jsonRespond(['error' => 'Falha ao salvar'], 500);
    }

    $pdo = db();
    if (function_exists('ensureQuoteTables')) ensureQuoteTables($pdo);
    if (function_exists('ensurePortalTables')) ensurePortalTables($pdo);
    $url = 'uploads/client/' . $filename;
    $entityId = san($_POST['entity_id'] ?? ('client_' . $clientId), 64) ?? ('client_' . $clientId);
    try {
        $pdo->prepare("INSERT INTO quote_photos (entity_type, entity_id, client_id, url, filename, size_bytes, mime, created_at)
            VALUES ('client', ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$entityId, $clientId, $url, $filename, (int)$file['size'], $mime, dbNow()]);
    } catch (PDOException $e) {
        $pdo->prepare("INSERT INTO quote_photos (entity_type, entity_id, url, filename, size_bytes, mime, created_at)
            VALUES ('client', ?, ?, ?, ?, ?, ?)")
            ->execute([$entityId, $url, $filename, (int)$file['size'], $mime, dbNow()]);
    }

    jsonRespond([
        'url' => $url,
        'filename' => $filename,
        'entityId' => $entityId,
        'id' => (int)$pdo->lastInsertId(),
    ], 201);
}

function handleClientLogout(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    $auth = getAuthorizationHeader();
    if (strpos($auth, 'Bearer ') === 0) {
        $token = trim(substr($auth, 7));
        if ($token !== '') {
            try {
                $h = hashSessionToken($token);
                // Sessões novas gravam hash em token + token_hash; legado pode ter token em claro.
                db()->prepare(
                    'DELETE FROM client_sessions WHERE token_hash = ? OR token = ? OR token = ?'
                )->execute([$h, $h, $token]);
            } catch (PDOException $e) {
                try {
                    db()->prepare('DELETE FROM client_sessions WHERE token = ?')->execute([$token]);
                } catch (PDOException $e2) { /* ignore */ }
            }
        }
    }
    jsonRespond(['ok' => true]);
}
