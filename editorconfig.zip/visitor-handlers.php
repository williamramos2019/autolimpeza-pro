<?php
/**
 * Persistência de endereço do visitante (geolocalização LGPD).
 */

function ensureVisitorLocationColumns(PDO $pdo): void {
    $alters = [
        "ALTER TABLE `visitors` ADD COLUMN `address` TEXT DEFAULT NULL",
        "ALTER TABLE `visitors` ADD COLUMN `neighborhood` VARCHAR(120) DEFAULT NULL",
        "ALTER TABLE `visitors` ADD COLUMN `zip_code` VARCHAR(20) DEFAULT NULL",
        "ALTER TABLE `visitors` ADD COLUMN `distance_km` DECIMAL(8,2) DEFAULT NULL",
    ];
    foreach ($alters as $sql) {
        try { $pdo->exec($sql); } catch (PDOException $e) { /* exists */ }
    }
}

function ensureClientAddressColumns(PDO $pdo): void {
    $alters = [
        "ALTER TABLE `clients` ADD COLUMN `city` VARCHAR(100) DEFAULT NULL",
        "ALTER TABLE `clients` ADD COLUMN `state` VARCHAR(100) DEFAULT NULL",
        "ALTER TABLE `clients` ADD COLUMN `address` TEXT DEFAULT NULL",
        "ALTER TABLE `clients` ADD COLUMN `neighborhood` VARCHAR(120) DEFAULT NULL",
        "ALTER TABLE `clients` ADD COLUMN `zip_code` VARCHAR(20) DEFAULT NULL",
        "ALTER TABLE `clients` ADD COLUMN `latitude` DECIMAL(10,8) DEFAULT NULL",
        "ALTER TABLE `clients` ADD COLUMN `longitude` DECIMAL(11,8) DEFAULT NULL",
    ];
    foreach ($alters as $sql) {
        try { $pdo->exec($sql); } catch (PDOException $e) { /* exists */ }
    }
}

function handleVisitorLocation(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Use POST'], 405);
    }
    rateLimit('visitor_location', 20);

    $b = jsonBody();
    $visitorId = san($b['visitor_id'] ?? null, 64);
    if (!$visitorId) {
        jsonRespond(['error' => 'visitor_id obrigatório'], 400);
    }
    // Impede sobrescrever localização de outro visitante (IDOR):
    // só o próprio dispositivo (cookie), cliente logado dono do id, ou admin.
    if (function_exists('assertVisitorAccess')) {
        assertVisitorAccess($visitorId);
    }

    $lat = sanFloat($b['latitude'] ?? null);
    $lon = sanFloat($b['longitude'] ?? null);
    if ($lat === null || $lon === null) {
        jsonRespond(['error' => 'Coordenadas inválidas'], 400);
    }

    $pdo = db();
    ensureVisitorLocationColumns($pdo);

    $now = dbNow();
    $city         = san($b['city'] ?? null, 100);
    $state        = san($b['state'] ?? null, 100);
    $country      = san($b['country'] ?? null, 100);
    $address      = san($b['address'] ?? null, 500);
    $neighborhood = san($b['neighborhood'] ?? null, 120);
    $zipCode      = san($b['zip_code'] ?? $b['zipCode'] ?? null, 20);
    $distanceKm   = sanFloat($b['distance_km'] ?? $b['distanceKm'] ?? null);

    $pdo->prepare("
        INSERT INTO visitors
            (id, first_seen, last_seen, visit_count, city, state, country,
             latitude, longitude, address, neighborhood, zip_code, distance_km)
        VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            last_seen    = VALUES(last_seen),
            city         = COALESCE(VALUES(city), city),
            state        = COALESCE(VALUES(state), state),
            country      = COALESCE(VALUES(country), country),
            latitude     = COALESCE(VALUES(latitude), latitude),
            longitude    = COALESCE(VALUES(longitude), longitude),
            address      = COALESCE(VALUES(address), address),
            neighborhood = COALESCE(VALUES(neighborhood), neighborhood),
            zip_code     = COALESCE(VALUES(zip_code), zip_code),
            distance_km  = COALESCE(VALUES(distance_km), distance_km)
    ")->execute([
        $visitorId, $now, $now,
        $city, $state, $country,
        $lat, $lon, $address, $neighborhood, $zipCode, $distanceKm,
    ]);

    jsonRespond(['ok' => true]);
}
