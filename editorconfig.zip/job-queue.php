<?php
/**
 * Job Queue genérica (e-mail, IA, webhooks).
 * Drivers: mysql (tabela job_queue) | redis | auto
 * Worker: incluído em cron.php → runCronJobs() → alpProcessJobQueue()
 * Alternativa manual: action=system/queue-process
 */

function ensureJobQueueTable(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `job_queue` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `job_type` VARCHAR(80) NOT NULL,
        `payload` JSON NOT NULL,
        `status` ENUM('pending','running','done','failed') NOT NULL DEFAULT 'pending',
        `attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
        `available_at` DATETIME NOT NULL,
        `locked_at` DATETIME NULL,
        `last_error` TEXT NULL,
        `created_at` DATETIME NOT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_status_available` (`status`, `available_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function alpEnqueueJob(string $jobType, array $payload, int $delaySeconds = 0): ?int {
    try {
        $pdo = db();
        ensureJobQueueTable($pdo);
        $now = dbNow();
        $available = $delaySeconds > 0
            ? date('Y-m-d H:i:s', time() + $delaySeconds)
            : $now;
        $pdo->prepare(
            'INSERT INTO job_queue (job_type, payload, status, attempts, available_at, created_at, updated_at)
             VALUES (?, ?, \'pending\', 0, ?, ?, ?)'
        )->execute([
            $jobType,
            json_encode($payload, JSON_UNESCAPED_UNICODE),
            $available,
            $now,
            $now,
        ]);
        return (int)$pdo->lastInsertId();
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('error', 'job_enqueue_failed', ['type' => $jobType, 'err' => $e->getMessage()]);
        }
        return null;
    }
}

/**
 * Processa até $limit jobs. Handlers registrados em $GLOBALS['alp_job_handlers'].
 */
function alpProcessJobQueue(int $limit = 20): array {
    $pdo = db();
    ensureJobQueueTable($pdo);
    $done = 0;
    $failed = 0;
    $now = dbNow();

    $stmt = $pdo->prepare(
        "SELECT * FROM job_queue
         WHERE status = 'pending' AND available_at <= ?
         ORDER BY id ASC LIMIT " . (int)$limit
    );
    $stmt->execute([$now]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $row) {
        $id = (int)$row['id'];
        $pdo->prepare("UPDATE job_queue SET status='running', locked_at=?, attempts=attempts+1, updated_at=? WHERE id=? AND status='pending'")
            ->execute([$now, $now, $id]);
        if ($pdo->query("SELECT status FROM job_queue WHERE id=$id")->fetchColumn() !== 'running') {
            continue;
        }

        $type = (string)$row['job_type'];
        $payload = json_decode((string)$row['payload'], true) ?: [];
        $handlers = $GLOBALS['alp_job_handlers'] ?? [];
        try {
            if (isset($handlers[$type]) && is_callable($handlers[$type])) {
                $handlers[$type]($pdo, $payload);
            } elseif ($type === 'mail.send' && function_exists('sendMailMessage')) {
                sendMailMessage(
                    (string)($payload['to'] ?? ''),
                    (string)($payload['subject'] ?? ''),
                    (string)($payload['body'] ?? '')
                );
            } else {
                throw new RuntimeException("handler ausente: $type");
            }
            $pdo->prepare("UPDATE job_queue SET status='done', updated_at=? WHERE id=?")->execute([dbNow(), $id]);
            $done++;
        } catch (Throwable $e) {
            $pdo->prepare("UPDATE job_queue SET status='failed', last_error=?, updated_at=? WHERE id=?")
                ->execute([substr($e->getMessage(), 0, 500), dbNow(), $id]);
            $failed++;
        }
    }

    return ['processed' => count($rows), 'done' => $done, 'failed' => $failed];
}

function handleSystemQueueProcess(string $method): void {
    if ($method !== 'POST' && $method !== 'GET') {
        jsonRespond(['error' => 'Use GET/POST'], 405);
    }
    // Cron secret OU admin
    $cronOk = false;
    if (defined('CRON_SECRET') && CRON_SECRET !== '') {
        $tok = $_GET['token'] ?? ($_SERVER['HTTP_X_CRON_TOKEN'] ?? '');
        $cronOk = is_string($tok) && hash_equals((string)CRON_SECRET, $tok);
    }
    if (!$cronOk) requireAdmin();
    $limit = min(50, max(1, (int)($_GET['limit'] ?? 20)));
    jsonRespond(array_merge(['ok' => true], alpProcessJobQueue($limit)));
}
