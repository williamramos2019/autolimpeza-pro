<?php

/**
 * Front controller na raiz do addon HostGator (Document Root != public/).
 * Não alterar a lógica em public/index.php.
 */
require __DIR__.'/public/index.php';
