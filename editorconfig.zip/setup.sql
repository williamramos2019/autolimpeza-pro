-- ============================================================
-- Auto Limpeza Pro — Schema MySQL
-- ============================================================
-- Como usar:
--   1. Acesse cPanel → phpMyAdmin
--   2. Selecione seu banco de dados
--   3. Clique na aba "SQL"
--   4. Cole este conteúdo e clique em "Executar"
--
--  OU acesse install.php no seu navegador (mais fácil).
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '-03:00';

-- ── 1. Visitantes únicos ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `visitors` (
  `id`          VARCHAR(64)  NOT NULL,
  `first_seen`  DATETIME     NOT NULL,
  `last_seen`   DATETIME     NOT NULL,
  `visit_count` INT UNSIGNED NOT NULL DEFAULT 1,
  `device_type` VARCHAR(20)  DEFAULT NULL,
  `browser`     VARCHAR(50)  DEFAULT NULL,
  `city`        VARCHAR(100) DEFAULT NULL,
  `state`       VARCHAR(100) DEFAULT NULL,
  `country`     VARCHAR(100) DEFAULT NULL,
  `latitude`    DECIMAL(10,8) DEFAULT NULL,
  `longitude`   DECIMAL(11,8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_last_seen` (`last_seen`),
  INDEX `idx_city`      (`city`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 2. Sessões ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `sessions` (
  `id`              VARCHAR(64)  NOT NULL,
  `visitor_id`      VARCHAR(64)  NOT NULL,
  `started_at`      DATETIME     NOT NULL,
  `last_active`     DATETIME     NOT NULL,
  `path_count`      INT UNSIGNED NOT NULL DEFAULT 1,
  `source_category` VARCHAR(20)  DEFAULT 'direct',
  `source_name`     VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_visitor_id` (`visitor_id`),
  INDEX `idx_started_at` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 3. Analytics (pageviews) ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `analytics` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `visitor_id`      VARCHAR(64)   DEFAULT NULL,
  `session_id`      VARCHAR(64)   DEFAULT NULL,
  `path`            VARCHAR(255)  NOT NULL,
  `source_category` VARCHAR(20)   DEFAULT 'direct',
  `source_name`     VARCHAR(100)  DEFAULT NULL,
  `device_type`     VARCHAR(20)   DEFAULT NULL,
  `browser`         VARCHAR(50)   DEFAULT NULL,
  `city`            VARCHAR(100)  DEFAULT NULL,
  `state`           VARCHAR(100)  DEFAULT NULL,
  `country`         VARCHAR(100)  DEFAULT NULL,
  `latitude`        DECIMAL(10,8) DEFAULT NULL,
  `longitude`       DECIMAL(11,8) DEFAULT NULL,
  `is_new_visitor`  TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`      DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_visitor_id` (`visitor_id`),
  INDEX `idx_session_id` (`session_id`),
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_city`       (`city`),
  INDEX `idx_path_created` (`path`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 4. Agendamentos ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `appointments` (
  `id`          VARCHAR(64)    NOT NULL,
  `time`        VARCHAR(10)    DEFAULT NULL,
  `date`        VARCHAR(10)    DEFAULT NULL,
  `client`      VARCHAR(200)   DEFAULT NULL,
  `phone`       VARCHAR(50)    DEFAULT NULL,
  `address`     TEXT           DEFAULT NULL,
  `distance_km` DECIMAL(8,2)   DEFAULT NULL,
  `services`    JSON           DEFAULT NULL,
  `employee`    VARCHAR(100)   DEFAULT NULL,
  `status`      VARCHAR(20)    NOT NULL DEFAULT 'pending',
  `duration`    INT            DEFAULT NULL,
  `visitor_id`  VARCHAR(64)    DEFAULT NULL,
  `client_id`   INT UNSIGNED   DEFAULT NULL,
  `created_at`  DATETIME       NOT NULL,
  `updated_at`  DATETIME       NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_date`       (`date`),
  INDEX `idx_status`     (`status`),
  INDEX `idx_visitor_id` (`visitor_id`),
  INDEX `idx_client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Para bancos já instalados sem visitor_id, execute no phpMyAdmin se necessário:
-- ALTER TABLE `appointments` ADD COLUMN `visitor_id` VARCHAR(64) DEFAULT NULL;
-- ALTER TABLE `appointments` ADD INDEX `idx_visitor_id` (`visitor_id`);

-- ── 5. Blog / Dicas ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `blog_posts` (
  `slug`         VARCHAR(200)  NOT NULL,
  `title`        VARCHAR(500)  DEFAULT NULL,
  `excerpt`      TEXT          DEFAULT NULL,
  `content`      LONGTEXT      DEFAULT NULL,
  `category`     VARCHAR(100)  DEFAULT NULL,
  `icon_name`    VARCHAR(50)   DEFAULT NULL,
  `read_minutes` INT           DEFAULT 5,
  `published_at` DATE          DEFAULT NULL,
  `tags`         JSON          DEFAULT NULL,
  `service_id`   VARCHAR(100)  DEFAULT NULL,
  `image_url`    VARCHAR(500)  DEFAULT NULL,
  `related`      JSON          DEFAULT NULL,
  `blocks`       JSON          DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL,
  `updated_at`   DATETIME      NOT NULL,
  PRIMARY KEY (`slug`),
  INDEX `idx_published_at` (`published_at`),
  INDEX `idx_category`     (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 6. Configurações do site ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `site_config` (
  `key_name`   VARCHAR(100) NOT NULL,
  `value`      TEXT         DEFAULT NULL,
  `updated_at` DATETIME     NOT NULL,
  PRIMARY KEY (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 6. Bairros ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `neighborhoods` (
  `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `city`         VARCHAR(255)  NOT NULL,
  `city_slug`    VARCHAR(255)  NOT NULL,
  `neighborhood` VARCHAR(255)  NOT NULL,
  `slug`         VARCHAR(255)  NOT NULL,
  `active`       TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_city_neighborhood` (`city_slug`, `slug`),
  INDEX `idx_city_slug` (`city_slug`),
  INDEX `idx_active`    (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 7. Leads ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `leads` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(255)  NOT NULL,
  `phone`      VARCHAR(50)   NOT NULL,
  `service`    VARCHAR(255)  NOT NULL DEFAULT '',
  `city`       VARCHAR(255)  NOT NULL DEFAULT '',
  `source`     VARCHAR(100)  NOT NULL DEFAULT 'lead_modal',
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 8. CMS — Transformações (antes/depois) ────────────────────────────────
CREATE TABLE IF NOT EXISTS `cms_transformations` (
  `id`           VARCHAR(64)   NOT NULL,
  `slug`         VARCHAR(200)  NOT NULL,
  `title`        VARCHAR(300)  NOT NULL,
  `service_type` VARCHAR(100)  NOT NULL DEFAULT '',
  `city`         VARCHAR(100)  NOT NULL DEFAULT '',
  `description`  TEXT          DEFAULT NULL,
  `before_image` VARCHAR(500)  DEFAULT NULL,
  `after_image`  VARCHAR(500)  DEFAULT NULL,
  `video_url`    VARCHAR(500)  DEFAULT NULL,
  `featured`     TINYINT(1)    NOT NULL DEFAULT 0,
  `sort_order`   INT           NOT NULL DEFAULT 0,
  `published`    TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`   DATETIME      NOT NULL,
  `updated_at`   DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`),
  INDEX `idx_published` (`published`),
  INDEX `idx_featured` (`featured`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 9. Chat IA — conversas e mensagens ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `conversations` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `visitor_id` VARCHAR(64)   DEFAULT NULL,
  `title`      VARCHAR(255)  NOT NULL DEFAULT 'Nova conversa',
  `created_at` DATETIME      NOT NULL,
  `updated_at` DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `messages` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `conversation_id` INT UNSIGNED NOT NULL,
  `role`            VARCHAR(20)  NOT NULL,
  `content`         TEXT         NOT NULL,
  `created_at`      DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_conversation_id` (`conversation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 10. Desafio de Transformação — participantes ─────────────────────────
CREATE TABLE IF NOT EXISTS `challenge_participants` (
  `id`                    VARCHAR(64)   NOT NULL,
  `slug`                  VARCHAR(200)  NOT NULL,
  `nome`                  VARCHAR(200)  NOT NULL,
  `whatsapp`              VARCHAR(50)   NOT NULL,
  `email`                 VARCHAR(200)  DEFAULT NULL,
  `cidade`                VARCHAR(100)  NOT NULL DEFAULT '',
  `categoria`             VARCHAR(50)   NOT NULL DEFAULT 'sofa',
  `descricao`             TEXT          DEFAULT NULL,
  `historia`              TEXT          DEFAULT NULL,
  `status`                VARCHAR(30)   NOT NULL DEFAULT 'pending',
  `pontos`                INT UNSIGNED  NOT NULL DEFAULT 0,
  `votos`                 INT UNSIGNED  NOT NULL DEFAULT 0,
  `compartilhamentos`     INT UNSIGNED  NOT NULL DEFAULT 0,
  `referral_code`         VARCHAR(20)   NOT NULL,
  `referred_by`           VARCHAR(64)   DEFAULT NULL,
  `campaign_month`        VARCHAR(7)    NOT NULL,
  `meta_title`            VARCHAR(300)  DEFAULT NULL,
  `meta_description`      TEXT          DEFAULT NULL,
  `score_sujeira`         DECIMAL(5,2)  DEFAULT NULL,
  `score_manchas`         DECIMAL(5,2)  DEFAULT NULL,
  `score_desgaste`        DECIMAL(5,2)  DEFAULT NULL,
  `score_odor_estimado`   DECIMAL(5,2)  DEFAULT NULL,
  `indice_transformacao`  DECIMAL(5,2)  DEFAULT NULL,
  `visitor_id`            VARCHAR(64)   DEFAULT NULL,
  `crm_status`            VARCHAR(30)   NOT NULL DEFAULT 'novo',
  `is_winner`             TINYINT(1)    NOT NULL DEFAULT 0,
  `winner_month`          VARCHAR(7)    DEFAULT NULL,
  `transformation_id`     VARCHAR(64)   DEFAULT NULL,
  `created_at`            DATETIME      NOT NULL,
  `updated_at`            DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`),
  UNIQUE KEY `uq_referral_code` (`referral_code`),
  INDEX `idx_status` (`status`),
  INDEX `idx_categoria` (`categoria`),
  INDEX `idx_campaign` (`campaign_month`),
  INDEX `idx_pontos` (`pontos`),
  INDEX `idx_votos` (`votos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `challenge_photos` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `participant_id`  VARCHAR(64)   NOT NULL,
  `url`             VARCHAR(500)  NOT NULL,
  `thumb_url`       VARCHAR(500)  DEFAULT NULL,
  `webp_url`        VARCHAR(500)  DEFAULT NULL,
  `photo_type`      VARCHAR(20)   NOT NULL DEFAULT 'geral',
  `sort_order`      INT           NOT NULL DEFAULT 0,
  `created_at`      DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_participant` (`participant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `challenge_videos` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `participant_id`  VARCHAR(64)   NOT NULL,
  `video_type`      VARCHAR(20)   NOT NULL DEFAULT 'upload',
  `url`             VARCHAR(500)  NOT NULL,
  `embed_url`       VARCHAR(500)  DEFAULT NULL,
  `sort_order`      INT           NOT NULL DEFAULT 0,
  `created_at`      DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_participant` (`participant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `challenge_votes` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `participant_id`  VARCHAR(64)   NOT NULL,
  `voter_hash`      VARCHAR(64)   NOT NULL,
  `ip_hash`         VARCHAR(64)   DEFAULT NULL,
  `cookie_id`       VARCHAR(64)   DEFAULT NULL,
  `visitor_id`      VARCHAR(64)   DEFAULT NULL,
  `created_at`      DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vote` (`participant_id`, `voter_hash`),
  INDEX `idx_participant` (`participant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `challenge_referrals` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `referrer_id`     VARCHAR(64)   NOT NULL,
  `code`            VARCHAR(20)   NOT NULL,
  `clicks`          INT UNSIGNED  NOT NULL DEFAULT 0,
  `signups`         INT UNSIGNED  NOT NULL DEFAULT 0,
  `conversions`     INT UNSIGNED  NOT NULL DEFAULT 0,
  `points_awarded`  INT UNSIGNED  NOT NULL DEFAULT 0,
  `created_at`      DATETIME      NOT NULL,
  `updated_at`      DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_code` (`code`),
  INDEX `idx_referrer` (`referrer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `challenge_referral_clicks` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `code`        VARCHAR(20)   NOT NULL,
  `ip_hash`     VARCHAR(64)   DEFAULT NULL,
  `created_at`  DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `challenge_badges` (
  `id`          VARCHAR(64)   NOT NULL,
  `slug`        VARCHAR(100)  NOT NULL,
  `nome`        VARCHAR(200)  NOT NULL,
  `descricao`   TEXT          DEFAULT NULL,
  `icon`        VARCHAR(50)   DEFAULT NULL,
  `pontos`      INT UNSIGNED  NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_badge_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `challenge_participant_badges` (
  `participant_id`  VARCHAR(64)  NOT NULL,
  `badge_id`        VARCHAR(64)  NOT NULL,
  `awarded_at`      DATETIME     NOT NULL,
  PRIMARY KEY (`participant_id`, `badge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `challenge_mission_log` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `participant_id`  VARCHAR(64)   NOT NULL,
  `mission_key`     VARCHAR(50)   NOT NULL,
  `points`          INT UNSIGNED  NOT NULL DEFAULT 0,
  `created_at`      DATETIME      NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mission` (`participant_id`, `mission_key`),
  INDEX `idx_participant` (`participant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── 11. Administradores ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id`                   INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `email`                VARCHAR(255)  NOT NULL,
  `name`                 VARCHAR(200)  NOT NULL DEFAULT 'Administrador',
  `password_hash`        VARCHAR(255)  NOT NULL,
  `role`                 VARCHAR(20)   NOT NULL DEFAULT 'admin',
  `must_change_password` TINYINT(1)    NOT NULL DEFAULT 1,
  `active`               TINYINT(1)    NOT NULL DEFAULT 1,
  `created_at`           DATETIME      NOT NULL,
  `updated_at`           DATETIME      NOT NULL,
  `last_login_at`        DATETIME      DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_email` (`email`),
  INDEX `idx_active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `admin_sessions` (
  `token`      VARCHAR(64)  NOT NULL,
  `user_id`    INT UNSIGNED NOT NULL,
  `expires_at` DATETIME     NOT NULL,
  `created_at` DATETIME     NOT NULL,
  PRIMARY KEY (`token`),
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Dados iniciais de configuração ────────────────────────────────────────
INSERT IGNORE INTO `site_config` (`key_name`, `value`, `updated_at`) VALUES
  ('ga_id',               NULL,               NOW()),
  ('meta_pixel_id',       '1301066345201510', NOW()),
  ('whatsapp',            '5531980252882',    NOW()),
  ('business_name',       'Auto Limpeza Pro', NOW()),
  ('pushalert_rest_key',  NULL,               NOW()),
  ('installed_at',        NOW(),              NOW()),
  ('challenge_missions',  '{"share":50,"refer":100,"whatsapp_group":30,"quote":80,"complete_profile":20}', NOW()),
  ('challenge_active',    '1',                NOW());

INSERT IGNORE INTO `challenge_badges` (`id`, `slug`, `nome`, `descricao`, `icon`, `pontos`) VALUES
  ('bdg_resgate',     'resgate-extremo',      'Resgate Extremo',       'Transformação mais impressionante do mês', 'flame',       500),
  ('bdg_raro',        'caso-raro',            'Caso Raro',             'Situação única e memorável',              'gem',         300),
  ('bdg_publico',     'escolha-publico',      'Escolha do Público',    'Mais votado pelos visitantes',            'heart',       400),
  ('bdg_mes',         'transformacao-mes',      'Transformação do Mês',  'Vencedor oficial do desafio mensal',      'trophy',      1000),
  ('bdg_share',       'top-compartilhador',   'Top Compartilhador',    'Maior alcance nas redes sociais',         'share-2',     250);
