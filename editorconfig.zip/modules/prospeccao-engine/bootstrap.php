<?php
/**
 * Prospecção Engine Pro — bootstrap (carrega módulos)
 */
require_once __DIR__ . '/services/EngineSchema.php';
require_once __DIR__ . '/services/JobService.php';
require_once __DIR__ . '/services/RateLimiter.php';
require_once __DIR__ . '/services/ResponseCache.php';
require_once __DIR__ . '/collector/GeoGrid.php';
require_once __DIR__ . '/adapters/GooglePlacesAdapter.php';
require_once __DIR__ . '/collector/PlacesCollector.php';
require_once __DIR__ . '/enrichment/LightCrawler.php';
require_once __DIR__ . '/enrichment/EnrichmentEngine.php';
require_once __DIR__ . '/normalization/IpcScorer.php';
require_once __DIR__ . '/normalization/LeadNormalizer.php';
require_once __DIR__ . '/adapters/CrmBridge.php';
require_once __DIR__ . '/export/ExportEngine.php';
require_once __DIR__ . '/jobs/JobProcessor.php';
