<?php
/**
 * Prospecção Engine Pro — collector (grade + paginação Places)
 */

class ProspeccaoEnginePlacesCollector {
    private PDO $pdo;
    private ProspeccaoEngineGooglePlacesAdapter $places;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->places = new ProspeccaoEngineGooglePlacesAdapter($pdo);
    }

    public function initGrid(int $jobId, array $job): int {
        $config = $job['config'] ?? [];
        $stepKm = (float)($config['gridStepKm'] ?? 3.0);
        $cells = ProspeccaoEngineGeoGrid::buildCells(
            $job['city'],
            $job['categories'],
            $job['radiusM'],
            $stepKm
        );
        $count = ProspeccaoEngineGeoGrid::persistCells($this->pdo, $jobId, $cells);
        ProspeccaoEngineJobService::updateProgress($this->pdo, $jobId, [
            'total_cells' => $count,
            'completed_cells' => 0,
            'phase' => 'collect',
            'status' => 'running',
            'started_at' => $job['startedAt'] ?? dbNow(),
        ]);
        ProspeccaoEngineJobService::logEvent($this->pdo, $jobId, 'grid_ready', 'info',
            "Grade criada: {$count} células ({$job['city']})", ['totalCells' => $count]);
        return $count;
    }

    /**
     * Processa uma página de uma célula ou avança para próxima célula.
     * @return array{done:bool,leadsAdded:int,message:string}
     */
    public function processCollectStep(int $jobId): array {
        $cell = ProspeccaoEngineGeoGrid::nextPendingCell($this->pdo, $jobId);
        if (!$cell) {
            return ['done' => true, 'leadsAdded' => 0, 'message' => 'Coleta concluída — todas as células processadas'];
        }

        $cellId = (int)$cell['id'];
        // Já claimed como running em nextPendingCell

        $query = trim($cell['category'] . ' ' . $cell['city'] . ' MG Brasil');
        $pageToken = $cell['page_token'] ?: null;
        $lat = (float)$cell['cell_lat'];
        $lng = (float)$cell['cell_lng'];
        $radiusM = (int)$cell['radius_m'];

        $res = $this->places->textSearch($query, $pageToken, $lat, $lng, $radiusM);

        if (!($res['ok'] ?? false)) {
            $retry = (int)$cell['retry_count'] + 1;
            if ($retry < ProspeccaoEngineRateLimiter::maxRetries()) {
                ProspeccaoEngineGeoGrid::setCellPageToken($this->pdo, $cellId, $pageToken, $retry);
                ProspeccaoEngineGeoGrid::markCell($this->pdo, $cellId, 'pending', null, $res['error'] ?? 'Erro Places');
                ProspeccaoEngineJobService::logEvent($this->pdo, $jobId, 'retry', 'warn',
                    "Retry {$retry} célula #{$cellId}: " . ($res['error'] ?? 'erro'), ['cellId' => $cellId]);
                usleep(ProspeccaoEngineRateLimiter::backoffMs($retry) * 1000);
                return ['done' => false, 'leadsAdded' => 0, 'message' => 'Retry agendado'];
            }
            ProspeccaoEngineGeoGrid::markCell($this->pdo, $cellId, 'failed', 0, $res['error'] ?? 'Falha após retries');
            $this->incrementCompletedCells($jobId);
            return ['done' => false, 'leadsAdded' => 0, 'message' => 'Célula falhou após retries'];
        }

        $added = 0;
        foreach ($res['items'] ?? [] as $item) {
            if ($this->upsertLead($jobId, $item, $cell)) {
                $added++;
            }
        }

        $nextToken = $res['nextPageToken'] ?? null;
        $placesFound = (int)$cell['places_found'] + count($res['items'] ?? []);

        if ($nextToken) {
            ProspeccaoEngineGeoGrid::setCellPageToken($this->pdo, $cellId, $nextToken, 0);
            ProspeccaoEngineGeoGrid::markCell($this->pdo, $cellId, 'pending', $placesFound);
            if ($pageToken === null) {
                usleep(2100000);
            }
            ProspeccaoEngineJobService::logEvent($this->pdo, $jobId, 'partial', 'info',
                "Célula #{$cellId} página parcial (+{$added} leads)", [
                    'cellId' => $cellId, 'category' => $cell['category'], 'added' => $added,
                ]);
            return ['done' => false, 'leadsAdded' => $added, 'message' => "Página coletada (+{$added})"];
        }

        ProspeccaoEngineGeoGrid::markCell($this->pdo, $cellId, 'done', $placesFound);
        $this->incrementCompletedCells($jobId);

        ProspeccaoEngineJobService::logEvent($this->pdo, $jobId, 'cell_done', 'info',
            "Célula #{$cellId} concluída: {$cell['category']} (+{$added} novos)", [
                'cellId' => $cellId, 'placesFound' => $placesFound, 'added' => $added,
            ]);

        return ['done' => false, 'leadsAdded' => $added, 'message' => "Célula concluída (+{$added})"];
    }

    private function upsertLead(int $jobId, array $item, array $cell): bool {
        $placeId = $item['placeId'] ?? null;
        if (!$placeId) return false;

        $stmt = $this->pdo->prepare('SELECT id FROM prospeccao_engine_leads WHERE job_id = ? AND place_id = ? LIMIT 1');
        $stmt->execute([$jobId, $placeId]);
        if ($stmt->fetchColumn()) return false;

        $details = $this->places->fetchDetails($placeId);
        if ($details) {
            $item = array_merge($item, array_filter($details, static fn($v) => $v !== null && $v !== ''));
        }

        $now = dbNow();
        $location = [
            'city'         => $cell['city'],
            'address'      => $item['address'] ?? null,
            'latitude'     => $item['latitude'] ?? null,
            'longitude'    => $item['longitude'] ?? null,
            'neighborhood' => null,
        ];

        try {
            $this->pdo->prepare('INSERT INTO prospeccao_engine_leads
                (job_id, place_id, name, category, phone, website, rating, reviews_count, location_json, hours_json,
                 raw_json, source, dedup_key, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([
                    $jobId,
                    $placeId,
                    san($item['name'] ?? 'Sem nome', 255) ?? 'Sem nome',
                    san($cell['category'], 120),
                    san($item['phone'] ?? null, 50),
                    san($item['website'] ?? null, 500),
                    $item['rating'] ?? null,
                    $item['reviewsCount'] ?? null,
                    json_encode($location, JSON_UNESCAPED_UNICODE),
                    isset($item['hours']) ? json_encode($item['hours'], JSON_UNESCAPED_UNICODE) : null,
                    json_encode($item, JSON_UNESCAPED_UNICODE),
                    'prospeccao-engine',
                    'place:' . $placeId,
                    $now, $now,
                ]);
        } catch (PDOException $e) {
            // Race UNIQUE (job_id, place_id) — outro worker já inseriu
            if ((int)($e->errorInfo[1] ?? 0) === 1062 || stripos($e->getMessage(), 'Duplicate') !== false) {
                return false;
            }
            throw $e;
        }

        $this->pdo->prepare('UPDATE prospeccao_engine_jobs SET leads_found = leads_found + 1, updated_at = ? WHERE id = ?')
            ->execute([$now, $jobId]);

        return true;
    }

    private function incrementCompletedCells(int $jobId): void {
        $this->pdo->prepare('UPDATE prospeccao_engine_jobs SET completed_cells = completed_cells + 1, updated_at = ? WHERE id = ?')
            ->execute([dbNow(), $jobId]);
        ProspeccaoEngineJobService::recalcProgress($this->pdo, $jobId);
    }

    public function isCollectComplete(int $jobId): bool {
        return ProspeccaoEngineGeoGrid::countCells($this->pdo, $jobId, 'pending') === 0
            && ProspeccaoEngineGeoGrid::countCells($this->pdo, $jobId, 'running') === 0;
    }
}
