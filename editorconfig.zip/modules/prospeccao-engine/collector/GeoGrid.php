<?php
/**
 * Prospecção Engine Pro — grade geográfica city × category
 */

class ProspeccaoEngineGeoGrid {
    /**
     * Gera células de busca para city × category com clustering por raio.
     * @return array<int,array{city:string,category:string,lat:float,lng:float,radius_m:int}>
     */
    public static function buildCells(string $city, array $categories, int $radiusM, float $stepKm = 3.0): array {
        $centers = prospeccaoEngineCityCenters();
        $center = $centers[$city] ?? $centers['São José da Lapa'];
        $lat = (float)$center['lat'];
        $lng = (float)$center['lng'];
        $spanKm = (float)($center['span_km'] ?? 8);

        $points = self::hexGridPoints($lat, $lng, $spanKm, $stepKm);
        $cells = [];
        foreach ($categories as $category) {
            foreach ($points as $pt) {
                $cells[] = [
                    'city'      => $city,
                    'category'  => $category,
                    'lat'       => $pt['lat'],
                    'lng'       => $pt['lng'],
                    'radius_m'  => $radiusM,
                ];
            }
        }
        return $cells;
    }

    /** @return array<int,array{lat:float,lng:float}> */
    private static function hexGridPoints(float $centerLat, float $centerLng, float $spanKm, float $stepKm): array {
        $points = [['lat' => $centerLat, 'lng' => $centerLng]];
        $latDegPerKm = 1 / 111.0;
        $lngDegPerKm = 1 / (111.0 * cos(deg2rad($centerLat)));
        $half = $spanKm / 2;
        $steps = max(1, (int)ceil($spanKm / $stepKm));

        for ($iy = -$steps; $iy <= $steps; $iy++) {
            for ($ix = -$steps; $ix <= $steps; $ix++) {
                if ($ix === 0 && $iy === 0) continue;
                $dy = $iy * $stepKm * $latDegPerKm;
                $dx = $ix * $stepKm * $lngDegPerKm;
                $dist = sqrt(($ix * $stepKm) ** 2 + ($iy * $stepKm) ** 2);
                if ($dist > $half) continue;
                $points[] = ['lat' => round($centerLat + $dy, 7), 'lng' => round($centerLng + $dx, 7)];
            }
        }
        return $points;
    }

    public static function persistCells(PDO $pdo, int $jobId, array $cells): int {
        ensureProspeccaoEngineTables($pdo);
        $now = dbNow();
        $ins = $pdo->prepare('INSERT INTO prospeccao_engine_grid_cells
            (job_id, city, category, cell_lat, cell_lng, radius_m, status, created_at)
            VALUES (?,?,?,?,?,?,?,?)');
        $count = 0;
        foreach ($cells as $c) {
            $ins->execute([
                $jobId, $c['city'], $c['category'], $c['lat'], $c['lng'],
                $c['radius_m'], 'pending', $now,
            ]);
            $count++;
        }
        return $count;
    }

    public static function nextPendingCell(PDO $pdo, int $jobId): ?array {
        // Claim atômico — evita double-process entre cron e UI
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT * FROM prospeccao_engine_grid_cells
                WHERE job_id = ? AND status = 'pending' ORDER BY id ASC LIMIT 1 FOR UPDATE");
            $stmt->execute([$jobId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                // Reclama célula stuck em running (crash mid-step) — schema sem updated_at
                $stmt = $pdo->prepare("SELECT * FROM prospeccao_engine_grid_cells
                    WHERE job_id = ? AND status = 'running' ORDER BY id ASC LIMIT 1 FOR UPDATE");
                $stmt->execute([$jobId]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            if ($row && ($row['status'] ?? '') === 'pending') {
                $pdo->prepare("UPDATE prospeccao_engine_grid_cells SET status = 'running' WHERE id = ? AND status = 'pending'")
                    ->execute([(int)$row['id']]);
                $row['status'] = 'running';
            }
            $pdo->commit();
            return $row ?: null;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }

    public static function markCell(PDO $pdo, int $cellId, string $status, ?int $placesFound = null, ?string $error = null): void {
        $sets = ['status = ?'];
        $params = [$status];
        if ($placesFound !== null) {
            $sets[] = 'places_found = ?';
            $params[] = $placesFound;
        }
        if ($error !== null) {
            $sets[] = 'last_error = ?';
            $params[] = mb_substr($error, 0, 2000);
        }
        if ($status === 'done' || $status === 'failed') {
            $sets[] = 'completed_at = ?';
            $params[] = dbNow();
        }
        $params[] = $cellId;
        $pdo->prepare('UPDATE prospeccao_engine_grid_cells SET ' . implode(', ', $sets) . ' WHERE id = ?')
            ->execute($params);
    }

    public static function setCellPageToken(PDO $pdo, int $cellId, ?string $token, int $retryCount = 0): void {
        $pdo->prepare('UPDATE prospeccao_engine_grid_cells SET page_token = ?, retry_count = ? WHERE id = ?')
            ->execute([$token, $retryCount, $cellId]);
    }

    public static function countCells(PDO $pdo, int $jobId, ?string $status = null): int {
        if ($status) {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM prospeccao_engine_grid_cells WHERE job_id = ? AND status = ?');
            $stmt->execute([$jobId, $status]);
        } else {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM prospeccao_engine_grid_cells WHERE job_id = ?');
            $stmt->execute([$jobId]);
        }
        return (int)$stmt->fetchColumn();
    }
}
