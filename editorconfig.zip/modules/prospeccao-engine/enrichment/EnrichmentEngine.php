<?php
/**
 * Prospecção Engine Pro — enrichment (crawler + AI Gateway fallback)
 */

class ProspeccaoEngineEnrichmentEngine {
    private PDO $pdo;
    private ProspeccaoEngineLightCrawler $crawler;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->crawler = new ProspeccaoEngineLightCrawler();
    }

    /**
     * Enriquece um lote de leads pendentes.
     * @return array{enriched:int,done:bool}
     */
    public function processBatch(int $jobId, int $batchSize = 5): array {
        $stmt = $this->pdo->prepare('SELECT * FROM prospeccao_engine_leads
            WHERE job_id = ? AND enriched_at IS NULL ORDER BY id ASC LIMIT ' . max(1, min(20, $batchSize)));
        $stmt->execute([$jobId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!$rows) {
            return ['enriched' => 0, 'done' => true];
        }

        $count = 0;
        foreach ($rows as $row) {
            $this->enrichLead($row);
            $count++;
        }

        $this->pdo->prepare('UPDATE prospeccao_engine_jobs SET leads_enriched = (
            SELECT COUNT(*) FROM prospeccao_engine_leads WHERE job_id = ? AND enriched_at IS NOT NULL
        ), updated_at = ? WHERE id = ?')->execute([$jobId, dbNow(), $jobId]);

        $remaining = $this->countPending($jobId);
        return ['enriched' => $count, 'done' => $remaining === 0];
    }

    private function enrichLead(array $row): void {
        $social = [];
        $email = $row['email'];
        $phone = $row['phone'];
        $website = $row['website'];

        if ($website) {
            $html = $this->crawler->fetch($website);
            if ($html) {
                $extracted = $this->crawler->extractFromHtml($html);
                if (!$email && !empty($extracted['email'])) $email = $extracted['email'];
                if (!$phone && !empty($extracted['phone'])) $phone = $extracted['phone'];
                foreach (['instagram', 'facebook', 'linkedin', 'whatsapp'] as $k) {
                    if (!empty($extracted[$k])) $social[$k] = $extracted[$k];
                }
            }
        }

        if ((!$email || !$social) && $website) {
            $aiData = $this->aiExtract($row['name'], $website, $row);
            if ($aiData) {
                if (!$email && !empty($aiData['email'])) $email = $aiData['email'];
                if (!$phone && !empty($aiData['phone'])) $phone = $aiData['phone'];
                foreach (['instagram', 'facebook', 'linkedin', 'whatsapp'] as $k) {
                    if (empty($social[$k]) && !empty($aiData[$k])) $social[$k] = $aiData[$k];
                }
            }
        }

        $now = dbNow();
        $this->pdo->prepare('UPDATE prospeccao_engine_leads SET email = ?, phone = ?, social_json = ?, enriched_at = ?, updated_at = ? WHERE id = ?')
            ->execute([
                $email, $phone,
                $social ? json_encode($social, JSON_UNESCAPED_UNICODE) : null,
                $now, $now, $row['id'],
            ]);

        ProspeccaoEngineJobService::logEvent($this->pdo, (int)$row['job_id'], 'enriched', 'info',
            "Lead enriquecido: {$row['name']}", ['leadId' => (int)$row['id'], 'hasEmail' => (bool)$email]);
    }

    private function aiExtract(string $name, string $website, array $row): ?array {
        if (!class_exists('AIGateway')) {
            require_once __DIR__ . '/../../../ai-gateway.php';
        }
        if (!class_exists('AIProviderFactory')) {
            require_once __DIR__ . '/../../../ai-providers.php';
        }

        $location = $row['location_json'] ?? '';
        if (is_string($location)) $location = json_decode($location, true) ?: [];

        $system = 'Você extrai contatos públicos de empresas. Responda APENAS JSON válido, sem markdown.';
        $user = json_encode([
            'empresa'  => $name,
            'website'  => $website,
            'cidade'   => $location['city'] ?? null,
            'endereco' => $location['address'] ?? null,
            'campos'   => ['email', 'phone', 'instagram', 'facebook', 'linkedin', 'whatsapp'],
        ], JSON_UNESCAPED_UNICODE);

        $r = AIGateway::chat([
            'system'    => $system,
            'user'      => $user,
            'maxTokens' => 512,
            'module'    => 'prospeccao',
            'json'      => true,
            'temperature' => 0.2,
        ]);

        if (($r['status'] ?? '') !== 'ok' || empty($r['content'])) {
            return null;
        }

        $parsed = json_decode($r['content'], true);
        return is_array($parsed) ? $parsed : null;
    }

    public function countPending(int $jobId): int {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM prospeccao_engine_leads WHERE job_id = ? AND enriched_at IS NULL');
        $stmt->execute([$jobId]);
        return (int)$stmt->fetchColumn();
    }
}
