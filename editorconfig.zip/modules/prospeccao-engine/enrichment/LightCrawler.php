<?php
/**
 * Prospecção Engine Pro — crawler leve (fetch + regex)
 */

class ProspeccaoEngineLightCrawler {
    public function fetch(string $url, int $timeoutSec = 10): ?string {
        $url = $this->normalizeUrl($url);
        if (!$url) return null;

        $ctx = stream_context_create([
            'http' => [
                'timeout' => $timeoutSec,
                'follow_location' => 1,
                'max_redirects' => 3,
                'header' => "User-Agent: Mozilla/5.0 (compatible; AutoLimpezaPro-Bot/1.0)\r\nAccept: text/html\r\n",
            ],
            'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
        ]);

        $html = @file_get_contents($url, false, $ctx);
        return $html !== false ? $html : null;
    }

    public function extractFromHtml(string $html): array {
        $out = [
            'email'     => null,
            'phone'     => null,
            'instagram' => null,
            'facebook'  => null,
            'linkedin'  => null,
            'whatsapp'  => null,
        ];

        if (preg_match_all('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', $html, $em)) {
            foreach ($em[0] as $e) {
                if (!preg_match('/\.(png|jpg|gif|svg|webp)$/i', $e)) {
                    $out['email'] = strtolower($e);
                    break;
                }
            }
        }

        if (preg_match('/(?:\+?55\s?)?(?:\(?\d{2}\)?\s?)?\d{4,5}[-\s]?\d{4}/', $html, $ph)) {
            $out['phone'] = $ph[0];
        }

        if (preg_match('#instagram\.com/([a-zA-Z0-9._]+)#i', $html, $ig)) {
            $out['instagram'] = 'https://instagram.com/' . $ig[1];
        }
        if (preg_match('#facebook\.com/([a-zA-Z0-9._-]+)#i', $html, $fb)) {
            $out['facebook'] = 'https://facebook.com/' . $fb[1];
        }
        if (preg_match('#linkedin\.com/(company|in)/([a-zA-Z0-9._-]+)#i', $html, $li)) {
            $out['linkedin'] = 'https://linkedin.com/' . $li[1] . '/' . $li[2];
        }
        if (preg_match('#(?:wa\.me|api\.whatsapp\.com/send\?phone=)(\d+)#i', $html, $wa)) {
            $out['whatsapp'] = 'https://wa.me/' . $wa[1];
        }

        return $out;
    }

    private function normalizeUrl(string $url): ?string {
        $url = trim($url);
        if ($url === '') return null;
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        if (!filter_var($url, FILTER_VALIDATE_URL)) return null;
        return $url;
    }
}
