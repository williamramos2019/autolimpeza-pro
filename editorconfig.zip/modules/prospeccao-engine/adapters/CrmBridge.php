<?php
/**
 * Prospecção Engine Pro — bridge CRM / prospeccao_prospects
 */

class ProspeccaoEngineCrmBridge {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Mescla leads do engine em prospeccao_prospects sem sobrescrever dados manuais.
     * @return array{merged:int,skipped:int,updated:int,errors:array}
     */
    public function mergeLeadsToCrm(int $jobId, ?array $leadIds = null): array {
        ensureProspeccaoTables($this->pdo);
        ensureProspeccaoEngineTables($this->pdo);

        $sql = 'SELECT * FROM prospeccao_engine_leads WHERE job_id = ? AND normalized_at IS NOT NULL AND merged_at IS NULL';
        $params = [$jobId];
        if ($leadIds) {
            $placeholders = implode(',', array_fill(0, count($leadIds), '?'));
            $sql .= " AND id IN ({$placeholders})";
            $params = array_merge($params, array_map('intval', $leadIds));
        }
        $sql .= ' ORDER BY score_ipc DESC LIMIT 200';

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $merged = 0;
        $skipped = 0;
        $updated = 0;
        $errors = [];

        foreach ($rows as $row) {
            try {
                $result = $this->mergeOne($row);
                if ($result === 'merged') $merged++;
                elseif ($result === 'updated') $updated++;
                else $skipped++;
            } catch (Throwable $e) {
                $errors[] = ['leadId' => (int)$row['id'], 'error' => $e->getMessage()];
            }
        }

        $this->pdo->prepare('UPDATE prospeccao_engine_jobs SET leads_merged = (
            SELECT COUNT(*) FROM prospeccao_engine_leads WHERE job_id = ? AND merged_at IS NOT NULL
        ), updated_at = ? WHERE id = ?')->execute([$jobId, dbNow(), $jobId]);

        ProspeccaoEngineJobService::logEvent($this->pdo, $jobId, 'crm_merge', 'info',
            "CRM merge: {$merged} novos, {$updated} atualizados, {$skipped} ignorados", compact('merged', 'updated', 'skipped'));

        return compact('merged', 'skipped', 'updated', 'errors');
    }

    /** @return 'merged'|'updated'|'skipped' */
    private function mergeOne(array $row): string {
        $placeId = $row['place_id'] ?? null;
        $existing = $this->findExistingProspect($placeId, $row);

        $social = $row['social_json'] ?? null;
        if (is_string($social)) $social = json_decode($social, true) ?: [];
        $location = $row['location_json'] ?? null;
        if (is_string($location)) $location = json_decode($location, true) ?: [];

        $prospectData = [
            'companyName'   => $row['name'],
            'category'      => $row['category'],
            'city'          => $location['city'] ?? null,
            'neighborhood'  => $location['neighborhood'] ?? null,
            'address'       => $location['address'] ?? null,
            'phone'         => $row['phone'],
            'email'         => $row['email'],
            'website'       => $row['website'],
            'instagram'     => $social['instagram'] ?? null,
            'facebook'      => $social['facebook'] ?? null,
            'googlePlaceId' => $placeId,
            'googleMapsUrl' => $placeId ? 'https://www.google.com/maps/place/?q=place_id:' . $placeId : null,
            'latitude'      => $location['latitude'] ?? null,
            'longitude'     => $location['longitude'] ?? null,
            'source'        => 'prospeccao-engine',
            'leadScore'     => $row['lead_score'],
            'tags'          => ['IPC:' . (int)$row['score_ipc'], 'engine-pro'],
        ];

        $now = dbNow();

        if ($existing) {
            $patch = $this->buildPatchOnlyEmpty($existing, $prospectData);
            if (!$patch) {
                $this->markMerged($row, (int)$existing['id'], $existing['status']);
                return 'skipped';
            }
            $patch['updated_at'] = $now;
            $sets = [];
            $params = [];
            foreach ($patch as $col => $val) {
                $sets[] = "`{$col}` = ?";
                $params[] = $val;
            }
            $params[] = (int)$existing['id'];
            $this->pdo->prepare('UPDATE prospeccao_prospects SET ' . implode(', ', $sets) . ' WHERE id = ?')
                ->execute($params);
            $this->markMerged($row, (int)$existing['id'], $existing['status']);
            return 'updated';
        }

        $dist = prospeccaoHaversineKm(
            isset($location['latitude']) ? (float)$location['latitude'] : null,
            isset($location['longitude']) ? (float)$location['longitude'] : null,
            PROSPECCAO_CONFINS_LAT,
            PROSPECCAO_CONFINS_LNG
        );

        $this->pdo->prepare('INSERT INTO prospeccao_prospects
            (company_name, category, city, neighborhood, address, phone, website, instagram, facebook,
             google_maps_url, google_place_id, email, source, status, lead_score, tags,
             latitude, longitude, distance_confins_km, imported_at, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([
                $prospectData['companyName'],
                $prospectData['category'],
                $prospectData['city'],
                $prospectData['neighborhood'],
                $prospectData['address'],
                $prospectData['phone'],
                $prospectData['website'],
                $prospectData['instagram'],
                $prospectData['facebook'],
                $prospectData['googleMapsUrl'],
                $prospectData['googlePlaceId'],
                $prospectData['email'],
                'prospeccao-engine',
                'novo',
                $prospectData['leadScore'],
                json_encode($prospectData['tags'], JSON_UNESCAPED_UNICODE),
                $prospectData['latitude'],
                $prospectData['longitude'],
                $dist,
                $now, $now, $now,
            ]);

        $prospectId = (int)$this->pdo->lastInsertId();
        $this->markMerged($row, $prospectId, 'novo');
        return 'merged';
    }

    private function findExistingProspect(?string $placeId, array $row): ?array {
        if ($placeId) {
            $stmt = $this->pdo->prepare('SELECT * FROM prospeccao_prospects WHERE google_place_id = ? LIMIT 1');
            $stmt->execute([$placeId]);
            $found = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($found) return $found;
        }

        $location = $row['location_json'] ?? '';
        if (is_string($location)) $location = json_decode($location, true) ?: [];
        $dupId = prospeccaoFindDuplicate($this->pdo, [
            'company_name' => $row['name'],
            'phone'        => $row['phone'],
            'city'         => $location['city'] ?? '',
        ]);
        if ($dupId) {
            $stmt = $this->pdo->prepare('SELECT * FROM prospeccao_prospects WHERE id = ?');
            $stmt->execute([$dupId]);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        return null;
    }

    private function buildPatchOnlyEmpty(array $existing, array $incoming): array {
        $protectedStatuses = ['cliente', 'parceiro', 'interessado', 'contatado'];
        $patch = [];

        $map = [
            'company_name'    => 'companyName',
            'category'        => 'category',
            'city'            => 'city',
            'neighborhood'    => 'neighborhood',
            'address'         => 'address',
            'phone'           => 'phone',
            'email'           => 'email',
            'website'         => 'website',
            'instagram'       => 'instagram',
            'facebook'        => 'facebook',
            'google_place_id' => 'googlePlaceId',
            'google_maps_url' => 'googleMapsUrl',
            'latitude'        => 'latitude',
            'longitude'       => 'longitude',
        ];

        foreach ($map as $dbCol => $inKey) {
            $cur = trim((string)($existing[$dbCol] ?? ''));
            $new = $incoming[$inKey] ?? null;
            if ($cur === '' && $new !== null && trim((string)$new) !== '') {
                $patch[$dbCol] = $new;
            }
        }

        if (!in_array($existing['status'] ?? 'novo', $protectedStatuses, true)) {
            if (!empty($incoming['leadScore']) && ($existing['lead_score'] ?? 'baixo') === 'baixo') {
                $patch['lead_score'] = $incoming['leadScore'];
            }
        }

        $existingTags = $existing['tags'] ?? '[]';
        if (is_string($existingTags)) $existingTags = json_decode($existingTags, true) ?: [];
        $newTags = array_unique(array_merge($existingTags, $incoming['tags'] ?? []));
        if ($newTags !== $existingTags) {
            $patch['tags'] = json_encode(array_values($newTags), JSON_UNESCAPED_UNICODE);
        }

        if (!str_contains((string)($existing['source'] ?? ''), 'prospeccao-engine')) {
            $patch['source'] = trim(($existing['source'] ?? 'manual') . '+prospeccao-engine', '+');
        }

        return $patch;
    }

    private function markMerged(array $row, int $prospectId, ?string $crmStatus): void {
        $stmt = $this->pdo->prepare('SELECT status FROM prospeccao_prospects WHERE id = ?');
        $stmt->execute([$prospectId]);
        $status = $stmt->fetchColumn() ?: $crmStatus;

        $this->pdo->prepare('UPDATE prospeccao_engine_leads SET prospect_id = ?, crm_status = ?, merged_at = ?, updated_at = ? WHERE id = ?')
            ->execute([$prospectId, $status, dbNow(), dbNow(), $row['id']]);
    }
}

function merge_leads_to_crm(PDO $pdo, int $jobId, ?array $leadIds = null): array {
    $bridge = new ProspeccaoEngineCrmBridge($pdo);
    return $bridge->mergeLeadsToCrm($jobId, $leadIds);
}
