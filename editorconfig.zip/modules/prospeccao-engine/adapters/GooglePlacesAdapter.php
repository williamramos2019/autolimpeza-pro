<?php
/**
 * Prospecção Engine Pro — Google Places adapter (paginação, details, cache)
 */

class ProspeccaoEngineGooglePlacesAdapter {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function apiKey(): ?string {
        return prospeccaoPlacesApiKey();
    }

    /**
     * Text search com paginação completa (até 3 páginas / ~60 resultados por query).
     * @return array{ok:bool,items:array,nextPageToken:?string,error:?string,status:?string}
     */
    public function textSearch(string $query, ?string $pageToken = null, ?float $lat = null, ?float $lng = null, ?int $radiusM = null): array {
        $key = $this->apiKey();
        if (!$key) {
            return ['ok' => false, 'items' => [], 'nextPageToken' => null, 'error' => 'GOOGLE_PLACES_API_KEY não configurada', 'status' => 'NO_KEY'];
        }

        $cacheKey = ProspeccaoEngineResponseCache::cacheKey('textsearch', $query, $pageToken ?? '', (string)$lat, (string)$lng);
        $cached = ProspeccaoEngineResponseCache::get($this->pdo, $cacheKey);
        if ($cached) {
            return $cached;
        }

        ProspeccaoEngineRateLimiter::throttle('google_places');

        $params = ['query' => $query, 'key' => $key, 'language' => 'pt-BR'];
        if ($pageToken) {
            $params = ['pagetoken' => $pageToken, 'key' => $key, 'language' => 'pt-BR'];
        } elseif ($lat !== null && $lng !== null) {
            $params['location'] = "{$lat},{$lng}";
            if ($radiusM) $params['radius'] = min(50000, $radiusM);
        }

        $url = 'https://maps.googleapis.com/maps/api/place/textsearch/json?' . http_build_query($params);
        $raw = $this->httpGet($url);
        if (!$raw) {
            return ['ok' => false, 'items' => [], 'nextPageToken' => null, 'error' => 'Falha HTTP Places', 'status' => 'HTTP_ERROR'];
        }

        $data = json_decode($raw, true);
        $status = $data['status'] ?? 'UNKNOWN';

        if ($status === 'INVALID_REQUEST' && $pageToken) {
            usleep(2000000);
            return $this->textSearch($query, $pageToken, $lat, $lng, $radiusM);
        }

        if ($status !== 'OK' && $status !== 'ZERO_RESULTS') {
            return [
                'ok' => false, 'items' => [], 'nextPageToken' => null,
                'error' => $data['error_message'] ?? $status, 'status' => $status,
            ];
        }

        $items = [];
        foreach ($data['results'] ?? [] as $r) {
            $items[] = $this->mapPlaceResult($r);
        }

        $result = [
            'ok'            => true,
            'items'         => $items,
            'nextPageToken' => $data['next_page_token'] ?? null,
            'error'         => null,
            'status'        => $status,
        ];

        ProspeccaoEngineResponseCache::set($this->pdo, $cacheKey, $result, $pageToken ? 300 : 86400);
        return $result;
    }

    public function fetchDetails(string $placeId): ?array {
        $key = $this->apiKey();
        if (!$key || $placeId === '') return null;

        $cacheKey = ProspeccaoEngineResponseCache::cacheKey('details', $placeId);
        $cached = ProspeccaoEngineResponseCache::get($this->pdo, $cacheKey);
        if ($cached) return $cached;

        ProspeccaoEngineRateLimiter::throttle('google_places');

        $fields = implode(',', [
            'place_id', 'name', 'formatted_address', 'formatted_phone_number', 'international_phone_number',
            'website', 'url', 'rating', 'user_ratings_total', 'opening_hours', 'geometry', 'types',
            'business_status',
        ]);
        $url = 'https://maps.googleapis.com/maps/api/place/details/json?place_id='
            . urlencode($placeId) . '&fields=' . urlencode($fields)
            . '&key=' . urlencode($key) . '&language=pt-BR';

        $raw = $this->httpGet($url);
        if (!$raw) return null;
        $data = json_decode($raw, true);
        if (($data['status'] ?? '') !== 'OK') return null;

        $r = $data['result'] ?? [];
        $mapped = [
            'placeId'       => $r['place_id'] ?? $placeId,
            'name'          => $r['name'] ?? null,
            'address'       => $r['formatted_address'] ?? null,
            'phone'         => $r['formatted_phone_number'] ?? $r['international_phone_number'] ?? null,
            'website'       => $r['website'] ?? null,
            'googleMapsUrl' => $r['url'] ?? ('https://www.google.com/maps/place/?q=place_id:' . $placeId),
            'rating'        => isset($r['rating']) ? (float)$r['rating'] : null,
            'reviewsCount'  => isset($r['user_ratings_total']) ? (int)$r['user_ratings_total'] : null,
            'latitude'      => $r['geometry']['location']['lat'] ?? null,
            'longitude'     => $r['geometry']['location']['lng'] ?? null,
            'types'         => $r['types'] ?? [],
            'hours'         => $r['opening_hours']['weekday_text'] ?? null,
            'businessStatus'=> $r['business_status'] ?? null,
        ];

        ProspeccaoEngineResponseCache::set($this->pdo, $cacheKey, $mapped, 604800);
        return $mapped;
    }

    private function mapPlaceResult(array $r): array {
        $placeId = $r['place_id'] ?? null;
        return [
            'placeId'       => $placeId,
            'name'          => $r['name'] ?? '',
            'address'       => $r['formatted_address'] ?? '',
            'rating'        => isset($r['rating']) ? (float)$r['rating'] : null,
            'reviewsCount'  => isset($r['user_ratings_total']) ? (int)$r['user_ratings_total'] : null,
            'latitude'      => $r['geometry']['location']['lat'] ?? null,
            'longitude'     => $r['geometry']['location']['lng'] ?? null,
            'types'         => $r['types'] ?? [],
            'googleMapsUrl' => $placeId ? 'https://www.google.com/maps/place/?q=place_id:' . $placeId : null,
            'businessStatus'=> $r['business_status'] ?? null,
        ];
    }

    private function httpGet(string $url, int $attempt = 1): ?string {
        $ctx = stream_context_create(['http' => [
            'timeout' => 15,
            'header'  => "User-Agent: AutoLimpezaPro-ProspeccaoEngine/1.0\r\n",
        ]]);
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false && $attempt < ProspeccaoEngineRateLimiter::maxRetries()) {
            usleep(ProspeccaoEngineRateLimiter::backoffMs($attempt) * 1000);
            return $this->httpGet($url, $attempt + 1);
        }
        return $raw !== false ? $raw : null;
    }
}
