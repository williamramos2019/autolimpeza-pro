<?php
/**
 * Prospecção Engine Pro — normalização para estrutura padrão
 */

class ProspeccaoEngineLeadNormalizer {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function normalizeRow(array $row): array {
        $social = $row['social_json'] ?? null;
        if (is_string($social)) $social = json_decode($social, true);
        $location = $row['location_json'] ?? null;
        if (is_string($location)) $location = json_decode($location, true);

        $lead = [
            'name'          => $row['name'],
            'category'      => $row['category'],
            'phone'         => $row['phone'],
            'email'         => $row['email'],
            'website'       => $row['website'],
            'social'        => $social ?: [],
            'rating'        => $row['rating'] !== null ? (float)$row['rating'] : null,
            'reviewsCount'  => $row['reviews_count'] !== null ? (int)$row['reviews_count'] : null,
            'location'      => $location ?: [],
            'placeId'       => $row['place_id'],
            'source'        => 'prospeccao-engine',
        ];

        $scores = ProspeccaoEngineIpcScorer::compute($lead);
        $lead['scoreIpc'] = $scores['scoreIpc'];
        $lead['leadScore'] = $scores['leadScore'];

        return $lead;
    }

    /**
     * @return array{normalized:int,done:bool}
     */
    public function processBatch(int $jobId, int $batchSize = 20): array {
        $stmt = $this->pdo->prepare('SELECT * FROM prospeccao_engine_leads
            WHERE job_id = ? AND normalized_at IS NULL ORDER BY id ASC LIMIT ' . max(1, min(50, $batchSize)));
        $stmt->execute([$jobId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!$rows) {
            return ['normalized' => 0, 'done' => true];
        }

        $now = dbNow();
        $count = 0;
        foreach ($rows as $row) {
            $norm = $this->normalizeRow($row);
            $this->pdo->prepare('UPDATE prospeccao_engine_leads SET score_ipc = ?, lead_score = ?, normalized_at = ?, updated_at = ? WHERE id = ?')
                ->execute([$norm['scoreIpc'], $norm['leadScore'], $now, $now, $row['id']]);
            $count++;
        }

        $remaining = $this->countPending($jobId);
        return ['normalized' => $count, 'done' => $remaining === 0];
    }

    public function countPending(int $jobId): int {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM prospeccao_engine_leads WHERE job_id = ? AND normalized_at IS NULL');
        $stmt->execute([$jobId]);
        return (int)$stmt->fetchColumn();
    }
}
