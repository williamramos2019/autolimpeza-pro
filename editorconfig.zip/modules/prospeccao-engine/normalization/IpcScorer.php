<?php
/**
 * Prospecção Engine Pro — score IPC (0-100)
 */

class ProspeccaoEngineIpcScorer {
    public static function compute(array $lead): array {
        $score = 0;
        $social = $lead['social'] ?? [];
        if (is_string($social)) $social = json_decode($social, true) ?: [];

        $website = trim((string)($lead['website'] ?? ''));
        if ($website !== '') $score += 8;
        $socialCount = count(array_filter($social));
        $score += min(17, $socialCount * 5);

        $contacts = 0;
        if (!empty($lead['phone'])) $contacts++;
        if (!empty($lead['email'])) $contacts++;
        if (!empty($social['whatsapp'])) $contacts++;
        $score += min(20, $contacts * 7);

        $rating = isset($lead['rating']) ? (float)$lead['rating'] : null;
        if ($rating !== null) {
            $score += (int)round(min(15, ($rating / 5) * 15));
        }

        $reviews = (int)($lead['reviewsCount'] ?? $lead['reviews_count'] ?? 0);
        if ($reviews >= 50) $score += 10;
        elseif ($reviews >= 10) $score += 7;
        elseif ($reviews >= 1) $score += 4;

        $completeness = 0;
        foreach (['name', 'category', 'phone', 'email', 'website'] as $f) {
            if (!empty($lead[$f])) $completeness++;
        }
        $location = $lead['location'] ?? [];
        if (is_string($location)) $location = json_decode($location, true) ?: [];
        if (!empty($location['address'])) $completeness++;
        if (!empty($location['latitude'])) $completeness++;
        $score += (int)round(min(15, ($completeness / 7) * 15));

        $city = mb_strtolower((string)($location['city'] ?? ''));
        if (str_contains($city, 'são josé da lapa') || str_contains($city, 'vespasiano')) {
            $score += 10;
        }
        $cat = mb_strtolower((string)($lead['category'] ?? ''));
        if (str_contains($cat, 'indústria') || str_contains($cat, 'comércio') || str_contains($cat, 'escritório')) {
            $score += 5;
        }

        $ipc = max(0, min(100, $score));
        $band = 'baixo';
        if ($ipc >= 70) $band = 'vip';
        elseif ($ipc >= 50) $band = 'alto';
        elseif ($ipc >= 30) $band = 'medio';

        return ['scoreIpc' => $ipc, 'leadScore' => $band];
    }
}
