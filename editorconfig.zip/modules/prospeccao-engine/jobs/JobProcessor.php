<?php
/**
 * Prospecção Engine Pro — processador de jobs (processStep)
 */

class ProspeccaoEngineJobProcessor {
    private PDO $pdo;
    private ProspeccaoEnginePlacesCollector $collector;
    private ProspeccaoEngineEnrichmentEngine $enricher;
    private ProspeccaoEngineLeadNormalizer $normalizer;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->collector = new ProspeccaoEnginePlacesCollector($pdo);
        $this->enricher = new ProspeccaoEngineEnrichmentEngine($pdo);
        $this->normalizer = new ProspeccaoEngineLeadNormalizer($pdo);
    }

    /**
     * Executa um passo do job. Chamável via cron API ou manualmente.
     * @return array{ok:bool,job:array,step:array,elapsedMs:int}
     */
    public function processStep(?int $jobId = null): array {
        ensureProspeccaoEngineTables($this->pdo);
        ProspeccaoEngineResponseCache::purgeExpired($this->pdo);

        $started = microtime(true);

        if (!$jobId) {
            $jobId = $this->pickNextJob();
            if (!$jobId) {
                return [
                    'ok' => true,
                    'job' => null,
                    'step' => ['message' => 'Nenhum job na fila'],
                    'elapsedMs' => (int)round((microtime(true) - $started) * 1000),
                ];
            }
        }

        $job = ProspeccaoEngineJobService::get($this->pdo, $jobId);

        if ($job['status'] === 'paused') {
            return [
                'ok' => false,
                'job' => $job,
                'step' => ['message' => 'Job pausado'],
                'elapsedMs' => (int)round((microtime(true) - $started) * 1000),
            ];
        }

        if (in_array($job['status'], ['completed', 'failed'], true)) {
            return [
                'ok' => true,
                'job' => $job,
                'step' => ['message' => 'Job já finalizado'],
                'elapsedMs' => (int)round((microtime(true) - $started) * 1000),
            ];
        }

        if ($job['status'] === 'queued') {
            ProspeccaoEngineJobService::updateProgress($this->pdo, $jobId, [
                'status' => 'running',
                'started_at' => dbNow(),
            ]);
            $job = ProspeccaoEngineJobService::get($this->pdo, $jobId);
        }

        $stepResult = $this->runPhase($jobId, $job);
        $job = ProspeccaoEngineJobService::get($this->pdo, $jobId);
        ProspeccaoEngineJobService::recalcProgress($this->pdo, $jobId);

        $elapsed = (int)round((microtime(true) - $started) * 1000);
        ProspeccaoEngineJobService::logEvent($this->pdo, $jobId, 'step', 'info',
            $stepResult['message'] ?? 'Step executado', ['elapsedMs' => $elapsed, 'phase' => $job['phase']]);

        return [
            'ok'        => true,
            'job'       => ProspeccaoEngineJobService::get($this->pdo, $jobId),
            'step'      => $stepResult,
            'elapsedMs' => $elapsed,
        ];
    }

    private function pickNextJob(): ?int {
        $stmt = $this->pdo->query("SELECT id FROM prospeccao_engine_jobs WHERE status IN ('queued','running') ORDER BY id ASC LIMIT 1");
        $id = $stmt->fetchColumn();
        return $id ? (int)$id : null;
    }

    private function runPhase(int $jobId, array $job): array {
        $phase = $job['phase'];
        $config = $job['config'] ?? [];

        try {
            if ($phase === 'init') {
                $count = $this->collector->initGrid($jobId, $job);
                return ['phase' => 'collect', 'message' => "Grid inicializada ({$count} células)"];
            }

            if ($phase === 'collect') {
                $result = $this->collector->processCollectStep($jobId);
                if ($this->collector->isCollectComplete($jobId)) {
                    $nextPhase = !empty($config['autoEnrich']) ? 'enrich' : (
                        !empty($config['autoNormalize']) ? 'normalize' : 'done'
                    );
                    ProspeccaoEngineJobService::updateProgress($this->pdo, $jobId, ['phase' => $nextPhase]);
                    if ($nextPhase === 'done') {
                        $this->completeJob($jobId);
                    }
                    $result['phaseTransition'] = $nextPhase;
                }
                return array_merge(['phase' => 'collect'], $result);
            }

            if ($phase === 'enrich') {
                $batch = $this->enricher->processBatch($jobId, 5);
                if ($batch['done']) {
                    $nextPhase = !empty($config['autoNormalize']) ? 'normalize' : 'done';
                    ProspeccaoEngineJobService::updateProgress($this->pdo, $jobId, ['phase' => $nextPhase]);
                    if ($nextPhase === 'done') {
                        $this->completeJob($jobId);
                    }
                }
                return ['phase' => 'enrich', 'message' => "Enriquecidos: {$batch['enriched']}", 'done' => $batch['done']];
            }

            if ($phase === 'normalize') {
                $batch = $this->normalizer->processBatch($jobId, 20);
                if ($batch['done']) {
                    ProspeccaoEngineJobService::updateProgress($this->pdo, $jobId, ['phase' => 'done']);
                    $this->completeJob($jobId);
                }
                return ['phase' => 'normalize', 'message' => "Normalizados: {$batch['normalized']}", 'done' => $batch['done']];
            }

            return ['phase' => $phase, 'message' => 'Job em estado final'];
        } catch (Throwable $e) {
            ProspeccaoEngineJobService::updateProgress($this->pdo, $jobId, [
                'status' => 'failed',
                'error_message' => $e->getMessage(),
                'completed_at' => dbNow(),
            ]);
            ProspeccaoEngineJobService::logEvent($this->pdo, $jobId, 'failed', 'error', $e->getMessage());
            throw $e;
        }
    }

    private function completeJob(int $jobId): void {
        ProspeccaoEngineJobService::updateProgress($this->pdo, $jobId, [
            'status' => 'completed',
            'phase' => 'done',
            'progress_pct' => 100,
            'completed_at' => dbNow(),
        ]);
        ProspeccaoEngineJobService::logEvent($this->pdo, $jobId, 'completed', 'info', 'Job concluído com sucesso');
    }
}

function prospeccaoEngineProcessStep(PDO $pdo, ?int $jobId = null): array {
    $processor = new ProspeccaoEngineJobProcessor($pdo);
    return $processor->processStep($jobId);
}
