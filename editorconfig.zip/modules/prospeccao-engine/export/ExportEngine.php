<?php
/**
 * Prospecção Engine Pro — export CSV, JSON, Markdown
 */

class ProspeccaoEngineExportEngine {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function fetchLeads(int $jobId, ?bool $mergedOnly = null): array {
        ensureProspeccaoEngineTables($this->pdo);
        $sql = 'SELECT l.*, p.status AS prospect_status FROM prospeccao_engine_leads l
            LEFT JOIN prospeccao_prospects p ON p.id = l.prospect_id
            WHERE l.job_id = ?';
        if ($mergedOnly === true) $sql .= ' AND l.merged_at IS NOT NULL';
        if ($mergedOnly === false) $sql .= ' AND l.merged_at IS NULL';
        $sql .= ' ORDER BY l.score_ipc DESC, l.id ASC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$jobId]);
        return array_map('prospeccaoEngineMapLead', $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    public function toCsv(int $jobId): string {
        $leads = $this->fetchLeads($jobId);
        $lines = ['Nome;Categoria;Telefone;Email;Site;IPC;Score;Cidade;Place ID;CRM Status;Fonte'];
        foreach ($leads as $l) {
            $city = $l['location']['city'] ?? '';
            $lines[] = implode(';', [
                $this->csvEsc($l['name']),
                $this->csvEsc($l['category'] ?? ''),
                $this->csvEsc($l['phone'] ?? ''),
                $this->csvEsc($l['email'] ?? ''),
                $this->csvEsc($l['website'] ?? ''),
                (string)$l['scoreIpc'],
                $l['leadScore'],
                $this->csvEsc($city),
                $this->csvEsc($l['placeId'] ?? ''),
                $this->csvEsc($l['crmStatus'] ?? ''),
                $l['source'],
            ]);
        }
        return implode("\n", $lines);
    }

    public function toJson(int $jobId): string {
        $job = ProspeccaoEngineJobService::get($this->pdo, $jobId);
        $leads = $this->fetchLeads($jobId);
        return json_encode([
            'exportedAt' => date('c'),
            'job'        => $job,
            'count'      => count($leads),
            'leads'      => $leads,
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }

    public function toMarkdown(int $jobId): string {
        $job = ProspeccaoEngineJobService::get($this->pdo, $jobId);
        $leads = $this->fetchLeads($jobId);
        $md = "# Relatório Prospecção Engine Pro\n\n";
        $md .= "**Job #{$jobId}** — {$job['city']} — status: `{$job['status']}`\n\n";
        $md .= "- Progresso: {$job['progressPct']}%\n";
        $md .= "- Leads: {$job['leadsFound']} encontrados, {$job['leadsEnriched']} enriquecidos, {$job['leadsMerged']} no CRM\n\n";
        $md .= "## Top leads por IPC\n\n";
        $md .= "| Empresa | Categoria | IPC | Score | Cidade | CRM |\n";
        $md .= "|---------|-----------|-----|-------|--------|-----|\n";
        foreach (array_slice($leads, 0, 50) as $l) {
            $city = $l['location']['city'] ?? '—';
            $crm = $l['crmStatus'] ?? ($l['mergedAt'] ? 'merged' : '—');
            $md .= '| ' . implode(' | ', [
                str_replace('|', '/', $l['name']),
                $l['category'] ?? '—',
                (string)$l['scoreIpc'],
                $l['leadScore'],
                $city,
                $crm,
            ]) . " |\n";
        }
        $md .= "\n_Gerado em " . date('d/m/Y H:i') . "_\n";
        return $md;
    }

    private function csvEsc(?string $v): string {
        $v = str_replace('"', '""', (string)$v);
        return '"' . $v . '"';
    }
}
