<?php
/**
 * Prospecção Engine Pro — rate limiter (in-memory + DB throttle)
 */

class ProspeccaoEngineRateLimiter {
    private static array $lastCall = [];
    private const MIN_INTERVAL_MS = 350;
    private const MAX_RETRIES = 4;

    public static function throttle(string $bucket = 'google_places'): void {
        $key = $bucket;
        $now = (int)(microtime(true) * 1000);
        if (isset(self::$lastCall[$key])) {
            $elapsed = $now - self::$lastCall[$key];
            if ($elapsed < self::MIN_INTERVAL_MS) {
                usleep((self::MIN_INTERVAL_MS - $elapsed) * 1000);
            }
        }
        self::$lastCall[$key] = (int)(microtime(true) * 1000);
    }

    public static function maxRetries(): int {
        return self::MAX_RETRIES;
    }

    public static function backoffMs(int $attempt): int {
        return min(8000, (int)(500 * (2 ** max(0, $attempt - 1))));
    }
}
