<?php
/**
 * Prospecção Engine Pro — job CRUD, events, pause/resume
 */

class ProspeccaoEngineJobService {
    public static function create(PDO $pdo, array $opts): array {
        ensureProspeccaoEngineTables($pdo);
        ensureProspeccaoTables($pdo);

        $city = san($opts['city'] ?? 'São José da Lapa', 120) ?? 'São José da Lapa';
        $categories = $opts['categories'] ?? prospeccaoCategories();
        if (!is_array($categories) || !$categories) {
            $categories = prospeccaoCategories();
        }
        $categories = array_values(array_filter(array_map(static fn($c) => san((string)$c, 120), $categories)));
        if (!$categories) {
            throw new InvalidArgumentException('Informe ao menos uma categoria');
        }

        $radiusM = max(1000, min(15000, (int)($opts['radiusM'] ?? $opts['radius_m'] ?? 5000)));
        $config = [
            'autoEnrich'   => !isset($opts['autoEnrich']) || !empty($opts['autoEnrich']),
            'autoNormalize'=> !isset($opts['autoNormalize']) || !empty($opts['autoNormalize']),
            'gridStepKm'   => (float)($opts['gridStepKm'] ?? 3.0),
        ];
        $now = dbNow();
        $createdBy = san($opts['createdBy'] ?? null, 120);

        $pdo->prepare('INSERT INTO prospeccao_engine_jobs
            (status, phase, city, categories, radius_m, progress_pct, config_json, created_by, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)')
            ->execute([
                'queued', 'init', $city, json_encode($categories, JSON_UNESCAPED_UNICODE),
                $radiusM, 0, json_encode($config, JSON_UNESCAPED_UNICODE), $createdBy, $now, $now,
            ]);

        $jobId = (int)$pdo->lastInsertId();
        self::logEvent($pdo, $jobId, 'job_created', 'info', 'Job criado na fila', [
            'city' => $city, 'categories' => $categories, 'radiusM' => $radiusM,
        ]);

        return self::get($pdo, $jobId);
    }

    public static function get(PDO $pdo, int $jobId): array {
        ensureProspeccaoEngineTables($pdo);
        $stmt = $pdo->prepare('SELECT * FROM prospeccao_engine_jobs WHERE id = ?');
        $stmt->execute([$jobId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new InvalidArgumentException('Job não encontrado');
        return prospeccaoEngineMapJob($row);
    }

    public static function list(PDO $pdo, int $limit = 50): array {
        ensureProspeccaoEngineTables($pdo);
        $limit = max(1, min(100, $limit));
        $stmt = $pdo->query("SELECT * FROM prospeccao_engine_jobs ORDER BY id DESC LIMIT {$limit}");
        return array_map('prospeccaoEngineMapJob', $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function pause(PDO $pdo, int $jobId): array {
        $job = self::get($pdo, $jobId);
        if (!in_array($job['status'], ['queued', 'running'], true)) {
            throw new InvalidArgumentException('Job não pode ser pausado no status atual: ' . $job['status']);
        }
        $now = dbNow();
        $pdo->prepare('UPDATE prospeccao_engine_jobs SET status = ?, updated_at = ? WHERE id = ?')
            ->execute(['paused', $now, $jobId]);
        self::logEvent($pdo, $jobId, 'paused', 'info', 'Job pausado pelo operador');
        return self::get($pdo, $jobId);
    }

    public static function resume(PDO $pdo, int $jobId): array {
        $job = self::get($pdo, $jobId);
        if ($job['status'] !== 'paused') {
            throw new InvalidArgumentException('Apenas jobs pausados podem ser retomados');
        }
        $now = dbNow();
        $pdo->prepare('UPDATE prospeccao_engine_jobs SET status = ?, updated_at = ? WHERE id = ?')
            ->execute(['queued', $now, $jobId]);
        self::logEvent($pdo, $jobId, 'resumed', 'info', 'Job retomado — aguardando processamento');
        return self::get($pdo, $jobId);
    }

    public static function updateProgress(PDO $pdo, int $jobId, array $fields): void {
        $allowed = ['status', 'phase', 'progress_pct', 'total_cells', 'completed_cells',
            'leads_found', 'leads_enriched', 'leads_merged', 'state_json', 'error_message',
            'started_at', 'completed_at'];
        $sets = [];
        $params = [];
        foreach ($fields as $k => $v) {
            if (!in_array($k, $allowed, true)) continue;
            if (in_array($k, ['state_json', 'config_json'], true) && is_array($v)) {
                $v = json_encode($v, JSON_UNESCAPED_UNICODE);
            }
            $sets[] = "`{$k}` = ?";
            $params[] = $v;
        }
        if (!$sets) return;
        $sets[] = '`updated_at` = ?';
        $params[] = dbNow();
        $params[] = $jobId;
        $pdo->prepare('UPDATE prospeccao_engine_jobs SET ' . implode(', ', $sets) . ' WHERE id = ?')
            ->execute($params);
    }

    public static function logEvent(PDO $pdo, int $jobId, string $type, string $level, string $message, ?array $meta = null): void {
        ensureProspeccaoEngineTables($pdo);
        $pdo->prepare('INSERT INTO prospeccao_engine_job_events (job_id, event_type, level, message, meta_json, created_at) VALUES (?,?,?,?,?,?)')
            ->execute([
                $jobId, san($type, 40) ?? 'log', san($level, 10) ?? 'info',
                mb_substr($message, 0, 5000),
                $meta ? json_encode($meta, JSON_UNESCAPED_UNICODE) : null,
                dbNow(),
            ]);
    }

    public static function listEvents(PDO $pdo, int $jobId, int $limit = 100, ?string $since = null): array {
        ensureProspeccaoEngineTables($pdo);
        $limit = max(1, min(500, $limit));
        $sql = 'SELECT * FROM prospeccao_engine_job_events WHERE job_id = ?';
        $params = [$jobId];
        if ($since) {
            $sql .= ' AND created_at > ?';
            $params[] = $since;
        }
        $sql .= ' ORDER BY id DESC LIMIT ' . $limit;
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return array_map('prospeccaoEngineMapEvent', $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function recalcProgress(PDO $pdo, int $jobId): float {
        ensureProspeccaoEngineTables($pdo);
        $stmt = $pdo->prepare('SELECT phase, total_cells, completed_cells FROM prospeccao_engine_jobs WHERE id = ?');
        $stmt->execute([$jobId]);
        $job = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$job) return 0;

        $phase = $job['phase'];
        $total = max(1, (int)$job['total_cells']);
        $done = (int)$job['completed_cells'];

        $phaseWeight = ['init' => 5, 'collect' => 55, 'enrich' => 25, 'normalize' => 10, 'done' => 5];
        $base = 0;
        foreach ($phaseWeight as $p => $w) {
            if ($p === $phase) break;
            $base += $w;
        }
        $currentW = $phaseWeight[$phase] ?? 10;
        $phasePct = $phase === 'collect' ? ($done / $total) * $currentW : ($phase === 'done' ? $currentW : $currentW * 0.5);
        $pct = min(100, round($base + $phasePct, 2));

        self::updateProgress($pdo, $jobId, ['progress_pct' => $pct]);
        return $pct;
    }
}
