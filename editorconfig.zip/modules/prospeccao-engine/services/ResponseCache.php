<?php
/**
 * Prospecção Engine Pro — response cache (Google Places)
 */

class ProspeccaoEngineResponseCache {
    public static function get(PDO $pdo, string $key): ?array {
        ensureProspeccaoEngineTables($pdo);
        try {
            $stmt = $pdo->prepare('SELECT response_json FROM prospeccao_engine_api_cache WHERE cache_key = ? AND expires_at > ? LIMIT 1');
            $stmt->execute([$key, dbNow()]);
            $raw = $stmt->fetchColumn();
            if (!$raw) return null;
            $data = json_decode((string)$raw, true);
            return is_array($data) ? $data : null;
        } catch (Throwable $e) {
            return null;
        }
    }

    public static function set(PDO $pdo, string $key, array $data, int $ttlSec = 86400): void {
        ensureProspeccaoEngineTables($pdo);
        $now = dbNow();
        $expires = date('Y-m-d H:i:s', time() + $ttlSec);
        try {
            $pdo->prepare('INSERT INTO prospeccao_engine_api_cache (cache_key, response_json, expires_at, created_at) VALUES (?,?,?,?)
                ON DUPLICATE KEY UPDATE response_json = VALUES(response_json), expires_at = VALUES(expires_at)')
                ->execute([$key, json_encode($data, JSON_UNESCAPED_UNICODE), $expires, $now]);
        } catch (Throwable $e) {
            /* cache opcional */
        }
    }

    public static function cacheKey(string ...$parts): string {
        return hash('sha256', implode('|', $parts));
    }

    public static function purgeExpired(PDO $pdo): void {
        try {
            $pdo->exec('DELETE FROM prospeccao_engine_api_cache WHERE expires_at < NOW()');
        } catch (Throwable $e) { /* */ }
    }
}
