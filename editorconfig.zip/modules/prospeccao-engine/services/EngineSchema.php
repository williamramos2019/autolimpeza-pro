<?php
/**
 * Prospecção Engine Pro — schema e ensure tables
 */

function ensureProspeccaoEngineTables(PDO $pdo): void {
    static $verified = false;
    if ($verified) return;

    $required = [
        'prospeccao_engine_jobs',
        'prospeccao_engine_job_events',
        'prospeccao_engine_leads',
        'prospeccao_engine_grid_cells',
        'prospeccao_engine_api_cache',
    ];

    $tableOk = static function (string $table) use ($pdo): bool {
        try {
            $pdo->query('SELECT 1 FROM `' . str_replace('`', '', $table) . '` LIMIT 1');
            return true;
        } catch (Throwable $e) {
            return false;
        }
    };

    $allOk = true;
    foreach ($required as $t) {
        if (!$tableOk($t)) {
            $allOk = false;
            break;
        }
    }

    if (!$allOk) {
        alpRunSqlMigration($pdo, dirname(__DIR__, 3) . '/migrations/prospeccao_engine_v1.sql');
    }

    $allOk = true;
    foreach ($required as $t) {
        if (!$tableOk($t)) {
            $allOk = false;
            break;
        }
    }

    if ($allOk) {
        $verified = true;
    }
}

function prospeccaoEngineJobStatuses(): array {
    return ['queued', 'running', 'paused', 'completed', 'failed'];
}

function prospeccaoEngineJobPhases(): array {
    return ['init', 'collect', 'enrich', 'normalize', 'done'];
}

function prospeccaoEngineCityCenters(): array {
    return [
        'São José da Lapa' => ['lat' => -19.7378, 'lng' => -43.9867, 'span_km' => 8],
        'Vespasiano'       => ['lat' => -19.6922, 'lng' => -43.9233, 'span_km' => 10],
        'Confins'          => ['lat' => -19.6244, 'lng' => -43.9719, 'span_km' => 6],
        'Lagoa Santa'      => ['lat' => -19.6278, 'lng' => -43.8897, 'span_km' => 8],
    ];
}

function prospeccaoEngineMapJob(array $row): array {
    $categories = $row['categories'] ?? '[]';
    if (is_string($categories)) $categories = json_decode($categories, true) ?: [];
    $config = $row['config_json'] ?? null;
    if (is_string($config)) $config = json_decode($config, true);
    $state = $row['state_json'] ?? null;
    if (is_string($state)) $state = json_decode($state, true);

    return [
        'id'              => (int)$row['id'],
        'status'          => $row['status'],
        'phase'           => $row['phase'],
        'city'            => $row['city'],
        'categories'      => $categories,
        'radiusM'         => (int)$row['radius_m'],
        'progressPct'     => (float)$row['progress_pct'],
        'totalCells'      => (int)$row['total_cells'],
        'completedCells'  => (int)$row['completed_cells'],
        'leadsFound'      => (int)$row['leads_found'],
        'leadsEnriched'   => (int)$row['leads_enriched'],
        'leadsMerged'     => (int)$row['leads_merged'],
        'config'          => $config,
        'state'           => $state,
        'errorMessage'    => $row['error_message'],
        'startedAt'       => $row['started_at'],
        'completedAt'     => $row['completed_at'],
        'createdBy'       => $row['created_by'],
        'createdAt'       => $row['created_at'],
        'updatedAt'       => $row['updated_at'],
    ];
}

function prospeccaoEngineMapLead(array $row): array {
    $social = $row['social_json'] ?? null;
    if (is_string($social)) $social = json_decode($social, true);
    $location = $row['location_json'] ?? null;
    if (is_string($location)) $location = json_decode($location, true);
    $hours = $row['hours_json'] ?? null;
    if (is_string($hours)) $hours = json_decode($hours, true);

    return [
        'id'            => (int)$row['id'],
        'jobId'         => (int)$row['job_id'],
        'placeId'       => $row['place_id'],
        'name'          => $row['name'],
        'category'      => $row['category'],
        'phone'         => $row['phone'],
        'email'         => $row['email'],
        'website'       => $row['website'],
        'social'        => $social ?: [],
        'rating'        => $row['rating'] !== null ? (float)$row['rating'] : null,
        'reviewsCount'  => $row['reviews_count'] !== null ? (int)$row['reviews_count'] : null,
        'location'      => $location ?: [],
        'hours'         => $hours,
        'scoreIpc'      => (int)$row['score_ipc'],
        'leadScore'     => $row['lead_score'],
        'enrichedAt'    => $row['enriched_at'],
        'normalizedAt'  => $row['normalized_at'],
        'mergedAt'      => $row['merged_at'],
        'prospectId'    => $row['prospect_id'] ? (int)$row['prospect_id'] : null,
        'crmStatus'     => $row['crm_status'],
        'source'        => $row['source'],
        'createdAt'     => $row['created_at'],
        'updatedAt'     => $row['updated_at'],
    ];
}

function prospeccaoEngineMapEvent(array $row): array {
    $meta = $row['meta_json'] ?? null;
    if (is_string($meta)) $meta = json_decode($meta, true);
    return [
        'id'        => (int)$row['id'],
        'jobId'     => (int)$row['job_id'],
        'eventType' => $row['event_type'],
        'level'     => $row['level'],
        'message'   => $row['message'],
        'meta'      => $meta,
        'createdAt' => $row['created_at'],
    ];
}
