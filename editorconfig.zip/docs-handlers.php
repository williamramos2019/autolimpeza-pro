<?php
/**
 * Central de Documentação Técnica — API admin.
 * Catálogo = arquivos em docs/ + rotas ROUTES ao vivo + tabelas MySQL.
 * Sem CMS paralelo: só leitura autenticada.
 */

function docsTechRoot(): string {
    static $root = null;
    if ($root !== null) return $root;
    $candidates = [
        __DIR__ . '/docs',                    // deploy: FINAL_CPANEL/docs
        dirname(__DIR__) . '/docs',           // monorepo: artifacts/cleanpro/docs
        dirname(__DIR__, 2) . '/docs',
    ];
    foreach ($candidates as $d) {
        if (is_dir($d)) {
            $root = realpath($d) ?: $d;
            return $root;
        }
    }
    $fallback = __DIR__ . '/docs';
    if (!is_dir($fallback)) @mkdir($fallback, 0755, true);
    $root = $fallback;
    return $root;
}

function docsTechChangelogPath(): ?string {
    $candidates = [
        dirname(docsTechRoot()) . '/CHANGELOG.md',
        __DIR__ . '/CHANGELOG.md',
        dirname(__DIR__) . '/CHANGELOG.md',
    ];
    foreach ($candidates as $p) {
        if (is_file($p)) return $p;
    }
    return null;
}

/** @return string[] pastas relativas permitidas */
function docsTechAllowedDirs(): array {
    return ['', 'wiki', 'audit', 'status', 'build-final'];
}

function docsTechNormalizeRel(string $rel): ?string {
    $rel = str_replace('\\', '/', $rel);
    $rel = ltrim($rel, '/');
    if ($rel === '' || str_contains($rel, '..') || str_contains($rel, "\0")) return null;
    if (!preg_match('/^[a-zA-Z0-9_\/.\-]+\.md$/i', $rel) && $rel !== 'CHANGELOG.md') return null;
    $dir = dirname($rel);
    if ($dir === '.') $dir = '';
    if (!in_array($dir, docsTechAllowedDirs(), true) && $rel !== 'CHANGELOG.md') {
        // permite .md na raiz de docs/
        if ($dir !== '') return null;
    }
    return $rel;
}

function docsTechResolveFile(string $rel): ?string {
    if ($rel === 'CHANGELOG.md' || strcasecmp($rel, 'changelog.md') === 0) {
        return docsTechChangelogPath();
    }
    $norm = docsTechNormalizeRel($rel);
    if ($norm === null) return null;
    $full = docsTechRoot() . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $norm);
    $real = realpath($full);
    $root = realpath(docsTechRoot());
    if (!$real || !$root || !str_starts_with($real, $root) || !is_file($real)) return null;
    return $real;
}

/** @return array{id:string,label:string,description:string}[] */
function docsTechCategories(): array {
    return [
        ['id' => 'wiki', 'label' => 'Wiki técnica', 'description' => 'Visão geral, integrações, manutenção e FAQ'],
        ['id' => 'audit', 'label' => 'Arquitetura & auditoria', 'description' => 'Documentos de arquitetura, APIs, banco e segurança'],
        ['id' => 'status', 'label' => 'Status & inventário', 'description' => 'Módulos, integrações e dívida técnica'],
        ['id' => 'reports', 'label' => 'Relatórios', 'description' => 'Relatórios datados de entregas e correções'],
        ['id' => 'build', 'label' => 'Deploy & instalação', 'description' => 'Guias de cPanel, checklists e validação'],
        ['id' => 'live', 'label' => 'Catálogo ao vivo', 'description' => 'APIs (ROUTES), tabelas MySQL e CHANGELOG'],
    ];
}

function docsTechGuessCategory(string $rel): string {
    if (str_starts_with($rel, 'wiki/')) return 'wiki';
    if (str_starts_with($rel, 'audit/')) return 'audit';
    if (str_starts_with($rel, 'status/')) return 'status';
    if (str_starts_with($rel, 'build-final/')) return 'build';
    return 'reports';
}

function docsTechTitleFromFile(string $path, string $rel): string {
    $fh = @fopen($path, 'r');
    if ($fh) {
        for ($i = 0; $i < 8; $i++) {
            $line = fgets($fh);
            if ($line === false) break;
            if (preg_match('/^#\s+(.+)/', trim($line), $m)) {
                fclose($fh);
                return trim($m[1]);
            }
        }
        fclose($fh);
    }
    return pathinfo($rel, PATHINFO_FILENAME);
}

/** @return array<int,array<string,mixed>> */
function docsTechScanMarkdown(): array {
    $root = docsTechRoot();
    $out = [];
    $dirs = [
        $root,
        $root . '/wiki',
        $root . '/audit',
        $root . '/status',
        $root . '/build-final',
    ];
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) continue;
        $files = glob($dir . '/*.md') ?: [];
        foreach ($files as $path) {
            $rel = ltrim(str_replace('\\', '/', substr($path, strlen($root))), '/');
            if ($rel === '' || !docsTechNormalizeRel($rel)) continue;
            $out[] = [
                'slug'     => str_replace(['/', '.md'], ['__', ''], $rel),
                'path'     => $rel,
                'title'    => docsTechTitleFromFile($path, $rel),
                'category' => docsTechGuessCategory($rel),
                'updatedAt'=> date('c', (int)@filemtime($path)),
                'bytes'    => (int)@filesize($path),
                'source'   => 'file',
            ];
        }
    }
    $cl = docsTechChangelogPath();
    if ($cl) {
        $out[] = [
            'slug'     => 'CHANGELOG',
            'path'     => 'CHANGELOG.md',
            'title'    => 'CHANGELOG — histórico de versões',
            'category' => 'live',
            'updatedAt'=> date('c', (int)@filemtime($cl)),
            'bytes'    => (int)@filesize($cl),
            'source'   => 'changelog',
        ];
    }
    // Entradas virtuais (geradas dinamicamente)
    $out[] = [
        'slug' => 'live__apis',
        'path' => '__live__/apis',
        'title' => 'Catálogo de APIs (ROUTES ao vivo)',
        'category' => 'live',
        'updatedAt' => date('c'),
        'bytes' => 0,
        'source' => 'routes',
    ];
    $out[] = [
        'slug' => 'live__schema',
        'path' => '__live__/schema',
        'title' => 'Dicionário de dados (tabelas MySQL)',
        'category' => 'live',
        'updatedAt' => date('c'),
        'bytes' => 0,
        'source' => 'schema',
    ];
    usort($out, static fn($a, $b) => strcmp($a['title'], $b['title']));
    return $out;
}

/** Versão do produto: lê a entrada mais recente do CHANGELOG (fallback se ausente). */
function docsTechProductVersion(): string {
    $cl = docsTechChangelogPath();
    if ($cl && is_file($cl)) {
        $head = (string)@file_get_contents($cl, false, null, 0, 8000);
        if ($head !== '' && preg_match('/##\s*\[v?(\d+\.\d+\.\d+)\]/', $head, $m)) {
            return $m[1];
        }
    }
    return '1.19.1';
}

/** @return array<string,mixed> */
function docsTechBuildCatalog(): array {
    $docs = docsTechScanMarkdown();
    return [
        'version'    => docsTechProductVersion(),
        'generatedAt'=> date('c'),
        'root'       => basename(docsTechRoot()),
        'categories' => docsTechCategories(),
        'docs'       => $docs,
        'stats'      => [
            'documents' => count(array_filter($docs, static fn($d) => ($d['source'] ?? '') === 'file' || ($d['source'] ?? '') === 'changelog')),
            'live'      => count(array_filter($docs, static fn($d) => in_array($d['source'] ?? '', ['routes', 'schema'], true))),
        ],
    ];
}

/** @return array<int,array<string,mixed>> */
function docsTechRoutesCatalog(): array {
    if (!defined('ROUTES') || !is_array(ROUTES)) return [];
    $out = [];
    foreach (ROUTES as $action => $cfg) {
        if (!is_array($cfg)) continue;
        $out[] = [
            'action'  => (string)$action,
            'handler' => (string)($cfg['handler'] ?? ''),
            'methods' => array_values($cfg['methods'] ?? ['GET']),
            'auth'    => !empty($cfg['auth']),
            'rate'    => isset($cfg['rate']) ? (int)$cfg['rate'] : null,
        ];
    }
    usort($out, static fn($a, $b) => strcmp($a['action'], $b['action']));
    return $out;
}

function docsTechRoutesMarkdown(): string {
    $rows = docsTechRoutesCatalog();
    $md = "# Catálogo de APIs (ao vivo)\n\n";
    $md .= "> Gerado automaticamente a partir de `routes.php` em " . date('Y-m-d H:i') . ".\n\n";
    $md .= "Total: **" . count($rows) . "** rotas.\n\n";
    $md .= "| Action | Métodos | Auth | Rate | Handler |\n|--------|---------|------|------|----------|\n";
    foreach ($rows as $r) {
        $methods = implode(', ', $r['methods']);
        $auth = $r['auth'] ? 'admin' : 'público';
        $rate = $r['rate'] !== null ? (string)$r['rate'] : '—';
        $md .= '| `' . $r['action'] . '` | ' . $methods . ' | ' . $auth . ' | ' . $rate . ' | `' . $r['handler'] . "` |\n";
    }
    $md .= "\n## Como chamar\n\n`GET/POST /api.php?action=<action>` com headers `Authorization: Bearer <token>` quando Auth=admin.\n";
    return $md;
}

function docsTechSchemaMarkdown(PDO $pdo): string {
    $md = "# Dicionário de dados (ao vivo)\n\n";
    $md .= "> Tabelas do banco atual via `SHOW TABLES` / `INFORMATION_SCHEMA`.\n\n";
    try {
        $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        return $md . "Erro ao listar tabelas: " . $e->getMessage() . "\n";
    }
    sort($tables);
    $md .= "Total: **" . count($tables) . "** tabelas.\n\n";
    foreach ($tables as $table) {
        $t = (string)$table;
        $md .= "## `{$t}`\n\n";
        try {
            $cols = $pdo->query("SHOW FULL COLUMNS FROM `{$t}`")->fetchAll(PDO::FETCH_ASSOC);
            $md .= "| Campo | Tipo | Null | Key | Default | Extra |\n|-------|------|------|-----|---------|-------|\n";
            foreach ($cols as $c) {
                $md .= '| `' . ($c['Field'] ?? '') . '` | ' . ($c['Type'] ?? '')
                    . ' | ' . ($c['Null'] ?? '') . ' | ' . ($c['Key'] ?? '')
                    . ' | ' . (($c['Default'] === null) ? 'NULL' : (string)$c['Default'])
                    . ' | ' . ($c['Extra'] ?? '') . " |\n";
            }
            $md .= "\n";
        } catch (Throwable $e) {
            $md .= "_Não foi possível ler colunas: " . $e->getMessage() . "_\n\n";
        }
    }
    return $md;
}

function docsTechMarkdownToHtml(string $md, string $title = 'Documento'): string {
    $escaped = htmlspecialchars($md, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $lines = preg_split("/\r\n|\n|\r/", $escaped) ?: [];
    $html = [];
    $inCode = false;
    $inUl = false;
    $inOl = false;
    $inTable = false;
    $tableRows = [];

    $closeLists = static function () use (&$html, &$inUl, &$inOl): void {
        if ($inUl) { $html[] = '</ul>'; $inUl = false; }
        if ($inOl) { $html[] = '</ol>'; $inOl = false; }
    };
    $inline = static function (string $t): string {
        $t = preg_replace('/`([^`]+)`/', '<code>$1</code>', $t) ?? $t;
        $t = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $t) ?? $t;
        $t = preg_replace('/\*([^*]+)\*/', '<em>$1</em>', $t) ?? $t;
        $t = preg_replace('/\[([^\]]+)\]\(([^)]+)\)/', '<a href="$2">$1</a>', $t) ?? $t;
        return $t;
    };
    $flushTable = static function () use (&$html, &$inTable, &$tableRows, $inline): void {
        if (!$inTable) return;
        $html[] = '<div class="table-wrap"><table>';
        foreach ($tableRows as $i => $row) {
            $parts = array_map('trim', explode('|', trim($row, '|')));
            if ($parts && preg_match('/^[\s:\-]+$/', implode('', $parts))) continue;
            $tag = $i === 0 ? 'th' : 'td';
            $cells = array_map(static fn($p) => "<{$tag}>" . $inline($p) . "</{$tag}>", $parts);
            $html[] = '<tr>' . implode('', $cells) . '</tr>';
        }
        $html[] = '</table></div>';
        $tableRows = [];
        $inTable = false;
    };

    foreach ($lines as $line) {
        if (preg_match('/^```/', $line)) {
            $closeLists();
            $flushTable();
            if ($inCode) { $html[] = '</code></pre>'; $inCode = false; }
            else { $html[] = '<pre><code>'; $inCode = true; }
            continue;
        }
        if ($inCode) { $html[] = $line . "\n"; continue; }

        if (str_starts_with(ltrim($line), '|')) {
            $closeLists();
            $inTable = true;
            $tableRows[] = $line;
            continue;
        }
        if ($inTable) $flushTable();

        if (preg_match('/^(#{1,6})\s+(.+)$/', $line, $hm)) {
            $closeLists();
            $level = strlen($hm[1]);
            $html[] = '<h' . $level . '>' . $inline($hm[2]) . '</h' . $level . '>';
            continue;
        }
        if (preg_match('/^[-*]\s+(.+)$/', $line, $m)) {
            if ($inOl) { $html[] = '</ol>'; $inOl = false; }
            if (!$inUl) { $html[] = '<ul>'; $inUl = true; }
            $html[] = '<li>' . $inline($m[1]) . '</li>';
            continue;
        }
        if (preg_match('/^\d+\.\s+(.+)$/', $line, $m)) {
            if ($inUl) { $html[] = '</ul>'; $inUl = false; }
            if (!$inOl) { $html[] = '<ol>'; $inOl = true; }
            $html[] = '<li>' . $inline($m[1]) . '</li>';
            continue;
        }
        if (trim($line) === '' || trim($line) === '---' || trim($line) === '***') {
            $closeLists();
            if (trim($line) === '---' || trim($line) === '***') $html[] = '<hr>';
            else $html[] = '';
            continue;
        }
        if (preg_match('/^>\s?(.*)$/', $line, $m)) {
            $closeLists();
            $html[] = '<blockquote>' . $inline($m[1]) . '</blockquote>';
            continue;
        }
        $closeLists();
        $html[] = '<p>' . $inline($line) . '</p>';
    }
    $closeLists();
    $flushTable();

    $body = implode("\n", $html);
    $safeTitle = htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    return '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . $safeTitle . ' — Auto Limpeza Pro</title>'
        . '<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.55;max-width:880px;margin:0 auto;padding:24px;color:#111;background:#fff}
h1,h2,h3{line-height:1.25;margin-top:1.4em}
code,pre{font-family:ui-monospace,Consolas,monospace;font-size:0.9em}
pre{background:#f4f4f5;padding:12px;border-radius:8px;overflow:auto}
code{background:#f4f4f5;padding:1px 5px;border-radius:4px}
pre code{background:transparent;padding:0}
table{border-collapse:collapse;width:100%;font-size:0.85em;margin:1em 0}
th,td{border:1px solid #d4d4d8;padding:6px 8px;text-align:left}
th{background:#f4f4f5}
blockquote{margin:0;padding:8px 14px;border-left:4px solid #1FB1F9;background:#f0f9ff;color:#334155}
.table-wrap{overflow-x:auto}
.meta{color:#71717a;font-size:0.8em;margin-bottom:24px}
a{color:#0284c7}
hr{border:none;border-top:1px solid #e4e4e7;margin:2em 0}
@media print{body{max-width:none;padding:0}}
</style></head><body>'
        . '<p class="meta">Auto Limpeza Pro — Documentação técnica · ' . date('Y-m-d H:i') . '</p>'
        . '<h1>' . $safeTitle . '</h1>'
        . $body
        . '</body></html>';
}

/** Pasta amigável por categoria */
function docsTechExportFolder(string $category): string {
    return match ($category) {
        'wiki' => '01-Wiki',
        'status' => '02-Status-e-Inventario',
        'audit' => '03-Arquitetura-e-Auditoria',
        'reports' => '04-Relatorios',
        'build' => '05-Deploy-e-Instalacao',
        'live' => '06-Ao-Vivo',
        default => '99-Outros',
    };
}

function docsTechExportReadme(): string {
    $date = date('Y-m-d H:i');
    return <<<MD
# Documentação técnica — Auto Limpeza Pro

Pacote gerado em **{$date}** pela Central de Documentação (admin).

## Como navegar

1. Comece por este arquivo (`00-COMECE-AQUI.md`) ou pela versão HTML.
2. Abra `INDICE.md` / `INDICE.html` para a lista completa com links.
3. Pastas numeradas agrupam os documentos por assunto:

| Pasta | Conteúdo |
|-------|----------|
| `01-Wiki` | Visão geral, integrações, manutenção, FAQ |
| `02-Status-e-Inventario` | Status dos módulos e sequência de finalização |
| `03-Arquitetura-e-Auditoria` | Arquitetura, APIs, banco, segurança |
| `04-Relatorios` | Relatórios datados de entregas |
| `05-Deploy-e-Instalacao` | Guias cPanel e checklists |
| `06-Ao-Vivo` | Catálogo de APIs e dicionário MySQL (snapshot) |

4. Formatos:
   - **markdown/** — fonte original (edição / Git)
   - **html/** — leitura no navegador ou impressão (Ctrl+P → PDF)
   - **catalogo.json** — índice máquina (ferramentas / busca)

## Observação

Os arquivos em `06-Ao-Vivo` refletem o estado do servidor **no momento do download** (rotas e tabelas).
MD;
}

/**
 * @return array{name:string,md:string,html:string,folder:string}[]
 */
function docsTechCollectExportDocs(PDO $pdo): array {
    $items = [];
    foreach (docsTechScanMarkdown() as $doc) {
        $src = (string)($doc['source'] ?? '');
        $path = (string)($doc['path'] ?? '');
        $title = (string)($doc['title'] ?? $path);
        $cat = (string)($doc['category'] ?? 'reports');
        $folder = docsTechExportFolder($cat);
        $md = '';
        if ($src === 'file' || $src === 'changelog') {
            $file = docsTechResolveFile($path);
            if (!$file) continue;
            $raw = file_get_contents($file);
            if ($raw === false) continue;
            if (strlen($raw) > 1_500_000) {
                $raw = substr($raw, 0, 1_500_000) . "\n\n… _(truncado no export)_";
            }
            $md = $raw;
        } elseif ($src === 'routes') {
            $md = docsTechRoutesMarkdown();
            $path = 'catalogo-apis.md';
        } elseif ($src === 'schema') {
            $md = docsTechSchemaMarkdown($pdo);
            $path = 'dicionario-banco.md';
        } else {
            continue;
        }
        $base = pathinfo(str_replace(['/', '\\'], '-', $path), PATHINFO_FILENAME);
        if ($base === '' || $base === '.') $base = $doc['slug'] ?? 'doc';
        $items[] = [
            'name'   => $base,
            'md'     => $md,
            'html'   => docsTechMarkdownToHtml($md, $title),
            'folder' => $folder,
            'title'  => $title,
            'path'   => $path,
            'category' => $cat,
        ];
    }
    return $items;
}

function docsTechBuildIndexMarkdown(array $items): string {
    $md = "# Índice da documentação\n\n";
    $md .= "> Gerado em " . date('Y-m-d H:i') . " · " . count($items) . " documentos\n\n";
    $by = [];
    foreach ($items as $it) {
        $by[$it['folder']][] = $it;
    }
    ksort($by);
    foreach ($by as $folder => $list) {
        $md .= "## {$folder}\n\n";
        foreach ($list as $it) {
            $md .= '- [' . $it['title'] . '](markdown/' . $folder . '/' . $it['name'] . ".md)\n";
        }
        $md .= "\n";
    }
    return $md;
}

function docsTechStreamExportZip(PDO $pdo, string $format): void {
    if (!class_exists('ZipArchive')) {
        jsonRespond(['error' => 'ZipArchive indisponível neste PHP. Use format=json ou peça ao host ativar ext-zip.'], 503);
    }

    $wantMd = in_array($format, ['zip', 'md', 'all'], true);
    $wantHtml = in_array($format, ['zip', 'html', 'all'], true);
    if ($format === 'zip' || $format === 'all') {
        $wantMd = true;
        $wantHtml = true;
    }

    $items = docsTechCollectExportDocs($pdo);
    $stamp = date('Y-m-d');
    $rootName = "Documentacao-AutoLimpezaPro-{$stamp}";
    $tmp = tempnam(sys_get_temp_dir(), 'alpdocs');
    if ($tmp === false) jsonRespond(['error' => 'Falha ao criar arquivo temporário'], 500);
    @unlink($tmp);
    $zipPath = $tmp . '.zip';

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        jsonRespond(['error' => 'Falha ao criar ZIP'], 500);
    }

    $readme = docsTechExportReadme();
    $indexMd = docsTechBuildIndexMarkdown($items);
    $catalog = [
        'generatedAt' => date('c'),
        'product'     => 'Auto Limpeza Pro',
        'format'      => $format,
        'documents'   => array_map(static fn($it) => [
            'title'    => $it['title'],
            'folder'   => $it['folder'],
            'file'     => $it['name'],
            'category' => $it['category'],
            'sourcePath' => $it['path'],
        ], $items),
        'total' => count($items),
    ];

    $zip->addFromString("{$rootName}/00-COMECE-AQUI.md", $readme);
    $zip->addFromString("{$rootName}/00-COMECE-AQUI.html", docsTechMarkdownToHtml($readme, 'Comece aqui'));
    $zip->addFromString("{$rootName}/INDICE.md", $indexMd);
    $zip->addFromString("{$rootName}/INDICE.html", docsTechMarkdownToHtml($indexMd, 'Índice'));
    $zip->addFromString("{$rootName}/catalogo.json", json_encode($catalog, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

    foreach ($items as $it) {
        $folder = $it['folder'];
        $name = $it['name'];
        if ($wantMd) {
            $zip->addFromString("{$rootName}/markdown/{$folder}/{$name}.md", $it['md']);
        }
        if ($wantHtml) {
            $zip->addFromString("{$rootName}/html/{$folder}/{$name}.html", $it['html']);
        }
    }

    $zip->close();

    $filename = $rootName . '-' . $format . '.zip';
    $size = filesize($zipPath);
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    if ($size !== false) header('Content-Length: ' . $size);
    header('Cache-Control: no-store');
    readfile($zipPath);
    @unlink($zipPath);
    exit;
}

function docsTechStreamExportJson(PDO $pdo): void {
    $items = docsTechCollectExportDocs($pdo);
    $payload = [
        'generatedAt' => date('c'),
        'product' => 'Auto Limpeza Pro',
        'readme' => docsTechExportReadme(),
        'documents' => array_map(static fn($it) => [
            'title' => $it['title'],
            'folder' => $it['folder'],
            'category' => $it['category'],
            'path' => $it['path'],
            'markdown' => $it['md'],
        ], $items),
        'total' => count($items),
    ];
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $filename = 'Documentacao-AutoLimpezaPro-' . date('Y-m-d') . '.json';
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($json));
    header('Cache-Control: no-store');
    echo $json;
    exit;
}

function handleDocsTech(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);

    $action = trim((string)($_GET['action'] ?? ''));
    $sub = match ($action) {
        'docs/catalog' => 'catalog',
        'docs/file'    => 'file',
        'docs/apis'    => 'apis',
        'docs/schema'  => 'schema',
        'docs/search'  => 'search',
        'docs/export'  => 'export',
        default        => san($_GET['sub'] ?? 'catalog', 40) ?? 'catalog',
    };
    $pdo = db();

    if ($sub === 'export') {
        $format = strtolower(san($_GET['format'] ?? 'zip', 12) ?? 'zip');
        if (!in_array($format, ['zip', 'md', 'html', 'json', 'all'], true)) {
            jsonRespond(['error' => 'format inválido (zip|md|html|json)'], 400);
        }
        if ($format === 'json') {
            docsTechStreamExportJson($pdo);
        }
        docsTechStreamExportZip($pdo, $format === 'all' ? 'zip' : $format);
    }

    if ($sub === 'catalog') {
        jsonRespond(docsTechBuildCatalog());
    }

    if ($sub === 'apis' || $sub === 'routes') {
        $format = san($_GET['format'] ?? 'json', 10) ?? 'json';
        if ($format === 'md') {
            jsonRespond(['path' => '__live__/apis', 'title' => 'Catálogo de APIs', 'markdown' => docsTechRoutesMarkdown()]);
        }
        jsonRespond(['routes' => docsTechRoutesCatalog(), 'total' => count(docsTechRoutesCatalog())]);
    }

    if ($sub === 'schema') {
        $format = san($_GET['format'] ?? 'md', 10) ?? 'md';
        if ($format === 'json') {
            try {
                $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
            } catch (Throwable $e) {
                jsonRespond(['error' => $e->getMessage()], 500);
            }
            jsonRespond(['tables' => array_values($tables), 'total' => count($tables)]);
        }
        jsonRespond(['path' => '__live__/schema', 'title' => 'Dicionário de dados', 'markdown' => docsTechSchemaMarkdown($pdo)]);
    }

    if ($sub === 'file') {
        $path = (string)($_GET['path'] ?? '');
        if ($path === '__live__/apis') {
            jsonRespond(['path' => $path, 'title' => 'Catálogo de APIs', 'markdown' => docsTechRoutesMarkdown(), 'source' => 'routes']);
        }
        if ($path === '__live__/schema') {
            jsonRespond(['path' => $path, 'title' => 'Dicionário de dados', 'markdown' => docsTechSchemaMarkdown($pdo), 'source' => 'schema']);
        }
        $file = docsTechResolveFile($path);
        if (!$file) jsonRespond(['error' => 'Documento não encontrado'], 404);
        $md = file_get_contents($file);
        if ($md === false) jsonRespond(['error' => 'Falha ao ler arquivo'], 500);
        // Limite de segurança (~1.5 MB)
        if (strlen($md) > 1_500_000) {
            $md = substr($md, 0, 1_500_000) . "\n\n… _(truncado)_";
        }
        jsonRespond([
            'path'     => $path,
            'title'    => docsTechTitleFromFile($file, $path),
            'markdown' => $md,
            'updatedAt'=> date('c', (int)@filemtime($file)),
            'source'   => 'file',
        ]);
    }

    if ($sub === 'search') {
        $q = mb_strtolower(trim((string)($_GET['q'] ?? '')));
        if ($q === '' || mb_strlen($q) < 2) jsonRespond(['results' => [], 'q' => $q]);
        $catalog = docsTechBuildCatalog();
        $results = [];
        foreach ($catalog['docs'] as $doc) {
            $hay = mb_strtolower(($doc['title'] ?? '') . ' ' . ($doc['path'] ?? '') . ' ' . ($doc['category'] ?? ''));
            if (str_contains($hay, $q)) {
                $results[] = $doc;
                continue;
            }
            // Busca leve no início do arquivo (primeiros 4 KB)
            if (($doc['source'] ?? '') === 'file' && !empty($doc['path'])) {
                $f = docsTechResolveFile((string)$doc['path']);
                if ($f) {
                    $snippet = mb_strtolower((string)@file_get_contents($f, false, null, 0, 4096));
                    if (str_contains($snippet, $q)) $results[] = $doc;
                }
            }
        }
        jsonRespond(['q' => $q, 'results' => array_values($results), 'total' => count($results)]);
    }

    jsonRespond(['error' => 'sub inválido (catalog|file|apis|schema|search|export)'], 400);
}
