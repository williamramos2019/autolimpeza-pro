<?php
/**
 * E-mail transacional — SMTP, templates e central de notificações.
 */

require_once __DIR__ . '/smtp-client.php';

function smtpConfigDefaultEmail(): string {
    if (defined('MAIL_FROM') && MAIL_FROM !== '') {
        return (string) MAIL_FROM;
    }
    if (defined('CONTACT_EMAIL') && CONTACT_EMAIL !== '') {
        return (string) CONTACT_EMAIL;
    }
    return 'contato@autolimpezapro.com.br';
}

function smtpConfigDefaults(): array {
    $email = smtpConfigDefaultEmail();
    $user  = (defined('SMTP_USER') && SMTP_USER !== '') ? (string) SMTP_USER : $email;
    $host  = (defined('SMTP_HOST') && SMTP_HOST !== '') ? (string) SMTP_HOST : 'smtp.titan.email';
    $port  = (defined('SMTP_PORT') && (int) SMTP_PORT > 0) ? (int) SMTP_PORT : 465;
    $enc   = (defined('SMTP_ENCRYPTION') && SMTP_ENCRYPTION !== '') ? (string) SMTP_ENCRYPTION : 'SSL/TLS';
    if (strcasecmp($enc, 'ssl') === 0) $enc = 'SSL/TLS';
    return [
        'company_name'  => 'Auto Limpeza Pro',
        'from_email'    => $email,
        'from_name'     => 'Auto Limpeza Pro',
        'smtp_host'     => $host,
        'smtp_port'     => $port,
        'encryption'    => $enc,
        'smtp_user'     => $user,
        'admin_email'   => $email,
        'enabled'       => true,
    ];
}

const NOTIFICATION_CHANNELS_DEFAULT = [
    'new_appointment' => [
        'panel' => true, 'push' => true, 'email_admin' => true, 'email_client' => true,
        'whatsapp' => false, 'telegram' => false, 'slack' => true,
    ],
    'appointment_confirmed' => ['panel' => true, 'push' => true, 'email_client' => true, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'appointment_cancelled' => ['panel' => true, 'push' => true, 'email_client' => true, 'whatsapp' => false, 'telegram' => false, 'slack' => true],
    'appointment_completed' => ['panel' => true, 'push' => false, 'email_client' => true, 'whatsapp' => false, 'telegram' => false, 'slack' => true],
    'appointment_status'    => ['panel' => true, 'push' => true, 'email_client' => true, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'appointment_reminder'  => ['panel' => true, 'push' => true, 'email_client' => true, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'new_lead' => ['panel' => true, 'push' => true, 'email_admin' => true, 'whatsapp' => false, 'telegram' => false, 'slack' => true],
    'new_sale' => ['panel' => true, 'push' => false, 'email_admin' => true, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'new_expense' => ['panel' => true, 'email_admin' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'payment_received' => ['panel' => true, 'email_admin' => true, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'new_article' => ['panel' => true, 'push' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'system_alert' => ['panel' => true, 'push' => true, 'email_admin' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => true],
    'password_reset' => ['email' => true],
    // Live Service 2.0 — todos editáveis pelo mesmo painel existente.
    'DriverStarted'   => ['panel' => true, 'push' => true,  'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'DriverTracking'  => ['panel' => false, 'push' => false, 'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'DriverNear'      => ['panel' => true, 'push' => true,  'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'DriverStopped'   => ['panel' => true, 'push' => false, 'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'DriverArrived'   => ['panel' => true, 'push' => true,  'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'DriverDelayed'   => ['panel' => true, 'push' => true,  'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'DriverOffline'   => ['panel' => true, 'push' => false, 'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'GpsStale'        => ['panel' => true, 'push' => false, 'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'InternetLost'    => ['panel' => true, 'push' => false, 'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'ServiceStarted'  => ['panel' => true, 'push' => true,  'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'ServicePaused'   => ['panel' => true, 'push' => false, 'email_client' => false, 'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'ServiceFinished' => ['panel' => true, 'push' => true,  'email_client' => true,  'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'ReviewRequested' => ['panel' => true, 'push' => true,  'email_client' => true,  'whatsapp' => false, 'telegram' => false, 'slack' => false],
    'WarrantyCreated' => ['panel' => true, 'push' => true,  'email_client' => true,  'whatsapp' => false, 'telegram' => false, 'slack' => false],
];

// ── Criptografia de segredos ──────────────────────────────────────────────

function mailEncryptionKey(): string {
    if (defined('MAIL_ENCRYPTION_KEY') && MAIL_ENCRYPTION_KEY !== '') {
        return hash('sha256', (string) MAIL_ENCRYPTION_KEY, true);
    }
    $parts = [];
    if (defined('DB_NAME') && DB_NAME !== '') $parts[] = DB_NAME;
    if (defined('DB_PASS') && DB_PASS !== '') $parts[] = DB_PASS;
    if (defined('ADMIN_TOKEN') && ADMIN_TOKEN !== '') $parts[] = ADMIN_TOKEN;
    $material = $parts ? implode('|', $parts) : 'autolimpezapro-mail-key';
    return hash('sha256', $material, true);
}

/** Em production, exige chave dedicada ao gravar novos secrets. */
function requireDedicatedEncryptionKey(string $kind = 'mail'): void {
    $isProd = defined('APP_ENV') && APP_ENV === 'production';
    if (!$isProd) return;
    if ($kind === 'ai') {
        if (!defined('AI_GATEWAY_ENCRYPTION_KEY') || trim((string)AI_GATEWAY_ENCRYPTION_KEY) === '') {
            jsonRespond(['error' => 'Defina AI_GATEWAY_ENCRYPTION_KEY em config.local.php antes de salvar chaves de IA'], 503);
        }
        return;
    }
    if (!defined('MAIL_ENCRYPTION_KEY') || trim((string)MAIL_ENCRYPTION_KEY) === '') {
        // Soft: não bloqueia se já houver material derivado — só avisa em log
        if (function_exists('appLog')) {
            appLog('warning', 'mail_encryption_key_missing', ['hint' => 'Defina MAIL_ENCRYPTION_KEY']);
        }
    }
}

function encryptMailSecret(string $plain): string {
    $iv  = random_bytes(16);
    $enc = openssl_encrypt($plain, 'AES-256-CBC', mailEncryptionKey(), OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $enc);
}

function decryptMailSecret(string $stored): string {
    if ($stored === '') return '';
    $raw = base64_decode($stored, true);
    if ($raw === false || strlen($raw) < 17) return '';
    $iv  = substr($raw, 0, 16);
    $enc = substr($raw, 16);
    $dec = openssl_decrypt($enc, 'AES-256-CBC', mailEncryptionKey(), OPENSSL_RAW_DATA, $iv);
    return $dec !== false ? $dec : '';
}

// ── Configuração ──────────────────────────────────────────────────────────

/** Valores gravados em site_config (sem merge com config.php). */
function getSmtpConfigStored(PDO $pdo): array {
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'smtp_config' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    $stored = $row && $row['value'] ? json_decode($row['value'], true) : [];
    return is_array($stored) ? $stored : [];
}

/**
 * DB tem prioridade sobre config.php; config.php só preenche chaves ausentes ou vazias.
 */
function getSmtpConfigRow(PDO $pdo): array {
    $defaults = smtpConfigDefaults();
    $stored   = getSmtpConfigStored($pdo);
    $merged   = $defaults;
    foreach ($stored as $key => $value) {
        if ($value !== null && $value !== '') {
            $merged[$key] = $value;
        }
    }
    return $merged;
}

/** Domínios legados que devem ser migrados para o e-mail canônico do config.php. */
function smtpLegacyEmailDomains(): array {
    return ['autolimpezapro.agendaaqui.online', 'teste.agendaaqui.online', 'agendaaqui.online'];
}

function smtpIsLegacyEmail(string $email): bool {
    $lower = strtolower(trim($email));
    if ($lower === '') return false;
    foreach (smtpLegacyEmailDomains() as $domain) {
        if (str_ends_with($lower, '@' . $domain) || str_contains($lower, $domain)) {
            return true;
        }
    }
    return false;
}

/** Normaliza e-mails legados para o domínio atual (Titan: smtp_user = from_email). */
function smtpNormalizeEmailFields(array $cfg): array {
    $canonical = smtpConfigDefaultEmail();
    foreach (['from_email', 'smtp_user', 'admin_email'] as $field) {
        if (empty($cfg[$field]) || !is_string($cfg[$field])) {
            continue;
        }
        if (smtpIsLegacyEmail($cfg[$field]) && $canonical !== '' && isEmail($canonical)) {
            $cfg[$field] = $canonical;
        }
    }
    if (!empty($cfg['from_email']) && isEmail($cfg['from_email'])) {
        $cfg['smtp_user'] = $cfg['from_email'];
    }
    return $cfg;
}

function getSmtpPassword(PDO $pdo): string {
    if (defined('SMTP_PASSWORD') && SMTP_PASSWORD !== '') {
        return trim((string) SMTP_PASSWORD);
    }
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'smtp_password_enc' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    if (!$row || !$row['value']) return '';
    $dec = decryptMailSecret($row['value']);
    if ($dec === '' && strlen((string)$row['value']) > 20) {
        throw new RuntimeException(
            'Senha SMTP salva está corrompida (chave de criptografia mudou). '
            . 'Salve a senha novamente em Central de Notificações → Canais, ou defina SMTP_PASSWORD no config.php.'
        );
    }
    return trim($dec);
}

function isSmtpPasswordConfigured(PDO $pdo): bool {
    if (defined('SMTP_PASSWORD') && SMTP_PASSWORD !== '') {
        return true;
    }
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'smtp_password_enc' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    return $row && !empty($row['value']);
}

function saveSmtpConfig(PDO $pdo, array $config, ?string $newPassword = null): array {
    unset($config['password'], $config['smtp_password'], $config['password_configured']);

    $defaults = smtpConfigDefaults();
    $stored   = getSmtpConfigStored($pdo);
    // Prioridade: payload > DB > config.php (evita reset em save parcial, ex. só senha)
    $merged = array_replace($defaults, $stored, $config);

    foreach (['from_email', 'smtp_user', 'admin_email'] as $emailField) {
        if (isset($merged[$emailField]) && is_string($merged[$emailField])) {
            $merged[$emailField] = strtolower(trim($merged[$emailField]));
        }
    }

    if (!empty($merged['from_email']) && empty($merged['smtp_user'])) {
        $merged['smtp_user'] = $merged['from_email'];
    }
    if (!empty($merged['from_email']) && !empty($merged['smtp_user'])
        && strtolower($merged['smtp_user']) !== strtolower($merged['from_email'])) {
        $merged['smtp_user'] = $merged['from_email'];
    }

    $merged = smtpNormalizeEmailFields($merged);

    $now = dbNow();

    $pdo->prepare("INSERT INTO site_config (key_name, value, updated_at) VALUES ('smtp_config', ?, ?)
        ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)")
        ->execute([json_encode($merged, JSON_UNESCAPED_UNICODE), $now]);

    if ($newPassword !== null && $newPassword !== '') {
        $plain = trim($newPassword);
        $enc   = encryptMailSecret($plain);
        if (decryptMailSecret($enc) !== $plain) {
            throw new RuntimeException('Falha ao criptografar senha SMTP no servidor (OpenSSL).');
        }
        $pdo->prepare("INSERT INTO site_config (key_name, value, updated_at) VALUES ('smtp_password_enc', ?, ?)
            ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)")
            ->execute([$enc, $now]);
    }

    return getSmtpConfigPublic($pdo);
}

/** Testa login SMTP sem enviar e-mail (para validar credenciais). */
function testSmtpConnection(PDO $pdo): array {
    $cfg = getSmtpConfigRow($pdo);
    try {
        $password = getSmtpPassword($pdo);
    } catch (RuntimeException $e) {
        return ['ok' => false, 'error' => $e->getMessage()];
    }
    if ($password === '') {
        return ['ok' => false, 'error' => 'Senha SMTP não configurada'];
    }
    $client = new SmtpClient();
    try {
        $client->connect($cfg['smtp_host'], (int)$cfg['smtp_port'], $cfg['encryption']);
        $client->auth($cfg['smtp_user'], $password);
        $client->quit();
        return ['ok' => true, 'smtp_user' => $cfg['smtp_user'], 'from_email' => $cfg['from_email']];
    } catch (Throwable $e) {
        try { $client->quit(); } catch (Throwable $ignored) {}
        return ['ok' => false, 'error' => $e->getMessage(), 'smtp_user' => $cfg['smtp_user'], 'from_email' => $cfg['from_email']];
    }
}

function getSmtpConfigPublic(PDO $pdo): array {
    $cfg = getSmtpConfigRow($pdo);
    $from = (string)($cfg['from_email'] ?? '');
    $user = (string)($cfg['smtp_user'] ?? '');
    $mismatch = $from !== '' && $user !== '' && strtolower($from) !== strtolower($user);
    return [
        'company_name'        => $cfg['company_name'],
        'from_email'          => $cfg['from_email'],
        'from_name'           => $cfg['from_name'],
        'smtp_host'           => $cfg['smtp_host'],
        'smtp_port'           => (int)$cfg['smtp_port'],
        'encryption'          => $cfg['encryption'],
        'smtp_user'           => $cfg['smtp_user'],
        'admin_email'         => $cfg['admin_email'],
        'enabled'             => (bool)$cfg['enabled'],
        'password_configured' => isSmtpPasswordConfigured($pdo),
        'smtp_user_mismatch'  => $mismatch,
        'legacy_email_detected' => smtpIsLegacyEmail($from) || smtpIsLegacyEmail($user) || smtpIsLegacyEmail((string)($cfg['admin_email'] ?? '')),
    ];
}

function getNotificationChannels(PDO $pdo): array {
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'notification_channels' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    $stored = $row && $row['value'] ? json_decode($row['value'], true) : [];
    if (!is_array($stored)) $stored = [];
    // Compat: chave legada status_change → appointment_status
    if (isset($stored['status_change']) && !isset($stored['appointment_status'])) {
        $stored['appointment_status'] = $stored['status_change'];
        unset($stored['status_change']);
    }
    return array_replace_recursive(NOTIFICATION_CHANNELS_DEFAULT, $stored);
}

function saveNotificationChannels(PDO $pdo, array $channels): array {
    if (isset($channels['status_change']) && !isset($channels['appointment_status'])) {
        $channels['appointment_status'] = $channels['status_change'];
    }
    unset($channels['status_change']);
    $merged = array_replace_recursive(NOTIFICATION_CHANNELS_DEFAULT, $channels);
    $pdo->prepare("INSERT INTO site_config (key_name, value, updated_at) VALUES ('notification_channels', ?, NOW())
        ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = NOW()")
        ->execute([json_encode($merged, JSON_UNESCAPED_UNICODE)]);
    return $merged;
}

function isChannelEnabled(PDO $pdo, string $event, string $channel): bool {
    $ch = getNotificationChannels($pdo);
    return !empty($ch[$event][$channel]);
}

// ── Histórico e observabilidade SMTP ──────────────────────────────────────

function ensureMailLogTable(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `mail_send_log` (
        `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `to_email`      VARCHAR(255) NOT NULL,
        `subject`       VARCHAR(500) DEFAULT NULL,
        `status`        VARCHAR(10)  NOT NULL DEFAULT 'ok',
        `error_message` TEXT         DEFAULT NULL,
        `template`      VARCHAR(50)  DEFAULT NULL,
        `created_at`    DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_status_created` (`status`, `created_at`),
        INDEX `idx_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function mailConfigSet(PDO $pdo, string $key, ?string $value): void {
    $pdo->prepare("
        INSERT INTO site_config (key_name, value, updated_at) VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)
    ")->execute([$key, $value, dbNow()]);
}

function recordMailSend(PDO $pdo, string $to, string $subject, bool $ok, ?string $error = null, ?string $template = null): void {
    ensureMailLogTable($pdo);
    $now = dbNow();
    $pdo->prepare("
        INSERT INTO mail_send_log (to_email, subject, status, error_message, template, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
    ")->execute([
        mb_substr($to, 0, 255),
        mb_substr($subject, 0, 500),
        $ok ? 'ok' : 'error',
        $error ? mb_substr($error, 0, 2000) : null,
        $template,
        $now,
    ]);
    if ($ok) {
        mailConfigSet($pdo, 'smtp_last_success_at', $now);
        mailConfigSet($pdo, 'smtp_last_success_to', mb_substr($to, 0, 255));
    } else {
        mailConfigSet($pdo, 'smtp_last_error_at', $now);
        mailConfigSet($pdo, 'smtp_last_error', mb_substr((string)$error, 0, 1000));
    }
}

function getMailObservability(PDO $pdo): array {
    ensureMailLogTable($pdo);
    $get = function (string $key) use ($pdo): ?string {
        $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = ? LIMIT 1");
        $stmt->execute([$key]);
        $v = $stmt->fetchColumn();
        return $v !== false && $v !== null && $v !== '' ? (string)$v : null;
    };
    $stats = $pdo->query("
        SELECT
            COUNT(*) AS total,
            SUM(status = 'ok') AS sent_ok,
            SUM(status = 'error') AS sent_error
        FROM mail_send_log
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ")->fetch(PDO::FETCH_ASSOC) ?: ['total' => 0, 'sent_ok' => 0, 'sent_error' => 0];
    $history = $pdo->query("
        SELECT id, to_email, subject, status, error_message, template, created_at
        FROM mail_send_log ORDER BY id DESC LIMIT 25
    ")->fetchAll(PDO::FETCH_ASSOC);
    return [
        'lastSuccessAt' => $get('smtp_last_success_at'),
        'lastSuccessTo' => $get('smtp_last_success_to'),
        'lastErrorAt'   => $get('smtp_last_error_at'),
        'lastError'     => $get('smtp_last_error'),
        'stats30d'      => [
            'total'  => (int)($stats['total'] ?? 0),
            'ok'     => (int)($stats['sent_ok'] ?? 0),
            'error'  => (int)($stats['sent_error'] ?? 0),
        ],
        'history'       => $history,
    ];
}

// ── Envio ─────────────────────────────────────────────────────────────────

function sendMailMessage(string $to, string $subject, string $htmlBody): array {
    if (!isEmail($to)) {
        return ['ok' => false, 'error' => 'E-mail de destino inválido'];
    }

    $pdo = db();
    $cfg = getSmtpConfigRow($pdo);
    if (!(bool)$cfg['enabled']) {
        return ['ok' => false, 'error' => 'Envio de e-mail desativado nas configurações'];
    }

    try {
        $password = getSmtpPassword($pdo);
    } catch (RuntimeException $e) {
        return ['ok' => false, 'error' => $e->getMessage()];
    }
    if ($password === '') {
        return ['ok' => false, 'error' => 'Senha SMTP não configurada'];
    }

    $client = new SmtpClient();
    try {
        $client->connect($cfg['smtp_host'], (int)$cfg['smtp_port'], $cfg['encryption']);
        $client->auth($cfg['smtp_user'], $password);
        $client->send(
            $cfg['from_email'],
            $to,
            $subject,
            $htmlBody,
            $cfg['from_name'] ?? $cfg['company_name']
        );
        $client->quit();
        recordMailSend($pdo, $to, $subject, true);
        appLog('info', 'mail_sent', ['to' => $to, 'subject' => $subject]);
        return ['ok' => true];
    } catch (Throwable $e) {
        try { $client->quit(); } catch (Throwable $ignored) {}
        $err = $e->getMessage();
        recordMailSend($pdo, $to, $subject, false, $err);
        appLog('error', 'mail_failed', ['to' => $to, 'error' => $err]);
        return ['ok' => false, 'error' => $err];
    }
}

/**
 * Envelope HTML padrão dos e-mails — identidade visual da marca (alpBrand):
 * faixa em degradê azul→ciano, tipografia Plus Jakarta Sans (com fallbacks
 * seguros para clientes de e-mail) e links/CTAs na cor primária.
 */
function mailWrapHtml(string $title, string $bodyHtml): string {
    $b = function_exists('alpBrand') ? alpBrand() : [
        'name' => 'Auto Limpeza Pro', 'siteUrl' => 'https://autolimpezapro.com.br',
        'primary' => '#1FB1F9', 'gradient' => 'linear-gradient(135deg,#1FB1F9 0%,#06C6E0 100%)',
        'textDark' => '#0f172a', 'textMuted' => '#64748b', 'surface' => '#f4f7fa',
        'fontStack' => "'Plus Jakarta Sans','Segoe UI',system-ui,Arial,sans-serif", 'radius' => '12px',
    ];
    $site = htmlspecialchars($b['name'], ENT_QUOTES, 'UTF-8');
    $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $host = htmlspecialchars(preg_replace('#^https?://#', '', (string)$b['siteUrl']), ENT_QUOTES, 'UTF-8');

    return '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . $safeTitle . '</title>'
        // <style> cobre clientes que o suportam; o essencial permanece inline.
        . '<style>a{color:' . $b['primary'] . '}</style>'
        . '</head>'
        . '<body style="margin:0;font-family:' . $b['fontStack'] . ';background:' . $b['surface'] . ';padding:24px;color:' . $b['textDark'] . '">'
        . '<div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:' . $b['radius'] . ';border:1px solid #e2e8f0;overflow:hidden">'
        // Faixa da marca (degradê azul → ciano)
        . '<div style="height:6px;background:' . $b['gradient'] . ';background-color:' . $b['primary'] . '"></div>'
        . '<div style="padding:32px">'
        . '<h2 style="margin:0 0 4px;font-size:20px;color:' . $b['textDark'] . '">'
        . '<span style="color:' . $b['primary'] . '">&#9679;</span> ' . $site . '</h2>'
        . '<p style="margin:0 0 20px;font-size:13px;color:' . $b['textMuted'] . '">' . $safeTitle . '</p>'
        . '<div style="font-size:15px;line-height:1.6;color:' . $b['textDark'] . '">' . $bodyHtml . '</div>'
        . '<p style="color:#94a3b8;font-size:12px;margin-top:32px;border-top:1px solid #e2e8f0;padding-top:16px">'
        . 'Este é um e-mail automático de <a href="' . htmlspecialchars((string)$b['siteUrl'], ENT_QUOTES, 'UTF-8')
        . '" style="color:' . $b['primary'] . ';text-decoration:none;font-weight:600">' . $host . '</a>. '
        . 'Não responda diretamente a esta mensagem.</p>'
        . '</div></div></body></html>';
}

/**
 * Botão CTA no padrão visual da marca para uso em corpos de e-mail.
 */
function mailBrandButton(string $label, string $url): string {
    $b = function_exists('alpBrand') ? alpBrand() : ['primary' => '#1FB1F9'];
    return '<p style="margin:20px 0"><a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" '
        . 'style="display:inline-block;background:' . $b['primary'] . ';color:#ffffff;padding:12px 24px;'
        . 'border-radius:10px;text-decoration:none;font-weight:700;font-size:14px">'
        . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</a></p>';
}

function renderMailTemplate(string $template, array $vars): array {
    $templates = [
        'appointment_client' => [
            'subject' => 'Agendamento confirmado — Auto Limpeza Pro',
            'body'    => '<p>Olá <strong>{nome_cliente}</strong>,</p>'
                . '<p>Recebemos seu agendamento. Seguem os detalhes:</p>'
                . '<p><strong>Serviço:</strong><br>{servico}</p>'
                . '<p><strong>Data:</strong><br>{data}</p>'
                . '<p><strong>Horário:</strong><br>{horario}</p>'
                . '<p>Se precisar ajustar horário ou endereço, responda este e-mail ou fale conosco no WhatsApp.</p>'
                . '<p style="color:#64748b;font-size:13px">Equipe Auto Limpeza Pro — São José da Lapa e Vespasiano, MG</p>',
        ],
        'appointment_admin' => [
            'subject' => 'Novo atendimento solicitado',
            'body'    => '<p>Novo cliente realizou uma solicitação.</p>'
                . '<p><strong>Cliente:</strong><br>{nome}</p>'
                . '<p><strong>Serviço:</strong><br>{servico}</p>'
                . '<p><strong>Data:</strong><br>{data}</p>'
                . '<p><strong>Horário:</strong><br>{horario}</p>'
                . '<p><strong>Telefone:</strong><br>{telefone}</p>',
        ],
        'password_reset' => [
            'subject' => 'Redefinição de senha — Auto Limpeza Pro',
            'body'    => '<p>Olá <strong>{nome}</strong>,</p>'
                . '<p>Recebemos uma solicitação para redefinir sua senha de administrador.</p>'
                . '<p><a href="{link}" style="display:inline-block;background:#1FB1F9;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold">Redefinir senha</a></p>'
                . '<p style="color:#64748b;font-size:13px">Este link expira em 1 hora. Se você não solicitou, ignore este e-mail.</p>',
        ],
        'mail_test' => [
            'subject' => 'Teste de e-mail — Auto Limpeza Pro',
            'body'    => '<p>Este é um e-mail de teste enviado pelo painel administrativo.</p>'
                . '<p>Se você recebeu esta mensagem, a configuração SMTP está funcionando corretamente.</p>'
                . '<p><strong>Data/hora:</strong> {data_hora}</p>',
        ],
    ];

    $tpl = $templates[$template] ?? ['subject' => 'Notificação', 'body' => ''];
    $subject = $tpl['subject'];
    $body    = $tpl['body'];
    foreach ($vars as $key => $val) {
        $subject = str_replace('{' . $key . '}', (string)$val, $subject);
        $safe    = ($key === 'link') ? (string)$val : htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8');
        $body    = str_replace('{' . $key . '}', $safe, $body);
    }
    return ['subject' => $subject, 'body' => mailWrapHtml($subject, $body)];
}

function getPushObservability(PDO $pdo): array {
    $configured = function_exists('webPushIsConfigured') && webPushIsConfigured($pdo);
    $subs = 0;
    $lastError = null;
    $lastSuccessAt = null;
    $lastErrorAt = null;
    try {
        if (function_exists('ensurePushSubscriptionsTable')) {
            ensurePushSubscriptionsTable($pdo);
            $subs = (int)$pdo->query('SELECT COUNT(*) FROM push_subscriptions WHERE enabled = 1')->fetchColumn();
        }
        $get = static function (string $key) use ($pdo): ?string {
            $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = ? LIMIT 1");
            $stmt->execute([$key]);
            $v = $stmt->fetchColumn();
            return $v !== false && $v !== null && $v !== '' ? (string)$v : null;
        };
        $lastError = $get('webpush_last_error');
        $lastSuccessAt = $get('webpush_last_success_at');
        $lastErrorAt = $get('webpush_last_error_at');
    } catch (Throwable $e) { /* */ }
    $cfg = function_exists('webPushConfig') ? webPushConfig($pdo) : ['subject' => '', 'public' => ''];
    return [
        'configured'      => $configured,
        'engine'          => 'webpush_vapid',
        'subscriptions'   => $subs,
        'subject'         => $cfg['subject'] ?? null,
        'lastSuccessAt'   => $lastSuccessAt,
        'lastErrorAt'     => $lastErrorAt,
        'lastError'       => $lastError,
        'circuitOpen'     => false,
        'circuitReason'   => null,
        'circuitOpenedAt' => null,
        'apiEndpoint'     => 'native-web-push',
    ];
}

/** Endpoint oficial REST API v2 — Web Push (documentação PushAlert 2026). */
function pushAlertApiEndpoint(): string {
    return pushAlertApiEndpoints()[0];
}

/** v2 primeiro; v1 legado como fallback em servidores com deploy antigo. */
function pushAlertApiEndpoints(): array {
    return [
        'https://api.pushalert.co/rest/v2/web-push/send',
        'https://api.pushalert.co/api/v1/send',
    ];
}

function pushAlertResetCircuit(PDO $pdo): void {
    mailConfigSet($pdo, 'pushalert_circuit_open', '0');
    mailConfigSet($pdo, 'pushalert_circuit_reason', '');
    mailConfigSet($pdo, 'pushalert_circuit_open_until', '');
    mailConfigSet($pdo, 'pushalert_last_error', '');
}

function pushAlertCircuitIsOpen(PDO $pdo): bool {
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'pushalert_circuit_open' LIMIT 1");
    $stmt->execute();
    if ((string)($stmt->fetchColumn() ?: '0') !== '1') {
        return false;
    }
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'pushalert_circuit_open_until' LIMIT 1");
    $stmt->execute();
    $until = $stmt->fetchColumn();
    if ($until && strtotime((string)$until) > 0 && time() >= strtotime((string)$until)) {
        mailConfigSet($pdo, 'pushalert_circuit_open', '0');
        mailConfigSet($pdo, 'pushalert_circuit_reason', '');
        return false;
    }
    return true;
}

function pushAlertTripCircuit(PDO $pdo, int $httpCode, string $reason): void {
    if (pushAlertCircuitIsOpen($pdo)) {
        return;
    }
    $now = dbNow();
    mailConfigSet($pdo, 'pushalert_circuit_open', '1');
    mailConfigSet($pdo, 'pushalert_circuit_reason', mb_substr($reason, 0, 500));
    mailConfigSet($pdo, 'pushalert_circuit_open_at', $now);
    mailConfigSet($pdo, 'pushalert_circuit_open_until', date('Y-m-d H:i:s', time() + 86400));
    mailConfigSet($pdo, 'pushalert_last_error_at', $now);
    mailConfigSet($pdo, 'pushalert_last_error', mb_substr("HTTP {$httpCode}: {$reason}", 0, 1000));

    if (function_exists('appLog')) {
        appLog('error', 'pushalert_circuit_open', [
            'code' => $httpCode,
            'reason' => $reason,
            'endpoint' => pushAlertApiEndpoint(),
        ]);
    }
    if (function_exists('systemLog')) {
        systemLog('pushalert', 'error', 'Circuit breaker aberto — PushAlert desativado temporariamente', [
            'http_code' => $httpCode,
            'reason' => $reason,
            'endpoint' => pushAlertApiEndpoint(),
        ]);
    }
    if (function_exists('createAdminNotification')) {
        try {
            createAdminNotification(
                $pdo,
                'system_alert',
                'PushAlert indisponível (HTTP ' . $httpCode . ')',
                'O canal PushAlert foi desativado automaticamente. Verifique a REST API Key e o endpoint em Comunicação → Push. Painel, e-mail e WhatsApp continuam ativos.',
                ['http_code' => $httpCode, 'endpoint' => pushAlertApiEndpoint()],
                ['priority' => 'high', 'action_url' => '/comunicacao-admin']
            );
        } catch (Throwable $e) {
            // não bloquear fluxo
        }
    }
}

function pushAlertShouldRetry(int $httpCode, ?string $curlError): bool {
    if ($curlError !== null && $curlError !== '') {
        return true;
    }
    return in_array($httpCode, [500, 502, 503, 504], true);
}

function pushAlertIsFatalHttp(int $httpCode): bool {
    return in_array($httpCode, [400, 401, 402, 403, 404], true);
}

/**
 * Envio HTTP PushAlert REST v2 (form-urlencoded, conforme documentação oficial).
 * Retry apenas em 5xx/timeout. Fallback v1 em 404. Circuit breaker só após esgotar endpoints.
 */
function pushAlertHttpSend(string $apiKey, string $title, string $message, string $url, ?PDO $pdo = null): array {
    $started  = microtime(true);
    $requestId = uniqid('pa_', true);

    $postFields = http_build_query([
        'title'   => mb_substr(trim($title), 0, 64),
        'message' => mb_substr(trim($message), 0, 192),
        'url'     => $url !== '' ? $url : (defined('SITE_URL') ? SITE_URL . '/' : 'https://autolimpezapro.com.br/'),
    ]);

    $headers = [
        'Authorization: api_key=' . trim($apiKey),
        'Accept: application/json',
    ];

    $maxAttempts = 3;
    $last = ['ok' => false, 'code' => 0, 'body' => '', 'err' => null, 'request_id' => $requestId, 'url' => pushAlertApiEndpoint(), 'method' => 'POST'];
    $endpoints = pushAlertApiEndpoints();
    $endpointIndex = 0;

    for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
        if (!function_exists('curl_init')) {
            $last['err'] = 'cURL não disponível no servidor';
            break;
        }

        $endpoint = $endpoints[$endpointIndex] ?? $endpoints[0];

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $postFields,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch) ?: null;
        curl_close($ch);

        $last = [
            'ok'         => !$err && $code >= 200 && $code < 300,
            'code'       => $code,
            'body'       => is_string($body) ? $body : '',
            'err'        => $err,
            'request_id' => $requestId,
            'url'        => $endpoint,
            'method'     => 'POST',
            'attempt'    => $attempt,
            'duration_ms'=> (int) round((microtime(true) - $started) * 1000),
        ];

        if ($last['ok']) {
            if ($pdo instanceof PDO) {
                pushAlertResetCircuit($pdo);
            }
            if (function_exists('systemLog')) {
                systemLog('pushalert', 'info', 'Push enviado com sucesso', [
                    'request_id' => $requestId,
                    'http_code' => $code,
                    'duration_ms' => $last['duration_ms'],
                    'endpoint' => $endpoint,
                ]);
            }
            return $last;
        }

        if (function_exists('systemLog')) {
            systemLog('pushalert', 'warning', 'PushAlert tentativa falhou', [
                'request_id' => $requestId,
                'attempt' => $attempt,
                'http_code' => $code,
                'curl_error' => $err,
                'endpoint' => $endpoint,
                'payload_keys' => ['title', 'message', 'url'],
                'response_preview' => mb_substr($last['body'], 0, 300),
            ]);
        }

        if ($code === 404 && $endpointIndex < count($endpoints) - 1) {
            $endpointIndex++;
            continue;
        }

        if ($code === 404 && $pdo instanceof PDO && $endpointIndex >= count($endpoints) - 1) {
            pushAlertTripCircuit($pdo, $code, 'Endpoints v2 e v1 retornaram 404. Verifique REST API Key.');
            break;
        }
        if (pushAlertIsFatalHttp($code) && $pdo instanceof PDO && in_array($code, [401, 402, 403], true)) {
            pushAlertTripCircuit($pdo, $code, 'Autenticação PushAlert recusada (HTTP ' . $code . ')');
            break;
        }
        if (!pushAlertShouldRetry($code, $err) || $attempt >= $maxAttempts) {
            break;
        }
        usleep(500000 * $attempt);
    }

    if (function_exists('appLogRateLimited')) {
        appLogRateLimited('warn', 'pushalert_failed', [
            'code' => $last['code'],
            'err' => $last['err'],
            'body' => mb_substr($last['body'], 0, 300),
            'request_id' => $requestId,
            'endpoint' => $last['url'] ?? pushAlertApiEndpoint(),
            'attempts' => $last['attempt'] ?? 1,
        ], 900);
    } elseif (function_exists('appLog')) {
        appLog('warn', 'pushalert_failed', [
            'code' => $last['code'],
            'err' => $last['err'],
            'body' => mb_substr($last['body'], 0, 300),
            'request_id' => $requestId,
            'endpoint' => $last['url'] ?? pushAlertApiEndpoint(),
            'attempts' => $last['attempt'] ?? 1,
        ]);
    }

    return $last;
}

/** @deprecated Use testWebPushConnection — PushAlert removido */
function testPushAlertConnection(PDO $pdo): array {
    if (function_exists('testWebPushConnection')) {
        return testWebPushConnection($pdo);
    }
    return ['ok' => false, 'error' => 'Web Push VAPID não disponível'];
}

/**
 * Alias legado — redireciona para Notification Engine (Web Push VAPID).
 * @deprecated Use sendWebPushIfConfigured
 */
function sendPushAlertIfConfigured(PDO $pdo, string $title, string $message, ?string $url = null): bool {
    if (!function_exists('sendWebPushIfConfigured') || !function_exists('webPushIsConfigured')) {
        return false;
    }
    if (!webPushIsConfigured($pdo)) {
        return false;
    }
    $url = $url ?? (defined('SITE_URL') ? SITE_URL . '/comunicacao-admin' : '/comunicacao-admin');
    $res = sendWebPushIfConfigured($pdo, $title, $message, $url, ['urgency' => 'normal']);
    return ($res['sent'] ?? 0) > 0;
}

// ── Handlers API ──────────────────────────────────────────────────────────

function handleComunicacaoSettings(string $method): void {
    $pdo = db();
    requireAdmin();

    if ($method === 'GET') {
        jsonRespond([
            'smtp'     => getSmtpConfigPublic($pdo),
            'channels' => getNotificationChannels($pdo),
            'mail'     => getMailObservability($pdo),
            'push'     => getPushObservability($pdo),
            'slack'    => function_exists('slackGetConfigPublic') ? slackGetConfigPublic($pdo) : null,
        ]);
    }

    if ($method === 'PUT' || $method === 'POST') {
        $b = jsonBody();
        $result = [
            'smtp' => getSmtpConfigPublic($pdo),
            'channels' => getNotificationChannels($pdo),
            'slack' => function_exists('slackGetConfigPublic') ? slackGetConfigPublic($pdo) : null,
        ];

        if (isset($b['smtp']) && is_array($b['smtp'])) {
            $newPassword = isset($b['smtp']['password']) && $b['smtp']['password'] !== ''
                ? trim((string)$b['smtp']['password'])
                : null;
            unset($b['smtp']['password']);
            try {
                $result['smtp'] = saveSmtpConfig($pdo, $b['smtp'], $newPassword);
            } catch (RuntimeException $e) {
                jsonRespond(['error' => $e->getMessage()], 400);
            }
            if ($newPassword !== null || !empty($b['smtp_test'])) {
                $test = testSmtpConnection($pdo);
                $result['smtp_test'] = $test;
                if (!$test['ok']) {
                    $result['smtp_warning'] = $test['error'];
                }
            }
        }

        if (isset($b['channels']) && is_array($b['channels'])) {
            $result['channels'] = saveNotificationChannels($pdo, $b['channels']);
        }

        if (isset($b['slack']) && is_array($b['slack']) && function_exists('slackSaveConfig')) {
            try {
                $result['slack'] = slackSaveConfig($pdo, $b['slack']);
            } catch (RuntimeException $e) {
                jsonRespond(['error' => $e->getMessage()], 400);
            }
            if (!empty($b['slack_test']) && function_exists('slackTestConnection')) {
                $result['slack_test'] = slackTestConnection($pdo);
            }
        }

        jsonRespond($result);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleNotificationsSlack(string $method): void {
    $pdo = db();
    requireAdmin();
    if (!function_exists('slackGetConfigPublic')) {
        require_once __DIR__ . '/slack-service.php';
    }

    if ($method === 'GET') {
        jsonRespond(['ok' => true, 'slack' => slackGetConfigPublic($pdo)]);
    }

    if ($method === 'PUT' || $method === 'POST') {
        $b = jsonBody();
        try {
            $cfg = slackSaveConfig($pdo, is_array($b['slack'] ?? null) ? $b['slack'] : $b);
        } catch (RuntimeException $e) {
            jsonRespond(['error' => $e->getMessage()], 400);
        }
        jsonRespond(['ok' => true, 'slack' => $cfg]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleNotificationsSlackTest(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('slack_test', 8);
    $pdo = db();
    if (!function_exists('slackTestConnection')) {
        require_once __DIR__ . '/slack-service.php';
    }
    $test = slackTestConnection($pdo);
    if (empty($test['ok'])) {
        jsonRespond(['ok' => false, 'error' => $test['error'] ?? 'Falha no teste Slack', 'detail' => $test], 400);
    }
    jsonRespond(['ok' => true, 'message' => 'Mensagem de teste enviada ao Slack', 'detail' => $test]);
}

function handleMailSmtpTest(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('mail_smtp_test', 10);
    $pdo  = db();
    $test = testSmtpConnection($pdo);
    if (!$test['ok']) {
        mailConfigSet($pdo, 'smtp_last_error_at', dbNow());
        mailConfigSet($pdo, 'smtp_last_error', mb_substr((string)($test['error'] ?? 'Falha'), 0, 1000));
        jsonRespond(['ok' => false, 'error' => $test['error'] ?? 'Falha na autenticação SMTP'], 400);
    }
    mailConfigSet($pdo, 'smtp_last_success_at', dbNow());
    mailConfigSet($pdo, 'smtp_last_error', '');
    $cfg = getSmtpConfigRow($pdo);
    jsonRespond([
        'ok' => true,
        'message' => 'Autenticação SMTP OK',
        'smtp_user' => $cfg['smtp_user'],
        'from_email' => $cfg['from_email'],
    ]);
}

function handleMailTest(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('mail_test', 5);

    $b   = jsonBody();
    $pdo = db();
    $cfg = getSmtpConfigRow($pdo);
    $to  = san($b['to'] ?? null, 255) ?: ($cfg['admin_email'] ?: $cfg['from_email']);

    $mail = renderMailTemplate('mail_test', ['data_hora' => date('d/m/Y H:i:s')]);
    $res  = sendMailMessage($to, $mail['subject'], $mail['body']);

    if (!$res['ok']) {
        jsonRespond(['error' => $res['error'] ?? 'Falha ao enviar', 'from_email' => $cfg['from_email']], 500);
    }
    jsonRespond(['ok' => true, 'to' => $to, 'from_email' => $cfg['from_email'], 'smtp_user' => $cfg['smtp_user']]);
}

function ensurePasswordResetTable(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `admin_password_resets` (
        `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id`    INT UNSIGNED NOT NULL,
        `token_hash` VARCHAR(64)  NOT NULL,
        `expires_at` DATETIME     NOT NULL,
        `used_at`    DATETIME     DEFAULT NULL,
        `created_at` DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_token` (`token_hash`),
        INDEX `idx_user`  (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function handleAdminForgotPassword(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('admin_forgot_pw', 5);

    $b     = jsonBody();
    $email = strtolower(trim(san($b['email'] ?? '', 255) ?? ''));
    if ($email === '' || !isEmail($email)) {
        jsonRespond(['error' => 'Informe um e-mail válido'], 400);
    }

    // Resposta genérica (não revela se o e-mail existe)
    $generic = ['ok' => true, 'message' => 'Se o e-mail estiver cadastrado, você receberá um link de recuperação.'];

    try {
        $stmt = db()->prepare('SELECT id, name, email FROM admin_users WHERE email = ? AND active = 1 LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
    } catch (PDOException $e) {
        jsonRespond($generic);
    }

    if (!$user || !isChannelEnabled(db(), 'password_reset', 'email')) {
        jsonRespond($generic);
    }

    $pdo   = db();
    $token = generateToken(32);
    $hash  = hash('sha256', $token);
    $now   = dbNow();
    $exp   = date('Y-m-d H:i:s', strtotime('+1 hour'));

    ensurePasswordResetTable($pdo);
    $pdo->prepare('DELETE FROM admin_password_resets WHERE user_id = ? AND used_at IS NULL')->execute([$user['id']]);
    $pdo->prepare('INSERT INTO admin_password_resets (user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, ?)')
        ->execute([$user['id'], $hash, $exp, $now]);

    $baseUrl = defined('SITE_URL') ? SITE_URL : 'https://autolimpezapro.com.br';
    $link    = $baseUrl . '/admin?reset=' . urlencode($token);

    $mail = renderMailTemplate('password_reset', [
        'nome' => $user['name'],
        'link' => $link,
    ]);

    sendMailMessage($user['email'], $mail['subject'], $mail['body']);
    appLog('info', 'admin_forgot_password', ['user_id' => $user['id']]);

    jsonRespond($generic);
}

function handleAdminResetPassword(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('admin_reset_pw', 5);

    $b           = jsonBody();
    $token       = trim((string)($b['token'] ?? ''));
    $newPassword = (string)($b['newPassword'] ?? '');

    if ($token === '' || strlen($newPassword) < 8) {
        jsonRespond(['error' => 'Token inválido ou senha muito curta (mín. 8 caracteres)'], 400);
    }

    $pdo  = db();
    ensurePasswordResetTable($pdo);
    $hash = hash('sha256', $token);

    $stmt = $pdo->prepare(
        'SELECT r.id, r.user_id FROM admin_password_resets r
         WHERE r.token_hash = ? AND r.used_at IS NULL AND r.expires_at > NOW() LIMIT 1'
    );
    $stmt->execute([$hash]);
    $reset = $stmt->fetch();
    if (!$reset) {
        jsonRespond(['error' => 'Link expirado ou inválido. Solicite um novo.'], 400);
    }

    $passHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $now      = dbNow();
    $pdo->prepare('UPDATE admin_users SET password_hash = ?, must_change_password = 0, updated_at = ? WHERE id = ?')
        ->execute([$passHash, $now, $reset['user_id']]);
    $pdo->prepare('UPDATE admin_password_resets SET used_at = ? WHERE id = ?')->execute([$now, $reset['id']]);
    try {
        $pdo->prepare('DELETE FROM admin_sessions WHERE user_id = ?')->execute([(int)$reset['user_id']]);
    } catch (Throwable $e) { /* ignore */ }

    appLog('info', 'admin_reset_password', ['user_id' => $reset['user_id']]);
    jsonRespond(['ok' => true]);
}
