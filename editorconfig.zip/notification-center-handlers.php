<?php
/**
 * API — Central Híbrida de Notificações
 */

function handleNotificationCenterDashboard(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    jsonRespond(NotificationCenter::getDashboard(db()));
}

function handleNotificationCenterHealth(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    jsonRespond([
        'health'      => NotificationCenter::getSystemHealth(db()),
        'suggestions' => NotificationCenter::getCapitaoSuggestions(db()),
        'variables'   => NotificationCenter::standardVariables(),
    ]);
}

function handleNotificationCenterQueue(string $method): void {
    requireAdmin();
    $pdo = db();
    NotificationCenter::ensureTables($pdo);

    if ($method === 'GET') {
        $status = san($_GET['status'] ?? null, 20);
        $sql = 'SELECT id, uuid, cliente_id, tipo, canal, status, prioridade, tentativas, erro, created_at, updated_at, sent_at FROM notification_queue';
        if ($status) {
            $stmt = $pdo->prepare($sql . ' WHERE status = ? ORDER BY id DESC LIMIT 100');
            $stmt->execute([$status]);
        } else {
            $stmt = $pdo->query($sql . ' ORDER BY id DESC LIMIT 100');
        }
        jsonRespond(['items' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($method === 'POST') {
        rateLimit('nc_queue_process', 10);
        $limit = min(50, max(1, sanInt(jsonBody()['limit'] ?? 25)));
        $processed = NotificationCenter::processQueue($pdo, $limit);
        jsonRespond(['ok' => true, 'processed' => $processed]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleNotificationCenterTemplates(string $method): void {
    requireAdmin();
    $pdo = db();
    NotificationCenter::ensureTables($pdo);

    if ($method === 'GET') {
        // Preferir ?op= — ?action= colide com a rota da API
        $action = san($_GET['op'] ?? $_GET['sub'] ?? $_GET['action'] ?? 'list', 20) ?? 'list';
        // Se action veio como nome da rota (ex.: notification/templates), tratar como list
        if (strpos((string)$action, '/') !== false) {
            $action = 'list';
        }
        $id = sanInt($_GET['id'] ?? 0);

        if ($action === 'preview') {
            $slug = san($_GET['slug'] ?? '', 80);
            $vars = [];
            if (!empty($_GET['vars'])) {
                $decoded = json_decode((string)$_GET['vars'], true);
                if (is_array($decoded)) $vars = $decoded;
            }
            jsonRespond(NotificationCenter::previewTemplate($pdo, $slug, $vars));
        }

        if ($action === 'versions' && $id > 0) {
            jsonRespond(['items' => NotificationCenter::listTemplateVersions($pdo, $id)]);
        }

        $q = san($_GET['q'] ?? null, 100);
        $category = san($_GET['category'] ?? null, 80);
        $sql = 'SELECT id, slug, name, channel, category, subject, body_text, body_html, enabled, version, updated_at FROM notification_templates WHERE 1=1';
        $params = [];
        if ($q) {
            $sql .= ' AND (name LIKE ? OR slug LIKE ? OR body_text LIKE ?)';
            $like = '%' . $q . '%';
            $params = [$like, $like, $like];
        }
        if ($category) {
            $sql .= ' AND category = ?';
            $params[] = $category;
        }
        $sql .= ' ORDER BY category, name';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        jsonRespond([
            'items'      => $stmt->fetchAll(PDO::FETCH_ASSOC),
            'categories' => $pdo->query("SELECT DISTINCT category FROM notification_templates ORDER BY category")->fetchAll(PDO::FETCH_COLUMN),
            'variables'  => NotificationCenter::standardVariables(),
        ]);
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $action = san($b['action'] ?? 'update', 20);

        if ($action === 'duplicate') {
            $id = sanInt($b['id'] ?? 0);
            if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
            $copy = NotificationCenter::duplicateTemplate($pdo, $id);
            if (!$copy) jsonRespond(['error' => 'Template não encontrado'], 404);
            jsonRespond(['ok' => true, 'template' => $copy]);
        }

        if ($action === 'preview') {
            $slug = san($b['slug'] ?? '', 80);
            $vars = is_array($b['vars'] ?? null) ? $b['vars'] : [];
            jsonRespond(NotificationCenter::previewTemplate($pdo, $slug, $vars));
        }

        if ($action === 'update') {
            notificationCenterUpdateTemplate($pdo, $b);
        }
    }

    if ($method === 'PUT') {
        notificationCenterUpdateTemplate($pdo, jsonBody());
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function notificationCenterUpdateTemplate(PDO $pdo, array $b): void {
    $id = sanInt($b['id'] ?? 0);
    if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);

    NotificationCenter::saveTemplateVersion($pdo, $id, 'admin');

    $fields = [];
    $params = [];
    foreach (['name', 'subject', 'body_text', 'body_html', 'category'] as $col) {
        if (array_key_exists($col, $b)) {
            $fields[] = "{$col} = ?";
            $params[] = san($b[$col], in_array($col, ['body_html', 'body_text'], true) ? 10000 : 500);
        }
    }
    if (array_key_exists('enabled', $b)) {
        $fields[] = 'enabled = ?';
        $params[] = !empty($b['enabled']) ? 1 : 0;
    }
    if (!$fields) jsonRespond(['error' => 'Nada para atualizar'], 400);
    $fields[] = 'version = version + 1';
    $fields[] = 'updated_at = ?';
    $params[] = dbNow();
    $params[] = $id;
    $pdo->prepare('UPDATE notification_templates SET ' . implode(', ', $fields) . ' WHERE id = ?')->execute($params);
    jsonRespond(['ok' => true]);
}

function handleNotificationCenterRetry(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('nc_retry', 10);
    $b = jsonBody();
    $uuid = san($b['uuid'] ?? null, 32);
    if (!$uuid) jsonRespond(['error' => 'uuid obrigatório'], 400);
    $pdo = db();
    $pdo->prepare("UPDATE notification_queue SET status = ?, tentativas = 0, erro = NULL, updated_at = ? WHERE uuid = ?")
        ->execute([NotificationCenter::STATUS_RETRIED, dbNow(), $uuid]);
    jsonRespond(['ok' => true]);
}

function processNotificationCenterQueue(PDO $pdo, int $limit = 25): array {
    NotificationCenter::ensureTables($pdo);
    return NotificationCenter::processQueue($pdo, $limit);
}

function processNotificationCenterCleanup(PDO $pdo): int {
    return NotificationCenter::cleanup($pdo, 90);
}
