<?php
/**
 * Communication Hub — Provider Registry.
 *
 * Providers plugáveis que ADAPTAM (sem reimplementar) os canais existentes:
 *  - internal  → createAdminNotification / createClientNotification
 *  - push      → Web Push VAPID (sendWebPushIfConfigured)
 *  - email     → Titan SMTP (sendMailMessage / mailWrapHtml)
 *  - whatsapp  → Evolution API (crmTrySendEvolutionTextDetailed) + fallback wa.me
 *  - sms       → estrutura pronta, desabilitado (sem credencial fictícia)
 *  - webhook   → estrutura pronta, desabilitado por padrão
 *
 * Nenhuma credencial é lida diretamente aqui — apenas via helpers existentes.
 */

interface CommunicationProvider {
    /** Identificador do canal (push, email, whatsapp, internal, sms, webhook). */
    public function key(): string;

    /** Nome amigável exibido no painel. */
    public function label(): string;

    /** Provider está configurado e pronto para envio? */
    public function isConfigured(PDO $pdo): bool;

    /** Provider está habilitado (pode estar configurado e desativado)? */
    public function isEnabled(PDO $pdo): bool;

    /**
     * Envia uma mensagem.
     * @param array $message title, body, url, meta, opts
     * @return array{ok:bool, detail?:string}
     */
    public function send(PDO $pdo, array $message): array;

    /** Estado de saúde resumido (status green|yellow|red + mensagem, sem segredos). */
    public function health(PDO $pdo): array;
}

// ── Providers concretos ─────────────────────────────────────────────────────

class InternalProvider implements CommunicationProvider {
    public function key(): string { return 'internal'; }
    public function label(): string { return 'Painel interno'; }
    public function isConfigured(PDO $pdo): bool { return function_exists('createAdminNotification'); }
    public function isEnabled(PDO $pdo): bool { return $this->isConfigured($pdo); }

    public function send(PDO $pdo, array $message): array {
        if (!function_exists('createAdminNotification')) return ['ok' => false, 'detail' => 'createAdminNotification indisponível'];
        $meta = is_array($message['meta'] ?? null) ? $message['meta'] : [];
        $opts = is_array($message['opts'] ?? null) ? $message['opts'] : [];
        $id = createAdminNotification($pdo, (string)($message['type'] ?? 'system_alert'), (string)($message['title'] ?? ''), (string)($message['body'] ?? ''), $meta, $opts);
        return ['ok' => $id > 0, 'detail' => $id > 0 ? "notification_id={$id}" : 'insert falhou'];
    }

    public function health(PDO $pdo): array {
        return ['status' => 'green', 'message' => 'Inbox interno ativo'];
    }
}

class PushProvider implements CommunicationProvider {
    public function key(): string { return 'push'; }
    public function label(): string { return 'Web Push (VAPID)'; }
    public function isConfigured(PDO $pdo): bool {
        return function_exists('webPushIsConfigured') && webPushIsConfigured($pdo);
    }
    public function isEnabled(PDO $pdo): bool { return $this->isConfigured($pdo); }

    public function send(PDO $pdo, array $message): array {
        if (!$this->isConfigured($pdo)) return ['ok' => false, 'detail' => 'VAPID não configurado'];
        $opts = is_array($message['opts'] ?? null) ? $message['opts'] : [];
        $result = sendWebPushIfConfigured($pdo, (string)($message['title'] ?? ''), (string)($message['body'] ?? ''), $message['url'] ?? null, $opts);
        $sent = (int)($result['sent'] ?? 0);
        return ['ok' => $sent > 0, 'detail' => "sent={$sent} failed=" . (int)($result['failed'] ?? 0) . " total=" . (int)($result['total'] ?? 0)];
    }

    public function health(PDO $pdo): array {
        if (!$this->isConfigured($pdo)) {
            return ['status' => 'red', 'message' => 'VAPID não configurado'];
        }
        $count = 0;
        try {
            ensurePushSubscriptionsTable($pdo);
            $count = (int)$pdo->query('SELECT COUNT(*) FROM push_subscriptions WHERE enabled = 1')->fetchColumn();
        } catch (Throwable $e) { /* */ }
        return ['status' => $count > 0 ? 'green' : 'yellow', 'message' => "VAPID OK — {$count} assinatura(s)"];
    }
}

class EmailProvider implements CommunicationProvider {
    public function key(): string { return 'email'; }
    public function label(): string { return 'E-mail (Titan SMTP)'; }
    public function isConfigured(PDO $pdo): bool {
        if (!function_exists('getSmtpConfigRow') || !function_exists('isSmtpPasswordConfigured')) return false;
        try {
            $cfg = getSmtpConfigRow($pdo);
            return (bool)($cfg['enabled'] ?? false) && isSmtpPasswordConfigured($pdo);
        } catch (Throwable $e) {
            return false;
        }
    }
    public function isEnabled(PDO $pdo): bool { return $this->isConfigured($pdo); }

    public function send(PDO $pdo, array $message): array {
        if (!function_exists('sendMailMessage')) return ['ok' => false, 'detail' => 'sendMailMessage indisponível'];
        $to = (string)($message['to'] ?? '');
        if ($to === '' && function_exists('getSmtpConfigRow')) {
            $cfg = getSmtpConfigRow($pdo);
            $to = (string)($cfg['admin_email'] ?: $cfg['from_email']);
        }
        if ($to === '' || !isEmail($to)) return ['ok' => false, 'detail' => 'destinatário inválido'];
        $title = (string)($message['title'] ?? '');
        $body  = (string)($message['body'] ?? '');
        $html = function_exists('mailWrapHtml')
            ? mailWrapHtml($title, '<p>' . nl2br(htmlspecialchars($body, ENT_QUOTES, 'UTF-8')) . '</p>')
            : $body;
        $res = sendMailMessage($to, $title, $html);
        return ['ok' => !empty($res['ok']), 'detail' => $res['error'] ?? null];
    }

    public function health(PDO $pdo): array {
        if (!$this->isConfigured($pdo)) return ['status' => 'red', 'message' => 'SMTP não configurado ou senha ausente'];
        $err = null;
        try {
            $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'smtp_last_error' LIMIT 1");
            $stmt->execute();
            $err = $stmt->fetchColumn() ?: null;
        } catch (Throwable $e) { /* */ }
        return $err
            ? ['status' => 'yellow', 'message' => 'SMTP configurado — último erro: ' . mb_substr((string)$err, 0, 120)]
            : ['status' => 'green', 'message' => 'SMTP Titan configurado'];
    }
}

class WhatsAppProvider implements CommunicationProvider {
    public function key(): string { return 'whatsapp'; }
    public function label(): string { return 'WhatsApp (Evolution API)'; }

    public function isConfigured(PDO $pdo): bool {
        try {
            if (function_exists('ensureCrmTables')) ensureCrmTables($pdo);
            $cfg = $pdo->query("SELECT evolution_url, evolution_api_key, evolution_api_key_enc FROM crm_whatsapp_config WHERE id = 1")->fetch();
            return $cfg && !empty($cfg['evolution_url']) && function_exists('crmGetEvolutionApiKey') && crmGetEvolutionApiKey($cfg) !== '';
        } catch (Throwable $e) {
            return false;
        }
    }
    public function isEnabled(PDO $pdo): bool {
        // wa.me manual continua disponível mesmo sem Evolution
        return $this->isConfigured($pdo) || function_exists('crmWaMeLink');
    }

    public function send(PDO $pdo, array $message): array {
        $phone = (string)($message['phone'] ?? ($message['opts']['phone'] ?? ''));
        if ($phone === '') return ['ok' => false, 'detail' => 'telefone ausente'];
        $body = (string)($message['body'] ?? '');

        if (function_exists('crmTrySendEvolutionTextDetailed')) {
            if (function_exists('ensureCrmTables')) ensureCrmTables($pdo);
            $result = crmTrySendEvolutionTextDetailed($pdo, $phone, $body);
            if (!empty($result['sent'])) return ['ok' => true, 'detail' => 'evolution'];
            $err = (string)($result['error'] ?? 'Evolution não enviou');
            $waUrl = function_exists('crmWaMeLink') ? crmWaMeLink($phone, $body) : null;
            if (function_exists('appLog')) {
                appLog('warn', 'whatsapp_provider_failed', [
                    'phone' => $phone,
                    'error' => $err,
                    'wa_me_fallback' => $waUrl ?: null,
                ]);
            }
            return [
                'ok' => false,
                'detail' => $waUrl
                    ? $err . ' — fallback wa.me: ' . $waUrl
                    : $err,
            ];
        }
        $waUrl = function_exists('crmWaMeLink') ? crmWaMeLink($phone, $body) : null;
        return ['ok' => false, 'detail' => $waUrl ? 'fallback wa.me disponível: ' . $waUrl : 'Evolution indisponível'];
    }

    public function health(PDO $pdo): array {
        try {
            if (function_exists('ensureCrmTables')) ensureCrmTables($pdo);
            $cfg = $pdo->query("SELECT * FROM crm_whatsapp_config WHERE id = 1")->fetch();
            if ($cfg && !empty($cfg['evolution_url']) && function_exists('crmGetEvolutionApiKey') && crmGetEvolutionApiKey($cfg) !== '') {
                $conn = $cfg['connection_status'] ?? 'disconnected';
                $status = $conn === 'open' ? 'green' : ($conn === 'connecting' ? 'yellow' : 'red');
                return ['status' => $status, 'message' => 'Evolution: ' . $conn];
            }
        } catch (Throwable $e) { /* */ }
        return ['status' => 'yellow', 'message' => 'Evolution não configurado — links wa.me ativos'];
    }
}

class TelegramProvider implements CommunicationProvider {
    public function key(): string { return 'telegram'; }
    public function label(): string { return 'Telegram Bot'; }

    public function isConfigured(PDO $pdo): bool {
        return function_exists('telegramIsConfigured') && telegramIsConfigured($pdo);
    }
    public function isEnabled(PDO $pdo): bool {
        return function_exists('telegramIsEnabled') && telegramIsEnabled($pdo);
    }

    public function send(PDO $pdo, array $message): array {
        if (!function_exists('telegramSendMessage')) {
            return ['ok' => false, 'detail' => 'telegram-service indisponível'];
        }
        $opts = is_array($message['opts'] ?? null) ? $message['opts'] : [];
        $chatId = (string)($message['chat_id'] ?? ($opts['telegram_chat_id'] ?? ''));
        if ($chatId === '' && function_exists('telegramEnrichOpts')) {
            $opts = telegramEnrichOpts($pdo, $opts, is_array($message['meta'] ?? null) ? $message['meta'] : []);
            $chatId = (string)($opts['telegram_chat_id'] ?? '');
        }
        if ($chatId === '') return ['ok' => false, 'detail' => 'telegram_chat_id ausente'];
        $body = (string)($message['body'] ?? '');
        $result = telegramSendMessage($pdo, $chatId, $body);
        return ['ok' => !empty($result['sent']), 'detail' => $result['error'] ?? ($result['message_id'] ? 'message_id=' . $result['message_id'] : null)];
    }

    public function health(PDO $pdo): array {
        if (!function_exists('telegramMapStatus')) {
            return ['status' => 'yellow', 'message' => 'Telegram service não carregado'];
        }
        try {
            if (function_exists('ensureTelegramTables')) ensureTelegramTables($pdo);
            $st = telegramMapStatus($pdo);
            if (empty($st['configured'])) {
                return ['status' => 'yellow', 'message' => 'Bot Token não configurado'];
            }
            $conn = $st['connectionStatus'] ?? 'disconnected';
            $status = $conn === 'open' ? 'green' : 'yellow';
            $user = $st['botUsername'] ? '@' . $st['botUsername'] : 'sem username';
            $msg = ($st['enabled'] ? 'Ativo' : 'Configurado (desligado)') . " — {$user}";
            if (!empty($st['lastError'])) $msg .= ' · ' . mb_substr((string)$st['lastError'], 0, 80);
            return ['status' => $status, 'message' => $msg];
        } catch (Throwable $e) {
            return ['status' => 'red', 'message' => $e->getMessage()];
        }
    }
}

class SlackProvider implements CommunicationProvider {
    public function key(): string { return 'slack'; }
    public function label(): string { return 'Slack (Webhook / Bot)'; }

    public function isConfigured(PDO $pdo): bool {
        return function_exists('slackIsConfigured') && slackIsConfigured($pdo);
    }
    public function isEnabled(PDO $pdo): bool {
        return function_exists('slackIsEnabled') && slackIsEnabled($pdo);
    }

    public function send(PDO $pdo, array $message): array {
        if (!function_exists('slackSendMessage')) {
            return ['ok' => false, 'detail' => 'slack-service indisponível'];
        }
        $title = (string)($message['title'] ?? '');
        $body = (string)($message['body'] ?? '');
        $meta = is_array($message['meta'] ?? null) ? $message['meta'] : [];
        $text = function_exists('slackFormatInternalAlert')
            ? slackFormatInternalAlert($title, $body, $meta, $message['url'] ?? null)
            : trim($title . "\n" . $body);
        $result = slackSendMessage($pdo, $text, [
            'force' => !empty($message['force']),
            'skip_rate_limit' => !empty($message['skip_rate_limit']),
            'fingerprint' => (string)($message['fingerprint'] ?? ('hub:' . md5($text))),
            'topic' => (string)($message['type'] ?? ''),
        ]);
        return [
            'ok' => !empty($result['sent']),
            'detail' => $result['error'] ?? ($result['skipped'] ?? ($result['sent'] ? 'ok' : 'falha')),
        ];
    }

    public function health(PDO $pdo): array {
        if (!function_exists('slackMapStatus')) {
            return ['status' => 'yellow', 'message' => 'Slack service não carregado'];
        }
        try {
            if (function_exists('ensureSlackTables')) ensureSlackTables($pdo);
            $st = slackMapStatus($pdo);
            if (empty($st['configured'])) {
                return ['status' => 'yellow', 'message' => 'Slack não configurado (webhook ou bot)'];
            }
            $conn = $st['connectionStatus'] ?? 'disconnected';
            $status = ($conn === 'open' && !empty($st['enabled'])) ? 'green' : 'yellow';
            if ($conn === 'error') $status = 'red';
            $msg = (!empty($st['enabled']) ? 'Ativo' : 'Configurado (desligado)');
            $label = trim(($st['workspace'] ?? '') . ' / ' . ($st['channel'] ?? ''), ' /');
            if ($label !== '') $msg .= ' — ' . $label;
            if (!empty($st['lastError'])) $msg .= ' · ' . mb_substr((string)$st['lastError'], 0, 80);
            return ['status' => $status, 'message' => $msg];
        } catch (Throwable $e) {
            return ['status' => 'red', 'message' => $e->getMessage()];
        }
    }
}

class SmsProvider implements CommunicationProvider {
    public function key(): string { return 'sms'; }
    public function label(): string { return 'SMS (futuro)'; }
    public function isConfigured(PDO $pdo): bool { return false; }
    public function isEnabled(PDO $pdo): bool { return false; }
    public function send(PDO $pdo, array $message): array {
        return ['ok' => false, 'detail' => 'SMS não configurado — estrutura preparada'];
    }
    public function health(PDO $pdo): array {
        return ['status' => 'yellow', 'message' => 'Desabilitado — aguardando provedor SMS'];
    }
}

class WebhookProvider implements CommunicationProvider {
    public function key(): string { return 'webhook'; }
    public function label(): string { return 'Webhook (futuro)'; }

    private function url(PDO $pdo): string {
        try {
            $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'communication_webhook_url' LIMIT 1");
            $stmt->execute();
            return trim((string)($stmt->fetchColumn() ?: ''));
        } catch (Throwable $e) {
            return '';
        }
    }

    public function isConfigured(PDO $pdo): bool { return $this->url($pdo) !== ''; }
    public function isEnabled(PDO $pdo): bool { return $this->isConfigured($pdo); }

    public function send(PDO $pdo, array $message): array {
        $url = $this->url($pdo);
        if ($url === '') return ['ok' => false, 'detail' => 'communication_webhook_url não configurada'];
        $payload = json_encode([
            'type'  => $message['type'] ?? 'notification',
            'title' => $message['title'] ?? '',
            'body'  => $message['body'] ?? '',
            'url'   => $message['url'] ?? null,
            'meta'  => $message['meta'] ?? [],
            'sentAt' => date('c'),
        ], JSON_UNESCAPED_UNICODE);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        return ['ok' => $code >= 200 && $code < 300, 'detail' => $err !== '' ? $err : "HTTP {$code}"];
    }

    public function health(PDO $pdo): array {
        return $this->isConfigured($pdo)
            ? ['status' => 'green', 'message' => 'Webhook configurado']
            : ['status' => 'yellow', 'message' => 'Desabilitado — defina communication_webhook_url'];
    }
}

// ── Registry ────────────────────────────────────────────────────────────────

class CommunicationProviderRegistry {
    /** @var CommunicationProvider[] */
    private static ?array $providers = null;

    /** @return CommunicationProvider[] indexados pela key */
    public static function all(): array {
        if (self::$providers === null) {
            self::$providers = [];
            foreach ([
                new InternalProvider(),
                new PushProvider(),
                new EmailProvider(),
                new WhatsAppProvider(),
                new TelegramProvider(),
                new SlackProvider(),
                new SmsProvider(),
                new WebhookProvider(),
            ] as $provider) {
                self::$providers[$provider->key()] = $provider;
            }
        }
        return self::$providers;
    }

    public static function get(string $key): ?CommunicationProvider {
        return self::all()[$key] ?? null;
    }

    /** Estado consolidado de todos os providers (para painel/Test Center). */
    public static function status(PDO $pdo): array {
        $out = [];
        foreach (self::all() as $key => $provider) {
            try {
                $health = $provider->health($pdo);
            } catch (Throwable $e) {
                $health = ['status' => 'red', 'message' => $e->getMessage()];
            }
            // Um provider com defeito não pode derrubar o painel inteiro (HTTP 500).
            try { $configured = $provider->isConfigured($pdo); } catch (Throwable $e) { $configured = false; }
            try { $enabled = $provider->isEnabled($pdo); } catch (Throwable $e) { $enabled = false; }
            $out[] = [
                'key'        => $key,
                'label'      => $provider->label(),
                'configured' => $configured,
                'enabled'    => $enabled,
                'health'     => $health,
            ];
        }
        return $out;
    }
}
