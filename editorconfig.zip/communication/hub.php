<?php
/**
 * Communication Hub — fundação e preservação.
 * Schema aditivo/idempotente + snapshot de saúde sem segredos.
 *
 * REGRAS:
 *  - Nunca renomear/apagar tabelas ou colunas existentes.
 *  - Nunca ler, gravar ou expor valores de credenciais (apenas flags "configurado").
 *  - Rotas legadas permanecem intactas; endpoints novos vivem sob communication/*.
 */

function ensureCommunicationHubTables(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;

    $sqlFile = __DIR__ . '/../migrations/communication_hub_v1.sql';
    if (is_file($sqlFile) && function_exists('alpRunSqlMigration')) {
        alpRunSqlMigration($pdo, $sqlFile);
        return;
    }

    // Fallback inline (mesmo conteúdo essencial da migração datada)
    foreach ([
        "CREATE TABLE IF NOT EXISTS `communication_events` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `event_key` VARCHAR(80) NOT NULL,
            `source` VARCHAR(80) DEFAULT NULL,
            `actor_type` VARCHAR(20) DEFAULT NULL,
            `actor_id` VARCHAR(64) DEFAULT NULL,
            `title` VARCHAR(200) DEFAULT NULL,
            `payload` JSON DEFAULT NULL,
            `uuid` VARCHAR(32) DEFAULT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'received',
            `listeners` INT NOT NULL DEFAULT 0,
            `is_test` TINYINT(1) NOT NULL DEFAULT 0,
            `error` TEXT DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_ce_key` (`event_key`, `created_at`),
            INDEX `idx_ce_uuid` (`uuid`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS `notification_queue_dlq` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `queue_id` INT UNSIGNED DEFAULT NULL,
            `uuid` VARCHAR(32) NOT NULL,
            `cliente_id` VARCHAR(64) DEFAULT NULL,
            `tipo` VARCHAR(80) NOT NULL,
            `canal` VARCHAR(30) NOT NULL DEFAULT 'multi',
            `tentativas` TINYINT NOT NULL DEFAULT 0,
            `payload` JSON NOT NULL,
            `erro` TEXT DEFAULT NULL,
            `moved_at` DATETIME NOT NULL,
            `reprocessed_at` DATETIME DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_dlq_uuid` (`uuid`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS `communication_ai_log` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `action` VARCHAR(40) NOT NULL,
            `channel` VARCHAR(30) DEFAULT NULL,
            `input_json` JSON DEFAULT NULL,
            `output_json` JSON DEFAULT NULL,
            `provider` VARCHAR(40) DEFAULT NULL,
            `duration_ms` INT DEFAULT NULL,
            `admin_email` VARCHAR(255) DEFAULT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'ok',
            `error` TEXT DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_cal_action` (`action`, `created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS `communication_captain_actions` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `action` VARCHAR(60) NOT NULL,
            `params_json` JSON DEFAULT NULL,
            `result_json` JSON DEFAULT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'ok',
            `requires_confirmation` TINYINT(1) NOT NULL DEFAULT 0,
            `confirmed_by` VARCHAR(255) DEFAULT NULL,
            `admin_email` VARCHAR(255) DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_cca_action` (`action`, `created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ] as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { /* já existe */ }
    }
    foreach ([
        "ALTER TABLE notification_queue ADD COLUMN next_retry_at DATETIME DEFAULT NULL",
        "ALTER TABLE notification_queue ADD COLUMN locked_by VARCHAR(64) DEFAULT NULL",
        "ALTER TABLE notification_queue ADD COLUMN locked_at DATETIME DEFAULT NULL",
        "ALTER TABLE notification_queue ADD COLUMN event_id BIGINT UNSIGNED DEFAULT NULL",
        "ALTER TABLE notification_queue ADD COLUMN canal_entregue VARCHAR(30) DEFAULT NULL",
        "ALTER TABLE notification_logs ADD COLUMN event_id BIGINT UNSIGNED DEFAULT NULL",
        "ALTER TABLE notification_campaigns ADD COLUMN channels JSON DEFAULT NULL",
        "ALTER TABLE notification_campaigns ADD COLUMN content_json JSON DEFAULT NULL",
        "ALTER TABLE notification_campaigns ADD COLUMN paused_at DATETIME DEFAULT NULL",
        "ALTER TABLE notification_campaigns ADD COLUMN duplicated_from INT UNSIGNED DEFAULT NULL",
        "ALTER TABLE notification_campaigns ADD COLUMN ai_generated TINYINT(1) NOT NULL DEFAULT 0",
    ] as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { /* coluna já existe */ }
    }
}

/**
 * Snapshot de preservação: contagens + flags de configuração, SEM segredos.
 * Executar antes/depois de cada fase da refatoração para validar integridade.
 */
function communicationHubSnapshot(PDO $pdo): array {
    ensureCommunicationHubTables($pdo);
    if (class_exists('NotificationCenter')) NotificationCenter::ensureTables($pdo);
    if (function_exists('ensureNotificationEngineTables')) ensureNotificationEngineTables($pdo);
    if (function_exists('ensureSystemNotificationsTable')) ensureSystemNotificationsTable($pdo);

    $count = function (string $sql) use ($pdo): int {
        try { return (int)$pdo->query($sql)->fetchColumn(); } catch (Throwable $e) { return -1; }
    };

    $queueByStatus = [];
    try {
        foreach ($pdo->query("SELECT status, COUNT(*) c FROM notification_queue GROUP BY status")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $queueByStatus[$r['status']] = (int)$r['c'];
        }
    } catch (Throwable $e) { /* */ }

    // Flags de configuração — apenas booleanos, nunca valores
    $smtpConfigured = false;
    if (function_exists('getSmtpConfigRow') && function_exists('isSmtpPasswordConfigured')) {
        try {
            $cfg = getSmtpConfigRow($pdo);
            $smtpConfigured = (bool)($cfg['enabled'] ?? false) && isSmtpPasswordConfigured($pdo);
        } catch (Throwable $e) { /* */ }
    }
    $evolutionConfigured = false;
    try {
        if (function_exists('ensureCrmTables')) {
            ensureCrmTables($pdo);
            $wa = $pdo->query("SELECT * FROM crm_whatsapp_config WHERE id = 1")->fetch();
            $evolutionConfigured = $wa && !empty($wa['evolution_url'])
                && function_exists('crmGetEvolutionApiKey') && crmGetEvolutionApiKey($wa) !== '';
        }
    } catch (Throwable $e) { /* */ }

    return [
        'generatedAt' => date('c'),
        'counts' => [
            'system_notifications'       => $count("SELECT COUNT(*) FROM system_notifications"),
            'client_notifications'       => $count("SELECT COUNT(*) FROM client_notifications"),
            'push_devices'               => $count("SELECT COUNT(*) FROM push_devices"),
            'push_subscriptions_active'  => $count("SELECT COUNT(*) FROM push_subscriptions WHERE enabled = 1"),
            'push_subscriptions_total'   => $count("SELECT COUNT(*) FROM push_subscriptions"),
            'notification_queue'         => $count("SELECT COUNT(*) FROM notification_queue"),
            'notification_queue_dlq'     => $count("SELECT COUNT(*) FROM notification_queue_dlq"),
            'notification_templates'     => $count("SELECT COUNT(*) FROM notification_templates"),
            'notification_template_versions' => $count("SELECT COUNT(*) FROM notification_template_versions"),
            'notification_logs_30d'      => $count("SELECT COUNT(*) FROM notification_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"),
            'notification_campaigns'     => $count("SELECT COUNT(*) FROM notification_campaigns"),
            'notification_engine_sends'  => $count("SELECT COUNT(*) FROM notification_engine_sends"),
            'notification_delivery_logs' => $count("SELECT COUNT(*) FROM notification_delivery_logs"),
            'communication_events'       => $count("SELECT COUNT(*) FROM communication_events"),
            'captain_automation_rules'   => $count("SELECT COUNT(*) FROM captain_automation_rules"),
            'captain_automation_log'     => $count("SELECT COUNT(*) FROM captain_automation_log"),
            'appointment_reminders_sent' => $count("SELECT COUNT(*) FROM appointment_reminders_sent"),
        ],
        'queueByStatus' => $queueByStatus,
        'configured' => [
            'smtp'      => $smtpConfigured,
            'webpush'   => function_exists('webPushIsConfigured') ? webPushIsConfigured($pdo) : false,
            'evolution' => $evolutionConfigured,
            'gemini'    => function_exists('aiConfigKey') ? (bool)aiConfigKey('gemini') : false,
            'cron'      => defined('CRON_SECRET') && CRON_SECRET !== '',
        ],
    ];
}

function handleCommunicationSnapshot(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    jsonRespond(communicationHubSnapshot(db()));
}
