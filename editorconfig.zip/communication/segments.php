<?php
/**
 * Communication Hub — SegmentResolver.
 *
 * Resolve segmentos para assinaturas Web Push (push_subscriptions) usando
 * SOMENTE dados reais existentes (appointments, clients, visitors, crm).
 * Compatível com os segmentos legados do Notification Engine
 * (all, admins, clients/clientes, leads) e adiciona os novos do Hub.
 */

/** Catálogo de segmentos disponíveis (para o painel). */
function communicationSegmentCatalog(): array {
    return [
        ['key' => 'all',            'label' => 'Todos os inscritos',            'params' => []],
        ['key' => 'admins',         'label' => 'Administradores',               'params' => []],
        ['key' => 'clients',        'label' => 'Clientes com conta',            'params' => []],
        ['key' => 'visitors',       'label' => 'Visitantes (sem conta)',        'params' => []],
        ['key' => 'city',           'label' => 'Por cidade',                    'params' => ['city']],
        ['key' => 'service',        'label' => 'Por serviço contratado',        'params' => ['service']],
        ['key' => 'active_90d',     'label' => 'Agendaram nos últimos 90 dias', 'params' => []],
        ['key' => 'inactive_180d',  'label' => 'Inativos há 180+ dias',         'params' => []],
        ['key' => 'first_purchase', 'label' => 'Primeira compra (1 serviço)',   'params' => []],
        ['key' => 'vip',            'label' => 'VIP (3+ serviços concluídos)',  'params' => []],
        ['key' => 'device',         'label' => 'Por dispositivo',               'params' => ['device']],
        ['key' => 'platform',       'label' => 'Por plataforma',                'params' => ['platform']],
        ['key' => 'language',       'label' => 'Por idioma',                    'params' => ['language']],
        ['key' => 'recent_seen',    'label' => 'Ativos no site (30 dias)',      'params' => []],
    ];
}

/**
 * Resolve um segmento em IDs de assinaturas push habilitadas.
 *
 * @return array{ids:int[], total:int, description:string}
 */
function communicationResolveSegment(PDO $pdo, string $segment, array $params = [], int $limit = 2000): array {
    ensurePushSubscriptionsTable($pdo);
    $limit = max(1, min(5000, $limit));
    $base = "SELECT s.id FROM push_subscriptions s WHERE s.enabled = 1";
    $bind = [];
    $desc = $segment;

    switch ($segment) {
        case 'all':
        case '':
            $sql = $base;
            $desc = 'Todos os inscritos ativos';
            break;

        case 'admins':
            $sql = $base . " AND s.owner_type = 'admin'";
            $desc = 'Administradores';
            break;

        case 'clients':
        case 'clientes':
            // Conta de cliente vinculada diretamente (client_id) ou via visitor_id
            $sql = $base . " AND (s.owner_type = 'client' OR s.client_id IS NOT NULL
                OR EXISTS (SELECT 1 FROM clients c WHERE c.visitor_id = s.owner_id AND c.active = 1))";
            $desc = 'Clientes com conta';
            break;

        case 'visitors':
        case 'leads':
            $sql = $base . " AND s.owner_type = 'visitor' AND s.client_id IS NULL
                AND NOT EXISTS (SELECT 1 FROM clients c WHERE c.visitor_id = s.owner_id)";
            $desc = 'Visitantes sem conta';
            break;

        case 'city':
            $city = trim((string)($params['city'] ?? ''));
            if ($city === '') return ['ids' => [], 'total' => 0, 'description' => 'Cidade não informada'];
            $sql = $base . " AND EXISTS (SELECT 1 FROM visitors v WHERE v.id = s.owner_id AND v.city LIKE ?)";
            $bind[] = '%' . $city . '%';
            $desc = "Cidade: {$city}";
            break;

        case 'service':
            $service = trim((string)($params['service'] ?? ''));
            if ($service === '') return ['ids' => [], 'total' => 0, 'description' => 'Serviço não informado'];
            $sql = $base . " AND EXISTS (SELECT 1 FROM appointments a WHERE a.visitor_id = s.owner_id AND a.services LIKE ?)";
            $bind[] = '%' . $service . '%';
            $desc = "Serviço: {$service}";
            break;

        case 'active_90d':
            $sql = $base . " AND EXISTS (SELECT 1 FROM appointments a WHERE a.visitor_id = s.owner_id
                AND a.date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY) AND a.status <> 'cancelled')";
            $desc = 'Com agendamento nos últimos 90 dias';
            break;

        case 'inactive_180d':
            $sql = $base . " AND EXISTS (SELECT 1 FROM appointments a WHERE a.visitor_id = s.owner_id)
                AND NOT EXISTS (SELECT 1 FROM appointments a2 WHERE a2.visitor_id = s.owner_id
                    AND a2.date >= DATE_SUB(CURDATE(), INTERVAL 180 DAY))";
            $desc = 'Inativos há 180+ dias (já foram clientes)';
            break;

        case 'first_purchase':
            $sql = $base . " AND (SELECT COUNT(*) FROM appointments a WHERE a.visitor_id = s.owner_id
                AND a.status = 'completed') = 1";
            $desc = 'Exatamente 1 serviço concluído';
            break;

        case 'vip':
            $sql = $base . " AND (SELECT COUNT(*) FROM appointments a WHERE a.visitor_id = s.owner_id
                AND a.status = 'completed') >= 3";
            $desc = 'VIP — 3+ serviços concluídos';
            break;

        case 'device':
            $device = trim((string)($params['device'] ?? ''));
            if ($device === '') return ['ids' => [], 'total' => 0, 'description' => 'Dispositivo não informado'];
            $sql = $base . " AND s.device = ?";
            $bind[] = $device;
            $desc = "Dispositivo: {$device}";
            break;

        case 'platform':
            $platform = trim((string)($params['platform'] ?? ''));
            if ($platform === '') return ['ids' => [], 'total' => 0, 'description' => 'Plataforma não informada'];
            $sql = $base . " AND s.platform = ?";
            $bind[] = $platform;
            $desc = "Plataforma: {$platform}";
            break;

        case 'language':
            $language = trim((string)($params['language'] ?? ''));
            if ($language === '') return ['ids' => [], 'total' => 0, 'description' => 'Idioma não informado'];
            $sql = $base . " AND s.language LIKE ?";
            $bind[] = $language . '%';
            $desc = "Idioma: {$language}";
            break;

        case 'recent_seen':
            $sql = $base . " AND s.last_seen >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            $desc = 'Vistos nos últimos 30 dias';
            break;

        default:
            // Segmento desconhecido → comportamento legado (todos), sem quebrar envios antigos
            $sql = $base;
            $desc = "Segmento '{$segment}' não reconhecido — usando todos";
            break;
    }

    try {
        $stmt = $pdo->prepare($sql . " ORDER BY s.updated_at DESC LIMIT {$limit}");
        $stmt->execute($bind);
        $ids = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('warn', 'segment_resolve_failed', ['segment' => $segment, 'err' => $e->getMessage()]);
        }
        $ids = [];
    }

    return ['ids' => $ids, 'total' => count($ids), 'description' => $desc];
}

/** Preview de alcance de um segmento (sem enviar nada). */
function communicationSegmentPreview(PDO $pdo, string $segment, array $params = []): array {
    $resolved = communicationResolveSegment($pdo, $segment, $params);
    return [
        'segment'     => $segment,
        'description' => $resolved['description'],
        'reach'       => $resolved['total'],
    ];
}
