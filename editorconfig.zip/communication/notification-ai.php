<?php
/**
 * Communication Hub — Notification AI.
 *
 * Geração de conteúdo de notificações/campanhas exclusivamente via AI Gateway
 * (aiGatewayGenerateText, módulo "notification_ai"). Gemini permanece o
 * provider prioritário com failover configurável no Gateway — nenhuma chave é
 * lida ou movida aqui. Toda chamada é auditada em communication_ai_log.
 */

/** Extrai o primeiro objeto JSON válido de uma resposta de LLM. */
function notificationAiParseJson(?string $text): ?array {
    if (!is_string($text) || trim($text) === '') return null;
    $text = trim($text);
    // Remove cercas markdown ```json ... ```
    $text = preg_replace('/^```(?:json)?\s*/i', '', $text);
    $text = preg_replace('/\s*```$/', '', (string)$text);
    $decoded = json_decode((string)$text, true);
    if (is_array($decoded)) return $decoded;
    // Fallback: primeiro bloco { ... }
    $start = strpos((string)$text, '{');
    $end = strrpos((string)$text, '}');
    if ($start !== false && $end !== false && $end > $start) {
        $decoded = json_decode(substr((string)$text, $start, $end - $start + 1), true);
        if (is_array($decoded)) return $decoded;
    }
    return null;
}

function notificationAiLog(PDO $pdo, string $action, ?string $channel, array $input, ?array $output, ?string $provider, int $durationMs, string $status = 'ok', ?string $error = null): void {
    try {
        ensureCommunicationHubTables($pdo);
        unset($input['secrets']);
        $pdo->prepare("
            INSERT INTO communication_ai_log (action, channel, input_json, output_json, provider, duration_ms, admin_email, status, error, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ")->execute([
            mb_substr($action, 0, 40),
            $channel ? mb_substr($channel, 0, 30) : null,
            json_encode($input, JSON_UNESCAPED_UNICODE),
            $output ? json_encode($output, JSON_UNESCAPED_UNICODE) : null,
            $provider ? mb_substr($provider, 0, 40) : null,
            $durationMs,
            function_exists('capitaoAdminEmail') ? capitaoAdminEmail() : null,
            $status,
            $error ? mb_substr($error, 0, 2000) : null,
            dbNow(),
        ]);
    } catch (Throwable $e) { /* auditoria nunca bloqueia */ }
}

/**
 * Gera conteúdo completo de notificação para um canal.
 *
 * @param array $params channel(push|email|whatsapp|internal), goal, context,
 *                      tone, segment, event, action(generate|improve|summarize|adapt), base_text
 * @return array{ok:bool, content?:array, provider?:string, error?:string}
 */
function notificationAiGenerate(PDO $pdo, array $params): array {
    $channel = in_array($params['channel'] ?? '', ['push', 'email', 'whatsapp', 'internal'], true) ? $params['channel'] : 'push';
    $action  = in_array($params['action'] ?? '', ['generate', 'improve', 'summarize', 'adapt'], true) ? $params['action'] : 'generate';
    $goal    = trim((string)($params['goal'] ?? ''));
    $context = trim((string)($params['context'] ?? ''));
    $tone    = trim((string)($params['tone'] ?? 'profissional e amigável'));
    $segment = trim((string)($params['segment'] ?? 'todos os clientes'));
    $event   = trim((string)($params['event'] ?? ''));
    $base    = trim((string)($params['base_text'] ?? ''));

    $brand = function_exists('alpBrand') ? alpBrand() : ['primary' => '#1FB1F9', 'accent' => '#06C6E0'];
    $channelRules = [
        'push'     => 'Título até 50 caracteres. Corpo até 120 caracteres. Direto e com senso de urgência saudável.',
        'email'    => 'Assunto até 70 caracteres. Corpo em HTML simples (p, strong, ul, a) até 800 caracteres, com saudação personalizada {{nome}}. '
            . 'NÃO defina font-family, cores de texto nem fundos — o template oficial da marca aplica a tipografia e as cores. '
            . 'Exceção: o link de CTA deve ser um botão no padrão da marca: '
            . '<a href="URL" style="display:inline-block;background:' . $brand['primary'] . ';color:#ffffff;padding:12px 24px;border-radius:10px;text-decoration:none;font-weight:700">TEXTO</a>.',
        'whatsapp' => 'Mensagem única até 500 caracteres, tom conversacional, pode usar quebras de linha e 1-2 emojis.',
        'internal' => 'Título até 80 caracteres e corpo até 300 caracteres, tom informativo para o painel administrativo.',
    ];

    $actionText = [
        'generate'  => 'Crie o conteúdo do zero.',
        'improve'   => "Melhore este texto existente, mantendo a intenção:\n{$base}",
        'summarize' => "Resuma este texto para o canal indicado:\n{$base}",
        'adapt'     => "Adapte este texto para o canal indicado:\n{$base}",
    ];

    $system = 'Você é a Notification AI da Auto Limpeza Pro (limpeza de estofados e higienização automotiva em São José da Lapa e Vespasiano, MG). '
        . 'Escreva em português do Brasil. Nunca invente preços, prazos ou promoções não informadas. '
        . 'IDENTIDADE VISUAL DA MARCA (preserve sempre): paleta azul-céu ' . ($brand['primary'] ?? '#1FB1F9')
        . ' e ciano ' . ($brand['accent'] ?? '#06C6E0') . ' sobre tema escuro tech; tipografia Plus Jakarta Sans; '
        . 'tom profissional, tecnológico e acolhedor. Em "suggested_image", descreva imagens alinhadas a essa paleta '
        . '(tons de azul/ciano, visual limpo e tecnológico). Não use cores nem fontes fora da identidade. '
        . 'Responda APENAS com JSON válido, sem markdown, no formato: '
        . '{"title":"","body":"","short_version":"","long_version":"","cta":"","emoji":"","deep_link":"","category":"","priority":"low|medium|high","tags":[],"suggested_image":"","best_time":"","suggested_segment":""}';

    $user = "Canal: {$channel}. Regras do canal: {$channelRules[$channel]}\n"
        . "Ação: {$actionText[$action]}\n"
        . ($event !== '' ? "Evento: {$event}\n" : '')
        . ($goal !== '' ? "Objetivo: {$goal}\n" : '')
        . ($context !== '' ? "Contexto: {$context}\n" : '')
        . "Tom: {$tone}\nSegmento-alvo: {$segment}\n"
        . 'Variáveis disponíveis para personalização: {{nome}}, {{servico}}, {{data}}, {{hora}}, {{cidade}}.';

    $start = microtime(true);
    $r = aiGatewayGenerateText($system, $user, 1024, 'notification_ai');
    $ms = (int)((microtime(true) - $start) * 1000);

    if (empty($r['ok']) || empty($r['text'])) {
        $errMsg = $r['error'] ?? 'IA indisponível';
        if (
            stripos($errMsg, 'provedor') !== false
            || stripos($errMsg, 'chave') !== false
            || stripos($errMsg, 'Gateway') !== false
        ) {
            $errMsg = 'IA indisponível: configure a chave no AI Gateway (Sistema → AI Gateway) e teste o provedor.';
        }
        notificationAiLog($pdo, $action, $channel, $params, null, $r['provider'] ?? null, $ms, 'error', $errMsg);
        return ['ok' => false, 'error' => $errMsg];
    }

    $content = notificationAiParseJson($r['text']);
    if (!$content) {
        // Mantém utilizável mesmo sem JSON perfeito
        $content = ['title' => '', 'body' => trim((string)$r['text']), 'raw' => true];
    }
    $content['channel'] = $channel;
    $content['ai_generated'] = true;

    notificationAiLog($pdo, $action, $channel, $params, $content, $r['provider'] ?? null, $ms, 'ok');
    return ['ok' => true, 'content' => $content, 'provider' => $r['provider'] ?? null];
}

/**
 * Sugestões estratégicas da Notification AI para o Capitão Clean:
 * melhores horários, campanhas fracas, clientes inativos e automações.
 * Baseado apenas em dados agregados reais — nada é inventado.
 */
function notificationAiSuggestions(PDO $pdo): array {
    $suggestions = [];

    // Melhor horário por cliques (delivery logs 30d)
    try {
        $row = $pdo->query("
            SELECT HOUR(updated_at) AS h, COUNT(*) AS c
            FROM notification_delivery_logs
            WHERE clicked = 1 AND updated_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY HOUR(updated_at) ORDER BY c DESC LIMIT 1
        ")->fetch(PDO::FETCH_ASSOC);
        if ($row && (int)$row['c'] >= 3) {
            $suggestions[] = [
                'type' => 'best_time',
                'title' => 'Melhor horário de envio',
                'detail' => sprintf('Maior taxa de cliques por volta das %02d:00 (últimos 30 dias, %d cliques).', (int)$row['h'], (int)$row['c']),
            ];
        }
    } catch (Throwable $e) { /* */ }

    // Campanhas com CTR fraco
    try {
        $rows = $pdo->query("
            SELECT id, title, sent_count, click_count
            FROM notification_engine_sends
            WHERE status = 'sent' AND sent_count >= 10
              AND created_at >= DATE_SUB(NOW(), INTERVAL 60 DAY)
              AND (click_count / GREATEST(sent_count, 1)) < 0.02
            ORDER BY created_at DESC LIMIT 3
        ")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $suggestions[] = [
                'type' => 'weak_campaign',
                'title' => 'Campanha com CTR baixo',
                'detail' => sprintf('"%s" — %d envios, %d cliques. Considere reescrever com a Notification AI.', $r['title'], (int)$r['sent_count'], (int)$r['click_count']),
                'sendId' => (int)$r['id'],
            ];
        }
    } catch (Throwable $e) { /* */ }

    // Clientes inativos (>180d sem agendamento)
    try {
        $inactive = (int)$pdo->query("
            SELECT COUNT(DISTINCT visitor_id) FROM appointments a
            WHERE visitor_id IS NOT NULL AND visitor_id != ''
              AND NOT EXISTS (
                SELECT 1 FROM appointments b
                WHERE b.visitor_id = a.visitor_id
                  AND b.date >= DATE_SUB(CURDATE(), INTERVAL 180 DAY)
              )
        ")->fetchColumn();
        if ($inactive > 0) {
            $suggestions[] = [
                'type' => 'inactive_clients',
                'title' => 'Clientes inativos há 180+ dias',
                'detail' => "{$inactive} cliente(s) sem agendamento há mais de 180 dias. A automação recurring_180d cobre este grupo — revise se está habilitada.",
            ];
        }
    } catch (Throwable $e) { /* */ }

    // Fila / falhas
    try {
        $failed = (int)$pdo->query("SELECT COUNT(*) FROM notification_queue WHERE status = 'falhou'")->fetchColumn();
        if ($failed > 0) {
            $suggestions[] = [
                'type' => 'queue_failures',
                'title' => 'Mensagens com falha definitiva',
                'detail' => "{$failed} mensagem(ns) esgotaram as tentativas. Verifique a DLQ e os providers em Saúde.",
            ];
        }
    } catch (Throwable $e) { /* */ }

    return $suggestions;
}

/**
 * Rascunho de campanha gerado pela Notification AI (NUNCA envia sozinho —
 * cria sempre como draft para aprovação humana).
 */
function notificationAiCreateCampaignDraft(PDO $pdo, array $params): array {
    $gen = notificationAiGenerate($pdo, $params + ['channel' => $params['channel'] ?? 'push']);
    if (empty($gen['ok'])) return $gen;
    $content = $gen['content'];
    $now = dbNow();
    ensureNotificationEngineTables($pdo);
    $pdo->prepare("
        INSERT INTO notification_campaigns
            (name, description, status, segment, title, body, url, tag, priority, ttl, created_by, ai_generated, created_at, updated_at)
        VALUES (?, ?, 'draft', ?, ?, ?, ?, ?, ?, 86400, ?, 1, ?, ?)
    ")->execute([
        mb_substr((string)($params['name'] ?? ('Campanha IA — ' . date('d/m/Y H:i'))), 0, 200),
        mb_substr((string)($params['goal'] ?? ''), 0, 2000),
        mb_substr((string)($params['segment'] ?? 'all'), 0, 80),
        mb_substr((string)($content['title'] ?? ''), 0, 200),
        mb_substr((string)($content['body'] ?? ''), 0, 2000),
        mb_substr((string)($content['deep_link'] ?? '/'), 0, 500),
        'ai-' . substr(md5(uniqid('', true)), 0, 8),
        in_array($content['priority'] ?? '', ['low', 'medium', 'high'], true) ? ($content['priority'] === 'high' ? 'high' : 'normal') : 'normal',
        function_exists('capitaoAdminEmail') ? (capitaoAdminEmail() ?? 'notification_ai') : 'notification_ai',
        $now,
        $now,
    ]);
    return ['ok' => true, 'campaignId' => (int)$pdo->lastInsertId(), 'content' => $content, 'status' => 'draft'];
}

/** Registra ação do Capitão Clean no Hub (trilha de auditoria). */
function communicationCaptainAudit(PDO $pdo, string $action, array $params, $result, string $status = 'ok', bool $requiresConfirmation = false, ?string $confirmedBy = null): void {
    try {
        ensureCommunicationHubTables($pdo);
        $pdo->prepare("
            INSERT INTO communication_captain_actions
                (action, params_json, result_json, status, requires_confirmation, confirmed_by, admin_email, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ")->execute([
            mb_substr($action, 0, 60),
            json_encode($params, JSON_UNESCAPED_UNICODE),
            json_encode($result, JSON_UNESCAPED_UNICODE),
            $status,
            $requiresConfirmation ? 1 : 0,
            $confirmedBy,
            function_exists('capitaoAdminEmail') ? capitaoAdminEmail() : null,
            dbNow(),
        ]);
    } catch (Throwable $e) { /* */ }
}
