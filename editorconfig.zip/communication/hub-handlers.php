<?php
/**
 * Communication Hub — handlers REST (rotas communication/*).
 * Todas as rotas legadas de notifications/* permanecem intactas;
 * este arquivo apenas ADICIONA capacidades.
 */

// ── Visão geral / KPIs unificados ───────────────────────────────────────────

function handleCommunicationOverview(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    ensureCommunicationHubTables($pdo);
    NotificationCenter::ensureTables($pdo);
    ensureNotificationEngineTables($pdo);

    $count = function (string $sql, array $params = []) use ($pdo): int {
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return (int)$stmt->fetchColumn();
        } catch (Throwable $e) { return 0; }
    };

    $today = date('Y-m-d');
    $sentToday   = $count("SELECT COUNT(*) FROM notification_logs WHERE status = 'entregue' AND DATE(created_at) = ?", [$today]);
    $failedToday = $count("SELECT COUNT(*) FROM notification_logs WHERE status = 'falhou' AND DATE(created_at) = ?", [$today]);
    $totalToday  = $count("SELECT COUNT(*) FROM notification_logs WHERE DATE(created_at) = ?", [$today]);

    $engine = [];
    try {
        $engine = $pdo->query("SELECT COALESCE(SUM(sent_count),0) delivered, COALESCE(SUM(fail_count),0) failed, COALESCE(SUM(click_count),0) clicks, COALESCE(SUM(open_count),0) opens FROM notification_engine_sends WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetch(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) { /* */ }
    $delivered30 = (int)($engine['delivered'] ?? 0);
    $clicks30 = (int)($engine['clicks'] ?? 0);

    $byChannel = [];
    try {
        foreach ($pdo->query("SELECT canal, SUM(status='entregue') ok, COUNT(*) total FROM notification_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY canal")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $byChannel[$r['canal']] = ['total' => (int)$r['total'], 'ok' => (int)$r['ok']];
        }
    } catch (Throwable $e) { /* */ }

    $latency = null;
    try {
        $latency = $pdo->query("SELECT ROUND(AVG(duration_ms)) FROM notification_logs WHERE duration_ms IS NOT NULL AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn();
        $latency = $latency !== null && $latency !== false ? (int)$latency : null;
    } catch (Throwable $e) { /* */ }

    $eventsByDay = [];
    try {
        $eventsByDay = $pdo->query("SELECT DATE(created_at) day, COUNT(*) total FROM communication_events WHERE created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY) GROUP BY DATE(created_at) ORDER BY day")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { /* */ }

    jsonRespond([
        'kpis' => [
            'sentToday'      => $sentToday,
            'failedToday'    => $failedToday,
            'totalToday'     => $totalToday,
            'deliveryRate'   => $totalToday > 0 ? round(($sentToday / $totalToday) * 100, 1) : 100,
            'queuePending'   => $count("SELECT COUNT(*) FROM notification_queue WHERE status IN ('pendente','reenviada')"),
            'queueFailed'    => $count("SELECT COUNT(*) FROM notification_queue WHERE status = 'falhou'"),
            'dlq'            => $count("SELECT COUNT(*) FROM notification_queue_dlq WHERE reprocessed_at IS NULL"),
            'subscriptions'  => $count("SELECT COUNT(*) FROM push_subscriptions WHERE enabled = 1"),
            'devices'        => $count("SELECT COUNT(*) FROM push_devices WHERE enabled = 1"),
            'campaigns'      => $count("SELECT COUNT(*) FROM notification_campaigns"),
            'campaignDrafts' => $count("SELECT COUNT(*) FROM notification_campaigns WHERE status = 'draft'"),
            'delivered30d'   => $delivered30,
            'clicks30d'      => $clicks30,
            'ctr30d'         => $delivered30 > 0 ? round(($clicks30 / $delivered30) * 100, 2) : 0,
            'avgLatencyMs'   => $latency,
            'events24h'      => $count("SELECT COUNT(*) FROM communication_events WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"),
        ],
        'byChannel30d' => $byChannel,
        'eventsByDay'  => $eventsByDay,
        'providers'    => CommunicationProviderRegistry::status($pdo),
        'queue'        => communicationQueueAdapter($pdo)->stats($pdo),
        'health'       => NotificationCenter::getSystemHealth($pdo),
        'suggestions'  => NotificationCenter::getCapitaoSuggestions($pdo),
        'generatedAt'  => date('c'),
    ]);
}

// ── Event Bus: registry + eventos recentes ──────────────────────────────────

function handleCommunicationEvents(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    ensureCommunicationHubTables($pdo);

    $registry = [];
    foreach (communicationEventRegistry() as $key => $meta) {
        $registry[] = ['key' => $key] + $meta;
    }

    $limit = min(200, max(10, (int)($_GET['limit'] ?? 50)));
    $eventKey = san($_GET['event'] ?? null, 80);
    $sql = "SELECT id, event_key, source, actor_type, actor_id, title, uuid, status, listeners, is_test, error, created_at FROM communication_events";
    $params = [];
    if ($eventKey) {
        $sql .= " WHERE event_key = ?";
        $params[] = $eventKey;
    }
    $sql .= " ORDER BY id DESC LIMIT {$limit}";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    jsonRespond(['registry' => $registry, 'items' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
}

// ── Timeline canônica: evento → fila → provider → entrega → clique ──────────

function handleCommunicationTimeline(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    ensureCommunicationHubTables($pdo);
    NotificationCenter::ensureTables($pdo);

    $uuid = san($_GET['uuid'] ?? null, 32);

    if ($uuid) {
        $steps = [];

        try {
            $stmt = $pdo->prepare("SELECT id, event_key, source, title, status, created_at FROM communication_events WHERE uuid = ? ORDER BY id ASC");
            $stmt->execute([$uuid]);
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $steps[] = ['stage' => 'event', 'at' => $r['created_at'], 'detail' => $r['event_key'] . ' (' . ($r['source'] ?? 'sistema') . ')', 'status' => $r['status'], 'title' => $r['title']];
            }
        } catch (Throwable $e) { /* */ }

        $stmt = $pdo->prepare("SELECT status, tentativas, erro, canal_entregue, created_at, sent_at, next_retry_at FROM notification_queue WHERE uuid = ? LIMIT 1");
        try {
            $stmt->execute([$uuid]);
            $q = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            $stmt = $pdo->prepare("SELECT status, tentativas, erro, created_at, sent_at FROM notification_queue WHERE uuid = ? LIMIT 1");
            $stmt->execute([$uuid]);
            $q = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        if ($q) {
            $steps[] = ['stage' => 'queue', 'at' => $q['created_at'], 'detail' => 'Enfileirada', 'status' => 'ok'];
            if (!empty($q['sent_at'])) {
                $steps[] = ['stage' => 'delivered', 'at' => $q['sent_at'], 'detail' => 'Entregue' . (!empty($q['canal_entregue']) ? ' via ' . $q['canal_entregue'] : ''), 'status' => 'ok'];
            } elseif ($q['status'] === 'falhou') {
                $steps[] = ['stage' => 'failed', 'at' => null, 'detail' => mb_substr((string)($q['erro'] ?? 'Falha'), 0, 300), 'status' => 'error'];
            } elseif (!empty($q['next_retry_at'])) {
                $steps[] = ['stage' => 'retry_scheduled', 'at' => $q['next_retry_at'], 'detail' => 'Retry agendado (tentativa ' . ((int)$q['tentativas'] + 1) . ')', 'status' => 'pending'];
            }
        }

        $logsStmt = $pdo->prepare("SELECT canal, status, tentativa, erro, duration_ms, created_at FROM notification_logs WHERE uuid = ? ORDER BY id ASC LIMIT 100");
        $logsStmt->execute([$uuid]);
        foreach ($logsStmt->fetchAll(PDO::FETCH_ASSOC) as $log) {
            $steps[] = [
                'stage'  => 'provider',
                'at'     => $log['created_at'],
                'detail' => $log['canal'] . ' → ' . $log['status'] . ($log['erro'] ? ' — ' . mb_substr($log['erro'], 0, 200) : '') . ($log['duration_ms'] !== null ? " ({$log['duration_ms']}ms)" : ''),
                'status' => $log['status'] === 'entregue' ? 'ok' : 'error',
            ];
        }

        jsonRespond(['uuid' => $uuid, 'steps' => $steps, 'queue' => $q ?: null]);
    }

    // Timeline geral — últimos eventos + fila + logs mesclados
    $limit = min(100, max(10, (int)($_GET['limit'] ?? 40)));
    $items = [];
    try {
        foreach ($pdo->query("SELECT 'event' AS kind, event_key AS label, title, status, uuid, created_at FROM communication_events ORDER BY id DESC LIMIT {$limit}")->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $items[] = $r;
        }
    } catch (Throwable $e) { /* */ }
    foreach ($pdo->query("SELECT 'log' AS kind, CONCAT(tipo, ' · ', canal) AS label, NULL AS title, status, uuid, created_at FROM notification_logs ORDER BY id DESC LIMIT {$limit}")->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $items[] = $r;
    }
    usort($items, fn($a, $b) => strcmp((string)$b['created_at'], (string)$a['created_at']));
    jsonRespond(['items' => array_slice($items, 0, $limit)]);
}

// ── Providers / saúde ───────────────────────────────────────────────────────

function handleCommunicationProviders(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    jsonRespond([
        'providers'   => CommunicationProviderRegistry::status($pdo),
        'queue'       => communicationQueueAdapter($pdo)->stats($pdo),
        'adapter'     => communicationQueueAdapter($pdo)->name(),
        'generatedAt' => date('c'),
    ]);
}

// ── Segmentos ───────────────────────────────────────────────────────────────

function handleCommunicationSegments(string $method): void {
    requireAdmin();
    $pdo = db();

    if ($method === 'GET') {
        jsonRespond(['catalog' => communicationSegmentCatalog()]);
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $segment = san($b['segment'] ?? 'all', 80) ?? 'all';
        $params = is_array($b['params'] ?? null) ? $b['params'] : [];
        jsonRespond(communicationSegmentPreview($pdo, $segment, $params));
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

// ── Notification AI ─────────────────────────────────────────────────────────

function handleCommunicationAi(string $method): void {
    requireAdmin();
    $pdo = db();

    if ($method === 'GET') {
        jsonRespond(['suggestions' => notificationAiSuggestions($pdo)]);
    }

    if ($method === 'POST') {
        rateLimit('communication_ai', 15);
        // Geração via gateway pode varrer failover — evita fatal por max_execution_time (~30s em host compartilhado).
        @set_time_limit(120);
        $b = jsonBody();
        $action = san($b['action'] ?? 'generate', 30) ?? 'generate';

        if ($action === 'campaign_draft') {
            jsonRespond(notificationAiCreateCampaignDraft($pdo, $b));
        }

        if (in_array($action, ['generate', 'improve', 'summarize', 'adapt'], true)) {
            $b['action'] = $action;
            jsonRespond(notificationAiGenerate($pdo, $b));
        }

        jsonRespond(['error' => 'Ação inválida'], 400);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

// ── Campanhas — ações estendidas (duplicar, pausar, retomar, agendar) ───────

function handleCommunicationCampaigns(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('communication_campaigns', 20);
    $pdo = db();
    ensureNotificationEngineTables($pdo);
    ensureCommunicationHubTables($pdo);
    $b = jsonBody();
    $action = san($b['action'] ?? '', 30);
    $id = (int)($b['id'] ?? 0);
    if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
    $now = dbNow();

    $stmt = $pdo->prepare('SELECT * FROM notification_campaigns WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $camp = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$camp) jsonRespond(['error' => 'Campanha não encontrada'], 404);

    switch ($action) {
        case 'duplicate':
            $cols = ['name', 'description', 'segment', 'segment_json', 'template_id', 'title', 'body', 'image', 'icon', 'url', 'tag', 'priority', 'ttl'];
            $values = [];
            foreach ($cols as $c) $values[] = $camp[$c] ?? null;
            $values[0] = mb_substr((string)($camp['name'] ?? 'Campanha') . ' (cópia)', 0, 200);
            try {
                $pdo->prepare("INSERT INTO notification_campaigns (name, description, segment, segment_json, template_id, title, body, image, icon, url, tag, priority, ttl, status, duplicated_from, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'draft',?,?,?,?)")
                    ->execute(array_merge($values, [$id, function_exists('notificationEngineActor') ? notificationEngineActor() : null, $now, $now]));
            } catch (Throwable $e) {
                // Sem coluna duplicated_from (migração pendente)
                $pdo->prepare("INSERT INTO notification_campaigns (name, description, segment, segment_json, template_id, title, body, image, icon, url, tag, priority, ttl, status, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'draft',?,?,?)")
                    ->execute(array_merge($values, [function_exists('notificationEngineActor') ? notificationEngineActor() : null, $now, $now]));
            }
            jsonRespond(['ok' => true, 'id' => (int)$pdo->lastInsertId(), 'status' => 'draft']);
            break;

        case 'pause':
            if (!in_array($camp['status'], ['scheduled', 'sending'], true)) {
                jsonRespond(['error' => 'Só é possível pausar campanhas agendadas ou em envio'], 400);
            }
            try {
                $pdo->prepare("UPDATE notification_campaigns SET status = 'paused', paused_at = ?, updated_at = ? WHERE id = ?")->execute([$now, $now, $id]);
            } catch (Throwable $e) {
                $pdo->prepare("UPDATE notification_campaigns SET status = 'paused', updated_at = ? WHERE id = ?")->execute([$now, $id]);
            }
            jsonRespond(['ok' => true, 'status' => 'paused']);
            break;

        case 'resume':
            if ($camp['status'] !== 'paused') jsonRespond(['error' => 'Campanha não está pausada'], 400);
            $newStatus = !empty($camp['scheduled_at']) ? 'scheduled' : 'draft';
            $pdo->prepare("UPDATE notification_campaigns SET status = ?, updated_at = ? WHERE id = ?")->execute([$newStatus, $now, $id]);
            jsonRespond(['ok' => true, 'status' => $newStatus]);
            break;

        case 'schedule':
            $when = san($b['scheduled_at'] ?? null, 40);
            if (!$when) jsonRespond(['error' => 'scheduled_at obrigatório'], 400);
            $when = str_replace('T', ' ', $when);
            $pdo->prepare("UPDATE notification_campaigns SET status = 'scheduled', scheduled_at = ?, updated_at = ? WHERE id = ?")->execute([$when, $now, $id]);
            jsonRespond(['ok' => true, 'status' => 'scheduled', 'scheduled_at' => $when]);
            break;

        case 'cancel':
            $pdo->prepare("UPDATE notification_campaigns SET status = 'cancelled', updated_at = ? WHERE id = ?")->execute([$now, $id]);
            jsonRespond(['ok' => true, 'status' => 'cancelled']);
            break;

        default:
            jsonRespond(['error' => 'Ação inválida (duplicate|pause|resume|schedule|cancel)'], 400);
    }
}

// ── DLQ ─────────────────────────────────────────────────────────────────────

function handleCommunicationDlq(string $method): void {
    requireAdmin();
    $pdo = db();
    ensureCommunicationHubTables($pdo);

    if ($method === 'GET') {
        $limit = min(200, max(10, (int)($_GET['limit'] ?? 50)));
        $items = $pdo->query("SELECT id, queue_id, uuid, cliente_id, tipo, canal, tentativas, erro, moved_at, reprocessed_at, created_at FROM notification_queue_dlq ORDER BY id DESC LIMIT {$limit}")->fetchAll(PDO::FETCH_ASSOC);
        jsonRespond(['items' => $items]);
    }

    if ($method === 'POST') {
        rateLimit('communication_dlq', 10);
        $b = jsonBody();
        $id = (int)($b['id'] ?? 0);
        if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
        $stmt = $pdo->prepare('SELECT * FROM notification_queue_dlq WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) jsonRespond(['error' => 'Registro não encontrado'], 404);

        // Reprocessa: zera tentativas na fila original (retry manual preservado por UUID)
        $now = dbNow();
        try {
            $pdo->prepare("UPDATE notification_queue SET status = ?, tentativas = 0, erro = NULL, next_retry_at = NULL, locked_by = NULL, locked_at = NULL, updated_at = ? WHERE uuid = ?")
                ->execute([NotificationCenter::STATUS_RETRIED, $now, $row['uuid']]);
        } catch (Throwable $e) {
            $pdo->prepare("UPDATE notification_queue SET status = ?, tentativas = 0, erro = NULL, updated_at = ? WHERE uuid = ?")
                ->execute([NotificationCenter::STATUS_RETRIED, $now, $row['uuid']]);
        }
        $pdo->prepare("UPDATE notification_queue_dlq SET reprocessed_at = ? WHERE id = ?")->execute([$now, $id]);
        jsonRespond(['ok' => true, 'uuid' => $row['uuid']]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

// ── Test Center ─────────────────────────────────────────────────────────────

function handleCommunicationTest(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('communication_test', 15);
    $pdo = db();
    $b = jsonBody();
    $component = san($b['component'] ?? '', 40) ?? '';

    switch ($component) {
        case 'smtp':
        case 'push':
        case 'webpush':
        case 'database':
        case 'queue':
        case 'cron':
            jsonRespond(NotificationCenter::testComponent($pdo, $component === 'push' ? 'webpush' : $component));
            break;

        case 'whatsapp':
            $provider = CommunicationProviderRegistry::get('whatsapp');
            jsonRespond(['ok' => $provider && $provider->isConfigured($pdo), 'health' => $provider ? $provider->health($pdo) : null]);
            break;

        case 'telegram':
            $provider = CommunicationProviderRegistry::get('telegram');
            $test = function_exists('telegramTestConnection') ? telegramTestConnection($pdo) : ['ok' => false, 'error' => 'serviço ausente'];
            jsonRespond([
                'ok' => !empty($test['ok']),
                'health' => $provider ? $provider->health($pdo) : null,
                'detail' => $test,
            ]);
            break;

        case 'slack':
            $provider = CommunicationProviderRegistry::get('slack');
            $test = function_exists('slackTestConnection') ? slackTestConnection($pdo) : ['ok' => false, 'error' => 'serviço ausente'];
            jsonRespond([
                'ok' => !empty($test['ok']),
                'health' => $provider ? $provider->health($pdo) : null,
                'detail' => $test,
            ]);
            break;

        case 'gemini':
        case 'ai':
            @set_time_limit(120);
            $start = microtime(true);
            try {
                $r = aiGatewayGenerateText('Responda apenas com a palavra OK.', 'Teste de conectividade do Communication Hub.', 16, 'notification_ai');
            } catch (Throwable $e) {
                $r = ['ok' => false, 'error' => 'Falha no teste de IA: ' . $e->getMessage(), 'provider' => null];
            }
            jsonRespond([
                'ok' => !empty($r['ok']),
                'provider' => $r['provider'] ?? null,
                'latency_ms' => (int)((microtime(true) - $start) * 1000),
                'error' => $r['error'] ?? null,
                'hint' => empty($r['ok'])
                    ? 'Configure uma chave no AI Gateway (Sistema → AI Gateway) e teste o provedor antes.'
                    : null,
            ]);
            break;

        case 'providers':
            jsonRespond(['ok' => true, 'providers' => CommunicationProviderRegistry::status($pdo)]);
            break;

        case 'template':
            $slug = san($b['slug'] ?? '', 80) ?? '';
            if ($slug === '') jsonRespond(['error' => 'slug obrigatório'], 400);
            jsonRespond(['ok' => true, 'preview' => NotificationCenter::previewTemplate($pdo, $slug, is_array($b['vars'] ?? null) ? $b['vars'] : [])]);
            break;

        case 'event_bus':
            $eventId = communicationEventRecord($pdo, 'test_message', 'Teste do Event Bus', ['origin' => 'test_center'], ['source' => 'test_center', 'is_test' => true]);
            communicationEventFinalize($pdo, $eventId, 'processed', 0);
            jsonRespond(['ok' => $eventId !== null, 'eventId' => $eventId]);
            break;

        case 'segment':
            $segment = san($b['segment'] ?? 'all', 80) ?? 'all';
            jsonRespond(['ok' => true] + communicationSegmentPreview($pdo, $segment, is_array($b['params'] ?? null) ? $b['params'] : []));
            break;

        default:
            jsonRespond(['error' => 'Componente desconhecido (smtp|push|whatsapp|telegram|slack|gemini|queue|cron|database|providers|template|event_bus|segment)'], 400);
    }
}

// ── Analytics unificado ─────────────────────────────────────────────────────

function handleCommunicationAnalytics(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    NotificationCenter::ensureTables($pdo);
    ensureNotificationEngineTables($pdo);

    $days = max(1, min(365, (int)($_GET['days'] ?? 30)));
    $channel = san($_GET['channel'] ?? null, 30);

    // Volumetria por dia/canal (notification_logs)
    $sql = "SELECT DATE(created_at) day, canal, SUM(status='entregue') ok, COUNT(*) total
            FROM notification_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)";
    $params = [];
    if ($channel) { $sql .= " AND canal = ?"; $params[] = $channel; }
    $sql .= " GROUP BY DATE(created_at), canal ORDER BY day";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $byDay = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Web Push: browsers, plataformas, devices (dados reais das assinaturas)
    $browsers = $platforms = $devices = [];
    try {
        $browsers = $pdo->query("SELECT COALESCE(browser,'desconhecido') label, COUNT(*) c FROM push_subscriptions WHERE enabled = 1 GROUP BY browser ORDER BY c DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
        $platforms = $pdo->query("SELECT COALESCE(platform,'desconhecido') label, COUNT(*) c FROM push_subscriptions WHERE enabled = 1 GROUP BY platform ORDER BY c DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
        $devices = $pdo->query("SELECT COALESCE(device,'desconhecido') label, COUNT(*) c FROM push_subscriptions WHERE enabled = 1 GROUP BY device ORDER BY c DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { /* */ }

    // Cidades reais dos visitantes inscritos
    $cities = [];
    try {
        $cities = $pdo->query("
            SELECT v.city, v.state, COUNT(*) c
            FROM push_subscriptions s
            INNER JOIN visitors v ON v.id = s.owner_id
            WHERE s.enabled = 1 AND v.city IS NOT NULL AND v.city <> ''
            GROUP BY v.city, v.state ORDER BY c DESC LIMIT 10
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { /* */ }

    // Campanhas: desempenho
    $campaigns = [];
    try {
        $campaigns = $pdo->query("
            SELECT id, title, segment, status, sent_count, fail_count, click_count, open_count, created_at
            FROM notification_engine_sends
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)
            ORDER BY id DESC LIMIT 30
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { /* */ }

    jsonRespond([
        'days'       => $days,
        'byDay'      => $byDay,
        'browsers'   => $browsers,
        'platforms'  => $platforms,
        'devices'    => $devices,
        'cities'     => $cities,
        'campaigns'  => $campaigns,
        'generatedAt'=> date('c'),
    ]);
}

// ── Capitão Clean — ferramentas do Hub (leitura livre; mutação auditada) ────

function handleCommunicationCaptain(string $method): void {
    requireAdmin();
    $pdo = db();
    ensureCommunicationHubTables($pdo);
    // Ferramentas consultam tabelas do Center/Engine — garante que existem em instalações novas.
    if (class_exists('NotificationCenter')) NotificationCenter::ensureTables($pdo);
    if (function_exists('ensureNotificationEngineTables')) ensureNotificationEngineTables($pdo);

    if ($method === 'GET') {
        $tool = san($_GET['tool'] ?? 'summary', 40) ?? 'summary';
        switch ($tool) {
            case 'summary':
                // Normaliza: getCapitaoSuggestions retorna strings; notificationAiSuggestions retorna objetos.
                $aiTips = array_map(function (array $s): string {
                    $title = trim((string)($s['title'] ?? ''));
                    $detail = trim((string)($s['detail'] ?? ''));
                    return $title !== '' && $detail !== '' ? "{$title}: {$detail}" : ($detail !== '' ? $detail : $title);
                }, notificationAiSuggestions($pdo));
                jsonRespond([
                    'health'      => NotificationCenter::getSystemHealth($pdo),
                    'queue'       => communicationQueueAdapter($pdo)->stats($pdo),
                    'providers'   => CommunicationProviderRegistry::status($pdo),
                    'suggestions' => array_values(array_filter(array_merge(NotificationCenter::getCapitaoSuggestions($pdo), $aiTips))),
                ]);
                break;
            case 'failures':
                $items = $pdo->query("SELECT uuid, tipo, canal, status, erro, created_at FROM notification_logs WHERE status = 'falhou' ORDER BY id DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
                jsonRespond(['items' => $items]);
                break;
            case 'devices':
                if (function_exists('ensurePushSubscriptionsTable')) ensurePushSubscriptionsTable($pdo);
                $items = $pdo->query("SELECT id, owner_type, browser, platform, device, last_seen, enabled FROM push_subscriptions ORDER BY updated_at DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
                jsonRespond(['items' => $items]);
                break;
            case 'campaigns':
                $items = $pdo->query("SELECT id, name, status, segment, scheduled_at, sent_at, created_at FROM notification_campaigns ORDER BY id DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
                jsonRespond(['items' => $items]);
                break;
            case 'templates':
                $items = $pdo->query("SELECT id, slug, name, category, enabled, version FROM notification_templates ORDER BY category, name")->fetchAll(PDO::FETCH_ASSOC);
                jsonRespond(['items' => $items]);
                break;
            case 'actions':
                $items = $pdo->query("SELECT id, action, status, requires_confirmation, confirmed_by, admin_email, created_at FROM communication_captain_actions ORDER BY id DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
                jsonRespond(['items' => $items]);
                break;
            default:
                jsonRespond(['error' => 'Ferramenta desconhecida'], 400);
        }
    }

    if ($method === 'POST') {
        rateLimit('communication_captain', 10);
        $b = jsonBody();
        $action = san($b['action'] ?? '', 60) ?? '';
        $confirmed = !empty($b['confirm']);
        $adminEmail = function_exists('capitaoAdminEmail') ? capitaoAdminEmail() : null;

        // Ações mutáveis exigem confirmação explícita
        $mutable = ['process_queue', 'retry_uuid', 'create_campaign_draft', 'reprocess_dlq'];
        if (in_array($action, $mutable, true) && !$confirmed) {
            communicationCaptainAudit($pdo, $action, $b, ['blocked' => 'confirmação ausente'], 'blocked', true);
            jsonRespond(['error' => 'Ação requer confirmação explícita (confirm: true)', 'requiresConfirmation' => true], 428);
        }

        switch ($action) {
            case 'process_queue':
                $limit = min(50, max(1, (int)($b['limit'] ?? 25)));
                $result = communicationQueueAdapter($pdo)->process($pdo, $limit);
                communicationCaptainAudit($pdo, $action, ['limit' => $limit], ['processed' => count($result)], 'ok', true, $adminEmail);
                jsonRespond(['ok' => true, 'processed' => $result]);
                break;

            case 'retry_uuid':
                $uuid = san($b['uuid'] ?? '', 32) ?? '';
                if ($uuid === '') jsonRespond(['error' => 'uuid obrigatório'], 400);
                $pdo->prepare("UPDATE notification_queue SET status = ?, tentativas = 0, erro = NULL, updated_at = ? WHERE uuid = ?")
                    ->execute([NotificationCenter::STATUS_RETRIED, dbNow(), $uuid]);
                communicationCaptainAudit($pdo, $action, ['uuid' => $uuid], ['ok' => true], 'ok', true, $adminEmail);
                jsonRespond(['ok' => true]);
                break;

            case 'create_campaign_draft':
                $result = notificationAiCreateCampaignDraft($pdo, $b);
                communicationCaptainAudit($pdo, $action, $b, $result, empty($result['ok']) ? 'error' : 'ok', true, $adminEmail);
                jsonRespond($result);
                break;

            case 'reprocess_dlq':
                $id = (int)($b['id'] ?? 0);
                if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
                $stmt = $pdo->prepare('SELECT uuid FROM notification_queue_dlq WHERE id = ? LIMIT 1');
                $stmt->execute([$id]);
                $uuid = $stmt->fetchColumn();
                if (!$uuid) jsonRespond(['error' => 'Registro não encontrado'], 404);
                $pdo->prepare("UPDATE notification_queue SET status = ?, tentativas = 0, erro = NULL, updated_at = ? WHERE uuid = ?")
                    ->execute([NotificationCenter::STATUS_RETRIED, dbNow(), $uuid]);
                $pdo->prepare("UPDATE notification_queue_dlq SET reprocessed_at = ? WHERE id = ?")->execute([dbNow(), $id]);
                communicationCaptainAudit($pdo, $action, ['id' => $id, 'uuid' => $uuid], ['ok' => true], 'ok', true, $adminEmail);
                jsonRespond(['ok' => true, 'uuid' => $uuid]);
                break;

            default:
                jsonRespond(['error' => 'Ação desconhecida'], 400);
        }
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

// ── Automações do Hub (aditivas, desabilitáveis, idempotentes) ──────────────

/** Regras novas do Hub — seed aditivo em captain_automation_rules (desabilitadas por padrão). */
function communicationSeedHubAutomationRules(PDO $pdo): void {
    if (!function_exists('ensureAutomationTables')) return;
    ensureAutomationTables($pdo);
    $rules = [
        [
            'slug' => 'hub_welcome_new_client',
            'name' => 'Boas-vindas a novos clientes',
            'trigger_key' => 'hub_welcome_new_client',
            'description' => 'Mensagem de boas-vindas no painel do cliente após criação de conta (Hub)',
            'template' => 'Olá {{nome}}! Bem-vindo à Auto Limpeza Pro. Acompanhe seus agendamentos e ofertas exclusivas no seu portal.',
        ],
        [
            'slug' => 'hub_inactive_coupon',
            'name' => 'Cupom para clientes inativos',
            'trigger_key' => 'hub_inactive_coupon',
            'description' => 'Notifica clientes inativos (180+ dias) sobre cupom ativo disponível (Hub)',
            'template' => 'Olá {{nome}}, sentimos sua falta! Use o cupom {{cupom}} na sua próxima higienização.',
        ],
        [
            'slug' => 'hub_birthday',
            'name' => 'Mensagem de aniversário',
            'trigger_key' => 'hub_birthday',
            'description' => 'Parabeniza clientes aniversariantes (requer data de nascimento cadastrada) (Hub)',
            'template' => 'Feliz aniversário, {{nome}}! 🎉 A equipe Auto Limpeza Pro deseja um ótimo dia.',
        ],
    ];
    $now = dbNow();
    foreach ($rules as $rule) {
        try {
            $stmt = $pdo->prepare('SELECT id FROM captain_automation_rules WHERE slug = ? LIMIT 1');
            $stmt->execute([$rule['slug']]);
            if ($stmt->fetch()) continue;
            $pdo->prepare("
                INSERT INTO captain_automation_rules
                    (slug, name, trigger_key, description, conditions, actions, message_template, enabled, is_native, priority, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0, 1, 200, ?, ?)
            ")->execute([
                $rule['slug'], $rule['name'], $rule['trigger_key'], $rule['description'],
                json_encode(['hub' => true], JSON_UNESCAPED_UNICODE),
                json_encode([['type' => 'panel', 'enabled' => true], ['type' => 'push', 'enabled' => true], ['type' => 'log', 'enabled' => true]], JSON_UNESCAPED_UNICODE),
                $rule['template'], $now, $now,
            ]);
        } catch (Throwable $e) { /* seed nunca bloqueia */ }
    }
}

/** Processa automações do Hub no cron (idempotente via dedupe_key por dia/cliente). */
function processCommunicationHubAutomations(PDO $pdo): array {
    if (!function_exists('ensureAutomationTables')) return ['skipped' => 'automations indisponível'];
    communicationSeedHubAutomationRules($pdo);
    $ran = [];

    $ruleEnabled = function (string $slug) use ($pdo): bool {
        try {
            $stmt = $pdo->prepare('SELECT enabled FROM captain_automation_rules WHERE slug = ? LIMIT 1');
            $stmt->execute([$slug]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    };

    // 1) Boas-vindas — clientes criados nas últimas 24h
    if ($ruleEnabled('hub_welcome_new_client')) {
        try {
            $rows = $pdo->query("
                SELECT id, name, visitor_id FROM clients
                WHERE active = 1 AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                  AND visitor_id IS NOT NULL AND visitor_id <> ''
                LIMIT 50
            ")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $c) {
                $dedupe = 'hub_welcome:' . $c['id'];
                communicationDispatch($pdo, 'new_client', 'Bem-vindo à Auto Limpeza Pro!', "Olá {$c['name']}! Acompanhe seus agendamentos e ofertas no seu portal.", [
                    'client_id' => (int)$c['id'], 'visitor_id' => $c['visitor_id'],
                ], [
                    'dedupe_key' => $dedupe,
                    'visitor_id' => $c['visitor_id'],
                    'source'     => 'hub_automation',
                    'skip_internal' => true,
                    'client_notification' => [
                        'type' => 'welcome', 'title' => 'Bem-vindo à Auto Limpeza Pro!',
                        'body' => "Olá {$c['name']}! Acompanhe seus agendamentos e ofertas exclusivas por aqui.",
                        'action_url' => '/conta',
                    ],
                ]);
                $ran[] = ['rule' => 'hub_welcome_new_client', 'client' => (int)$c['id']];
            }
        } catch (Throwable $e) {
            if (function_exists('appLog')) appLog('warn', 'hub_welcome_failed', ['err' => $e->getMessage()]);
        }
    }

    // 2) Cupom para inativos — 1 notificação por cliente por mês, apenas se houver cupom ativo
    if ($ruleEnabled('hub_inactive_coupon')) {
        try {
            $coupon = $pdo->query("
                SELECT code, title FROM coupons
                WHERE active = 1 AND (expires_at IS NULL OR expires_at > NOW())
                  AND (max_redemptions = 0 OR redemption_count < max_redemptions)
                ORDER BY created_at DESC LIMIT 1
            ")->fetch(PDO::FETCH_ASSOC);
            if ($coupon) {
                $rows = $pdo->query("
                    SELECT c.id, c.name, c.visitor_id FROM clients c
                    WHERE c.active = 1 AND c.visitor_id IS NOT NULL AND c.visitor_id <> ''
                      AND EXISTS (SELECT 1 FROM appointments a WHERE a.visitor_id = c.visitor_id)
                      AND NOT EXISTS (
                        SELECT 1 FROM appointments a2 WHERE a2.visitor_id = c.visitor_id
                          AND a2.date >= DATE_SUB(CURDATE(), INTERVAL 180 DAY)
                      )
                    LIMIT 30
                ")->fetchAll(PDO::FETCH_ASSOC);
                $month = date('Y-m');
                foreach ($rows as $c) {
                    $dedupe = 'hub_inactive_coupon:' . $c['id'] . ':' . $month;
                    communicationDispatch($pdo, 'coupon_issued', 'Um presente para você voltar', "Olá {$c['name']}, sentimos sua falta! Use o cupom {$coupon['code']} na próxima higienização.", [
                        'client_id' => (int)$c['id'], 'visitor_id' => $c['visitor_id'], 'coupon' => $coupon['code'],
                    ], [
                        'dedupe_key' => $dedupe,
                        'visitor_id' => $c['visitor_id'],
                        'source'     => 'hub_automation',
                        'skip_internal' => true,
                        'client_notification' => [
                            'type' => 'coupon_issued', 'title' => 'Cupom exclusivo para você!',
                            'body' => "Use o cupom {$coupon['code']} ({$coupon['title']}) e agende sua próxima higienização.",
                            'action_url' => '/conta/cupons',
                        ],
                    ]);
                    $ran[] = ['rule' => 'hub_inactive_coupon', 'client' => (int)$c['id']];
                }
            }
        } catch (Throwable $e) {
            if (function_exists('appLog')) appLog('warn', 'hub_inactive_coupon_failed', ['err' => $e->getMessage()]);
        }
    }

    // 3) Aniversário — só roda se a coluna birthdate existir (nunca inventa dados)
    if ($ruleEnabled('hub_birthday')) {
        try {
            $hasCol = $pdo->query("SHOW COLUMNS FROM clients LIKE 'birthdate'")->fetch();
            if ($hasCol) {
                $rows = $pdo->query("
                    SELECT id, name, visitor_id FROM clients
                    WHERE active = 1 AND birthdate IS NOT NULL
                      AND DATE_FORMAT(birthdate, '%m-%d') = DATE_FORMAT(CURDATE(), '%m-%d')
                      AND visitor_id IS NOT NULL AND visitor_id <> ''
                    LIMIT 30
                ")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($rows as $c) {
                    $dedupe = 'hub_birthday:' . $c['id'] . ':' . date('Y');
                    communicationDispatch($pdo, 'client_birthday', 'Feliz aniversário!', "Feliz aniversário, {$c['name']}! A equipe Auto Limpeza Pro deseja um ótimo dia.", [
                        'client_id' => (int)$c['id'], 'visitor_id' => $c['visitor_id'],
                    ], [
                        'dedupe_key' => $dedupe,
                        'visitor_id' => $c['visitor_id'],
                        'source'     => 'hub_automation',
                        'skip_internal' => true,
                        'client_notification' => [
                            'type' => 'client_birthday', 'title' => 'Feliz aniversário! 🎉',
                            'body' => "Parabéns, {$c['name']}! Aproveite o dia — e conte com a gente para deixar tudo limpo.",
                            'action_url' => '/conta',
                        ],
                    ]);
                    $ran[] = ['rule' => 'hub_birthday', 'client' => (int)$c['id']];
                }
            }
        } catch (Throwable $e) {
            if (function_exists('appLog')) appLog('warn', 'hub_birthday_failed', ['err' => $e->getMessage()]);
        }
    }

    return $ran;
}
