<?php
/**
 * Communication Hub — Queue Adapter.
 *
 * MySqlQueueAdapter é o padrão de produção (HostGator, sem Redis) e delega
 * para a fila existente do NotificationCenter (notification_queue), com
 * retry/backoff/lease/DLQ já incorporados em NotificationCenter::processQueue.
 *
 * RedisQueueAdapter é OPCIONAL: só ativa se a extensão phpredis estiver
 * instalada E a chave communication_redis_url existir em site_config.
 * Nunca inventa credenciais; sempre com fallback MySQL.
 */

interface CommunicationQueueAdapter {
    public function name(): string;
    public function isAvailable(PDO $pdo): bool;
    public function enqueue(PDO $pdo, string $uuid, ?string $clienteId, string $tipo, array $payload, int $priority = 5, ?int $eventId = null): int;
    public function process(PDO $pdo, int $limit = 25): array;
    public function stats(PDO $pdo): array;
}

class MySqlQueueAdapter implements CommunicationQueueAdapter {
    public function name(): string { return 'mysql'; }
    public function isAvailable(PDO $pdo): bool { return true; }

    public function enqueue(PDO $pdo, string $uuid, ?string $clienteId, string $tipo, array $payload, int $priority = 5, ?int $eventId = null): int {
        return NotificationCenter::enqueue($pdo, $uuid, $clienteId, $tipo, $payload, $priority, $eventId);
    }

    public function process(PDO $pdo, int $limit = 25): array {
        return NotificationCenter::processQueue($pdo, $limit);
    }

    public function stats(PDO $pdo): array {
        $byStatus = [];
        try {
            foreach ($pdo->query("SELECT status, COUNT(*) c FROM notification_queue GROUP BY status")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $byStatus[$r['status']] = (int)$r['c'];
            }
        } catch (Throwable $e) { /* */ }
        $dlq = 0;
        try {
            $dlq = (int)$pdo->query("SELECT COUNT(*) FROM notification_queue_dlq WHERE reprocessed_at IS NULL")->fetchColumn();
        } catch (Throwable $e) { /* */ }
        return ['adapter' => 'mysql', 'byStatus' => $byStatus, 'dlq' => $dlq];
    }
}

class RedisQueueAdapter implements CommunicationQueueAdapter {
    private ?object $redis = null;
    private bool $checked = false;

    public function name(): string { return 'redis'; }

    private function connect(PDO $pdo): ?object {
        if ($this->checked) return $this->redis;
        $this->checked = true;
        if (!class_exists('Redis')) return null;
        try {
            $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'communication_redis_url' LIMIT 1");
            $stmt->execute();
            $url = trim((string)($stmt->fetchColumn() ?: ''));
            if ($url === '') return null;
            $parts = parse_url($url);
            if (!$parts || empty($parts['host'])) return null;
            $redis = new Redis();
            if (!@$redis->connect($parts['host'], (int)($parts['port'] ?? 6379), 2.0)) return null;
            if (!empty($parts['pass'])) $redis->auth($parts['pass']);
            $this->redis = $redis;
        } catch (Throwable $e) {
            $this->redis = null;
        }
        return $this->redis;
    }

    public function isAvailable(PDO $pdo): bool {
        return $this->connect($pdo) !== null;
    }

    public function enqueue(PDO $pdo, string $uuid, ?string $clienteId, string $tipo, array $payload, int $priority = 5, ?int $eventId = null): int {
        // Persistência canônica continua no MySQL (fonte de verdade / auditoria);
        // Redis serve apenas como fila rápida de sinalização.
        $id = NotificationCenter::enqueue($pdo, $uuid, $clienteId, $tipo, $payload, $priority, $eventId);
        $redis = $this->connect($pdo);
        if ($redis) {
            try {
                $redis->lPush('cleanpro:notification_queue', json_encode(['uuid' => $uuid, 'priority' => $priority]));
            } catch (Throwable $e) { /* fila MySQL cobre */ }
        }
        return $id;
    }

    public function process(PDO $pdo, int $limit = 25): array {
        // Processamento efetivo permanece no MySQL (estado por status pt-BR).
        return NotificationCenter::processQueue($pdo, $limit);
    }

    public function stats(PDO $pdo): array {
        $base = (new MySqlQueueAdapter())->stats($pdo);
        $base['adapter'] = 'redis+mysql';
        $redis = $this->connect($pdo);
        if ($redis) {
            try {
                $base['redisPending'] = (int)$redis->lLen('cleanpro:notification_queue');
            } catch (Throwable $e) { /* */ }
        }
        return $base;
    }
}

/** Resolve o adapter ativo: Redis se configurado/disponível, senão MySQL. */
function communicationQueueAdapter(PDO $pdo): CommunicationQueueAdapter {
    static $adapter = null;
    if ($adapter !== null) return $adapter;
    $redis = new RedisQueueAdapter();
    $adapter = $redis->isAvailable($pdo) ? $redis : new MySqlQueueAdapter();
    return $adapter;
}
