<?php
/**
 * Communication Hub — Event Bus canônico.
 *
 * Todo disparo de comunicação passa a ser registrado como CommunicationEvent
 * (tabela communication_events) antes de seguir para o Notification Engine
 * (NotificationCenter) e providers. O dispatch legado permanece 100% compatível:
 * dispatchNotificationEvent() agora registra o evento no bus e segue o fluxo
 * anterior sem nenhuma mudança de contrato.
 */

/**
 * Registro canônico de eventos — inclui os 18 tipos legados de
 * NOTIFICATION_EVENT_META e os gaps/novos eventos do Communication Hub.
 * Campos: category, priority, module, description, source (emissor típico).
 */
function communicationEventRegistry(): array {
    static $registry = null;
    if ($registry !== null) return $registry;

    $registry = [];

    // Base legada (preservada) — NOTIFICATION_EVENT_META
    if (defined('NOTIFICATION_EVENT_META')) {
        foreach (NOTIFICATION_EVENT_META as $key => $meta) {
            $registry[$key] = $meta + ['description' => null, 'legacy' => true];
        }
    }

    // Eventos emitidos hoje mas ausentes do meta legado
    $extras = [
        'new_quote'        => ['category' => 'forms',   'priority' => 'high',   'module' => 'quotes',   'description' => 'Novo pedido de orçamento'],
        'warranty_claim'   => ['category' => 'forms',   'priority' => 'high',   'module' => 'warranty', 'description' => 'Solicitação de garantia'],
        'crm_automation'   => ['category' => 'clients', 'priority' => 'medium', 'module' => 'crm',      'description' => 'Automação CRM disparada'],
        'weather_alert'    => ['category' => 'agenda',  'priority' => 'high',   'module' => 'weather',  'description' => 'Alerta climático para agendamento'],
        // Novos eventos do Communication Hub (aditivos)
        'coupon_issued'    => ['category' => 'content', 'priority' => 'medium', 'module' => 'coupons',  'description' => 'Cupom emitido para cliente'],
        'coupon_redeemed'  => ['category' => 'content', 'priority' => 'low',    'module' => 'coupons',  'description' => 'Cupom resgatado'],
        'loyalty_tier'     => ['category' => 'clients', 'priority' => 'medium', 'module' => 'loyalty',  'description' => 'Cliente mudou de nível de fidelidade'],
        'client_birthday'  => ['category' => 'clients', 'priority' => 'medium', 'module' => 'clients',  'description' => 'Aniversário de cliente'],
        'client_inactive'  => ['category' => 'clients', 'priority' => 'medium', 'module' => 'clients',  'description' => 'Cliente inativo detectado'],
        'review_requested' => ['category' => 'forms',   'priority' => 'low',    'module' => 'reviews',  'description' => 'Pedido de avaliação enviado'],
        'campaign_sent'    => ['category' => 'content', 'priority' => 'low',    'module' => 'campaigns','description' => 'Campanha disparada'],
        'test_message'     => ['category' => 'system',  'priority' => 'low',    'module' => 'test',     'description' => 'Envio de teste (Test Center)'],
        // Acompanhamento em tempo real
        'DriverStarted'         => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Equipe iniciou deslocamento'],
        'DriverTracking'        => ['category' => 'agenda', 'priority' => 'low',    'module' => 'tracking', 'description' => 'Localização/ETA atualizado'],
        'DriverNear'            => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Equipe próxima do destino'],
        'DriverStopped'         => ['category' => 'agenda', 'priority' => 'medium', 'module' => 'tracking', 'description' => 'Deslocamento pausado ou encerrado'],
        'DriverDelayed'         => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Equipe atrasada'],
        'DriverOffline'         => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Equipe sem comunicação'],
        'GpsStale'              => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'GPS perdido ou desatualizado'],
        'InternetLost'          => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Conectividade perdida'],
        'DriverArrived'         => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Equipe chegou'],
        'ServiceStarted'        => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Serviço iniciado'],
        'ServicePaused'         => ['category' => 'agenda', 'priority' => 'medium', 'module' => 'tracking', 'description' => 'Serviço pausado'],
        'ServiceFinished'       => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Serviço finalizado'],
        'ReviewRequested'       => ['category' => 'forms',  'priority' => 'medium', 'module' => 'reviews',  'description' => 'Avaliação solicitada'],
        'WarrantyCreated'       => ['category' => 'forms',  'priority' => 'medium', 'module' => 'warranty', 'description' => 'Garantia criada'],
        // Aliases de compatibilidade; emissores novos usam os nomes acima.
        'TrackingStarted'       => ['category' => 'agenda', 'priority' => 'high',   'module' => 'tracking', 'description' => 'Alias de DriverStarted'],
        'TrackingUpdated'       => ['category' => 'agenda', 'priority' => 'low',    'module' => 'tracking', 'description' => 'Alias de DriverTracking'],
        'DriverLocationUpdated' => ['category' => 'agenda', 'priority' => 'low',    'module' => 'tracking', 'description' => 'Alias legado de DriverTracking'],
    ];
    foreach ($extras as $key => $meta) {
        if (!isset($registry[$key])) {
            $registry[$key] = $meta + ['legacy' => false];
        }
    }

    return $registry;
}

/** Metadados de um evento (fallback general/medium como no comportamento atual). */
function communicationEventMeta(string $eventKey): array {
    $registry = communicationEventRegistry();
    return $registry[$eventKey] ?? ['category' => 'general', 'priority' => 'medium', 'module' => 'system', 'description' => null, 'legacy' => false];
}

/**
 * Registra um evento no bus. Nunca lança exceção (comunicação jamais pode
 * derrubar o fluxo de negócio). Retorna o id do evento ou null.
 */
function communicationEventRecord(
    PDO $pdo,
    string $eventKey,
    string $title,
    array $payload = [],
    array $opts = []
): ?int {
    try {
        ensureCommunicationHubTables($pdo);
        $safePayload = $payload;
        // Nunca persistir credenciais no payload do evento
        foreach (['password', 'token', 'secret', 'api_key', 'apikey'] as $forbidden) {
            unset($safePayload[$forbidden]);
        }
        $pdo->prepare("
            INSERT INTO communication_events
                (event_key, source, actor_type, actor_id, title, payload, uuid, status, listeners, is_test, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'received', 0, ?, ?)
        ")->execute([
            mb_substr($eventKey, 0, 80),
            isset($opts['source']) ? mb_substr((string)$opts['source'], 0, 80) : null,
            isset($opts['actor_type']) ? mb_substr((string)$opts['actor_type'], 0, 20) : null,
            isset($opts['actor_id']) ? mb_substr((string)$opts['actor_id'], 0, 64) : null,
            mb_substr($title, 0, 200),
            json_encode($safePayload, JSON_UNESCAPED_UNICODE),
            isset($opts['uuid']) ? mb_substr((string)$opts['uuid'], 0, 32) : null,
            !empty($opts['is_test']) ? 1 : 0,
            dbNow(),
        ]);
        return (int)$pdo->lastInsertId();
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('warn', 'communication_event_record_failed', ['event' => $eventKey, 'err' => $e->getMessage()]);
        }
        return null;
    }
}

/** Atualiza o evento após o processamento pelos listeners/engine. */
function communicationEventFinalize(PDO $pdo, ?int $eventId, string $status, int $listeners = 0, ?string $uuid = null, ?string $error = null): void {
    if (!$eventId) return;
    try {
        $pdo->prepare("UPDATE communication_events SET status = ?, listeners = ?, uuid = COALESCE(?, uuid), error = ? WHERE id = ?")
            ->execute([
                mb_substr($status, 0, 20),
                $listeners,
                $uuid ? mb_substr($uuid, 0, 32) : null,
                $error ? mb_substr($error, 0, 2000) : null,
                $eventId,
            ]);
    } catch (Throwable $e) { /* não bloqueia */ }
}

/**
 * Dispatch canônico do Communication Hub.
 * Registra o evento e o encaminha ao Notification Engine (NotificationCenter)
 * com o mesmo contrato do dispatch legado. Emissores novos devem usar esta
 * função; os antigos continuam funcionando via dispatchNotificationEvent().
 */
function communicationDispatch(PDO $pdo, string $eventKey, string $title, string $body, array $meta = [], array $opts = []): array {
    $eventId = communicationEventRecord($pdo, $eventKey, $title, $meta, [
        'source'     => $opts['source'] ?? null,
        'actor_type' => $opts['actor_type'] ?? null,
        'actor_id'   => $opts['visitor_id'] ?? ($opts['actor_id'] ?? null),
        'is_test'    => !empty($opts['is_test']),
    ]);
    $opts['communication_event_id'] = $eventId;

    if (!class_exists('NotificationCenter')) {
        communicationEventFinalize($pdo, $eventId, 'failed', 0, null, 'NotificationCenter indisponível');
        if (function_exists('dispatchNotificationEventLegacy')) {
            dispatchNotificationEventLegacy($pdo, $eventKey, $title, $body, $meta, $opts);
        }
        return ['event_id' => $eventId, 'uuid' => null, 'results' => []];
    }

    try {
        $dedupeKey = $opts['dedupe_key'] ?? ($meta['appointment_id'] ?? ($meta['id'] ?? null));
        $result = NotificationCenter::send([
            'type'       => $eventKey,
            'title'      => $title,
            'body'       => $body,
            'meta'       => $meta,
            'opts'       => $opts,
            'dedupe_key' => $dedupeKey ? ($eventKey . ':' . $dedupeKey) : null,
            'async'      => $opts['async'] ?? true,
        ]);
        $listeners = count($result['results'] ?? []);
        $status = !empty($result['skipped_duplicate']) ? 'deduped' : (!empty($result['queued']) ? 'queued' : 'processed');
        communicationEventFinalize($pdo, $eventId, $status, $listeners, $result['uuid'] ?? null);
        $result['event_id'] = $eventId;
        return $result;
    } catch (Throwable $e) {
        communicationEventFinalize($pdo, $eventId, 'failed', 0, null, $e->getMessage());
        if (function_exists('appLog')) {
            appLog('error', 'communication_dispatch_failed', ['event' => $eventKey, 'err' => $e->getMessage()]);
        }
        return ['event_id' => $eventId, 'uuid' => null, 'results' => [], 'error' => $e->getMessage()];
    }
}
