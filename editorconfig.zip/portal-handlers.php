<?php
/**
 * Portal do Cliente — APIs autenticadas (dashboard, fidelidade, cupons, suporte, IA, etc.)
 */

function ensurePortalTables(PDO $pdo): void {
    static $ensured = false;
    if ($ensured) return;
    $ensured = true;

    $alters = [
        "ALTER TABLE loyalty_pieces ADD COLUMN `client_id` INT UNSIGNED DEFAULT NULL",
        "ALTER TABLE warranty_tickets ADD COLUMN `client_id` INT UNSIGNED DEFAULT NULL",
        "ALTER TABLE hygiene_passports ADD COLUMN `client_id` INT UNSIGNED DEFAULT NULL",
        "ALTER TABLE client_notifications ADD COLUMN `client_id` INT UNSIGNED DEFAULT NULL",
        "ALTER TABLE quote_photos ADD COLUMN `client_id` INT UNSIGNED DEFAULT NULL",
    ];
    foreach ($alters as $sql) {
        try { $pdo->exec($sql); } catch (PDOException $e) { /* exists */ }
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS `client_addresses` (
        `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `client_id`    INT UNSIGNED NOT NULL,
        `label`        VARCHAR(40)  NOT NULL DEFAULT 'casa',
        `address`      VARCHAR(500) NOT NULL,
        `city`         VARCHAR(100) DEFAULT NULL,
        `state`        VARCHAR(50)  DEFAULT NULL,
        `neighborhood` VARCHAR(150) DEFAULT NULL,
        `zip_code`     VARCHAR(20)  DEFAULT NULL,
        `latitude`     DECIMAL(10,7) DEFAULT NULL,
        `longitude`    DECIMAL(10,7) DEFAULT NULL,
        `is_favorite`  TINYINT(1)   NOT NULL DEFAULT 0,
        `created_at`   DATETIME     NOT NULL,
        `updated_at`   DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_client_addr` (`client_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `client_reviews` (
        `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `client_id`      INT UNSIGNED NOT NULL,
        `appointment_id` VARCHAR(64)  NOT NULL,
        `rating`         TINYINT UNSIGNED NOT NULL,
        `comment`        TEXT         DEFAULT NULL,
        `created_at`     DATETIME     NOT NULL,
        `updated_at`     DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_client_appt_review` (`client_id`, `appointment_id`),
        INDEX `idx_review_client` (`client_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `coupons` (
        `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `code`             VARCHAR(40)  NOT NULL,
        `title`            VARCHAR(150) NOT NULL,
        `description`      VARCHAR(500) DEFAULT NULL,
        `discount_type`    VARCHAR(20)  NOT NULL DEFAULT 'percent',
        `discount_value`   DECIMAL(10,2) NOT NULL DEFAULT 0,
        `min_amount`       DECIMAL(10,2) DEFAULT NULL,
        `expires_at`       DATETIME     DEFAULT NULL,
        `active`           TINYINT(1)   NOT NULL DEFAULT 1,
        `max_redemptions`  INT UNSIGNED DEFAULT NULL,
        `redemption_count` INT UNSIGNED NOT NULL DEFAULT 0,
        `created_at`       DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_coupon_code` (`code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `coupon_redemptions` (
        `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `coupon_id`   INT UNSIGNED NOT NULL,
        `client_id`   INT UNSIGNED NOT NULL,
        `redeemed_at` DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_coupon_client` (`coupon_id`, `client_id`),
        INDEX `idx_redeem_client` (`client_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `support_tickets` (
        `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `client_id`  INT UNSIGNED NOT NULL,
        `subject`    VARCHAR(200) NOT NULL,
        `status`     VARCHAR(20)  NOT NULL DEFAULT 'open',
        `priority`   VARCHAR(20)  NOT NULL DEFAULT 'normal',
        `created_at` DATETIME     NOT NULL,
        `updated_at` DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_support_client` (`client_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `support_messages` (
        `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `ticket_id`   INT UNSIGNED NOT NULL,
        `sender_type` VARCHAR(20)  NOT NULL,
        `body`        TEXT         NOT NULL,
        `created_at`  DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_msg_ticket` (`ticket_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $count = (int)$pdo->query('SELECT COUNT(*) FROM coupons')->fetchColumn();
    if ($count === 0) {
        $now = dbNow();
        $pdo->prepare("INSERT INTO coupons (code, title, description, discount_type, discount_value, expires_at, active, max_redemptions, redemption_count, created_at)
            VALUES (?, ?, ?, 'percent', 10, DATE_ADD(NOW(), INTERVAL 90 DAY), 1, 500, 0, ?)")
            ->execute(['BEMVINDO10', 'Boas-vindas 10%', '10% na primeira higienização pelo portal', $now]);
        $pdo->prepare("INSERT INTO coupons (code, title, description, discount_type, discount_value, expires_at, active, max_redemptions, redemption_count, created_at)
            VALUES (?, ?, ?, 'fixed', 30, DATE_ADD(NOW(), INTERVAL 60 DAY), 1, 200, 0, ?)")
            ->execute(['SOFA30', 'R$ 30 no sofá', 'Desconto fixo em limpeza de sofá', $now]);
    }
}

function portalClientRow(PDO $pdo, int $clientId): array {
    $stmt = $pdo->prepare('SELECT * FROM clients WHERE id = ? LIMIT 1');
    $stmt->execute([$clientId]);
    $row = $stmt->fetch();
    if (!$row) jsonRespond(['error' => 'Cliente não encontrado'], 404);
    return $row;
}

function portalFetchAppointments(PDO $pdo, int $clientId): array {
    $client = portalClientRow($pdo, $clientId);
    $visitorId = $client['visitor_id'] ?? null;
    $sql = 'SELECT * FROM appointments WHERE client_id = ?';
    $params = [$clientId];
    if ($visitorId) {
        $sql .= ' OR (client_id IS NULL AND visitor_id = ?)';
        $params[] = $visitorId;
    }
    $sql .= ' ORDER BY date DESC, time ASC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function handleClientDashboard(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $clientId = requireClient();
    $pdo = db();
    ensureClientTables($pdo);
    ensurePortalTables($pdo);
    $client = portalClientRow($pdo, $clientId);
    $rows = portalFetchAppointments($pdo, $clientId);

    $upcoming = [];
    $totals = ['pending' => 0, 'confirmed' => 0, 'completed' => 0, 'cancelled' => 0, 'all' => count($rows)];
    foreach ($rows as $row) {
        $st = normalizeAppointmentStatus((string)($row['status'] ?? 'pending'));
        if (isset($totals[$st])) $totals[$st]++;
        if (!in_array($st, ['completed', 'cancelled'], true)) {
            $upcoming[] = enrichClientAppointment($pdo, $row);
        }
    }
    usort($upcoming, fn($a, $b) => strcmp($a['date'] . $a['time'], $b['date'] . $b['time']));

    $unread = 0;
    try {
        // Contagem única (evita somar duas vezes linhas com visitor_id + client_id)
        $parts = ['client_id = ?'];
        $params = [$clientId];
        if (!empty($client['visitor_id'])) {
            $parts[] = 'visitor_id = ?';
            $params[] = $client['visitor_id'];
        }
        $st = $pdo->prepare('SELECT COUNT(*) FROM client_notifications WHERE read_at IS NULL AND (' . implode(' OR ', $parts) . ')');
        $st->execute($params);
        $unread = (int)$st->fetchColumn();
    } catch (Throwable $e) { /* ignore */ }

    $loyalty = portalLoyaltyPayload($pdo, $clientId, $client);
    $maintenance = portalMaintenanceItems($pdo, $clientId, $client, $rows);

    jsonRespond([
        'client' => decodeClient($client),
        'nextAppointment' => $upcoming[0] ?? null,
        'upcomingCount' => count($upcoming),
        'totals' => $totals,
        'unreadNotifications' => $unread,
        'loyalty' => $loyalty,
        'maintenanceAlerts' => count(array_filter($maintenance, fn($m) => ($m['urgency'] ?? '') !== 'ok')),
    ]);
}

function portalLoyaltyPayload(PDO $pdo, int $clientId, array $client): array {
    if (function_exists('ensureInnovationTables')) ensureInnovationTables($pdo);
    $pieces = [];
    try {
        $st = $pdo->prepare('SELECT * FROM loyalty_pieces WHERE client_id = ? ORDER BY points DESC');
        $st->execute([$clientId]);
        $pieces = $st->fetchAll();
        if (!$pieces && !empty($client['phone'])) {
            $phone = preg_replace('/\D+/', '', (string)$client['phone']);
            if (strlen($phone) >= 10) {
                // Match exato no telefone normalizado (sem LIKE cross-client)
                $st = $pdo->prepare(
                    'SELECT * FROM loyalty_pieces
                     WHERE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone, " ", ""), "-", ""), "(", ""), ")", ""), "+", "") = ?
                     ORDER BY points DESC'
                );
                $st->execute([$phone]);
                $pieces = $st->fetchAll();
                // Vincula ao client_id na primeira leitura
                foreach ($pieces as $p) {
                    if (empty($p['client_id'])) {
                        try {
                            $pdo->prepare('UPDATE loyalty_pieces SET client_id = ? WHERE id = ? AND (client_id IS NULL OR client_id = 0)')
                                ->execute([$clientId, (int)$p['id']]);
                        } catch (Throwable $e) { /* ignore */ }
                    }
                }
            }
        }
    } catch (Throwable $e) {
        return ['points' => 0, 'tier' => 'bronze', 'discountPercent' => 5, 'pieces' => []];
    }
    $points = 0;
    $out = [];
    foreach ($pieces as $p) {
        $points += (int)$p['points'];
        $tier = $p['tier'] ?? (function_exists('innovationLoyaltyTier') ? innovationLoyaltyTier((int)$p['points']) : 'bronze');
        $out[] = [
            'id' => (int)$p['id'],
            'pieceType' => $p['piece_type'],
            'pieceLabel' => $p['piece_label'],
            'points' => (int)$p['points'],
            'tier' => $tier,
            'cleaningsCount' => (int)$p['cleanings_count'],
            'lastServiceDate' => $p['last_service_date'],
        ];
    }
    $tier = function_exists('innovationLoyaltyTier') ? innovationLoyaltyTier($points) : 'bronze';
    $discount = function_exists('innovationLoyaltyDiscount') ? innovationLoyaltyDiscount($tier) : 5;
    return [
        'points' => $points,
        'tier' => $tier,
        'discountPercent' => $discount,
        'pieces' => $out,
    ];
}

function handleClientLoyalty(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $clientId = requireClient();
    $pdo = db();
    ensureClientTables($pdo);
    ensurePortalTables($pdo);
    $client = portalClientRow($pdo, $clientId);
    jsonRespond(portalLoyaltyPayload($pdo, $clientId, $client));
}

function handleClientReviews(string $method): void {
    $clientId = requireClient();
    $pdo = db();
    ensurePortalTables($pdo);

    if ($method === 'GET') {
        $st = $pdo->prepare('SELECT * FROM client_reviews WHERE client_id = ? ORDER BY created_at DESC');
        $st->execute([$clientId]);
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'],
            'appointmentId' => $r['appointment_id'],
            'rating' => (int)$r['rating'],
            'comment' => $r['comment'],
            'createdAt' => $r['created_at'],
            'updatedAt' => $r['updated_at'],
        ], $st->fetchAll()));
    }

    if ($method === 'POST' || $method === 'PUT') {
        rateLimit('client_reviews', 20);
        $b = jsonBody();
        $apptId = san($b['appointmentId'] ?? $b['appointment_id'] ?? null, 64);
        $rating = (int)($b['rating'] ?? 0);
        $comment = san($b['comment'] ?? null, 1000);
        if (!$apptId || $rating < 1 || $rating > 5) jsonRespond(['error' => 'appointmentId e rating (1-5) obrigatórios'], 400);

        $st = $pdo->prepare('SELECT * FROM appointments WHERE id = ? LIMIT 1');
        $st->execute([$apptId]);
        $row = $st->fetch();
        if (!$row || !clientOwnsAppointment($pdo, $clientId, $row)) jsonRespond(['error' => 'Agendamento não encontrado'], 404);
        if (normalizeAppointmentStatus((string)$row['status']) !== 'completed') {
            jsonRespond(['error' => 'Só é possível avaliar serviços concluídos'], 409);
        }

        $now = dbNow();
        if ($method === 'POST') {
            try {
                $pdo->prepare('INSERT INTO client_reviews (client_id, appointment_id, rating, comment, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)')
                    ->execute([$clientId, $apptId, $rating, $comment, $now, $now]);
            } catch (PDOException $e) {
                jsonRespond(['error' => 'Você já avaliou este atendimento'], 409);
            }
            jsonRespond(['ok' => true, 'id' => (int)$pdo->lastInsertId()], 201);
        }

        $pdo->prepare('UPDATE client_reviews SET rating = ?, comment = ?, updated_at = ? WHERE client_id = ? AND appointment_id = ?')
            ->execute([$rating, $comment, $now, $clientId, $apptId]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não suportado'], 405);
}

function handleClientAddresses(string $method): void {
    $clientId = requireClient();
    $pdo = db();
    ensurePortalTables($pdo);

    if ($method === 'GET') {
        $st = $pdo->prepare('SELECT * FROM client_addresses WHERE client_id = ? ORDER BY is_favorite DESC, updated_at DESC');
        $st->execute([$clientId]);
        jsonRespond(array_map('portalDecodeAddress', $st->fetchAll()));
    }

    if ($method === 'POST') {
        rateLimit('client_addresses', 30);
        $b = jsonBody();
        $address = trim(san($b['address'] ?? '', 500) ?? '');
        if ($address === '') jsonRespond(['error' => 'Endereço obrigatório'], 400);
        $now = dbNow();
        $fav = !empty($b['isFavorite'] ?? $b['is_favorite']) ? 1 : 0;
        if ($fav) {
            $pdo->prepare('UPDATE client_addresses SET is_favorite = 0 WHERE client_id = ?')->execute([$clientId]);
        }
        $pdo->prepare('INSERT INTO client_addresses (client_id, label, address, city, state, neighborhood, zip_code, latitude, longitude, is_favorite, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([
                $clientId,
                san($b['label'] ?? 'casa', 40) ?? 'casa',
                $address,
                san($b['city'] ?? null, 100),
                san($b['state'] ?? null, 50),
                san($b['neighborhood'] ?? null, 150),
                san($b['zipCode'] ?? $b['zip_code'] ?? null, 20),
                sanFloat($b['latitude'] ?? null),
                sanFloat($b['longitude'] ?? null),
                $fav,
                $now,
                $now,
            ]);
        jsonRespond(['ok' => true, 'id' => (int)$pdo->lastInsertId()], 201);
    }

    if ($method === 'PUT') {
        rateLimit('client_addresses', 30);
        $b = jsonBody();
        $id = (int)($b['id'] ?? 0);
        if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
        $st = $pdo->prepare('SELECT * FROM client_addresses WHERE id = ? AND client_id = ?');
        $st->execute([$id, $clientId]);
        if (!$st->fetch()) jsonRespond(['error' => 'Endereço não encontrado'], 404);
        $fav = array_key_exists('isFavorite', $b) || array_key_exists('is_favorite', $b)
            ? (!empty($b['isFavorite'] ?? $b['is_favorite']) ? 1 : 0)
            : null;
        if ($fav === 1) {
            $pdo->prepare('UPDATE client_addresses SET is_favorite = 0 WHERE client_id = ?')->execute([$clientId]);
        }
        $pdo->prepare('UPDATE client_addresses SET
            label = COALESCE(?, label),
            address = COALESCE(?, address),
            city = COALESCE(?, city),
            state = COALESCE(?, state),
            neighborhood = COALESCE(?, neighborhood),
            zip_code = COALESCE(?, zip_code),
            latitude = COALESCE(?, latitude),
            longitude = COALESCE(?, longitude),
            is_favorite = COALESCE(?, is_favorite),
            updated_at = ?
            WHERE id = ? AND client_id = ?')
            ->execute([
                isset($b['label']) ? san($b['label'], 40) : null,
                isset($b['address']) ? san($b['address'], 500) : null,
                array_key_exists('city', $b) ? san($b['city'], 100) : null,
                array_key_exists('state', $b) ? san($b['state'], 50) : null,
                array_key_exists('neighborhood', $b) ? san($b['neighborhood'], 150) : null,
                array_key_exists('zipCode', $b) || array_key_exists('zip_code', $b) ? san($b['zipCode'] ?? $b['zip_code'], 20) : null,
                array_key_exists('latitude', $b) ? sanFloat($b['latitude']) : null,
                array_key_exists('longitude', $b) ? sanFloat($b['longitude']) : null,
                $fav,
                dbNow(),
                $id,
                $clientId,
            ]);
        jsonRespond(['ok' => true]);
    }

    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? (jsonBody()['id'] ?? 0));
        if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
        $pdo->prepare('DELETE FROM client_addresses WHERE id = ? AND client_id = ?')->execute([$id, $clientId]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não suportado'], 405);
}

function portalDecodeAddress(array $r): array {
    return [
        'id' => (int)$r['id'],
        'label' => $r['label'],
        'address' => $r['address'],
        'city' => $r['city'],
        'state' => $r['state'],
        'neighborhood' => $r['neighborhood'],
        'zipCode' => $r['zip_code'],
        'latitude' => $r['latitude'] !== null ? (float)$r['latitude'] : null,
        'longitude' => $r['longitude'] !== null ? (float)$r['longitude'] : null,
        'isFavorite' => (bool)(int)$r['is_favorite'],
        'createdAt' => $r['created_at'],
        'updatedAt' => $r['updated_at'],
    ];
}

function handleClientCoupons(string $method): void {
    $clientId = requireClient();
    $pdo = db();
    ensurePortalTables($pdo);

    if ($method === 'GET') {
        $coupons = $pdo->query('SELECT * FROM coupons ORDER BY created_at DESC LIMIT 100')->fetchAll();
        $st = $pdo->prepare('SELECT coupon_id, redeemed_at FROM coupon_redemptions WHERE client_id = ?');
        $st->execute([$clientId]);
        $redeemed = [];
        foreach ($st->fetchAll() as $r) {
            $redeemed[(int)$r['coupon_id']] = $r['redeemed_at'];
        }
        $now = time();
        $out = ['active' => [], 'used' => [], 'expired' => []];
        foreach ($coupons as $c) {
            $item = [
                'id' => (int)$c['id'],
                'code' => $c['code'],
                'title' => $c['title'],
                'description' => $c['description'],
                'discountType' => $c['discount_type'],
                'discountValue' => (float)$c['discount_value'],
                'expiresAt' => $c['expires_at'],
                'active' => (bool)(int)$c['active'],
                'redeemedAt' => $redeemed[(int)$c['id']] ?? null,
            ];
            $expired = $c['expires_at'] && strtotime($c['expires_at']) < $now;
            if (isset($redeemed[(int)$c['id']])) $out['used'][] = $item;
            elseif ($expired || !(int)$c['active']) $out['expired'][] = $item;
            else $out['active'][] = $item;
        }
        jsonRespond($out);
    }

    if ($method === 'POST') {
        rateLimit('client_coupon_redeem', 10);
        $b = jsonBody();
        $code = strtoupper(trim(san($b['code'] ?? '', 40) ?? ''));
        if ($code === '') jsonRespond(['error' => 'Código obrigatório'], 400);
        $st = $pdo->prepare('SELECT * FROM coupons WHERE code = ? LIMIT 1');
        $st->execute([$code]);
        $c = $st->fetch();
        if (!$c || !(int)$c['active']) jsonRespond(['error' => 'Cupom inválido'], 404);
        if ($c['expires_at'] && strtotime($c['expires_at']) < time()) jsonRespond(['error' => 'Cupom expirado'], 410);
        if ($c['max_redemptions'] !== null && (int)$c['redemption_count'] >= (int)$c['max_redemptions']) {
            jsonRespond(['error' => 'Cupom esgotado'], 409);
        }
        try {
            $pdo->prepare('INSERT INTO coupon_redemptions (coupon_id, client_id, redeemed_at) VALUES (?, ?, ?)')
                ->execute([(int)$c['id'], $clientId, dbNow()]);
            $pdo->prepare('UPDATE coupons SET redemption_count = redemption_count + 1 WHERE id = ?')->execute([(int)$c['id']]);
        } catch (PDOException $e) {
            jsonRespond(['error' => 'Você já resgatou este cupom'], 409);
        }
        jsonRespond(['ok' => true, 'code' => $code]);
    }

    jsonRespond(['error' => 'Use GET ou POST'], 405);
}

function handleClientSupport(string $method): void {
    $clientId = requireClient();
    $pdo = db();
    ensurePortalTables($pdo);

    if ($method === 'GET') {
        $st = $pdo->prepare('SELECT * FROM support_tickets WHERE client_id = ? ORDER BY updated_at DESC LIMIT 50');
        $st->execute([$clientId]);
        $tickets = $st->fetchAll();
        $out = [];
        $ticketIds = array_map(static fn($t) => (int)$t['id'], $tickets);
        $messagesByTicket = [];
        if ($ticketIds) {
            $placeholders = implode(',', array_fill(0, count($ticketIds), '?'));
            $ms = $pdo->prepare("SELECT * FROM support_messages WHERE ticket_id IN ($placeholders) ORDER BY created_at ASC");
            $ms->execute($ticketIds);
            foreach ($ms->fetchAll() as $msg) {
                $tid = (int)$msg['ticket_id'];
                $messagesByTicket[$tid][] = [
                    'id' => (int)$msg['id'],
                    'senderType' => $msg['sender_type'],
                    'body' => $msg['body'],
                    'createdAt' => $msg['created_at'],
                ];
            }
        }
        foreach ($tickets as $t) {
            $tid = (int)$t['id'];
            $out[] = [
                'id' => $tid,
                'subject' => $t['subject'],
                'status' => $t['status'],
                'priority' => $t['priority'],
                'createdAt' => $t['created_at'],
                'updatedAt' => $t['updated_at'],
                'messages' => $messagesByTicket[$tid] ?? [],
            ];
        }
        jsonRespond($out);
    }

    if ($method === 'POST') {
        rateLimit('client_support', 15);
        $b = jsonBody();
        $ticketId = (int)($b['ticketId'] ?? $b['ticket_id'] ?? 0);
        $body = trim((string)($b['body'] ?? $b['message'] ?? ''));
        $subject = trim(san($b['subject'] ?? '', 200) ?? '');

        if ($ticketId > 0) {
            if ($body === '') jsonRespond(['error' => 'Mensagem obrigatória'], 400);
            $st = $pdo->prepare('SELECT * FROM support_tickets WHERE id = ? AND client_id = ?');
            $st->execute([$ticketId, $clientId]);
            $t = $st->fetch();
            if (!$t) jsonRespond(['error' => 'Chamado não encontrado'], 404);
            if ($t['status'] === 'closed') jsonRespond(['error' => 'Chamado fechado'], 409);
            $pdo->prepare('INSERT INTO support_messages (ticket_id, sender_type, body, created_at) VALUES (?, ?, ?, ?)')
                ->execute([$ticketId, 'client', san($body, 4000), dbNow()]);
            $pdo->prepare('UPDATE support_tickets SET status = ?, updated_at = ? WHERE id = ?')
                ->execute(['pending', dbNow(), $ticketId]);
            jsonRespond(['ok' => true, 'ticketId' => $ticketId]);
        }

        if ($subject === '' || $body === '') jsonRespond(['error' => 'Assunto e mensagem obrigatórios'], 400);
        $now = dbNow();
        $pdo->prepare('INSERT INTO support_tickets (client_id, subject, status, priority, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$clientId, $subject, 'open', san($b['priority'] ?? 'normal', 20) ?? 'normal', $now, $now]);
        $tid = (int)$pdo->lastInsertId();
        $pdo->prepare('INSERT INTO support_messages (ticket_id, sender_type, body, created_at) VALUES (?, ?, ?, ?)')
            ->execute([$tid, 'client', san($body, 4000), $now]);
        jsonRespond(['ok' => true, 'ticketId' => $tid], 201);
    }

    jsonRespond(['error' => 'Use GET ou POST'], 405);
}

function handleClientAi(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    $clientId = requireClient();
    rateLimit('client_ai', 20);
    $b = jsonBody();
    $message = trim((string)($b['message'] ?? ''));
    if ($message === '' || mb_strlen($message) > 2000) jsonRespond(['error' => 'Mensagem inválida'], 400);

    $pdo = db();
    ensureClientTables($pdo);
    $client = portalClientRow($pdo, $clientId);
    $rows = portalFetchAppointments($pdo, $clientId);
    $loyalty = portalLoyaltyPayload($pdo, $clientId, $client);

    $summary = [];
    foreach (array_slice($rows, 0, 8) as $row) {
        $services = decodeJsonOrArray($row['services'] ?? '[]');
        $summary[] = sprintf(
            '%s %s — %s (%s)',
            $row['date'],
            $row['time'],
            is_array($services) ? implode(', ', $services) : '',
            normalizeAppointmentStatus((string)$row['status'])
        );
    }

    $maskedName = function_exists('innovationMaskName') ? innovationMaskName($client['name'] ?? '') : 'Cliente';
    $system = "Você é o Assistente do Portal do Cliente da Auto Limpeza Pro (higienização de estofados em MG). "
        . "Responda em português do Brasil, de forma objetiva e amigável. "
        . "NÃO invente preços fechados. NÃO peça dados sensíveis. "
        . "Contexto mascarado do cliente: nome={$maskedName}; pontos_fidelidade={$loyalty['points']}; tier={$loyalty['tier']}. "
        . "Agendamentos recentes:\n" . (implode("\n", $summary) ?: 'nenhum');

    if (!function_exists('aiGatewayGenerateText')) {
        jsonRespond(['reply' => 'Assistente temporariamente indisponível. Fale conosco pelo WhatsApp.', 'ok' => false], 503);
    }
    $r = aiGatewayGenerateText($system, $message, 512, 'client_portal');
    if (!$r['ok'] || empty($r['text'])) {
        jsonRespond([
            'ok' => false,
            'reply' => 'Não consegui responder agora. Tente novamente ou fale pelo WhatsApp (31) 98025-2882.',
            'error' => $r['error'] ?? null,
        ], 503);
    }
    jsonRespond(['ok' => true, 'reply' => $r['text']]);
}

function portalMaintenanceItems(PDO $pdo, int $clientId, array $client, array $apptRows): array {
    $intervals = [
        'sofa' => 6, 'sofá' => 6, 'estofado' => 6,
        'colchao' => 12, 'colchão' => 12,
        'carro' => 3, 'veiculo' => 3, 'veículo' => 3,
        'tapete' => 8, 'cadeira' => 9,
    ];
    $items = [];
    $seen = [];

    try {
        if (function_exists('ensureInnovationTables')) ensureInnovationTables($pdo);
        $st = $pdo->prepare('SELECT * FROM loyalty_pieces WHERE client_id = ? OR phone = ?');
        $st->execute([$clientId, $client['phone'] ?? '']);
        foreach ($st->fetchAll() as $p) {
            $type = strtolower((string)$p['piece_type']);
            $months = 6;
            foreach ($intervals as $k => $m) {
                if (str_contains($type, $k)) { $months = $m; break; }
            }
            $last = $p['last_service_date'] ?: null;
            $due = $last ? date('Y-m-d', strtotime($last . " +{$months} months")) : null;
            $urgency = 'ok';
            if ($due) {
                $diff = (int)((strtotime($due) - time()) / 86400);
                if ($diff < 0) $urgency = 'overdue';
                elseif ($diff <= 30) $urgency = 'soon';
            }
            $key = $type . '|' . $p['piece_label'];
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $items[] = [
                'pieceType' => $p['piece_type'],
                'pieceLabel' => $p['piece_label'],
                'lastServiceDate' => $last,
                'nextDueDate' => $due,
                'intervalMonths' => $months,
                'urgency' => $urgency,
                'message' => $urgency === 'overdue'
                    ? 'Manutenção recomendada — prazo ultrapassado'
                    : ($urgency === 'soon' ? 'Manutenção recomendada em breve' : 'Em dia'),
            ];
        }
    } catch (Throwable $e) { /* ignore */ }

    if (!$items) {
        foreach ($apptRows as $row) {
            if (normalizeAppointmentStatus((string)$row['status']) !== 'completed') continue;
            $services = decodeJsonOrArray($row['services'] ?? '[]');
            foreach ((array)$services as $svc) {
                $svcL = mb_strtolower((string)$svc);
                $months = 6;
                foreach ($intervals as $k => $m) {
                    if (str_contains($svcL, $k)) { $months = $m; break; }
                }
                $due = date('Y-m-d', strtotime($row['date'] . " +{$months} months"));
                $diff = (int)((strtotime($due) - time()) / 86400);
                $urgency = $diff < 0 ? 'overdue' : ($diff <= 30 ? 'soon' : 'ok');
                $items[] = [
                    'pieceType' => 'servico',
                    'pieceLabel' => $svc,
                    'lastServiceDate' => $row['date'],
                    'nextDueDate' => $due,
                    'intervalMonths' => $months,
                    'urgency' => $urgency,
                    'message' => $urgency === 'overdue' ? 'Reagendar higienização' : ($urgency === 'soon' ? 'Próxima manutenção em breve' : 'Em dia'),
                ];
            }
            if (count($items) >= 8) break;
        }
    }

    return $items;
}

function handleClientMaintenance(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $clientId = requireClient();
    $pdo = db();
    ensureClientTables($pdo);
    ensurePortalTables($pdo);
    $client = portalClientRow($pdo, $clientId);
    $rows = portalFetchAppointments($pdo, $clientId);
    jsonRespond(['items' => portalMaintenanceItems($pdo, $clientId, $client, $rows)]);
}

function handleClientRecommendations(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $clientId = requireClient();
    $pdo = db();
    $rows = portalFetchAppointments($pdo, $clientId);
    $counts = [];
    $lastBy = [];
    foreach ($rows as $row) {
        foreach ((array)decodeJsonOrArray($row['services'] ?? '[]') as $svc) {
            $k = (string)$svc;
            $counts[$k] = ($counts[$k] ?? 0) + 1;
            $lastBy[$k] = max($lastBy[$k] ?? '', (string)$row['date']);
        }
    }
    $recs = [];
    $catalog = [
        ['title' => 'Higienização de Sofá', 'reason' => 'Manutenção preventiva a cada 6 meses', 'serviceHint' => 'sofá'],
        ['title' => 'Limpeza de Colchão', 'reason' => 'Reduz ácaros e melhora o sono', 'serviceHint' => 'colchão'],
        ['title' => 'Higienização Automotiva', 'reason' => 'Ideal a cada 3 meses para quem usa o carro diariamente', 'serviceHint' => 'carro'],
        ['title' => 'Impermeabilização', 'reason' => 'Protege o estofado após a limpeza', 'serviceHint' => 'impermeabil'],
    ];
    foreach ($catalog as $c) {
        $matched = null;
        foreach ($counts as $svc => $n) {
            if (str_contains(mb_strtolower($svc), $c['serviceHint'])) {
                $matched = $svc;
                break;
            }
        }
        $recs[] = [
            'title' => $c['title'],
            'reason' => $matched
                ? "Você já fez \"{$matched}\" — vale repetir na janela ideal."
                : $c['reason'],
            'basedOnHistory' => (bool)$matched,
            'lastDate' => $matched ? ($lastBy[$matched] ?? null) : null,
            'cta' => 'Agendar',
        ];
    }
    jsonRespond(['items' => $recs]);
}

function handleClientGallery(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $clientId = requireClient();
    $pdo = db();
    ensurePortalTables($pdo);
    $items = [];

    foreach (portalFetchAppointments($pdo, $clientId) as $row) {
        $photos = [];
        if (!empty($row['photo_urls'])) {
            $decoded = is_string($row['photo_urls']) ? json_decode($row['photo_urls'], true) : $row['photo_urls'];
            if (is_array($decoded)) $photos = $decoded;
        }
        foreach ($photos as $p) {
            $url = is_array($p) ? ($p['url'] ?? $p['after'] ?? $p['before'] ?? null) : $p;
            if (!$url) continue;
            $items[] = [
                'url' => $url,
                'before' => is_array($p) ? ($p['before'] ?? null) : null,
                'after' => is_array($p) ? ($p['after'] ?? null) : null,
                'appointmentId' => $row['id'],
                'date' => $row['date'],
                'services' => decodeJsonOrArray($row['services'] ?? '[]'),
            ];
        }
    }

    try {
        $st = $pdo->prepare("SELECT * FROM quote_photos WHERE client_id = ? OR (entity_type = 'client' AND entity_id = ?) ORDER BY created_at DESC LIMIT 100");
        $st->execute([$clientId, 'client_' . $clientId]);
        foreach ($st->fetchAll() as $ph) {
            $items[] = [
                'url' => $ph['url'],
                'before' => null,
                'after' => $ph['url'],
                'appointmentId' => null,
                'date' => substr((string)$ph['created_at'], 0, 10),
                'services' => [],
            ];
        }
    } catch (Throwable $e) { /* ignore */ }

    jsonRespond(['items' => $items]);
}
