<?php
/**
 * Capitão Guardião — handlers HTTP (admin only)
 */

require_once __DIR__ . '/guardiao-system-observer.php';
require_once __DIR__ . '/guardiao-diagnostic-engine.php';
require_once __DIR__ . '/guardiao-autonomy.php';

function ensureGuardiaoTables(PDO $pdo): void
{
    static $verified = false;
    if ($verified) return;

    $required = ['guardiao_diagnostics', 'guardiao_observations', 'guardiao_knowledge'];
    $tableOk = static function (string $table) use ($pdo): bool {
        try {
            $pdo->query('SELECT 1 FROM `' . str_replace('`', '', $table) . '` LIMIT 1');
            return true;
        } catch (Throwable $e) {
            return false;
        }
    };

    $allOk = true;
    foreach ($required as $t) {
        if (!$tableOk($t)) {
            $allOk = false;
            break;
        }
    }

    if (!$allOk) {
        alpRunSqlMigration($pdo, __DIR__ . '/migrations/guardiao_v1.sql');
    }

    $allOk = true;
    foreach ($required as $t) {
        if (!$tableOk($t)) {
            $allOk = false;
            break;
        }
    }

    if ($allOk) {
        if (function_exists('ensureAiGatewayTables')) {
            ensureAiGatewayTables($pdo);
        }
        guardiaoSeedAiRouting($pdo);
        $verified = true;
    }
}

function guardiaoSeedAiRouting(PDO $pdo): void
{
    if (!function_exists('dbNow')) return;

    $geminiId = null;
    try {
        $geminiId = (int) $pdo->query(
            "SELECT id FROM ai_providers WHERE enabled = 1 AND provider_type = 'gemini' ORDER BY priority ASC LIMIT 1"
        )->fetchColumn() ?: null;
    } catch (Throwable $e) {
        // ai_providers pode não existir ainda
    }

    $keys = ['guardiao', 'guardiao_technical', 'guardiao_explain', 'guardiao_analysis'];
    $upsert = $pdo->prepare(
        'INSERT INTO ai_module_routing (module_key, strategy, preferred_provider_id, cache_ttl_sec, updated_at)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           preferred_provider_id = COALESCE(VALUES(preferred_provider_id), preferred_provider_id),
           updated_at = VALUES(updated_at)'
    );
    $now = dbNow();
    foreach ($keys as $key) {
        $ttl = $key === 'guardiao' ? 120 : 60;
        $upsert->execute([$key, 'priority', $geminiId, $ttl, $now]);
    }
}

function guardiaoAdminEmail(): ?string
{
    if (function_exists('capitaoAdminEmail')) {
        return capitaoAdminEmail();
    }
    return null;
}

function handleGuardiaoHealth(string $method): void
{
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);

    $pdo = db();
    ensureGuardiaoTables($pdo);

    $observation = SystemObserver::observe($pdo);
    // Reutiliza diagnostico já coletado no observe (evita 2ª execução + DDL duplicado)
    $diag = $observation['diagnostico'] ?? (function_exists('runSystemDiagnostico') ? runSystemDiagnostico($pdo) : ['checks' => []]);
    $ncHealth = class_exists('NotificationCenter') ? NotificationCenter::getSystemHealth($pdo) : [];
    if (is_array($ncHealth) && $ncHealth !== [] && !isset($ncHealth['overall']) && !isset($ncHealth['status'])) {
        $worst = 'green';
        $rank = ['green' => 0, 'yellow' => 1, 'red' => 2];
        foreach ($ncHealth as $channel) {
            if (!is_array($channel)) continue;
            $st = (string) ($channel['status'] ?? 'green');
            if (($rank[$st] ?? 0) > ($rank[$worst] ?? 0)) {
                $worst = $st;
            }
        }
        $ncHealth['overall'] = $worst;
        $ncHealth['status'] = $worst;
    }
    $cronHealth = function_exists('getCronHealth') ? getCronHealth($pdo) : [];
    $aiStatus = class_exists('AIProviderFactory') ? AIProviderFactory::status() : null;
    $suggestions = class_exists('NotificationCenter') ? NotificationCenter::getCapitaoSuggestions($pdo) : [];
    $proposed = GuardiaoAutonomy::proposeActions($observation);
    $autonomy = GuardiaoAutonomy::autonomyStatus($pdo);
    $scoreTrend = GuardiaoAutonomy::recentObservations($pdo, 12);

    jsonRespond([
        'health'              => $observation,
        'diagnostico'         => $diag,
        'notificationCenter'  => $ncHealth,
        'cron'                => $cronHealth,
        'aiProviders'         => $aiStatus,
        'suggestions'         => $suggestions,
        'autonomy'            => $autonomy,
        'proposedActions'     => $proposed,
        'scoreTrend'          => $scoreTrend,
        'generatedAt'         => date('c'),
    ]);
}

function handleGuardiaoObserve(string $method): void
{
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);

    $pdo = db();
    ensureGuardiaoTables($pdo);

    $snapshot = SystemObserver::observe($pdo);

    if (!empty($_GET['persist'])) {
        $stmt = $pdo->prepare('INSERT INTO guardiao_observations (snapshot_json, created_at) VALUES (?, ?)');
        $stmt->execute([json_encode($snapshot, JSON_UNESCAPED_UNICODE), dbNow()]);
    }

    jsonRespond($snapshot);
}

function handleGuardiaoDiagnose(string $method): void
{
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('guardiao_diagnose', 10);

    $pdo = db();
    ensureGuardiaoTables($pdo);
    $b = jsonBody();

    $scope = san($b['scope'] ?? 'general', 40) ?? 'general';
    $query = isset($b['query']) ? san($b['query'], 2000) : null;
    if (!empty($b['module'])) {
        $scope = san($b['module'], 40) ?? $scope;
    }

    try {
        $investigation = GuardiaoDiagnosticEngine::investigate($pdo, $scope, $query);
        $report = GuardiaoDiagnosticEngine::generateReport($pdo, $investigation);
    } catch (Throwable $e) {
        jsonRespond(['error' => 'Falha no motor de diagnóstico: ' . $e->getMessage()], 500);
    }

    $diagnosticId = 0;
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO guardiao_diagnostics (scope, query, report_json, confidence, evidence_json, admin_email, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $scope,
            $query,
            json_encode($report, JSON_UNESCAPED_UNICODE),
            (int) ($report['confidence'] ?? $investigation['confidence'] ?? 0),
            json_encode($investigation['steps']['evidence'] ?? [], JSON_UNESCAPED_UNICODE),
            guardiaoAdminEmail(),
            dbNow(),
        ]);
        $diagnosticId = (int) $pdo->lastInsertId();
    } catch (Throwable $e) {
        jsonRespond([
            'error'         => 'Diagnóstico gerado, mas falhou ao salvar histórico. Execute install.php?step=repair.',
            'detail'        => $e->getMessage(),
            'investigation' => $investigation,
            'report'        => $report,
        ], 500);
    }

    jsonRespond([
        'investigation' => $investigation,
        'report'        => $report,
        'diagnosticId'  => $diagnosticId,
        'aiUsed'        => !empty($report['aiUsed']),
        'aiError'       => $report['aiError'] ?? null,
    ]);
}

function handleGuardiaoAudit(string $method): void
{
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('guardiao_audit', 8);

    $pdo = db();
    ensureGuardiaoTables($pdo);
    $b = jsonBody();
    $type = san($b['type'] ?? 'general', 40) ?? 'general';

    try {
        $result = GuardiaoDiagnosticEngine::runAudit($pdo, $type);
    } catch (Throwable $e) {
        jsonRespond(['error' => 'Falha na auditoria: ' . $e->getMessage()], 500);
    }

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO guardiao_diagnostics (scope, query, report_json, confidence, evidence_json, admin_email, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $type,
            'audit:' . $type,
            json_encode($result['report'] ?? [], JSON_UNESCAPED_UNICODE),
            (int) ($result['report']['confidence'] ?? 0),
            json_encode($result['investigation']['steps']['evidence'] ?? [], JSON_UNESCAPED_UNICODE),
            guardiaoAdminEmail(),
            dbNow(),
        ]);
        $result['diagnosticId'] = (int) $pdo->lastInsertId();
    } catch (Throwable $e) {
        jsonRespond([
            'error'  => 'Auditoria concluída, mas falhou ao salvar histórico. Execute install.php?step=repair.',
            'detail' => $e->getMessage(),
            'report' => $result['report'] ?? null,
        ], 500);
    }

    $result['aiUsed'] = !empty($result['report']['aiUsed']);
    $result['aiError'] = $result['report']['aiError'] ?? null;
    jsonRespond($result);
}

function handleGuardiaoKnowledge(string $method): void
{
    requireAdmin();
    $pdo = db();
    ensureGuardiaoTables($pdo);

    if ($method === 'GET') {
        $module = san($_GET['module'] ?? null, 40);
        $q = san($_GET['q'] ?? null, 200);
        $sql = 'SELECT id, problem_key, problem, resolution, module, impact, created_at FROM guardiao_knowledge WHERE 1=1';
        $params = [];
        if ($module) {
            $sql .= ' AND module = ?';
            $params[] = $module;
        }
        if ($q) {
            $sql .= ' AND (problem LIKE ? OR resolution LIKE ? OR problem_key LIKE ?)';
            $like = '%' . $q . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        $sql .= ' ORDER BY id DESC LIMIT 100';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        jsonRespond(['items' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($method === 'POST') {
        rateLimit('guardiao_knowledge', 20);
        $b = jsonBody();
        $action = san($b['action'] ?? 'create', 20) ?? 'create';

        if ($action === 'delete' && !empty($b['id'])) {
            $pdo->prepare('DELETE FROM guardiao_knowledge WHERE id = ?')->execute([(int) $b['id']]);
            jsonRespond(['ok' => true]);
        }

        $problem = san($b['problem'] ?? '', 2000);
        $resolution = san($b['resolution'] ?? '', 4000);
        if (!$problem || !$resolution) {
            jsonRespond(['error' => 'problem e resolution são obrigatórios'], 400);
        }

        $problemKey = san($b['problem_key'] ?? null, 120)
            ?? ('kb_' . substr(md5($problem . $resolution), 0, 16));
        $module = san($b['module'] ?? null, 40);
        $impact = san($b['impact'] ?? 'medium', 20) ?? 'medium';
        $now = dbNow();

        if (!empty($b['id'])) {
            $pdo->prepare(
                'UPDATE guardiao_knowledge SET problem_key=?, problem=?, resolution=?, module=?, impact=? WHERE id=?'
            )->execute([$problemKey, $problem, $resolution, $module, $impact, (int) $b['id']]);
            jsonRespond(['ok' => true, 'id' => (int) $b['id']]);
        }

        $pdo->prepare(
            'INSERT INTO guardiao_knowledge (problem_key, problem, resolution, module, impact, created_at)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE problem=VALUES(problem), resolution=VALUES(resolution), module=VALUES(module), impact=VALUES(impact)'
        )->execute([$problemKey, $problem, $resolution, $module, $impact, $now]);

        jsonRespond(['ok' => true, 'id' => (int) $pdo->lastInsertId(), 'problem_key' => $problemKey]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleGuardiaoHistory(string $method): void
{
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);

    $pdo = db();
    ensureGuardiaoTables($pdo);

    $kind = san($_GET['kind'] ?? 'diagnostics', 40) ?? 'diagnostics';
    if ($kind === 'observations') {
        $limit = min(50, max(1, sanInt($_GET['limit'] ?? 30)));
        $items = GuardiaoAutonomy::recentObservations($pdo, $limit);
        jsonRespond([
            'items' => $items,
            'total' => count($items),
            'kind'  => 'observations',
        ]);
    }

    $limit = min(50, max(1, sanInt($_GET['limit'] ?? 25)));
    $scope = san($_GET['scope'] ?? null, 40);

    $sql = 'SELECT id, scope, query, report_json, confidence, evidence_json, admin_email, created_at
            FROM guardiao_diagnostics WHERE 1=1';
    $params = [];
    if ($scope) {
        $sql .= ' AND scope = ?';
        $params[] = $scope;
    }
    $sql .= ' ORDER BY id DESC LIMIT ' . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as &$row) {
        $row['report'] = json_decode((string) ($row['report_json'] ?? '{}'), true);
        $row['evidence'] = json_decode((string) ($row['evidence_json'] ?? '[]'), true);
        unset($row['report_json'], $row['evidence_json']);
    }

    jsonRespond(['items' => $rows, 'total' => count($rows), 'kind' => 'diagnostics']);
}

function handleGuardiaoActions(string $method): void
{
    requireAdmin();
    $pdo = db();
    ensureGuardiaoTables($pdo);

    if ($method === 'GET') {
        jsonRespond([
            'allowlist' => GuardiaoAutonomy::catalog(),
            'autonomy'  => GuardiaoAutonomy::autonomyStatus($pdo),
            'proposed'  => GuardiaoAutonomy::proposeActions(SystemObserver::observe($pdo)),
        ]);
    }

    if ($method !== 'POST') jsonRespond(['error' => 'Use GET ou POST'], 405);
    rateLimit('guardiao_actions', 20);

    $b = jsonBody();
    $action = san($b['action'] ?? '', 60);
    if (!$action) {
        jsonRespond(['error' => 'action é obrigatório'], 400);
    }

    $result = GuardiaoAutonomy::execute($pdo, $action, 'manual');
    if (empty($result['ok'])) {
        jsonRespond($result, 400);
    }
    jsonRespond($result);
}

function handleGuardiaoModuleDetail(string $method): void
{
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);

    $module = san($_GET['module'] ?? '', 40);
    if (!$module) jsonRespond(['error' => 'Parâmetro module obrigatório'], 400);

    $pdo = db();
    ensureGuardiaoTables($pdo);

    jsonRespond(SystemObserver::moduleDetail($pdo, $module));
}
