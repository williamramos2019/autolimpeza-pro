<?php
/**
 * CMS Blog — Handlers para categorias, tags, dicas, mídia, blocos e comentários.
 */

// ── Categorias ──────────────────────────────────────────────────────────────
function handleBlogCategories(string $method): void {
    ensureCmsMigrated();
    $pdo = db();

    if (!cmsTableExists($pdo, 'blog_categories')) {
        if ($method === 'GET') {
            jsonRespond([]);
        }
        jsonRespond(['error' => 'Tabela blog_categories ausente. Execute install.php?step=repair'], 503);
    }

    if ($method === 'GET') {
        if (function_exists('isAdmin') && isAdmin()) {
            $rows = $pdo->query('SELECT * FROM blog_categories ORDER BY sort_order ASC, name ASC')->fetchAll();
        } else {
            $stmt = $pdo->query("SELECT * FROM blog_categories WHERE active = 1 ORDER BY sort_order ASC, name ASC");
            $rows = $stmt ? $stmt->fetchAll() : [];
        }
        jsonRespond(array_map('decodeBlogCategory', $rows));
    }

    requireCmsManage();
    $b = jsonBody();
    $now = dbNow();

    if ($method === 'POST') {
        $name = san($b['name'] ?? null, 200);
        if (!$name) jsonRespond(['error' => 'Nome obrigatório'], 400);
        $slug = san($b['slug'] ?? null, 120) ?? slugify($name);
        $pdo->prepare(
            'INSERT INTO blog_categories (slug, name, icon, color, description, meta_title, meta_description, canonical, og_image, sort_order, active, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([
            $slug, $name,
            san($b['icon'] ?? 'BookOpen', 50),
            san($b['color'] ?? '#1FB1F9', 20),
            $b['description'] ?? null,
            san($b['metaTitle'] ?? null, 500),
            $b['metaDescription'] ?? null,
            san($b['canonical'] ?? null, 500),
            san($b['ogImage'] ?? null, 500),
            sanInt($b['sortOrder'] ?? 0),
            sanBool($b['active'] ?? true) ? 1 : 0,
            $now, $now,
        ]);
        $id = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT * FROM blog_categories WHERE id = ?');
        $stmt->execute([$id]);
        jsonRespond(decodeBlogCategory($stmt->fetch()));
    }

    if ($method === 'PUT') {
        $id = sanInt($_GET['id'] ?? 0);
        if (!$id) jsonRespond(['error' => 'ID obrigatório'], 400);
        $pdo->prepare(
            'UPDATE blog_categories SET slug=?, name=?, icon=?, color=?, description=?, meta_title=?, meta_description=?, canonical=?, og_image=?, sort_order=?, active=?, updated_at=? WHERE id=?'
        )->execute([
            san($b['slug'] ?? null, 120),
            san($b['name'] ?? null, 200),
            san($b['icon'] ?? 'BookOpen', 50),
            san($b['color'] ?? '#1FB1F9', 20),
            $b['description'] ?? null,
            san($b['metaTitle'] ?? null, 500),
            $b['metaDescription'] ?? null,
            san($b['canonical'] ?? null, 500),
            san($b['ogImage'] ?? null, 500),
            sanInt($b['sortOrder'] ?? 0),
            sanBool($b['active'] ?? true) ? 1 : 0,
            $now, $id,
        ]);
        $stmt = $pdo->prepare('SELECT * FROM blog_categories WHERE id = ?');
        $stmt->execute([$id]);
        jsonRespond(decodeBlogCategory($stmt->fetch()));
    }

    if ($method === 'DELETE') {
        requireCmsAdmin();
        $id = sanInt($_GET['id'] ?? 0);
        if (!$id) jsonRespond(['error' => 'ID obrigatório'], 400);
        $pdo->prepare('DELETE FROM blog_categories WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function decodeBlogCategory(array $r): array {
    return [
        'id' => (int)$r['id'],
        'slug' => $r['slug'],
        'name' => $r['name'],
        'icon' => $r['icon'],
        'color' => $r['color'],
        'description' => $r['description'],
        'metaTitle' => $r['meta_title'],
        'metaDescription' => $r['meta_description'],
        'canonical' => $r['canonical'],
        'ogImage' => $r['og_image'],
        'sortOrder' => (int)$r['sort_order'],
        'active' => (bool)$r['active'],
    ];
}

// ── Tags ────────────────────────────────────────────────────────────────────
function handleBlogTags(string $method): void {
    ensureCmsMigrated();
    $pdo = db();

    if ($method === 'GET') {
        $rows = $pdo->query('SELECT * FROM blog_tags ORDER BY name ASC')->fetchAll();
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'], 'slug' => $r['slug'], 'name' => $r['name'],
        ], $rows));
    }

    requireCmsManage();
    $b = jsonBody();
    $now = dbNow();

    if ($method === 'POST') {
        $name = san($b['name'] ?? null, 200);
        if (!$name) jsonRespond(['error' => 'Nome obrigatório'], 400);
        $slug = san($b['slug'] ?? null, 120) ?? slugify($name);
        $pdo->prepare('INSERT INTO blog_tags (slug, name, created_at) VALUES (?, ?, ?)')->execute([$slug, $name, $now]);
        jsonRespond(['id' => (int)$pdo->lastInsertId(), 'slug' => $slug, 'name' => $name]);
    }

    if ($method === 'PUT') {
        $id = sanInt($_GET['id'] ?? 0);
        if (!$id) jsonRespond(['error' => 'ID obrigatório'], 400);
        $pdo->prepare('UPDATE blog_tags SET slug=?, name=? WHERE id=?')->execute([
            san($b['slug'] ?? null, 120), san($b['name'] ?? null, 200), $id,
        ]);
        jsonRespond(['ok' => true, 'id' => $id]);
    }

    if ($method === 'DELETE') {
        requireCmsAdmin();
        $id = sanInt($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM blog_post_tags WHERE tag_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM blog_tags WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

// ── Dicas rápidas ───────────────────────────────────────────────────────────
function handleBlogTips(string $method): void {
    ensureCmsMigrated();
    $pdo = db();

    if ($method === 'GET') {
        $status = san($_GET['status'] ?? null, 20);
        $sql = 'SELECT t.*, c.name AS category_name FROM blog_tips t LEFT JOIN blog_categories c ON c.id = t.category_id';
        if ($status) {
            if (!isAdmin() && $status !== 'published') {
                jsonRespond(['error' => 'Acesso negado'], 403);
            }
            $stmt = $pdo->prepare($sql . ' WHERE t.status = ? ORDER BY t.sort_order ASC, t.id DESC');
            $stmt->execute([$status]);
            $rows = $stmt->fetchAll();
        } elseif (!isAdmin()) {
            $stmt = $pdo->prepare($sql . " WHERE t.status = 'published' ORDER BY t.sort_order ASC, t.id DESC");
            $stmt->execute();
            $rows = $stmt->fetchAll();
        } else {
            $rows = $pdo->query($sql . ' ORDER BY t.sort_order ASC, t.id DESC')->fetchAll();
        }
        if (!$status || $status === 'published') {
            header('Cache-Control: public, max-age=120, stale-while-revalidate=300');
        }
        jsonRespond(array_map('decodeBlogTip', $rows));
    }

    requireCmsWrite();
    $b = jsonBody();
    $now = dbNow();

    if ($method === 'POST') {
        $title = san($b['title'] ?? null, 500);
        if (!$title) jsonRespond(['error' => 'Título obrigatório'], 400);
        $slug = san($b['slug'] ?? null, 200) ?? slugify($title);
        $pdo->prepare(
            'INSERT INTO blog_tips (slug, title, image_url, text, category_id, featured, status, sort_order, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([
            $slug, $title,
            san($b['imageUrl'] ?? null, 500),
            sanitizeCmsHtml($b['text'] ?? '') ?? '',
            sanInt($b['categoryId'] ?? 0) ?: null,
            sanBool($b['featured'] ?? false) ? 1 : 0,
            san($b['status'] ?? 'published', 20),
            sanInt($b['sortOrder'] ?? 0),
            $now, $now,
        ]);
        $id = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT t.*, c.name AS category_name FROM blog_tips t LEFT JOIN blog_categories c ON c.id = t.category_id WHERE t.id = ?');
        $stmt->execute([$id]);
        jsonRespond(decodeBlogTip($stmt->fetch()));
    }

    if ($method === 'PUT') {
        $id = sanInt($_GET['id'] ?? 0);
        if (!$id) jsonRespond(['error' => 'ID obrigatório'], 400);
        $pdo->prepare(
            'UPDATE blog_tips SET slug=?, title=?, image_url=?, text=?, category_id=?, featured=?, status=?, sort_order=?, updated_at=? WHERE id=?'
        )->execute([
            san($b['slug'] ?? null, 200),
            san($b['title'] ?? null, 500),
            san($b['imageUrl'] ?? null, 500),
            sanitizeCmsHtml($b['text'] ?? ''),
            sanInt($b['categoryId'] ?? 0) ?: null,
            sanBool($b['featured'] ?? false) ? 1 : 0,
            san($b['status'] ?? 'published', 20),
            sanInt($b['sortOrder'] ?? 0),
            $now, $id,
        ]);
        $stmt = $pdo->prepare('SELECT t.*, c.name AS category_name FROM blog_tips t LEFT JOIN blog_categories c ON c.id = t.category_id WHERE t.id = ?');
        $stmt->execute([$id]);
        jsonRespond(decodeBlogTip($stmt->fetch()));
    }

    if ($method === 'DELETE') {
        requireCmsManage();
        $id = sanInt($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM blog_tips WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function decodeBlogTip(array $r): array {
    return [
        'id' => (int)$r['id'],
        'slug' => $r['slug'],
        'title' => $r['title'],
        'imageUrl' => $r['image_url'],
        'text' => $r['text'],
        'categoryId' => $r['category_id'] ? (int)$r['category_id'] : null,
        'categoryName' => $r['category_name'] ?? null,
        'featured' => (bool)$r['featured'],
        'status' => $r['status'],
        'sortOrder' => (int)$r['sort_order'],
    ];
}

// ── Biblioteca de mídia ─────────────────────────────────────────────────────
function handleMediaLibrary(string $method): void {
    ensureCmsMigrated();
    $pdo = db();

    if (!cmsTableExists($pdo, 'media_library')) {
        if ($method === 'GET') {
            jsonRespond([]);
        }
        if ($method === 'POST') {
            requireCmsWrite();
            jsonRespond(['error' => 'Biblioteca de mídia indisponível. Execute install.php?step=repair'], 503);
        }
        if ($method === 'DELETE') {
            requireCmsManage();
            jsonRespond(['error' => 'Biblioteca de mídia indisponível'], 503);
        }
        jsonRespond(['error' => 'Método não permitido'], 405);
    }

    if ($method === 'GET') {
        requireCmsWrite(); // biblioteca não é pública — evita enumeração de mídia
        ensureMediaLibraryAiColumns($pdo);
        try {
            $folder = san($_GET['folder'] ?? null, 50);
            $q = san($_GET['q'] ?? null, 100);
            $sql = 'SELECT * FROM media_library WHERE 1=1';
            $params = [];
            if ($folder) { $sql .= ' AND folder = ?'; $params[] = $folder; }
            if ($q) { $sql .= ' AND (original_name LIKE ? OR filename LIKE ?)'; $params[] = "%{$q}%"; $params[] = "%{$q}%"; }
            $sql .= ' ORDER BY created_at DESC LIMIT 200';
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            jsonRespond(array_map('decodeMediaItem', $stmt->fetchAll()));
        } catch (Throwable $e) {
            appLog('warn', 'media_library GET failed', ['err' => $e->getMessage()]);
            jsonRespond([]);
        }
    }

    if ($method === 'POST') {
        requireCmsWrite();
        if (!empty($_FILES['file'])) {
            jsonRespond(cmsProcessMediaUpload($pdo, $_FILES['file']));
        }
        if (!empty($_FILES['files'])) {
            $out = [];
            $files = $_FILES['files'];
            $count = is_array($files['name']) ? count($files['name']) : 0;
            for ($i = 0; $i < $count; $i++) {
                $f = [
                    'name' => $files['name'][$i], 'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i], 'error' => $files['error'][$i],
                    'size' => $files['size'][$i],
                ];
                if ($f['error'] === UPLOAD_ERR_OK) $out[] = cmsProcessMediaUpload($pdo, $f);
            }
            jsonRespond(['uploaded' => $out]);
        }
        jsonRespond(['error' => 'Nenhum arquivo enviado'], 400);
    }

    if ($method === 'DELETE') {
        requireCmsManage();
        $id = sanInt($_GET['id'] ?? 0);
        $stmt = $pdo->prepare('SELECT * FROM media_library WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if ($row) {
            $path = __DIR__ . '/' . ltrim($row['url'], '/');
            if (is_file($path)) @unlink($path);
            $pdo->prepare('DELETE FROM media_library WHERE id = ?')->execute([$id]);
        }
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function ensureMediaLibraryAiColumns(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $adds = [
        "ALTER TABLE media_library ADD COLUMN alt VARCHAR(255) NULL",
        "ALTER TABLE media_library ADD COLUMN caption VARCHAR(255) NULL",
        "ALTER TABLE media_library ADD COLUMN description TEXT NULL",
        "ALTER TABLE media_library ADD COLUMN thumb_url VARCHAR(500) NULL",
        "ALTER TABLE media_library ADD COLUMN webp_url VARCHAR(500) NULL",
        "ALTER TABLE media_library ADD COLUMN avif_url VARCHAR(500) NULL",
        "ALTER TABLE media_library ADD COLUMN source VARCHAR(20) NULL",
        "ALTER TABLE media_library ADD COLUMN provider VARCHAR(60) NULL",
        "ALTER TABLE media_library ADD COLUMN prompt TEXT NULL",
        "ALTER TABLE media_library ADD COLUMN meta_json JSON NULL",
    ];
    foreach ($adds as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { /* coluna já existe */ }
    }
    $done = true;
}

function mediaCompressionPreset(PDO $pdo): string {
    try {
        $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'media_compression_preset' LIMIT 1");
        $stmt->execute();
        $v = trim((string)($stmt->fetchColumn() ?: ''));
        if (in_array($v, ['alta', 'balanceado', 'leve'], true)) return $v;
    } catch (Throwable $e) { /* ignore */ }
    return 'balanceado';
}

function mediaPresetQuality(string $preset): int {
    return match ($preset) {
        'alta' => 88,
        'leve' => 72,
        default => 80,
    };
}

function mediaWriteDerivedImages(string $absPath, string $mime): array {
    $out = ['thumb_url' => null, 'webp_url' => null, 'avif_url' => null];
    if (!str_starts_with($mime, 'image/')) return $out;
    if (!function_exists('imagecreatefromjpeg')) return $out;

    $src = match ($mime) {
        'image/jpeg' => @imagecreatefromjpeg($absPath),
        'image/png' => @imagecreatefrompng($absPath),
        'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($absPath) : false,
        default => false,
    };
    if (!$src) return $out;

    $base = pathinfo($absPath, PATHINFO_FILENAME);
    $dir = dirname($absPath);
    $thumbAbs = $dir . '/' . $base . '-thumb.jpg';
    $webpAbs = $dir . '/' . $base . '.webp';
    $avifAbs = $dir . '/' . $base . '.avif';

    $w = imagesx($src);
    $h = imagesy($src);
    $tw = min(480, max(120, $w));
    $th = (int)round(($h / max(1, $w)) * $tw);
    $dst = imagecreatetruecolor($tw, $th);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $tw, $th, $w, $h);
    @imagejpeg($dst, $thumbAbs, 82);
    imagedestroy($dst);

    if (function_exists('imagewebp')) {
        @imagewebp($src, $webpAbs, 82);
    }
    if (function_exists('imageavif')) {
        @imageavif($src, $avifAbs, 52);
    }
    imagedestroy($src);

    $relBase = str_replace('\\', '/', basename(dirname($absPath)));
    $relDir = 'uploads/' . $relBase . '/';
    $out['thumb_url'] = is_file($thumbAbs) ? $relDir . basename($thumbAbs) : null;
    $out['webp_url'] = is_file($webpAbs) ? $relDir . basename($webpAbs) : null;
    $out['avif_url'] = is_file($avifAbs) ? $relDir . basename($avifAbs) : null;
    return $out;
}

function mediaIngestFromBinary(PDO $pdo, array $opts): array {
    ensureMediaLibraryAiColumns($pdo);
    $binary = (string)($opts['binary'] ?? '');
    if ($binary === '') throw new RuntimeException('binary obrigatório');
    $folder = san($opts['folder'] ?? 'Blog', 50) ?? 'Blog';
    if (!in_array($folder, cmsMediaFolders(), true)) $folder = 'Blog';
    $mime = san($opts['mime'] ?? 'image/png', 80) ?? 'image/png';
    if (!str_starts_with($mime, 'image/')) throw new RuntimeException('Apenas imagem é suportada');

    $ext = match ($mime) {
        'image/jpeg' => 'jpg',
        'image/webp' => 'webp',
        default => 'png',
    };
    $subdir = 'uploads/' . strtolower($folder) . '/';
    $absDir = __DIR__ . '/' . $subdir;
    if (!is_dir($absDir)) mkdir($absDir, 0755, true);

    $nameBase = preg_replace('/[^a-z0-9\-]+/i', '-', strtolower((string)($opts['title'] ?? 'ai-image')));
    $nameBase = trim((string)$nameBase, '-');
    if ($nameBase === '') $nameBase = 'media-ai';
    $filename = $nameBase . '-' . substr(md5($binary), 0, 10) . '.' . $ext;
    $absPath = $absDir . $filename;
    file_put_contents($absPath, $binary);
    cmsCompressImage($absPath, $mime);
    $derived = mediaWriteDerivedImages($absPath, $mime);

    $size = filesize($absPath) ?: strlen($binary);
    $w = null; $h = null;
    $info = @getimagesize($absPath);
    if ($info) { $w = (int)$info[0]; $h = (int)$info[1]; }

    $now = dbNow();
    $url = cmsPublicMediaUrl($subdir . $filename);
    $meta = is_array($opts['meta'] ?? null) ? $opts['meta'] : [];
    $pdo->prepare('INSERT INTO media_library (filename, original_name, folder, url, mime, size, width, height, uploaded_by, created_at, alt, caption, description, thumb_url, webp_url, avif_url, source, provider, prompt, meta_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([
            $filename,
            san($opts['original_name'] ?? $filename, 255),
            $folder,
            $url,
            $mime,
            (int)$size,
            $w,
            $h,
            adminSessionUserId(),
            $now,
            san($meta['alt'] ?? null, 255),
            san($meta['caption'] ?? null, 255),
            $meta['description'] ?? null,
            $derived['thumb_url'],
            $derived['webp_url'],
            $derived['avif_url'],
            san($opts['source'] ?? 'upload', 20),
            san($opts['provider'] ?? null, 60),
            $opts['prompt'] ?? null,
            json_encode($meta, JSON_UNESCAPED_UNICODE),
        ]);
    $id = (int)$pdo->lastInsertId();
    $stmt = $pdo->prepare('SELECT * FROM media_library WHERE id = ?');
    $stmt->execute([$id]);
    return decodeMediaItem($stmt->fetch() ?: []);
}

/** Valida host público (anti-SSRF) para download de imagem externa. */
function mediaAssertPublicHttpsHost(string $url): string {
    if (!preg_match('#^https://#i', $url)) {
        throw new RuntimeException('URL inválida (somente https)');
    }
    $host = parse_url($url, PHP_URL_HOST);
    if (!$host || !is_string($host)) {
        throw new RuntimeException('Host inválido');
    }
    $ips = gethostbynamel($host) ?: [];
    if (!$ips) {
        throw new RuntimeException('Não foi possível resolver o host');
    }
    foreach ($ips as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            throw new RuntimeException('URL aponta para rede privada/reservada');
        }
    }
    return $host;
}

function mediaIngestFromUrl(PDO $pdo, string $url, array $opts = []): array {
    $url = trim($url);
    if ($url === '') {
        throw new RuntimeException('URL inválida (somente https)');
    }
    // ChatGPT/CDN: URLs longas + redirects; seguir até 3 hops com revalidação SSRF.
    $maxHops = 3;
    $body = null;
    $ctype = '';
    $finalUrl = $url;
    for ($hop = 0; $hop <= $maxHops; $hop++) {
        mediaAssertPublicHttpsHost($finalUrl);
        $ch = curl_init($finalUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT => 35,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_MAXFILESIZE => 8 * 1024 * 1024,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; AutoLimpezaProMediaBot/1.0; +https://autolimpezapro.com.br)',
            CURLOPT_HTTPHEADER => [
                'Accept: image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
            ],
        ]);
        $body = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $redirect = (string)curl_getinfo($ch, CURLINFO_REDIRECT_URL);
        $err = curl_error($ch);
        curl_close($ch);
        if ($err) {
            throw new RuntimeException('Falha ao baixar imagem: ' . $err);
        }
        if ($http >= 300 && $http < 400 && $redirect !== '' && $hop < $maxHops) {
            if (!preg_match('#^https://#i', $redirect)) {
                $base = preg_replace('#(\?.*)$#', '', $finalUrl) ?? $finalUrl;
                $redirect = rtrim(dirname($base), '/') . '/' . ltrim($redirect, '/');
            }
            $finalUrl = $redirect;
            continue;
        }
        if ($http < 200 || $http >= 300 || !is_string($body) || $body === '') {
            throw new RuntimeException("Falha ao baixar imagem (HTTP {$http})");
        }
        break;
    }
    if (!is_string($body) || $body === '') {
        throw new RuntimeException('Falha ao baixar imagem');
    }
    if (!str_starts_with($ctype, 'image/')) {
        $g = @getimagesizefromstring($body);
        if (!$g || empty($g['mime']) || !str_starts_with((string)$g['mime'], 'image/')) {
            throw new RuntimeException('Conteúdo remoto não é imagem');
        }
        $ctype = (string)$g['mime'];
    }
    $opts['binary'] = $body;
    $opts['mime'] = $ctype;
    $opts['original_name'] = basename(parse_url($finalUrl, PHP_URL_PATH) ?: 'imagem-externa');
    $opts['source'] = $opts['source'] ?? 'url';
    return mediaIngestFromBinary($pdo, $opts);
}

/**
 * Se a capa for URL https externa, baixa e grava em /uploads/ (permanência).
 * Caminhos locais (/uploads/...) passam intactos.
 */
function cmsLocalizeExternalMediaUrl(PDO $pdo, ?string $url, array $opts = []): ?string {
    $url = trim((string)$url);
    if ($url === '') return null;
    if (preg_match('#^(/|uploads/)#i', $url) || preg_match('#^data:#i', $url)) {
        return cmsPublicMediaUrl($url);
    }
    if (!preg_match('#^https://#i', $url)) {
        return cmsPublicMediaUrl($url);
    }
    // Já é nosso domínio absoluto → normaliza para path relativo se possível
    $host = parse_url($url, PHP_URL_HOST);
    $path = parse_url($url, PHP_URL_PATH);
    $siteBase = defined('SITE_URL') ? (string)SITE_URL : (function_exists('blogSiteBaseUrl') ? blogSiteBaseUrl() : '');
    $siteHost = $siteBase !== '' ? parse_url($siteBase, PHP_URL_HOST) : null;
    if (is_string($path) && str_starts_with($path, '/uploads/') && $host && $siteHost && strcasecmp($host, (string)$siteHost) === 0) {
        return cmsPublicMediaUrl($path);
    }
    $media = mediaIngestFromUrl($pdo, $url, array_merge([
        'folder' => 'Blog',
        'source' => 'url',
        'title' => $opts['title'] ?? 'Capa externa',
        'provider' => $opts['provider'] ?? 'external_url',
        'meta' => $opts['meta'] ?? [],
    ], $opts));
    $local = $media['url'] ?? null;
    if (!is_string($local) || trim($local) === '') {
        throw new RuntimeException('Importação sem URL local');
    }
    return cmsPublicMediaUrl($local);
}

function handleMediaImportUrl(string $method): void {
    requireCmsWrite();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    $b = jsonBody();
    // URLs de CDN (ChatGPT/oaiusercontent) costumam passar de 500–1200 chars
    $rawUrl = trim((string)($b['url'] ?? ''));
    $url = $rawUrl !== '' ? mb_substr(strip_tags($rawUrl), 0, 2500) : null;
    if (!$url) jsonRespond(['error' => 'url obrigatória'], 400);
    try {
        $folder = san($b['folder'] ?? 'Blog', 50) ?? 'Blog';
        $media = mediaIngestFromUrl(db(), $url, [
            'folder' => $folder,
            'provider' => san($b['provider'] ?? null, 60),
            'prompt' => $b['prompt'] ?? null,
            'meta' => is_array($b['meta'] ?? null) ? $b['meta'] : [],
            'title' => san($b['title'] ?? 'Import URL', 200),
        ]);
        jsonRespond($media);
    } catch (Throwable $e) {
        jsonRespond(['error' => $e->getMessage()], 400);
    }
}

function cmsProcessMediaUpload(PDO $pdo, array $file): array {
    requireCmsWrite();
    $allowed = ['image/jpeg','image/png','image/gif','image/webp','video/mp4','video/webm'];
    $allowedExt = ['jpg','jpeg','png','gif','webp','mp4','webm'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        jsonRespond(['error' => 'Erro no upload do arquivo'], 400);
    }

    $finfo = class_exists('finfo') ? new finfo(FILEINFO_MIME_TYPE) : null;
    $detected = $finfo ? $finfo->file($file['tmp_name']) : false;
    if ($detected === false || !in_array($detected, $allowed, true)) {
        jsonRespond(['error' => 'Tipo não permitido. Use JPG, PNG, GIF, WebP, MP4 ou WebM.'], 400);
    }
    $mime = $detected;

    $maxBytes = MAX_UPLOAD_MB * 1024 * 1024;
    if ($file['size'] > $maxBytes) jsonRespond(['error' => 'Arquivo muito grande'], 400);

    $mimeToExt = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
        'video/mp4'  => 'mp4',
        'video/webm' => 'webm',
    ];
    $ext = $mimeToExt[$mime] ?? strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) {
        jsonRespond(['error' => 'Extensão não permitida'], 400);
    }

    $folder = san($_POST['folder'] ?? $_GET['folder'] ?? 'Blog', 50) ?? 'Blog';
    if (!in_array($folder, cmsMediaFolders(), true)) $folder = 'Blog';

    $subdir = 'uploads/' . strtolower($folder) . '/';
    $absDir = __DIR__ . '/' . $subdir;
    if (!is_dir($absDir)) mkdir($absDir, 0755, true);

    $filename = uniqid('media_', true) . '.' . $ext;
    $dest = $absDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        jsonRespond(['error' => 'Falha ao mover arquivo. Verifique permissões da pasta uploads.'], 500);
    }

    $width = $height = null;
    if (strpos($mime, 'image/') === 0 && function_exists('getimagesize')) {
        $info = @getimagesize($dest);
        if ($info) { $width = $info[0]; $height = $info[1]; }
        cmsCompressImage($dest, $mime);
    }

    $binary = (string)file_get_contents($dest);
    @unlink($dest);
    try {
        return mediaIngestFromBinary($pdo, [
            'binary' => $binary,
            'mime' => $mime,
            'folder' => $folder,
            'original_name' => $file['name'],
            'source' => 'upload',
            'title' => pathinfo($file['name'], PATHINFO_FILENAME),
        ]);
    } catch (Throwable $e) {
        jsonRespond(['error' => $e->getMessage()], 400);
    }
}

function cmsCompressImage(string $path, string $mime): void {
    if (!function_exists('imagecreatefromjpeg')) return;
    $maxW = 1920;
    $info = @getimagesize($path);
    if (!$info || $info[0] <= $maxW) return;
    $ratio = $maxW / $info[0];
    $newH = (int)($info[1] * $ratio);
    $src = match ($mime) {
        'image/jpeg' => @imagecreatefromjpeg($path),
        'image/png'  => @imagecreatefrompng($path),
        'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : false,
        default => false,
    };
    if (!$src) return;
    $dst = imagecreatetruecolor($maxW, $newH);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $maxW, $newH, $info[0], $info[1]);
    if ($mime === 'image/jpeg') imagejpeg($dst, $path, 82);
    elseif ($mime === 'image/png') imagepng($dst, $path, 7);
    elseif ($mime === 'image/webp' && function_exists('imagewebp')) imagewebp($dst, $path, 82);
    imagedestroy($src);
    imagedestroy($dst);
}

function decodeMediaItem(array $r): array {
    return [
        'id' => (int)$r['id'],
        'filename' => $r['filename'],
        'originalName' => $r['original_name'],
        'folder' => $r['folder'],
        'url' => cmsPublicMediaUrl($r['url'] ?? null),
        'mime' => $r['mime'],
        'size' => (int)$r['size'],
        'width' => $r['width'] ? (int)$r['width'] : null,
        'height' => $r['height'] ? (int)$r['height'] : null,
        'alt' => $r['alt'] ?? null,
        'caption' => $r['caption'] ?? null,
        'description' => $r['description'] ?? null,
        'thumbUrl' => cmsPublicMediaUrl($r['thumb_url'] ?? null),
        'webpUrl' => cmsPublicMediaUrl($r['webp_url'] ?? null),
        'avifUrl' => cmsPublicMediaUrl($r['avif_url'] ?? null),
        'source' => $r['source'] ?? 'upload',
        'provider' => $r['provider'] ?? null,
        'prompt' => $r['prompt'] ?? null,
        'meta' => is_string($r['meta_json'] ?? null) ? (json_decode($r['meta_json'], true) ?: []) : (is_array($r['meta_json'] ?? null) ? $r['meta_json'] : []),
        'createdAt' => $r['created_at'] ?? null,
    ];
}

// ── Blocos personalizados ───────────────────────────────────────────────────
function handleCustomBlocks(string $method): void {
    ensureCmsMigrated();
    $pdo = db();

    if ($method === 'GET') {
        $id = san($_GET['identifier'] ?? null, 100);
        if ($id) {
            $stmt = $pdo->prepare('SELECT * FROM custom_blocks WHERE identifier = ? AND active = 1 LIMIT 1');
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if (!$row) jsonRespond(['error' => 'Bloco não encontrado'], 404);
            jsonRespond(decodeCustomBlock($row));
        }
        requireAdmin();
        $rows = $pdo->query('SELECT * FROM custom_blocks ORDER BY name ASC')->fetchAll();
        jsonRespond(array_map('decodeCustomBlock', $rows));
    }

    requireCmsAdmin();
    $b = jsonBody();
    $now = dbNow();
    $allowJs = adminRole() === 'admin';

    if ($method === 'POST') {
        $name = san($b['name'] ?? null, 200);
        $identifier = san($b['identifier'] ?? null, 100) ?? slugify($name ?? '');
        if (!$name) jsonRespond(['error' => 'Nome obrigatório'], 400);
        $pdo->prepare(
            'INSERT INTO custom_blocks (identifier, name, html, css, js, active, created_by, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([
            $identifier, $name,
            sanitizeCmsHtml($b['html'] ?? '', $allowJs),
            $b['css'] ?? null,
            $allowJs ? ($b['js'] ?? null) : null,
            sanBool($b['active'] ?? true) ? 1 : 0,
            adminSessionUserId(), $now, $now,
        ]);
        $id = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT * FROM custom_blocks WHERE id = ?');
        $stmt->execute([$id]);
        jsonRespond(decodeCustomBlock($stmt->fetch()));
    }

    if ($method === 'PUT') {
        $id = sanInt($_GET['id'] ?? 0);
        $pdo->prepare(
            'UPDATE custom_blocks SET identifier=?, name=?, html=?, css=?, js=?, active=?, updated_at=? WHERE id=?'
        )->execute([
            san($b['identifier'] ?? null, 100),
            san($b['name'] ?? null, 200),
            sanitizeCmsHtml($b['html'] ?? '', $allowJs),
            $b['css'] ?? null,
            $allowJs ? ($b['js'] ?? null) : null,
            sanBool($b['active'] ?? true) ? 1 : 0,
            $now, $id,
        ]);
        jsonRespond(['ok' => true]);
    }

    if ($method === 'DELETE') {
        $id = sanInt($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM custom_blocks WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function decodeCustomBlock(array $r): array {
    return [
        'id' => (int)$r['id'],
        'identifier' => $r['identifier'],
        'name' => $r['name'],
        'html' => $r['html'],
        'css' => $r['css'],
        'js' => $r['js'],
        'active' => (bool)$r['active'],
    ];
}

// ── Comentários ─────────────────────────────────────────────────────────────
function handleBlogComments(string $method): void {
    ensureCmsMigrated();
    $pdo = db();

    if (!cmsTableExists($pdo, 'blog_comments')) {
        if ($method === 'GET') {
            jsonRespond([]);
        }
        if ($method === 'POST') {
            jsonRespond(['error' => 'Comentários indisponíveis. Execute install.php?step=repair'], 503);
        }
        jsonRespond(['error' => 'Tabela blog_comments ausente'], 503);
    }

    if ($method === 'GET') {
        $postSlug = san($_GET['postSlug'] ?? null, 200);
        if ($postSlug) {
            $stmt = $pdo->prepare(
                "SELECT id, post_slug, author_name, content, created_at FROM blog_comments
                 WHERE post_slug = ? AND status = 'approved' ORDER BY created_at DESC LIMIT 50"
            );
            $stmt->execute([$postSlug]);
            jsonRespond(array_map(fn($r) => [
                'id' => (int)$r['id'],
                'authorName' => $r['author_name'],
                'content' => $r['content'],
                'createdAt' => $r['created_at'],
            ], $stmt->fetchAll()));
            return;
        }
        requireAdmin();
        $status = san($_GET['status'] ?? null, 20);
        $sql = 'SELECT * FROM blog_comments';
        if ($status) {
            $stmt = $pdo->prepare($sql . ' WHERE status = ? ORDER BY created_at DESC LIMIT 100');
            $stmt->execute([$status]);
        } else {
            $stmt = $pdo->query($sql . ' ORDER BY created_at DESC LIMIT 100');
        }
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'], 'postSlug' => $r['post_slug'],
            'authorName' => $r['author_name'], 'email' => $r['email'],
            'content' => $r['content'], 'status' => $r['status'],
            'createdAt' => $r['created_at'],
        ], $stmt->fetchAll()));
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $pdo->prepare(
            'INSERT INTO blog_comments (post_slug, author_name, email, content, status, created_at) VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([
            san($b['postSlug'] ?? null, 200),
            san($b['authorName'] ?? 'Anônimo', 200),
            san($b['email'] ?? null, 255),
            sanitizeCmsHtml($b['content'] ?? '') ?? '',
            'pending',
            dbNow(),
        ]);
        jsonRespond(['ok' => true, 'message' => 'Comentário enviado para moderação.']);
    }

    requireCmsManage();
    if ($method === 'PUT') {
        $id = sanInt($_GET['id'] ?? 0);
        $status = san(jsonBody()['status'] ?? null, 20);
        $pdo->prepare('UPDATE blog_comments SET status = ? WHERE id = ?')->execute([$status, $id]);
        jsonRespond(['ok' => true]);
    }

    if ($method === 'DELETE') {
        $id = sanInt($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM blog_comments WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

// ── Versionamento de posts ──────────────────────────────────────────────────
function cmsSavePostRevision(PDO $pdo, string $slug): void {
    if (!cmsTableExists($pdo, 'blog_post_revisions')) return;
    $stmt = $pdo->prepare('SELECT * FROM blog_posts WHERE slug = ? LIMIT 1');
    $stmt->execute([$slug]);
    $row = $stmt->fetch();
    if (!$row) return;
    $uid = function_exists('adminSessionUserId') ? adminSessionUserId() : null;
    $pdo->prepare(
        'INSERT INTO blog_post_revisions (post_slug, title, excerpt, content, blocks, meta_title, meta_description, status, author_id, author_name, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([
        $slug,
        $row['title'],
        $row['excerpt'],
        $row['content'],
        $row['blocks'],
        $row['meta_title'] ?? null,
        $row['meta_description'] ?? null,
        $row['status'] ?? 'published',
        $uid,
        $row['author_name'] ?? null,
        dbNow(),
    ]);
    $stmtCnt = $pdo->prepare('SELECT COUNT(*) FROM blog_post_revisions WHERE post_slug = ?');
    $stmtCnt->execute([$slug]);
    if ((int)$stmtCnt->fetchColumn() > 20) {
        $pdo->prepare(
            'DELETE FROM blog_post_revisions WHERE post_slug = ? AND id NOT IN (
                SELECT id FROM (SELECT id FROM blog_post_revisions WHERE post_slug = ? ORDER BY created_at DESC LIMIT 20) AS keep_rev
            )'
        )->execute([$slug, $slug]);
    }
}

function handleBlogRevisions(string $method): void {
    ensureCmsMigrated();
    $pdo = db();
    requireCmsWrite();

    $slug = san($_GET['slug'] ?? null, 200);
    if (!$slug) jsonRespond(['error' => 'Slug obrigatório'], 400);

    if ($method === 'GET') {
        if (!cmsTableExists($pdo, 'blog_post_revisions')) {
            jsonRespond([]);
        }
        $stmt = $pdo->prepare('SELECT * FROM blog_post_revisions WHERE post_slug = ? ORDER BY created_at DESC LIMIT 20');
        $stmt->execute([$slug]);
        jsonRespond(array_map(fn($r) => [
            'id' => (int)$r['id'],
            'postSlug' => $r['post_slug'],
            'title' => $r['title'],
            'excerpt' => $r['excerpt'],
            'status' => $r['status'],
            'authorName' => $r['author_name'],
            'createdAt' => $r['created_at'],
        ], $stmt->fetchAll()));
    }

    if ($method === 'POST') {
        $id = sanInt(jsonBody()['revisionId'] ?? $_GET['id'] ?? 0);
        if (!$id) jsonRespond(['error' => 'revisionId obrigatório'], 400);
        $stmt = $pdo->prepare('SELECT * FROM blog_post_revisions WHERE id = ? AND post_slug = ?');
        $stmt->execute([$id, $slug]);
        $rev = $stmt->fetch();
        if (!$rev) jsonRespond(['error' => 'Revisão não encontrada'], 404);

        cmsSavePostRevision($pdo, $slug);
        $now = dbNow();
        $pdo->prepare(
            'UPDATE blog_posts SET title=?, excerpt=?, content=?, blocks=?, meta_title=?, meta_description=?, status=?, updated_at=? WHERE slug=?'
        )->execute([
            $rev['title'], $rev['excerpt'], $rev['content'], $rev['blocks'],
            $rev['meta_title'], $rev['meta_description'], $rev['status'] ?? 'draft',
            $now, $slug,
        ]);
        $stmt = $pdo->prepare('SELECT * FROM blog_posts WHERE slug = ?');
        $stmt->execute([$slug]);
        jsonRespond(decodeBlogPost($stmt->fetch()));
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function decodeBlogAuthor(array $r): array {
    if (!$r) {
        return [
            'id' => 0, 'slug' => '', 'name' => '', 'photoUrl' => null, 'bio' => null,
            'specialty' => null, 'social' => [], 'active' => true, 'sortOrder' => 0, 'postCount' => 0,
        ];
    }
    $social = $r['social_json'] ?? null;
    if (is_string($social)) $social = json_decode($social, true);
    return [
        'id' => (int)$r['id'],
        'slug' => $r['slug'],
        'name' => $r['name'],
        'photoUrl' => $r['photo_url'],
        'bio' => $r['bio'],
        'specialty' => $r['specialty'],
        'social' => is_array($social) ? $social : [],
        'active' => (bool)$r['active'],
        'sortOrder' => (int)$r['sort_order'],
        'postCount' => (int)($r['post_count'] ?? 0),
    ];
}

function handleBlogAuthors(string $method): void {
    ensureCmsMigrated();
    $pdo = db();

    if (!cmsTableExists($pdo, 'blog_authors')) {
        if ($method === 'GET') {
            jsonRespond([]);
        }
        jsonRespond(['error' => 'Tabela blog_authors ausente. Execute install.php?step=repair ou cms/migrate.'], 503);
    }

    if ($method === 'GET') {
        $hasAuthorCol = function_exists('cmsColumnExists')
            && cmsColumnExists($pdo, 'blog_posts', 'author_name');
        $sql = $hasAuthorCol
            ? 'SELECT a.*, (SELECT COUNT(*) FROM blog_posts p WHERE p.author_name = a.name) AS post_count
               FROM blog_authors a ORDER BY a.sort_order ASC, a.name ASC'
            : 'SELECT a.*, 0 AS post_count FROM blog_authors a ORDER BY a.sort_order ASC, a.name ASC';
        try {
            $rows = $pdo->query($sql)->fetchAll();
        } catch (Throwable $e) {
            appLog('error', 'blog_authors_list', ['err' => $e->getMessage()]);
            jsonRespond([]);
        }
        jsonRespond(array_map('decodeBlogAuthor', $rows));
    }

    requireCmsManage();
    $b = jsonBody();
    $now = dbNow();

    if ($method === 'POST') {
        $name = san($b['name'] ?? null, 200);
        if (!$name) jsonRespond(['error' => 'Nome obrigatório'], 400);
        $slug = san($b['slug'] ?? null, 120) ?? slugify($name);
        $pdo->prepare(
            'INSERT INTO blog_authors (slug, name, photo_url, bio, specialty, social_json, active, sort_order, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([
            $slug, $name,
            san($b['photoUrl'] ?? null, 500),
            $b['bio'] ?? null,
            san($b['specialty'] ?? null, 200),
            json_encode($b['social'] ?? [], JSON_UNESCAPED_UNICODE),
            sanBool($b['active'] ?? true) ? 1 : 0,
            sanInt($b['sortOrder'] ?? 0),
            $now, $now,
        ]);
        $id = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT a.*, 0 AS post_count FROM blog_authors a WHERE a.id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) jsonRespond(['error' => 'Autor não encontrado após salvar'], 500);
        jsonRespond(decodeBlogAuthor($row));
    }

    if ($method === 'PUT') {
        $id = sanInt($_GET['id'] ?? 0);
        if (!$id) jsonRespond(['error' => 'ID obrigatório'], 400);
        $pdo->prepare(
            'UPDATE blog_authors SET slug=?, name=?, photo_url=?, bio=?, specialty=?, social_json=?, active=?, sort_order=?, updated_at=? WHERE id=?'
        )->execute([
            san($b['slug'] ?? null, 120),
            san($b['name'] ?? null, 200),
            san($b['photoUrl'] ?? null, 500),
            $b['bio'] ?? null,
            san($b['specialty'] ?? null, 200),
            json_encode($b['social'] ?? [], JSON_UNESCAPED_UNICODE),
            sanBool($b['active'] ?? true) ? 1 : 0,
            sanInt($b['sortOrder'] ?? 0),
            $now, $id,
        ]);
        $hasAuthorCol = function_exists('cmsColumnExists')
            && cmsColumnExists($pdo, 'blog_posts', 'author_name');
        $selectSql = $hasAuthorCol
            ? 'SELECT a.*, (SELECT COUNT(*) FROM blog_posts p WHERE p.author_name = a.name) AS post_count FROM blog_authors a WHERE a.id = ?'
            : 'SELECT a.*, 0 AS post_count FROM blog_authors a WHERE a.id = ?';
        $stmt = $pdo->prepare($selectSql);
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) jsonRespond(['error' => 'Autor não encontrado'], 404);
        jsonRespond(decodeBlogAuthor($row));
    }

    if ($method === 'DELETE') {
        requireCmsAdmin();
        $id = sanInt($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM blog_authors WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function contentIdeaMatchesKeyword(array $idea, string $keyword): bool {
    if ($keyword === '') return true;
    $kw = mb_strtolower($keyword);
    $hay = mb_strtolower(trim(($idea['title'] ?? '') . ' ' . ($idea['keyword'] ?? '')));
    return $hay !== '' && str_contains($hay, $kw);
}

function contentIdeasDedupe(array $ideas): array {
    $seen = [];
    $out = [];
    foreach ($ideas as $idea) {
        $key = mb_strtolower(trim((string)($idea['title'] ?? '')));
        if ($key === '' || isset($seen[$key])) continue;
        $seen[$key] = true;
        $out[] = $idea;
    }
    return $out;
}

function handleContentIdeas(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);

    // Garante migrate-cms.php (cmsTableExists) — sem isso a rota explode em 500
    if (function_exists('ensureCmsMigrated')) {
        try {
            ensureCmsMigrated();
        } catch (Throwable $e) {
            appLog('warn', 'content_ideas_migrate', ['err' => $e->getMessage()]);
        }
    } elseif (!function_exists('cmsTableExists')) {
        require_once __DIR__ . '/migrate-cms.php';
    }

    $pdo = db();
    $keyword = trim(san($_GET['q'] ?? null, 200) ?? '');
    $searching = $keyword !== '';
    $ideas = [];

    if ($searching) {
        $prefixes = ['como', 'quanto custa', 'vale a pena', 'dicas de', 'melhor época para'];
        foreach ($prefixes as $prefix) {
            $ideas[] = [
                'title' => ucfirst("{$prefix} {$keyword}"),
                'source' => 'autosuggest',
                'keyword' => "{$prefix} {$keyword}",
            ];
        }
        $ideas[] = [
            'title' => "Perguntas frequentes sobre {$keyword}",
            'source' => 'paa',
            'keyword' => $keyword,
        ];
    }

    $services = [
        'Higienização de Sofá', 'Limpeza de Colchão', 'Limpeza Automotiva',
        'Impermeabilização', 'Limpeza Pós-Obra', 'Tapetes e Carpetes',
    ];
    $cities = [
        'São José da Lapa', 'Pedro Leopoldo', 'Vespasiano', 'Confins', 'Lagoa Santa',
        'Santa Luzia', 'Belo Horizonte', 'Ribeirão das Neves', 'Sabará', 'Nova Lima',
    ];
    $cityLimit = $searching ? count($cities) : 6;
    foreach (array_slice($cities, 0, $cityLimit) as $city) {
        foreach ($services as $svc) {
            $item = [
                'title' => "{$svc} em {$city}",
                'source' => 'seo-local',
                'keyword' => mb_strtolower("{$svc} {$city}"),
            ];
            if (contentIdeaMatchesKeyword($item, $keyword)) {
                $ideas[] = $item;
            }
        }
    }

    try {
        if (function_exists('cmsTableExists') && cmsTableExists($pdo, 'blog_categories')) {
            $catLimit = $searching ? 20 : 8;
            $catSql = cmsColumnExists($pdo, 'blog_categories', 'active')
                ? "SELECT name FROM blog_categories WHERE active = 1 ORDER BY sort_order ASC, name ASC LIMIT {$catLimit}"
                : "SELECT name FROM blog_categories ORDER BY name ASC LIMIT {$catLimit}";
            foreach ($pdo->query($catSql)->fetchAll() as $c) {
                $item = ['title' => "Guia completo: {$c['name']}", 'source' => 'categoria', 'keyword' => $c['name']];
                if (contentIdeaMatchesKeyword($item, $keyword)) {
                    $ideas[] = $item;
                }
            }
        }
    } catch (Throwable $e) {
        appLog('warn', 'content_ideas_categories', ['err' => $e->getMessage()]);
    }

    try {
        if (function_exists('cmsTableExists') && cmsTableExists($pdo, 'blog_posts')) {
            $postLimit = $searching ? 12 : 6;
            foreach ($pdo->query("SELECT title FROM blog_posts ORDER BY published_at DESC LIMIT {$postLimit}")->fetchAll() as $p) {
                $item = ['title' => "Atualizar: {$p['title']}", 'source' => 'site', 'keyword' => $p['title']];
                if (contentIdeaMatchesKeyword($item, $keyword)) {
                    $ideas[] = $item;
                }
            }
        }
    } catch (Throwable $e) {
        appLog('warn', 'content_ideas_posts', ['err' => $e->getMessage()]);
    }

    $ideas = contentIdeasDedupe($ideas);
    header('Cache-Control: private, max-age=30, stale-while-revalidate=120');
    jsonRespond(array_slice($ideas, 0, 40));
}

// ── Estatísticas do blog (views por artigo) ─────────────────────────────────
/** Total publicado exibido no site (DB + artigos estáticos não duplicados). */
function blogStaticSlugsManifest(): array {
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $file = __DIR__ . '/data/blog-static-slugs.json';
    if (!is_file($file)) {
        return $cache = [];
    }
    $data = json_decode((string) file_get_contents($file), true);
    $slugs = is_array($data['slugs'] ?? null) ? $data['slugs'] : [];
    return $cache = array_values(array_filter(array_map('strval', $slugs)));
}

function blogDisplayPublishedTotal(PDO $pdo, array $dbPosts = []): int {
    $dbSlugs = [];
    foreach ($dbPosts as $post) {
        $slug = is_array($post) ? ($post['slug'] ?? '') : ($post->slug ?? '');
        if ($slug !== '') {
            $dbSlugs[$slug] = true;
        }
    }
    if (!$dbPosts) {
        try {
            $rows = $pdo->query("SELECT slug FROM blog_posts WHERE status = 'published' OR status IS NULL")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($rows as $slug) {
                if ($slug !== '') {
                    $dbSlugs[(string) $slug] = true;
                }
            }
        } catch (Throwable $e) {
            // ignore
        }
    }
    $staticOnly = 0;
    foreach (blogStaticSlugsManifest() as $slug) {
        if (!isset($dbSlugs[$slug])) {
            $staticOnly++;
        }
    }
    return count($dbSlugs) + $staticOnly;
}

function handleBlogRepairRedundantCopy(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Use POST'], 405);
    }
    requireAdmin();
    ensureCmsMigrated();
    $pdo = db();
    $dryRun = !empty($_GET['dryRun']) || !empty($_POST['dryRun']);
    $result = blogRepairPostsRedundantCopy($pdo, $dryRun);
    jsonRespond([
        'ok'      => true,
        'dryRun'  => $dryRun,
        'scanned' => $result['scanned'],
        'updated' => $result['updated'],
        'slugs'   => $result['slugs'],
    ]);
}

function handleBlogMeta(string $method): void {
    if ($method !== 'GET') {
        jsonRespond(['error' => 'Use GET'], 405);
    }
    ensureCmsMigrated();
    $pdo = db();
    $dbCount = 0;
    try {
        $dbCount = (int) $pdo->query("SELECT COUNT(*) FROM blog_posts WHERE status = 'published' OR status IS NULL")->fetchColumn();
    } catch (Throwable $e) {
        appLog('warn', 'blog_meta count failed', ['err' => $e->getMessage()]);
    }
    jsonRespond([
        'databasePublished' => $dbCount,
        'displayTotal'      => blogDisplayPublishedTotal($pdo),
        'staticManifest'    => count(blogStaticSlugsManifest()) > 0,
    ]);
}

function handleBlogStats(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    requireAdmin();
    $pdo = db();
    ensureAnalyticsIndexes($pdo);
    $days = sanInt($_GET['days'] ?? 90) ?: 90;
    $days = min(365, max(7, $days));
    $cutoff = date('Y-m-d H:i:s', strtotime("-{$days} days"));

    $stats = [];
    try {
        $rows = $pdo->prepare(
            "SELECT path, COUNT(*) AS views FROM analytics
             WHERE path LIKE '/dicas/%' AND created_at >= ?
             GROUP BY path ORDER BY views DESC LIMIT 100"
        );
        $rows->execute([$cutoff]);
        foreach ($rows->fetchAll() as $r) {
            $slug = basename($r['path']);
            if ($slug === '' || $slug === 'dicas') continue;
            $stats[] = [
                'slug'  => $slug,
                'path'  => $r['path'],
                'views' => (int)$r['views'],
            ];
        }
    } catch (Throwable $e) {
        appLog('warn', 'blog_stats', ['err' => $e->getMessage()]);
    }

    // Compartilhamentos estimados via eventos de origem social
    $shares = [];
    try {
        $shareRows = $pdo->prepare(
            "SELECT path, COUNT(*) AS shares FROM analytics
             WHERE path LIKE '/dicas/%' AND created_at >= ?
             AND source_category IN ('social','referral')
             GROUP BY path ORDER BY shares DESC LIMIT 50"
        );
        $shareRows->execute([$cutoff]);
        foreach ($shareRows->fetchAll() as $r) {
            $slug = basename($r['path']);
            if ($slug) $shares[$slug] = (int)$r['shares'];
        }
    } catch (Throwable $e) { /* ignore */ }

    foreach ($stats as &$s) {
        $s['shares'] = $shares[$s['slug']] ?? 0;
    }
    unset($s);

    jsonRespond(['days' => $days, 'posts' => $stats]);
}

// ── Migração CMS (admin) ────────────────────────────────────────────────────
function handleCmsMigrate(string $method): void {
    requireCmsAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    require_once __DIR__ . '/migrate-cms.php';
    jsonRespond(['ok' => true, 'results' => runCmsMigrations(db())]);
}

// ── Info do usuário CMS (role/permissões) ───────────────────────────────────
function handleCmsMe(string $method): void {
    requireAdmin();
    jsonRespond([
        'role' => adminRole(),
        'userId' => adminSessionUserId(),
        'canWrite' => in_array(adminRole(), ['admin', 'editor', 'author'], true),
        'canManage' => in_array(adminRole(), ['admin', 'editor'], true),
        'canAdmin' => adminRole() === 'admin',
        'isMasterAdmin' => function_exists('isMasterAdminSession') ? isMasterAdminSession() : false,
        'folders' => cmsMediaFolders(),
    ]);
}
