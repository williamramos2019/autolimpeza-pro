<?php
/**
 * CMS — handlers de conteúdo do site e transformações
 */

define('CMS_DEFAULT_FILE', __DIR__ . '/data/cms-default.json');

function cmsLoadDefaults(): array {
    if (!file_exists(CMS_DEFAULT_FILE)) {
        return ['version' => 1, 'company' => ['nome' => SITE_NAME]];
    }
    $raw = file_get_contents(CMS_DEFAULT_FILE);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/** Mescla CMS salvo com defaults (ex.: lavagem-automotiva em homeServices). */
function cmsMergeWithDefaults(array $stored): array {
    $defaults = cmsLoadDefaults();
    if (!$defaults) return $stored;

    $merged = array_replace_recursive($defaults, $stored);

    $defaultHome = $defaults['homeServices'] ?? [];
    $storedHome = $stored['homeServices'] ?? [];
    if (is_array($defaultHome) && is_array($storedHome)) {
        $byId = [];
        foreach ($storedHome as $row) {
            if (is_array($row) && !empty($row['catalogId'])) {
                $byId[$row['catalogId']] = $row;
            }
        }
        foreach ($defaultHome as $row) {
            if (!is_array($row) || empty($row['catalogId'])) continue;
            if (!isset($byId[$row['catalogId']])) {
                $byId[$row['catalogId']] = $row;
            }
        }
        $merged['homeServices'] = array_values($byId);
        usort($merged['homeServices'], static function ($a, $b) {
            return (int)($a['sortOrder'] ?? 0) <=> (int)($b['sortOrder'] ?? 0);
        });
    }

    if (empty($stored['automotiveWash']) && !empty($defaults['automotiveWash'])) {
        $merged['automotiveWash'] = $defaults['automotiveWash'];
    }

    return $merged;
}

function cmsGetContent(PDO $pdo): array {
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'cms' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    if ($row && !empty($row['value'])) {
        $parsed = json_decode($row['value'], true);
        if (is_array($parsed)) return cmsMergeWithDefaults($parsed);
    }
    return cmsLoadDefaults();
}

function cmsSaveContent(PDO $pdo, array $content): void {
    $now = dbNow();
    $json = json_encode($content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $pdo->prepare("
        INSERT INTO site_config (key_name, value, updated_at) VALUES ('cms', ?, ?)
        ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)
    ")->execute([$json, $now]);
}

function cmsSeedIfEmpty(PDO $pdo): void {
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'cms' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    if ($row && !empty($row['value'])) return;
    cmsSaveContent($pdo, cmsLoadDefaults());
}

function handleContent(string $method): void {
    $pdo = db();

    if ($method === 'GET') {
        header('Cache-Control: public, max-age=120, stale-while-revalidate=300');
        cmsSeedIfEmpty($pdo);
        jsonRespond(cmsGetContent($pdo));
    }

    requireAdmin();

    if ($method === 'POST') {
        $b = jsonBody();
        if (empty($b) || !is_array($b)) {
            jsonRespond(['error' => 'Corpo JSON inválido'], 400);
        }
        cmsSaveContent($pdo, $b);
        jsonRespond(['ok' => true, 'cms' => cmsGetContent($pdo)]);
    }

    jsonRespond(['error' => lang('method_not_allowed')], 405);
}

function transformationRowToArray(array $row): array {
    $gallery = [];
    if (!empty($row['gallery'])) {
        $decoded = is_string($row['gallery']) ? json_decode($row['gallery'], true) : $row['gallery'];
        if (is_array($decoded)) $gallery = $decoded;
    }
    return [
        'id'           => $row['id'],
        'slug'         => $row['slug'],
        'title'        => $row['title'],
        'serviceType'  => $row['service_type'],
        'city'         => $row['city'],
        'description'  => $row['description'] ?? '',
        'beforeImage'  => $row['before_image'] ?? '',
        'afterImage'   => $row['after_image'] ?? '',
        'videoUrl'     => $row['video_url'] ?? '',
        'gallery'      => $gallery,
        'featured'     => (bool)(int)($row['featured'] ?? 0),
        'sortOrder'    => (int)($row['sort_order'] ?? 0),
        'published'    => (bool)(int)($row['published'] ?? 1),
        'createdAt'    => $row['created_at'] ?? null,
        'updatedAt'    => $row['updated_at'] ?? null,
    ];
}

function transformationEncodeGallery($gallery): ?string {
    if (!is_array($gallery) || count($gallery) === 0) return null;
    $clean = array_slice(array_values(array_filter($gallery, static function ($g) {
        return is_array($g) && (!empty($g['beforeImage']) || !empty($g['afterImage']));
    })), 0, 20);
    return count($clean) > 0 ? json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
}

function handleTransformations(string $method): void {
    $pdo = db();

    if ($method === 'GET') {
        $admin = isAdmin();
        $slug  = san($_GET['slug'] ?? null, 200);

        if ($slug) {
            $sql = "SELECT * FROM cms_transformations WHERE slug = ?";
            $params = [$slug];
            if (!$admin) {
                $sql .= " AND published = 1";
            }
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $row = $stmt->fetch();
            if (!$row) jsonRespond(['error' => lang('not_found')], 404);
            jsonRespond(transformationRowToArray($row));
        }

        $sql = "SELECT * FROM cms_transformations";
        if (!$admin) {
            $sql .= " WHERE published = 1";
        }
        $sql .= " ORDER BY featured DESC, sort_order ASC, created_at DESC";
        if (!$admin) {
            header('Cache-Control: public, max-age=120, stale-while-revalidate=300');
        }
        $rows = $pdo->query($sql)->fetchAll();
        jsonRespond(array_map('transformationRowToArray', $rows));
    }

    requireAdmin();

    if ($method === 'POST') {
        $b = jsonBody();
        $id = san($b['id'] ?? null, 64) ?? uniqid('tr_', true);
        $slug = san($b['slug'] ?? null, 200);
        $title = san($b['title'] ?? null, 300);
        if (!$slug || !$title) jsonRespond(['error' => 'slug e title são obrigatórios'], 400);

        $now = dbNow();
        $galleryJson = transformationEncodeGallery($b['gallery'] ?? null);
        $pdo->prepare("
            INSERT INTO cms_transformations
                (id, slug, title, service_type, city, description, before_image, after_image,
                 video_url, gallery, featured, sort_order, published, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ")->execute([
            $id, $slug, $title,
            san($b['serviceType'] ?? '', 100) ?? '',
            san($b['city'] ?? '', 100) ?? '',
            $b['description'] ?? '',
            san($b['beforeImage'] ?? '', 500) ?? '',
            san($b['afterImage'] ?? '', 500) ?? '',
            san($b['videoUrl'] ?? '', 500) ?? '',
            $galleryJson,
            !empty($b['featured']) ? 1 : 0,
            sanInt($b['sortOrder'] ?? 0, 0),
            isset($b['published']) ? ($b['published'] ? 1 : 0) : 1,
            $now, $now,
        ]);
        jsonRespond(['ok' => true, 'id' => $id]);
    }

    if ($method === 'PUT') {
        $b = jsonBody();
        $id = san($b['id'] ?? null, 64);
        if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);

        $now = dbNow();
        $galleryJson = array_key_exists('gallery', $b) ? transformationEncodeGallery($b['gallery']) : null;
        $pdo->prepare("
            UPDATE cms_transformations SET
                slug = COALESCE(?, slug),
                title = COALESCE(?, title),
                service_type = COALESCE(?, service_type),
                city = COALESCE(?, city),
                description = COALESCE(?, description),
                before_image = COALESCE(?, before_image),
                after_image = COALESCE(?, after_image),
                video_url = COALESCE(?, video_url),
                gallery = COALESCE(?, gallery),
                featured = COALESCE(?, featured),
                sort_order = COALESCE(?, sort_order),
                published = COALESCE(?, published),
                updated_at = ?
            WHERE id = ?
        ")->execute([
            san($b['slug'] ?? null, 200),
            san($b['title'] ?? null, 300),
            san($b['serviceType'] ?? null, 100),
            san($b['city'] ?? null, 100),
            array_key_exists('description', $b) ? $b['description'] : null,
            san($b['beforeImage'] ?? null, 500),
            san($b['afterImage'] ?? null, 500),
            san($b['videoUrl'] ?? null, 500),
            $galleryJson,
            array_key_exists('featured', $b) ? ($b['featured'] ? 1 : 0) : null,
            array_key_exists('sortOrder', $b) ? sanInt($b['sortOrder'], 0) : null,
            array_key_exists('published', $b) ? ($b['published'] ? 1 : 0) : null,
            $now, $id,
        ]);
        jsonRespond(['ok' => true]);
    }

    if ($method === 'DELETE') {
        $id = san($_GET['id'] ?? jsonBody()['id'] ?? null, 64);
        if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);
        $pdo->prepare("DELETE FROM cms_transformations WHERE id = ?")->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => lang('method_not_allowed')], 405);
}
