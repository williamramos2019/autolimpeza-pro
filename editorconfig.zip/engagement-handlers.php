<?php
/**
 * Engagement Tracker — post views + eventos (scroll, vídeo, WhatsApp).
 */

function ensureEngagementTables(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;

    $pdo->exec("CREATE TABLE IF NOT EXISTS blog_post_views (
        slug VARCHAR(200) NOT NULL PRIMARY KEY,
        views INT UNSIGNED NOT NULL DEFAULT 0,
        unique_views INT UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS blog_post_view_visitors (
        slug VARCHAR(200) NOT NULL,
        visitor_id VARCHAR(64) NOT NULL,
        first_viewed_at DATETIME NOT NULL,
        PRIMARY KEY (slug, visitor_id),
        KEY idx_bpvv_visitor (visitor_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS engagement_events (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        event_type VARCHAR(40) NOT NULL,
        path VARCHAR(255) NULL,
        slug VARCHAR(200) NULL,
        depth SMALLINT UNSIGNED NULL,
        visitor_id VARCHAR(64) NULL,
        session_id VARCHAR(64) NULL,
        meta_json TEXT NULL,
        created_at DATETIME NOT NULL,
        KEY idx_eng_type_created (event_type, created_at),
        KEY idx_eng_slug (slug),
        KEY idx_eng_path (path(100), created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/** Colunas de atribuição (UTM / click IDs) — idempotente, MySQL 5.7 + MariaDB. */
function ensureAnalyticsAttributionColumns(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;
    $cols = [
        'utm_source' => 'VARCHAR(100) NULL',
        'utm_medium' => 'VARCHAR(100) NULL',
        'utm_campaign' => 'VARCHAR(150) NULL',
        'utm_content' => 'VARCHAR(150) NULL',
        'utm_term' => 'VARCHAR(150) NULL',
        'gclid' => 'VARCHAR(120) NULL',
        'fbclid' => 'VARCHAR(120) NULL',
    ];
    foreach ($cols as $name => $def) {
        try {
            $exists = $pdo->query('SHOW COLUMNS FROM analytics LIKE ' . $pdo->quote($name))->fetch();
            if (!$exists) {
                $pdo->exec("ALTER TABLE analytics ADD COLUMN `{$name}` {$def}");
            }
        } catch (Throwable $e) {
            if (function_exists('appLog')) {
                appLog('warning', 'analytics_utm_col: ' . $name . ' ' . $e->getMessage());
            }
        }
    }
}

/**
 * Unifica slugs rascunho/duplicados sob a rota pai.
 * Ex.: meu-post-copia-12 → meu-post ; meu-post?x=1 → meu-post
 */
function sanitizeBlogViewSlug(?string $raw): string {
    $slug = trim((string)$raw);
    if ($slug === '') return '';
    $slug = explode('?', $slug, 2)[0];
    $slug = explode('#', $slug, 2)[0];
    $slug = trim($slug, "/ \t\n\r\0\x0B");
    if (strpos($slug, 'dicas/') === 0) {
        $slug = substr($slug, 6);
    }
    // -copia-123, -copy-123, -rascunho, -draft, -dup-xyz
    $slug = preg_replace('/-(?:copia|copy|rascunho|draft|dup)(?:-[a-z0-9]+)?$/iu', '', $slug) ?? $slug;
    $slug = preg_replace('/[^a-z0-9\-]/i', '', $slug) ?? $slug;
    $slug = preg_replace('/-+/', '-', $slug) ?? $slug;
    return strtolower(trim($slug, '-'));
}

function handleBlogView(string $method): void {
    if ($method !== 'POST' && $method !== 'GET') {
        jsonRespond(['error' => 'Método não permitido'], 405);
    }

    $pdo = db();
    ensureEngagementTables($pdo);

    if ($method === 'GET') {
        $slug = sanitizeBlogViewSlug($_GET['slug'] ?? '');
        if ($slug === '') jsonRespond(['error' => 'slug obrigatório'], 400);
        $stmt = $pdo->prepare('SELECT views, unique_views FROM blog_post_views WHERE slug = ? LIMIT 1');
        $stmt->execute([$slug]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        jsonRespond([
            'slug' => $slug,
            'views' => (int)($row['views'] ?? 0),
            'uniqueViews' => (int)($row['unique_views'] ?? 0),
        ]);
    }

    $b = jsonBody();
    $slug = sanitizeBlogViewSlug($b['slug'] ?? ($_GET['slug'] ?? ''));
    if ($slug === '') jsonRespond(['error' => 'slug obrigatório'], 400);

    $visitorId = san($b['visitor_id'] ?? null, 64) ?? '';
    $now = dbNow();
    $isUnique = false;

    if ($visitorId !== '') {
        try {
            $ins = $pdo->prepare('INSERT IGNORE INTO blog_post_view_visitors (slug, visitor_id, first_viewed_at) VALUES (?, ?, ?)');
            $ins->execute([$slug, $visitorId, $now]);
            $isUnique = $ins->rowCount() > 0;
        } catch (Throwable $e) {
            $isUnique = false;
        }
    }

    $pdo->prepare(
        'INSERT INTO blog_post_views (slug, views, unique_views, updated_at) VALUES (?, 1, ?, ?)
         ON DUPLICATE KEY UPDATE
           views = views + 1,
           unique_views = unique_views + VALUES(unique_views),
           updated_at = VALUES(updated_at)'
    )->execute([$slug, $isUnique ? 1 : 0, $now]);

    $stmt = $pdo->prepare('SELECT views, unique_views FROM blog_post_views WHERE slug = ? LIMIT 1');
    $stmt->execute([$slug]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['views' => 1, 'unique_views' => $isUnique ? 1 : 0];

    jsonRespond([
        'ok' => true,
        'slug' => $slug,
        'views' => (int)$row['views'],
        'uniqueViews' => (int)$row['unique_views'],
        'unique' => $isUnique,
    ]);
}

function handleEngagementEvent(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Método não permitido'], 405);

    $pdo = db();
    ensureEngagementTables($pdo);
    $b = jsonBody();

    $type = san($b['event_type'] ?? $b['type'] ?? '', 40) ?? '';
    $allowed = [
        'scroll_depth', 'video_play', 'video_50', 'video_100',
        'whatsapp_click', 'phone_click', 'page_engagement',
        'idle', 'rage_click', 'js_error', 'not_found',
        'careplus_action', 'affiliate_click',
    ];
    if (!in_array($type, $allowed, true)) {
        jsonRespond(['error' => 'event_type inválido'], 400);
    }

    $path = san($b['path'] ?? ($_SERVER['HTTP_REFERER'] ?? '/'), 255) ?? '/';
    $slug = sanitizeBlogViewSlug($b['slug'] ?? '');
    $depth = isset($b['depth']) ? (int)$b['depth'] : null;
    if ($depth !== null && !in_array($depth, [25, 50, 75, 100], true)) {
        $depth = null;
    }
    $visitorId = san($b['visitor_id'] ?? null, 64);
    $sessionId = san($b['session_id'] ?? null, 64);
    $meta = $b['meta'] ?? null;
    $metaJson = is_array($meta) || is_object($meta)
        ? json_encode($meta, JSON_UNESCAPED_UNICODE)
        : (is_string($meta) ? $meta : null);

    $pdo->prepare(
        'INSERT INTO engagement_events
            (event_type, path, slug, depth, visitor_id, session_id, meta_json, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([
        $type,
        $path,
        $slug !== '' ? $slug : null,
        $depth,
        $visitorId,
        $sessionId,
        $metaJson,
        dbNow(),
    ]);

    // Sem espelho PHP: conversion_events vêm de analytics.whatsappClick/phoneClick (debounce no client).

    jsonRespond(['ok' => true]);
}

function handleEngagementStats(): void {
    requireAdmin();
    $pdo = db();
    ensureEngagementTables($pdo);
    ensureAnalyticsIndexes($pdo);

    $range = san($_GET['range'] ?? '7d', 10) ?? '7d';
    $cutoff = rangeToCutoff($range);

    $q = static function (string $sql, array $params = []) use ($pdo) {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    };

    $totalVisits = (int)$q(
        'SELECT COUNT(*) FROM analytics WHERE created_at >= ?',
        [$cutoff]
    )->fetchColumn();
    $uniqueVisitors = (int)$q(
        'SELECT COUNT(DISTINCT visitor_id) FROM analytics WHERE created_at >= ?',
        [$cutoff]
    )->fetchColumn();
    $newVisitors = (int)$q(
        'SELECT COUNT(DISTINCT visitor_id) FROM analytics WHERE created_at >= ? AND is_new_visitor = 1',
        [$cutoff]
    )->fetchColumn();
    $returning = max(0, $uniqueVisitors - $newVisitors);

    $waClicks = (int)$q(
        "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'whatsapp_click'",
        [$cutoff]
    )->fetchColumn();
    // Fallback conversion_events
    try {
        $waAlt = (int)$q(
            "SELECT COUNT(*) FROM conversion_events WHERE created_at >= ? AND event_type = 'whatsapp_click'",
            [$cutoff]
        )->fetchColumn();
        $waClicks = max($waClicks, $waAlt);
    } catch (Throwable $e) { /* tabela pode não existir em installs antigos */ }

    $convRate = $uniqueVisitors > 0 ? round(($waClicks / $uniqueVisitors) * 100, 2) : 0.0;

    $devicesRaw = $q(
        "SELECT COALESCE(device_type,'outro') device_type, COUNT(DISTINCT visitor_id) n
         FROM analytics WHERE created_at >= ? GROUP BY device_type ORDER BY n DESC",
        [$cutoff]
    )->fetchAll(PDO::FETCH_ASSOC);
    $deviceTotal = max(1, array_sum(array_map(static fn ($r) => (int)$r['n'], $devicesRaw)));
    $devices = array_map(static function ($r) use ($deviceTotal) {
        $n = (int)$r['n'];
        return [
            'device' => $r['device_type'],
            'visitors' => $n,
            'pct' => round(($n / $deviceTotal) * 100, 1),
        ];
    }, $devicesRaw);

    // Geolocalização: % sobre ÚNICOS (soma ≤ 100% dos que têm cidade; base = uniqueVisitors)
    $citiesRaw = $q(
        "SELECT city, state, country, COUNT(DISTINCT visitor_id) visitors
         FROM analytics
         WHERE created_at >= ? AND city IS NOT NULL AND city <> ''
         GROUP BY city, state, country
         ORDER BY visitors DESC
         LIMIT 15",
        [$cutoff]
    )->fetchAll(PDO::FETCH_ASSOC);
    $cityBase = max(1, $uniqueVisitors);
    $cities = [];
    foreach ($citiesRaw as $r) {
        $n = (int)$r['visitors'];
        // % sobre visitantes únicos do período (soma das cidades ≤ 100%; sem cidade = residual implícito)
        $cities[] = [
            'city' => $r['city'],
            'state' => $r['state'],
            'country' => $r['country'],
            'visitors' => $n,
            'pct' => round(($n / $cityBase) * 100, 1),
        ];
    }

    $videoPlay = (int)$q(
        "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'video_play'",
        [$cutoff]
    )->fetchColumn();
    $video50 = (int)$q(
        "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'video_50'",
        [$cutoff]
    )->fetchColumn();
    $video100 = (int)$q(
        "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'video_100'",
        [$cutoff]
    )->fetchColumn();

    $scroll100 = (int)$q(
        "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'scroll_depth' AND depth = 100",
        [$cutoff]
    )->fetchColumn();

    // Páginas unificadas: pageviews + scroll 100 + WA
    $pages = $q(
        "SELECT path, COUNT(*) pageviews, COUNT(DISTINCT visitor_id) uniques
         FROM analytics WHERE created_at >= ?
         GROUP BY path ORDER BY pageviews DESC LIMIT 20",
        [$cutoff]
    )->fetchAll(PDO::FETCH_ASSOC);

    $scrollByPath = [];
    foreach ($q(
        "SELECT path, COUNT(*) n FROM engagement_events
         WHERE created_at >= ? AND event_type = 'scroll_depth' AND depth = 100
         GROUP BY path",
        [$cutoff]
    )->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $scrollByPath[$row['path']] = (int)$row['n'];
    }
    $waByPath = [];
    foreach ($q(
        "SELECT path, COUNT(*) n FROM engagement_events
         WHERE created_at >= ? AND event_type = 'whatsapp_click'
         GROUP BY path",
        [$cutoff]
    )->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $waByPath[$row['path']] = (int)$row['n'];
    }

    $pageRows = array_map(static function ($p) use ($scrollByPath, $waByPath) {
        $pv = (int)$p['pageviews'];
        $s100 = $scrollByPath[$p['path']] ?? 0;
        return [
            'path' => $p['path'],
            'pageviews' => $pv,
            'uniques' => (int)$p['uniques'],
            'scroll100' => $s100,
            'scroll100Pct' => $pv > 0 ? round(($s100 / $pv) * 100, 1) : 0,
            'whatsappClicks' => $waByPath[$p['path']] ?? 0,
        ];
    }, $pages);

    $topPosts = $q(
        'SELECT slug, views, unique_views, updated_at FROM blog_post_views ORDER BY views DESC LIMIT 15'
    )->fetchAll(PDO::FETCH_ASSOC);

    $newPct = $uniqueVisitors > 0 ? round(($newVisitors / $uniqueVisitors) * 100, 1) : 0;
    $retPct = $uniqueVisitors > 0 ? round(($returning / $uniqueVisitors) * 100, 1) : 0;

    // Onda 2 — origens + série diária
    $sources = $q(
        "SELECT COALESCE(source_category,'direct') source_category, COUNT(*) n
         FROM analytics WHERE created_at >= ? GROUP BY source_category ORDER BY n DESC",
        [$cutoff]
    )->fetchAll(PDO::FETCH_ASSOC);
    $sourceNames = $q(
        "SELECT COALESCE(NULLIF(source_name,''),'(direto)') source_name, COUNT(*) n
         FROM analytics WHERE created_at >= ? GROUP BY source_name ORDER BY n DESC LIMIT 12",
        [$cutoff]
    )->fetchAll(PDO::FETCH_ASSOC);
    $daily = $q(
        "SELECT DATE(created_at) day, COUNT(*) visits, COUNT(DISTINCT visitor_id) visitors
         FROM analytics WHERE created_at >= ? GROUP BY DATE(created_at) ORDER BY day",
        [$cutoff]
    )->fetchAll(PDO::FETCH_ASSOC);

    $phoneClicks = 0;
    $leadSubmits = 0;
    $formSubmits = 0;
    try {
        $phoneClicks = (int)$q(
            "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'phone_click'",
            [$cutoff]
        )->fetchColumn();
        $leadSubmits = (int)$q(
            "SELECT COUNT(*) FROM conversion_events WHERE created_at >= ? AND event_type = 'lead_submit'",
            [$cutoff]
        )->fetchColumn();
        $formSubmits = $leadSubmits;
        $phoneAlt = (int)$q(
            "SELECT COUNT(*) FROM conversion_events WHERE created_at >= ? AND event_type = 'phone_click'",
            [$cutoff]
        )->fetchColumn();
        $phoneClicks = max($phoneClicks, $phoneAlt);
    } catch (Throwable $e) { /* ignore */ }

    $leadsCount = 0;
    $apptsCount = 0;
    $completedCount = 0;
    try {
        $leadsCount = (int)$q('SELECT COUNT(*) FROM leads WHERE created_at >= ?', [$cutoff])->fetchColumn();
        $apptsCount = (int)$q('SELECT COUNT(*) FROM appointments WHERE created_at >= ?', [$cutoff])->fetchColumn();
        $completedCount = (int)$q(
            "SELECT COUNT(*) FROM appointments WHERE created_at >= ? AND status = 'completed'",
            [$cutoff]
        )->fetchColumn();
    } catch (Throwable $e) { /* ignore */ }

    $viewsBase = max(1, $totalVisits);
    $commercialFunnel = [
        'views' => $totalVisits,
        'leads' => max($leadsCount, $leadSubmits),
        'appointments' => $apptsCount,
        'completed' => $completedCount,
        'viewToLeadPct' => round((max($leadsCount, $leadSubmits) / $viewsBase) * 100, 2),
        'leadToApptPct' => max($leadsCount, $leadSubmits) > 0
            ? round(($apptsCount / max($leadsCount, $leadSubmits)) * 100, 2)
            : 0.0,
        'apptToDonePct' => $apptsCount > 0 ? round(($completedCount / $apptsCount) * 100, 2) : 0.0,
    ];

    // Onda 3 — eventos avançados + CWV
    $advanced = ['idle' => 0, 'rageClick' => 0, 'jsError' => 0, 'notFound' => 0];
    try {
        $advanced['idle'] = (int)$q(
            "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'idle'",
            [$cutoff]
        )->fetchColumn();
        $advanced['rageClick'] = (int)$q(
            "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'rage_click'",
            [$cutoff]
        )->fetchColumn();
        $advanced['jsError'] = (int)$q(
            "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'js_error'",
            [$cutoff]
        )->fetchColumn();
        $advanced['notFound'] = (int)$q(
            "SELECT COUNT(*) FROM engagement_events WHERE created_at >= ? AND event_type = 'not_found'",
            [$cutoff]
        )->fetchColumn();
    } catch (Throwable $e) { /* ignore */ }

    $webVitals = ['lcpAvg' => null, 'inpAvg' => null, 'clsAvg' => null, 'samples' => 0];
    try {
        $wvRows = $q(
            "SELECT source, metadata FROM conversion_events
             WHERE created_at >= ? AND event_type = 'web_vital'",
            [$cutoff]
        )->fetchAll(PDO::FETCH_ASSOC);
        $buckets = ['LCP' => [], 'INP' => [], 'CLS' => []];
        foreach ($wvRows as $row) {
            $src = strtoupper((string)($row['source'] ?? ''));
            $meta = is_string($row['metadata'] ?? null)
                ? json_decode($row['metadata'], true)
                : ($row['metadata'] ?? []);
            $val = isset($meta['value']) ? (float)$meta['value'] : null;
            if ($val === null || !isset($buckets[$src])) continue;
            $buckets[$src][] = $val;
        }
        $avg = static function (array $arr): ?float {
            if (!$arr) return null;
            return round(array_sum($arr) / count($arr), 1);
        };
        $webVitals = [
            'lcpAvg' => $avg($buckets['LCP']),
            'inpAvg' => $avg($buckets['INP']),
            'clsAvg' => $avg($buckets['CLS']),
            'samples' => count($wvRows),
        ];
    } catch (Throwable $e) { /* ignore */ }

    // Realtime — últimos 15 minutos
    $rtMinutes = 15;
    $rtCutoff = date('Y-m-d H:i:s', time() - ($rtMinutes * 60));
    $rtPageviews = (int)$q(
        'SELECT COUNT(*) FROM analytics WHERE created_at >= ?',
        [$rtCutoff]
    )->fetchColumn();
    $rtUniques = (int)$q(
        'SELECT COUNT(DISTINCT visitor_id) FROM analytics WHERE created_at >= ?',
        [$rtCutoff]
    )->fetchColumn();
    $rtPaths = $q(
        'SELECT path, COUNT(*) n FROM analytics WHERE created_at >= ? GROUP BY path ORDER BY n DESC LIMIT 8',
        [$rtCutoff]
    )->fetchAll(PDO::FETCH_ASSOC);

    // UTM agregados (se colunas existirem)
    $utmCampaigns = [];
    try {
        $hasUtm = $pdo->query("SHOW COLUMNS FROM analytics LIKE 'utm_campaign'")->fetch();
        if ($hasUtm) {
            $utmCampaigns = $q(
                "SELECT COALESCE(NULLIF(utm_campaign,''),'(sem campanha)') utm_campaign,
                        COALESCE(NULLIF(utm_source,''),'(direto)') utm_source,
                        COALESCE(NULLIF(utm_medium,''),'(n/a)') utm_medium,
                        COUNT(*) n
                 FROM analytics
                 WHERE created_at >= ? AND (utm_source IS NOT NULL OR utm_campaign IS NOT NULL OR gclid IS NOT NULL OR fbclid IS NOT NULL)
                 GROUP BY utm_campaign, utm_source, utm_medium
                 ORDER BY n DESC LIMIT 15",
                [$cutoff]
            )->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Throwable $e) { /* ignore */ }

    jsonRespond([
        'range' => $range,
        'gaId' => defined('GA_ID') ? GA_ID : (defined('GA_MEASUREMENT_ID') ? GA_MEASUREMENT_ID : null),
        'kpis' => [
            'pageviews' => $totalVisits,
            'uniqueVisitors' => $uniqueVisitors,
            'newVisitors' => $newVisitors,
            'returningVisitors' => $returning,
            'newPct' => $newPct,
            'returningPct' => $retPct,
            'whatsappClicks' => $waClicks,
            'conversionRate' => $convRate,
            'scroll100Events' => $scroll100,
            'phoneClicks' => $phoneClicks,
            'formSubmits' => $formSubmits,
            'leadSubmits' => $leadSubmits,
        ],
        'devices' => $devices,
        'cities' => $cities,
        'videoFunnel' => [
            'play' => $videoPlay,
            'watched50' => $video50,
            'watched100' => $video100,
            'completePct' => $videoPlay > 0 ? round(($video100 / $videoPlay) * 100, 1) : 0,
        ],
        'pages' => $pageRows,
        'topPosts' => $topPosts,
        'sources' => $sources,
        'sourceNames' => $sourceNames,
        'daily' => $daily,
        'commercialFunnel' => $commercialFunnel,
        'webVitals' => $webVitals,
        'advanced' => $advanced,
        'realtime' => [
            'windowMinutes' => $rtMinutes,
            'pageviews' => $rtPageviews,
            'uniqueVisitors' => $rtUniques,
            'topPaths' => $rtPaths,
        ],
        'utmCampaigns' => $utmCampaigns,
    ]);
}
