<?php
/** Proxy RSS YouTube — evita CORS no cliente e cacheia 1h. */

function youtubeChannelIdFromRequest(): string {
    $defaultChannelId = defined('YOUTUBE_CHANNEL_ID')
        ? YOUTUBE_CHANNEL_ID
        : 'UCM0LECJOYdp9R9J4XJYcRQg';
    $channelId = trim($_GET['channel'] ?? $defaultChannelId);
    if (!preg_match('/^UC[\w-]{20,}$/', $channelId)) {
        jsonRespond(['error' => 'Invalid channel id'], 400);
    }
    return $channelId;
}

function youtubeCacheFile(string $channelId): string {
    $cacheDir = defined('STORAGE_DIR') ? STORAGE_DIR . '/cache' : sys_get_temp_dir();
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0755, true);
    }
    return $cacheDir . '/yt_' . md5($channelId) . '.json';
}

/** Admin: invalida cache RSS do canal (próximo GET refetch). */
function handleYouTubeRefresh(string $method): void {
    requireAdmin();
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Method not allowed'], 405);
    }
    $channelId = youtubeChannelIdFromRequest();
    $cacheFile = youtubeCacheFile($channelId);
    $deleted = false;
    if (is_file($cacheFile)) {
        $deleted = @unlink($cacheFile);
    }
    // Cache Capitao (se existir via file cache simples)
    $capKey = (defined('STORAGE_DIR') ? STORAGE_DIR . '/cache' : sys_get_temp_dir())
        . '/youtube_stats_' . md5($channelId) . '.json';
    if (is_file($capKey)) {
        @unlink($capKey);
    }
    jsonRespond([
        'ok' => true,
        'channelId' => $channelId,
        'cacheCleared' => $deleted || !is_file($cacheFile),
        'hint' => 'Próximo GET youtube/videos busca o feed RSS novamente.',
    ]);
}

function handleYouTubeVideos(string $method): void {
    if ($method !== 'GET') {
        jsonRespond(['error' => 'Method not allowed'], 405);
    }

    $channelId = youtubeChannelIdFromRequest();
    $cacheFile = youtubeCacheFile($channelId);

    // refresh=1 + admin: ignora cache (útil no painel)
    $forceRefresh = isset($_GET['refresh']) && $_GET['refresh'] === '1' && function_exists('isAdmin') && isAdmin();

    if (!$forceRefresh && is_file($cacheFile) && filemtime($cacheFile) > time() - 3600) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: public, max-age=3600');
        readfile($cacheFile);
        exit;
    }

    $ctx = stream_context_create(['http' => ['timeout' => 8, 'user_agent' => 'AutoLimpezaPro/1.0']]);
    $feed = @file_get_contents(
        "https://www.youtube.com/feeds/videos.xml?channel_id={$channelId}",
        false,
        $ctx
    );

    $videos = [];
    if ($feed !== false && preg_match_all('/<entry>([\s\S]*?)<\/entry>/', $feed, $matches)) {
        foreach ($matches[1] as $block) {
            $id = null;
            $title = '';
            if (preg_match('/<yt:videoId>([^<]+)<\/yt:videoId>/', $block, $m)) {
                $id = $m[1];
            }
            if (preg_match('/<title>([^<]+)<\/title>/', $block, $m)) {
                $title = html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }
            if ($id) {
                $videos[] = [
                    'id'      => $id,
                    'title'   => $title,
                    // Shorts: só com #shorts (evitar falso positivo por título curto)
                    'isShort' => (bool) preg_match('/#shorts/i', $title),
                ];
            }
            if (count($videos) >= 20) {
                break;
            }
        }
    }

    $payload = json_encode(['videos' => $videos], JSON_UNESCAPED_UNICODE);
    @file_put_contents($cacheFile, $payload);

    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: ' . ($forceRefresh ? 'no-store' : 'public, max-age=3600'));
    echo $payload;
    exit;
}
