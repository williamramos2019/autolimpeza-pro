<?php
/**
 * Autenticação de administradores — login, sessão e troca de senha.
 */

/**
 * Credenciais master — somente via config.php.
 * Sem senha configurada: falha fechada (sem fallback hardcoded).
 */
function masterAdminCredentials(): ?array {
    $email = defined('MASTER_ADMIN_EMAIL') ? strtolower(trim((string) MASTER_ADMIN_EMAIL)) : '';
    $pass  = defined('MASTER_ADMIN_PASSWORD') ? (string) MASTER_ADMIN_PASSWORD : '';
    if ($email === '' || $pass === '') {
        return null;
    }
    return ['email' => $email, 'password' => $pass, 'name' => 'Administrador'];
}

function isMasterAdminLogin(string $email, string $password): bool {
    $m = masterAdminCredentials();
    if ($m === null) {
        return false;
    }
    return hash_equals($m['email'], strtolower(trim($email)))
        && hash_equals($m['password'], $password);
}

/** Garante usuário admin no banco. Sincroniza senha do config quando o hash não bate. */
function ensureMasterAdminUser(PDO $pdo, bool $syncPasswordFromConfig = false): array {
    $m = masterAdminCredentials();
    if ($m === null) {
        throw new RuntimeException('MASTER_ADMIN_PASSWORD não configurada');
    }
    $now = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare(
        'SELECT id, email, name, password_hash, role, must_change_password, active
           FROM admin_users WHERE email = ? LIMIT 1'
    );
    $stmt->execute([$m['email']]);
    $existing = $stmt->fetch();

    if ($existing) {
        $needsPwSync = $syncPasswordFromConfig
            && (empty($existing['password_hash']) || !password_verify($m['password'], (string)$existing['password_hash']));
        if ($needsPwSync) {
            $hash = password_hash($m['password'], PASSWORD_DEFAULT);
            $pdo->prepare(
                'UPDATE admin_users SET name = ?, password_hash = ?, must_change_password = 0, active = 1, updated_at = ? WHERE id = ?'
            )->execute([$m['name'], $hash, $now, $existing['id']]);
            $existing['password_hash'] = $hash;
            $existing['must_change_password'] = 0;
        } else {
            $pdo->prepare(
                'UPDATE admin_users SET name = ?, active = 1, updated_at = ? WHERE id = ?'
            )->execute([$m['name'], $now, $existing['id']]);
        }
        $existing['name'] = $m['name'];
        $existing['active'] = 1;
        return $existing;
    }

    $hash = password_hash($m['password'], PASSWORD_DEFAULT);
    $pdo->prepare(
        'INSERT INTO admin_users (email, name, password_hash, role, must_change_password, active, created_at, updated_at)
         VALUES (?, ?, ?, ?, 0, 1, ?, ?)'
    )->execute([$m['email'], $m['name'], $hash, 'admin', $now, $now]);

    $stmt->execute([$m['email']]);
    $user = $stmt->fetch();
    if (!$user) {
        throw new RuntimeException('Falha ao provisionar administrador master');
    }
    return $user;
}

function issueAdminSession(array $user, bool $forceNoPasswordChange = false): void {
    jsonRespond(buildAdminSessionResponse($user, $forceNoPasswordChange));
}

/**
 * Cria sessão admin e devolve payload (sem jsonRespond) — usado no portal
 * quando e-mail admin tenta login Google/senha e deve ir ao Painel Admin.
 */
function buildAdminSessionResponse(array $user, bool $forceNoPasswordChange = false): array {
    $token   = generateToken(32);
    $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
    $now     = dbNow();
    $hash    = hashSessionToken($token);
    $prefix  = sessionTokenPrefix($token);

    try {
        db()->prepare(
            'INSERT INTO admin_sessions (token, token_hash, token_prefix, user_id, expires_at, created_at)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([$hash, $hash, $prefix, $user['id'], $expires, $now]);
    } catch (PDOException $e) {
        if (!function_exists('pdoIsUnknownColumn') || !pdoIsUnknownColumn($e)) {
            throw $e;
        }
        db()->prepare(
            'INSERT INTO admin_sessions (token, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)'
        )->execute([$token, $user['id'], $expires, $now]);
    }

    db()->prepare('UPDATE admin_users SET last_login_at = ?, updated_at = ? WHERE id = ?')
        ->execute([$now, $now, $user['id']]);

    appLog('info', 'admin_login_ok', ['user_id' => $user['id']]);

    return [
        'ok'                 => true,
        'isAdmin'            => true,
        'redirect'           => '/admin',
        'token'              => $token,
        'email'              => $user['email'],
        'name'               => $user['name'],
        'role'               => $user['role'],
        'mustChangePassword' => $forceNoPasswordChange ? false : (bool)$user['must_change_password'],
        'expiresAt'          => $expires,
        'message'            => 'Conta de administrador — redirecionando ao Painel Admin.',
    ];
}

/**
 * True se o e-mail é Admin Mestre ou está em admin_users ativo.
 * Usado para impedir conta cliente paralela e forçar redirect ao /admin.
 */
function emailIsAdminAccount(PDO $pdo, string $email): bool {
    $email = strtolower(trim($email));
    if ($email === '' || !isEmail($email)) {
        return false;
    }
    $master = masterAdminCredentials();
    if ($master !== null && hash_equals($master['email'], $email)) {
        return true;
    }
    try {
        $stmt = $pdo->prepare('SELECT id FROM admin_users WHERE email = ? AND active = 1 LIMIT 1');
        $stmt->execute([$email]);
        return (bool)$stmt->fetch();
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Autentica admin por e-mail+senha (master config ou admin_users).
 * @return array|null usuário admin ou null
 */
function authenticateAdminByPassword(PDO $pdo, string $email, string $password): ?array {
    $email = strtolower(trim($email));
    if ($email === '' || $password === '') {
        return null;
    }
    if (isMasterAdminLogin($email, $password)) {
        return ensureMasterAdminUser($pdo, true);
    }
    $stmt = $pdo->prepare(
        'SELECT id, email, name, password_hash, role, must_change_password, active
           FROM admin_users WHERE email = ? LIMIT 1'
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if (!$user || !(int)$user['active']) {
        return null;
    }
    if (empty($user['password_hash']) || !password_verify($password, (string)$user['password_hash'])) {
        return null;
    }
    return $user;
}

/** Resposta 403 pedindo redirect ao admin (sem emitir sessão). */
function respondAdminAccountRedirect(string $email, string $extraMessage = ''): void {
    $msg = 'Este e-mail é de administrador. Acesse o Painel Admin em /admin.';
    if ($extraMessage !== '') {
        $msg = $extraMessage;
    }
    jsonRespond([
        'error'     => $msg,
        'isAdmin'   => true,
        'redirect'  => '/admin',
        'email'     => strtolower(trim($email)),
        'message'   => $msg,
    ], 403);
}

function handleAdminLogin(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Use POST'], 405);
    }
    rateLimit('admin_login', 10);

    $b        = jsonBody();
    $email    = strtolower(trim(san($b['email'] ?? '', 255) ?? ''));
    $password = (string)($b['password'] ?? '');

    if ($email === '' || $password === '') {
        jsonRespond(['error' => 'E-mail e senha são obrigatórios'], 400);
    }

    // Login master — e-mail + senha do config (MASTER_ADMIN_*)
    if (isMasterAdminLogin($email, $password)) {
        try {
            $user = ensureMasterAdminUser(db(), true);
            issueAdminSession($user, true);
        } catch (PDOException $e) {
            appLog('error', 'admin_login_master_db', ['msg' => $e->getMessage()]);
            jsonRespond(['error' => 'Sistema não instalado. Execute install.php'], 503);
        } catch (Throwable $e) {
            appLog('error', 'admin_login_master', ['msg' => $e->getMessage()]);
            jsonRespond(['error' => 'Falha ao autenticar administrador'], 500);
        }
        return;
    }

    try {
        $stmt = db()->prepare(
            'SELECT id, email, name, password_hash, role, must_change_password, active
               FROM admin_users WHERE email = ? LIMIT 1'
        );
        $stmt->execute([$email]);
        $user = $stmt->fetch();
    } catch (PDOException $e) {
        appLog('error', 'admin_login_db', ['msg' => $e->getMessage()]);
        jsonRespond(['error' => 'Sistema não instalado. Execute install.php'], 503);
    }

    if (!$user || !(int)$user['active'] || !password_verify($password, $user['password_hash'])) {
        appLog('warn', 'admin_login_failed', ['email' => $email]);
        jsonRespond(['error' => 'Credenciais inválidas'], 401);
    }

    issueAdminSession($user);
}

function handleAdminChangePassword(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Use POST'], 405);
    }
    rateLimit('admin_change_pw', 5);
    requireAdmin();

    $userId = adminSessionUserId();
    if (!$userId) {
        jsonRespond(['error' => 'Sessão inválida'], 401);
    }

    $b           = jsonBody();
    $current     = (string)($b['currentPassword'] ?? '');
    $newPassword = (string)($b['newPassword'] ?? '');
    $skipCurrent = !empty($b['skipCurrent']);

    if (strlen($newPassword) < 8) {
        jsonRespond(['error' => 'Nova senha deve ter no mínimo 8 caracteres'], 400);
    }

    $stmt = db()->prepare('SELECT password_hash, must_change_password FROM admin_users WHERE id = ? AND active = 1');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if (!$user) {
        jsonRespond(['error' => 'Usuário não encontrado'], 401);
    }

    $mustChange = !empty($user['must_change_password']);
    // Gate único: Google / must_change — permite definir senha sem senha atual
    if (!($mustChange && $skipCurrent)) {
        if ($current === '' || !password_verify($current, $user['password_hash'])) {
            jsonRespond(['error' => 'Senha atual incorreta'], 401);
        }
    }

    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
    $now  = dbNow();
    db()->prepare(
        'UPDATE admin_users SET password_hash = ?, must_change_password = 0, updated_at = ? WHERE id = ?'
    )->execute([$hash, $now, $userId]);

    // Revoga outras sessões (mantém a atual se possível)
    $auth = getAuthorizationHeader();
    $currentToken = (strpos($auth, 'Bearer ') === 0) ? trim(substr($auth, 7)) : '';
    try {
        if ($currentToken !== '') {
            $h = hashSessionToken($currentToken);
            db()->prepare(
                'DELETE FROM admin_sessions WHERE user_id = ? AND token_hash IS NOT NULL AND token_hash != ?'
            )->execute([$userId, $h]);
            db()->prepare(
                'DELETE FROM admin_sessions WHERE user_id = ? AND (token_hash IS NULL OR token_hash = "") AND token != ?'
            )->execute([$userId, $currentToken]);
        } else {
            db()->prepare('DELETE FROM admin_sessions WHERE user_id = ?')->execute([$userId]);
        }
    } catch (PDOException $e) {
        try {
            db()->prepare('DELETE FROM admin_sessions WHERE user_id = ?')->execute([$userId]);
        } catch (PDOException $e2) { /* ignore */ }
    }

    appLog('info', 'admin_password_changed', ['user_id' => $userId]);
    jsonRespond(['ok' => true]);
}

function handleAdminLogout(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Use POST'], 405);
    }
    requireAdmin();

    $auth = getAuthorizationHeader();
    if (strpos($auth, 'Bearer ') !== 0) {
        jsonRespond(['ok' => true]);
    }
    $token = trim(substr($auth, 7));
    if ($token === '') {
        jsonRespond(['ok' => true]);
    }
    // Token estático (DEV): nada a revogar no banco
    if (
        function_exists('allowStaticAdminToken')
        && allowStaticAdminToken()
        && defined('ADMIN_TOKEN')
        && ADMIN_TOKEN !== ''
        && hash_equals((string)ADMIN_TOKEN, $token)
    ) {
        jsonRespond(['ok' => true]);
    }

    try {
        $h = hashSessionToken($token);
        db()->prepare('DELETE FROM admin_sessions WHERE token_hash = ? OR token = ?')->execute([$h, $token]);
        appLog('info', 'admin_logout', []);
    } catch (PDOException $e) {
        try {
            db()->prepare('DELETE FROM admin_sessions WHERE token = ?')->execute([$token]);
        } catch (PDOException $e2) {
            appLog('warn', 'admin_logout_failed', ['err' => $e2->getMessage()]);
        }
    }

    jsonRespond(['ok' => true]);
}

function handleAdminMe(string $method): void {
    if ($method !== 'GET') {
        jsonRespond(['error' => 'Use GET'], 405);
    }
    requireAdmin();
    $userId = adminSessionUserId();
    if (!$userId) {
        jsonRespond(['legacy' => true, 'mustChangePassword' => false]);
    }

    // Sliding renewal: estende a sessão a cada visitação autenticada (até 30 dias)
    renewAdminSessionToken();

    $stmt = db()->prepare(
        'SELECT id, email, name, role, must_change_password FROM admin_users WHERE id = ?'
    );
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if (!$user) {
        jsonRespond(['error' => 'Usuário não encontrado'], 404);
    }
    jsonRespond([
        'id'                 => (int)$user['id'],
        'email'              => $user['email'],
        'name'               => $user['name'],
        'role'               => $user['role'],
        'mustChangePassword' => (bool)$user['must_change_password'],
    ]);
}

/** Estende expires_at da sessão Bearer atual (+30 dias), respeitando teto de created_at+30d. */
function renewAdminSessionToken(): void {
    $auth = getAuthorizationHeader();
    if (strpos($auth, 'Bearer ') !== 0) {
        return;
    }
    $token = trim(substr($auth, 7));
    if ($token === '') {
        return;
    }
    if (
        function_exists('allowStaticAdminToken')
        && allowStaticAdminToken()
        && defined('ADMIN_TOKEN')
        && ADMIN_TOKEN !== ''
        && hash_equals((string)ADMIN_TOKEN, $token)
    ) {
        return;
    }
    try {
        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
        $h = hashSessionToken($token);
        db()->prepare(
            'UPDATE admin_sessions SET expires_at = LEAST(?, DATE_ADD(created_at, INTERVAL 30 DAY))
             WHERE (token_hash = ? OR token = ?) AND expires_at > NOW()
               AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)'
        )->execute([$expires, $h, $token]);
    } catch (PDOException $e) {
        try {
            $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
            db()->prepare(
                'UPDATE admin_sessions SET expires_at = ? WHERE token = ? AND expires_at > NOW()'
            )->execute([$expires, $token]);
        } catch (PDOException $e2) { /* ignore */ }
    }
}

function adminSessionUserId(): ?int {
    $auth = getAuthorizationHeader();
    if (strpos($auth, 'Bearer ') !== 0) {
        return null;
    }
    $token = trim(substr($auth, 7));
    if ($token === '') {
        return null;
    }
    if (
        function_exists('allowStaticAdminToken')
        && allowStaticAdminToken()
        && defined('ADMIN_TOKEN')
        && ADMIN_TOKEN !== ''
        && hash_equals((string)ADMIN_TOKEN, $token)
    ) {
        return null; // legacy static — sem user_id
    }
    try {
        $h = hashSessionToken($token);
        $stmt = db()->prepare(
            'SELECT s.user_id FROM admin_sessions s
             JOIN admin_users u ON u.id = s.user_id
             WHERE (s.token_hash = ? OR (s.token_hash IS NULL AND s.token = ?))
               AND s.expires_at > NOW()
               AND s.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
               AND u.active = 1
             LIMIT 1'
        );
        $stmt->execute([$h, $token]);
        $row = $stmt->fetch();
        return $row ? (int)$row['user_id'] : null;
    } catch (PDOException $e) {
        try {
            $stmt = db()->prepare(
                'SELECT s.user_id FROM admin_sessions s
                 JOIN admin_users u ON u.id = s.user_id
                 WHERE s.token = ? AND s.expires_at > NOW() AND u.active = 1'
            );
            $stmt->execute([$token]);
            $row = $stmt->fetch();
            return $row ? (int)$row['user_id'] : null;
        } catch (PDOException $e2) {
            return null;
        }
    }
}

/** Valida ID token JWT do Google Sign-In e retorna claims ou null. */
function verifyGoogleIdToken(string $idToken): ?array {
    $clientId = googleOAuthClientId();
    if ($clientId === '' || $idToken === '') {
        return null;
    }
    $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($idToken);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_CONNECTTIMEOUT => 6,
    ]);
    $raw = curl_exec($ch);
    $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($http !== 200 || !$raw) {
        return null;
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return null;
    }
    if (($data['aud'] ?? '') !== $clientId) {
        return null;
    }
    $iss = (string) ($data['iss'] ?? '');
    if ($iss !== 'accounts.google.com' && $iss !== 'https://accounts.google.com') {
        return null;
    }
    $verified = $data['email_verified'] ?? false;
    if ($verified !== true && $verified !== 'true') {
        return null;
    }
    if (empty($data['email'])) {
        return null;
    }
    if (isset($data['exp']) && (int) $data['exp'] < time()) {
        return null;
    }
    return $data;
}

/** Resolve admin ativo pelo e-mail Google (master ou registro em admin_users). */
function resolveAdminUserForGoogleEmail(PDO $pdo, string $email, ?string $displayName = null): ?array {
    $email = strtolower(trim($email));
    if ($email === '') {
        return null;
    }
    $master = masterAdminCredentials();
    if ($master !== null && hash_equals($master['email'], $email)) {
        return ensureMasterAdminUser($pdo, true);
    }
    $stmt = $pdo->prepare(
        'SELECT id, email, name, password_hash, role, must_change_password, active
           FROM admin_users WHERE email = ? LIMIT 1'
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if (!$user || !(int) $user['active']) {
        return null;
    }
    if ($displayName !== null && trim($displayName) !== '' && trim((string) $user['name']) === 'Administrador') {
        $now = dbNow();
        $pdo->prepare('UPDATE admin_users SET name = ?, updated_at = ? WHERE id = ?')
            ->execute([san($displayName, 200) ?: $user['name'], $now, $user['id']]);
        $user['name'] = san($displayName, 200) ?: $user['name'];
    }
    return $user;
}

function handleAdminGoogleConfig(string $method): void {
    if ($method !== 'GET') {
        jsonRespond(['error' => 'Use GET'], 405);
    }
    $clientId = googleOAuthClientId();
    jsonRespond([
        'enabled'  => $clientId !== '',
        'clientId' => $clientId !== '' ? $clientId : null,
    ]);
}

function handleAdminGoogleLogin(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Use POST'], 405);
    }
    rateLimit('admin_google_login', 10);

    if (googleOAuthClientId() === '') {
        jsonRespond(['error' => 'Login com Google não configurado. Defina GOOGLE_OAUTH_CLIENT_ID no config.php'], 503);
    }

    $b = jsonBody();
    $credential = trim((string) ($b['credential'] ?? $b['idToken'] ?? ''));
    if ($credential === '') {
        jsonRespond(['error' => 'Token Google ausente'], 400);
    }

    $claims = verifyGoogleIdToken($credential);
    if (!$claims) {
        appLog('warn', 'admin_google_invalid_token', []);
        jsonRespond(['error' => 'Token Google inválido ou expirado'], 401);
    }

    $email = strtolower(trim((string) $claims['email']));
    $name  = (string) ($claims['name'] ?? $claims['given_name'] ?? '');

    try {
        $user = resolveAdminUserForGoogleEmail(db(), $email, $name);
    } catch (PDOException $e) {
        appLog('error', 'admin_google_db', ['msg' => $e->getMessage()]);
        jsonRespond(['error' => 'Sistema não instalado. Execute install.php'], 503);
    } catch (Throwable $e) {
        appLog('error', 'admin_google_resolve', ['msg' => $e->getMessage()]);
        jsonRespond(['error' => 'Falha ao autenticar'], 500);
    }

    if (!$user) {
        appLog('warn', 'admin_google_denied', ['email' => $email]);
        jsonRespond([
            'error' => 'Esta conta Google não está autorizada como administrador. Use o e-mail cadastrado no sistema.',
        ], 403);
    }

    appLog('info', 'admin_google_login_ok', ['user_id' => $user['id'], 'email' => $email]);
    // Conta master (MASTER_ADMIN_EMAIL): entra direto no painel, sem forçar troca de senha
    $isMaster = false;
    $master = masterAdminCredentials();
    if ($master !== null && hash_equals($master['email'], $email)) {
        $isMaster = true;
    }
    issueAdminSession($user, $isMaster);
}

function createInitialAdminUser(
    PDO $pdo,
    string $email,
    string $plainPassword,
    string $name = 'Administrador',
    bool $mustChange = true,
): array {
    $hash = password_hash($plainPassword, PASSWORD_DEFAULT);
    $now  = date('Y-m-d H:i:s');
    $flag = $mustChange ? 1 : 0;
    $pdo->prepare(
        'INSERT INTO admin_users (email, name, password_hash, role, must_change_password, active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?)
         ON DUPLICATE KEY UPDATE
           password_hash = VALUES(password_hash),
           must_change_password = VALUES(must_change_password),
           updated_at = VALUES(updated_at)'
    )->execute([$email, $name, $hash, 'admin', $flag, $now, $now]);
    return ['email' => $email, 'password' => $plainPassword, 'name' => $name];
}
