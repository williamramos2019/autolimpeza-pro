<?php
/**
 * AI Image Gateway
 * Geração de imagem com fallback entre provedores e logs.
 */

function ensureAiImageTables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `ai_image_providers` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `name` VARCHAR(120) NOT NULL,
        `provider_type` VARCHAR(40) NOT NULL,
        `api_key_enc` TEXT DEFAULT NULL,
        `base_url` VARCHAR(500) DEFAULT NULL,
        `model` VARCHAR(120) DEFAULT NULL,
        `priority` INT NOT NULL DEFAULT 100,
        `timeout_sec` INT NOT NULL DEFAULT 45,
        `daily_limit` INT DEFAULT NULL,
        `enabled` TINYINT(1) NOT NULL DEFAULT 1,
        `last_error` VARCHAR(500) DEFAULT NULL,
        `last_used_at` DATETIME DEFAULT NULL,
        `created_at` DATETIME NOT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_ai_img_prio` (`priority`, `enabled`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `ai_image_logs` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `prompt_hash` VARCHAR(64) NOT NULL,
        `provider` VARCHAR(120) DEFAULT NULL,
        `provider_type` VARCHAR(40) DEFAULT NULL,
        `model` VARCHAR(120) DEFAULT NULL,
        `status` VARCHAR(20) NOT NULL,
        `error_code` VARCHAR(60) DEFAULT NULL,
        `error_message` VARCHAR(500) DEFAULT NULL,
        `latency_ms` INT DEFAULT NULL,
        `image_url` VARCHAR(800) DEFAULT NULL,
        `meta_json` JSON DEFAULT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_ai_img_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $count = (int)$pdo->query('SELECT COUNT(*) FROM ai_image_providers')->fetchColumn();
    if ($count === 0) {
        $now = dbNow();
        $pdo->prepare('INSERT INTO ai_image_providers (name, provider_type, base_url, model, priority, timeout_sec, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute(['Pollinations (Free)', 'pollinations', 'https://image.pollinations.ai', 'flux', 10, 40, 1, $now, $now]);
        $pdo->prepare('INSERT INTO ai_image_providers (name, provider_type, base_url, model, priority, timeout_sec, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute(['OpenAI Images', 'openai_images', 'https://api.openai.com/v1/images/generations', 'gpt-image-1', 30, 60, 0, $now, $now]);
        $pdo->prepare('INSERT INTO ai_image_providers (name, provider_type, base_url, model, priority, timeout_sec, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute(['Stability', 'stability', null, 'stable-image-ultra', 40, 60, 0, $now, $now]);
        $pdo->prepare('INSERT INTO ai_image_providers (name, provider_type, base_url, model, priority, timeout_sec, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute(['HuggingFace', 'huggingface_image', null, 'black-forest-labs/FLUX.1-schnell', 50, 60, 0, $now, $now]);
        $pdo->prepare('INSERT INTO ai_image_providers (name, provider_type, base_url, model, priority, timeout_sec, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute(['Gemini Image', 'gemini_image', null, 'imagen-3.0-generate-002', 60, 60, 0, $now, $now]);
    }
}

function aiImageProviderApiKey(string $type, string $encStored = ''): string {
    $key = aiGatewayNormalizeApiKey(null, $encStored, match ($type) {
        'openai_images' => 'openai',
        'gemini_image' => 'gemini',
        default => null,
    });
    return $key;
}

function aiImageDownloadBinary(string $url, int $timeoutSec): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeoutSec,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPGET => true,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($err) {
        return ['ok' => false, 'error' => $err, 'http' => 0];
    }
    if ($code < 200 || $code >= 300 || !is_string($body) || $body === '') {
        return ['ok' => false, 'error' => "HTTP {$code}", 'http' => $code];
    }
    return ['ok' => true, 'binary' => $body, 'contentType' => $ctype, 'http' => $code];
}

function aiImageLooksValid(string $binary): bool {
    if ($binary === '' || strlen($binary) < 64) return false;
    if (function_exists('getimagesizefromstring')) {
        $g = @getimagesizefromstring($binary);
        return is_array($g) && !empty($g[0]) && !empty($g[1]);
    }
    return true;
}

/**
 * Define o objeto/cena EXATO da capa com base no tema do artigo (nunca genérico).
 * @return array{subject:string,scene:string,focus:string}
 */
function aiImageVisualBriefFromArticle(array $article): array {
    $title = trim((string)($article['title'] ?? ''));
    $keyword = trim((string)($article['keyword'] ?? $article['topic'] ?? ''));
    $keywords = trim((string)($article['keywords'] ?? ''));
    $category = trim((string)($article['category'] ?? ''));
    $serviceId = mb_strtolower(trim((string)($article['serviceId'] ?? $article['service_id'] ?? '')));
    $excerpt = trim(strip_tags((string)($article['excerpt'] ?? '')));
    $content = trim(strip_tags((string)($article['content'] ?? '')));
    if ($content === '' && function_exists('cmsBlocksToPlainText')) {
        $content = cmsBlocksToPlainText($article['blocks'] ?? []);
    }
    $blob = mb_strtolower(implode(' ', array_filter([$title, $keyword, $keywords, $category, $excerpt, mb_substr($content, 0, 400)])));

    $pick = static function (array $rules, array $fallback) use ($blob, $serviceId): array {
        foreach ($rules as $rule) {
            $match = false;
            if (!empty($rule['service']) && $serviceId !== '' && in_array($serviceId, (array)$rule['service'], true)) {
                $match = true;
            }
            if (!$match && !empty($rule['pattern']) && preg_match($rule['pattern'], $blob)) {
                $match = true;
            }
            if ($match) {
                return [
                    'subject' => $rule['subject'],
                    'scene' => $rule['scene'],
                    'focus' => $rule['focus'],
                ];
            }
        }
        return $fallback;
    };

    return $pick([
        [
            'service' => ['automotivo'],
            'pattern' => '/\b(automotiv|carro|ve[ií]culo|banco do carro|interior automotiv|estofado automotiv|couro automotiv)\b/u',
            'subject' => 'real car interior with fabric and leather car seats',
            'scene' => 'professional automotive upholstery steam cleaning, technician extracting dirt from car seat fibers',
            'focus' => 'close-up of car seat upholstery before and after deep cleaning, visible stain removal',
        ],
        [
            'service' => ['colchao'],
            'pattern' => '/\b(colch[aã]o|colchões|anti.?ácaro|ácaros no colch|mites mattress)\b/u',
            'subject' => 'real mattress surface and bedroom mattress side view',
            'scene' => 'professional mattress hygienization with extraction machine on mattress fabric',
            'focus' => 'macro of mattress fabric fibers with dust mites concept vs sanitized clean mattress',
        ],
        [
            'service' => ['tapete'],
            'pattern' => '/\b(tapete|carpete|persa|rug cleaning)\b/u',
            'subject' => 'real area rug or carpet on living room floor',
            'scene' => 'professional carpet cleaning with extraction wand on rug fibers',
            'focus' => 'split view dirty carpet traffic lane vs freshly cleaned carpet pile',
        ],
        [
            'service' => ['pos-obra'],
            'pattern' => '/\b(p[oó]s.?obra|obra|constru[cç][aã]o|cimento|entulho|reforma)\b/u',
            'subject' => 'real construction site interior with dusty floor and unfinished walls',
            'scene' => 'heavy-duty post-construction cleaning, removing construction dust and debris',
            'focus' => 'dramatic before messy construction dust after pristine clean room',
        ],
        [
            'service' => ['impermeabilizacao'],
            'pattern' => '/\b(impermeabiliz|protetor de tecido|repelente|waterproof)\b/u',
            'subject' => 'real fabric sofa with water droplets beading on treated upholstery',
            'scene' => 'fabric waterproofing treatment on sofa textile, hydrophobic effect visible',
            'focus' => 'close-up water beads on protected sofa fabric after professional treatment',
        ],
        [
            'service' => ['cadeira'],
            'pattern' => '/\b(cadeira|cadeiras|chair upholstery|escritório)\b/u',
            'subject' => 'real office or dining chair with fabric upholstery',
            'scene' => 'professional chair upholstery cleaning with foam and extraction',
            'focus' => 'chair seat fabric before stains vs after professional hygienization',
        ],
        [
            'service' => ['sofa'],
            'pattern' => '/\b(sof[aá]|sofa|living room couch|sala de estar)\b/u',
            'subject' => 'real L-shaped fabric sofa in Brazilian living room',
            'scene' => 'professional sofa deep cleaning with extraction machine on couch cushions',
            'focus' => 'sofa cushion fibers macro with dust vs immaculately clean sofa upholstery',
        ],
        [
            'service' => ['estofado'],
            'pattern' => '/\b(estofado|estofados|poltrona|upholstery)\b/u',
            'subject' => 'real upholstered armchair or sectional sofa fabric',
            'scene' => 'professional upholstery hygienization in home interior',
            'focus' => 'upholstered furniture fabric texture before and after sanitization',
        ],
    ], [
        'subject' => $title !== ''
            ? 'the exact physical subject of the article titled "' . mb_substr($title, 0, 120) . '"'
            : 'the exact cleaning/hygienization subject described by the article topic',
        'scene' => 'professional cleaning / hygienization scene that matches the article topic in a Brazilian home',
        'focus' => 'photorealistic depiction of the article subject (not a generic stock sofa unless the article is about sofa)',
    ]);
}

function aiImagePromptFromArticle(array $article): string {
    $explicit = trim((string)($article['coverImagePrompt'] ?? $article['cover_image_prompt'] ?? ''));
    $brief = aiImageVisualBriefFromArticle($article);
    $title = trim((string)($article['title'] ?? ''));
    $category = trim((string)($article['category'] ?? ''));
    $city = trim((string)($article['city'] ?? ''));
    $keyword = trim((string)($article['keyword'] ?? $article['topic'] ?? ''));
    $quality = 'Ultra-realistic 8K commercial photograph, photorealistic, accurate materials and textures, '
        . 'dramatic cinematic lighting, shallow depth of field. '
        . 'NOT abstract, NOT random stock collage, NOT unrelated objects, NOT generic office, NOT people faces. '
        . 'No text, no logos, no watermarks.';

    // Prompt explícito do artigo (LLM) tem prioridade — evita conflito com brief genérico de sofá
    if (mb_strlen($explicit) >= 40) {
        $prompt = 'PRIMARY SUBJECT (follow exactly): ' . $explicit . '. ' . $quality;
        if ($title !== '') {
            $prompt .= " Article title: \"{$title}\".";
        }
        if ($category !== '') {
            $prompt .= " Category: {$category}.";
        }
        if ($keyword !== '' && mb_strtolower($keyword) !== mb_strtolower($title)) {
            $prompt .= " Focus keyword: {$keyword}.";
        }
        if ($city !== '') {
            $prompt .= " Brazilian home in {$city}, Minas Gerais.";
        } else {
            $prompt .= ' Brazilian residential interior.';
        }
        return $prompt;
    }

    $mandatory = 'MANDATORY: depict ONLY ' . $brief['subject'] . '. Scene: ' . $brief['scene'] . '. '
        . 'Visual focus: ' . $brief['focus'] . '. ' . $quality;

    $prompt = $mandatory;
    if ($title !== '') {
        $prompt .= " This image MUST illustrate the blog article titled: \"{$title}\".";
    }
    if ($category !== '') {
        $prompt .= " Service category: {$category}.";
    }
    if ($keyword !== '' && mb_strtolower($keyword) !== mb_strtolower($title)) {
        $prompt .= " Main topic keyword: {$keyword}.";
    }
    if ($explicit !== '') {
        $prompt .= ' Article-specific direction: ' . $explicit . '.';
    }
    if ($city !== '') {
        $prompt .= " Setting: typical Brazilian home in {$city}, Minas Gerais region.";
    }
    return $prompt;
}

/**
 * Prompt limpo (EN) para copiar em Midjourney / Leonardo / Ideogram / Flux / DALL·E.
 * Remove jargão interno e adiciona qualidade editorial 16:9.
 */
function aiImagePromptForExternalPlatform(array $article, ?string $internalPrompt = null): string {
    $raw = trim((string)($internalPrompt ?: aiImagePromptFromArticle($article)));
    $raw = preg_replace('/\bMANDATORY:\s*/i', '', $raw) ?? $raw;
    $raw = preg_replace('/\bArticle-specific direction:\s*/i', '', $raw) ?? $raw;
    $raw = preg_replace('/\bArticle title context:\s*/i', 'Context: ', $raw) ?? $raw;
    $raw = preg_replace('/\s+/', ' ', $raw) ?? $raw;
    $raw = trim($raw);
    if ($raw === '') {
        $raw = 'Create a high quality commercial photography image showing professional upholstery cleaning in a Brazilian living room';
    }
    if (!preg_match('/^Create a high quality/i', $raw)) {
        $raw = 'Create a high quality commercial photography image: ' . $raw;
    }
    $title = trim((string)($article['title'] ?? ''));
    $city = trim((string)($article['city'] ?? 'São José da Lapa / Vespasiano, Minas Gerais, Brazil'));
    $negative = 'NEGATIVE PROMPT: text, logos, watermarks, blurry, distorted hands, deformed furniture, cartoon, illustration, stock collage, generic office, people faces close-up, low resolution, oversaturated.';
    $tail = ' Environment: typical Brazilian residential interior in ' . $city . '.'
        . ' Style: ultra-realistic commercial photography, 8K, accurate materials and textures, cinematic natural lighting, shallow depth of field, editorial quality.'
        . ' Aspect ratio: 16:9 horizontal blog cover.'
        . ($title !== '' ? " Article context: {$title}." : '')
        . ' ' . $negative;
    if (!preg_match('/NEGATIVE PROMPT/i', $raw)) {
        $raw .= $tail;
    }
    return trim(preg_replace('/\s+/', ' ', $raw) ?? $raw);
}

/** Monta prompt a partir de título/conteúdo (posts, dicas, geração on-demand). */
function aiImagePromptFromContext(array $ctx): string {
    $explicit = trim((string)($ctx['prompt'] ?? $ctx['coverImagePrompt'] ?? $ctx['cover_image_prompt'] ?? ''));
    if ($explicit !== '' && !empty($ctx['skipBriefMerge'])) {
        return $explicit;
    }

    $article = [
        'title' => trim((string)($ctx['title'] ?? '')),
        'category' => trim((string)($ctx['category'] ?? '')),
        'city' => trim((string)($ctx['city'] ?? '')),
        'keyword' => trim((string)($ctx['keyword'] ?? $ctx['topic'] ?? '')),
        'keywords' => trim((string)($ctx['keywords'] ?? '')),
        'serviceId' => $ctx['serviceId'] ?? $ctx['service_id'] ?? null,
        'excerpt' => trim((string)($ctx['excerpt'] ?? '')),
        'content' => trim(strip_tags((string)($ctx['content'] ?? $ctx['text'] ?? ''))),
        'blocks' => $ctx['blocks'] ?? [],
        'coverImagePrompt' => $explicit,
    ];
    if ($article['content'] === '' && !empty($ctx['text'])) {
        $article['content'] = trim(strip_tags((string)$ctx['text']));
    }
    return aiImagePromptFromArticle($article);
}

/** Seed determinístico por artigo — mesma capa ao regerar o mesmo post. */
function aiImageSeedFromContext(array $ctx, string $prompt): int {
    $key = trim((string)($ctx['slug'] ?? $ctx['postSlug'] ?? ''))
        . '|' . substr(hash('sha256', $prompt), 0, 16)
        . '|' . (string)($ctx['try'] ?? '1');
    return (int) sprintf('%u', crc32($key));
}

function aiImageResolveContextFromIds(PDO $pdo, ?int $postId, ?string $postSlug, ?int $tipId): array {
    $ctx = [];
    if ($tipId) {
        if (!cmsTableExists($pdo, 'blog_tips')) return $ctx;
        $stmt = $pdo->prepare('SELECT title, text FROM blog_tips WHERE id = ? LIMIT 1');
        $stmt->execute([$tipId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $ctx['title'] = $row['title'];
            $ctx['text'] = $row['text'];
        }
        return $ctx;
    }
    if ($postSlug || $postId) {
        if (!cmsTableExists($pdo, 'blog_posts')) return $ctx;
        if (function_exists('ensureBlogPostImageColumns')) {
            ensureBlogPostImageColumns($pdo);
        }
        $cols = 'title, excerpt, content, category, city, service_id, keywords, blocks';
        if (function_exists('cmsColumnExists') && cmsColumnExists($pdo, 'blog_posts', 'image_prompt')) {
            $cols .= ', image_prompt, image_status';
        }
        if ($postSlug) {
            $stmt = $pdo->prepare("SELECT {$cols} FROM blog_posts WHERE slug = ? LIMIT 1");
            $stmt->execute([$postSlug]);
        } else {
            $stmt = $pdo->prepare("SELECT {$cols} FROM blog_posts WHERE id = ? LIMIT 1");
            $stmt->execute([$postId]);
        }
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $ctx['title'] = $row['title'];
            $ctx['content'] = $row['content'] ?? $row['excerpt'];
            $ctx['excerpt'] = $row['excerpt'];
            $ctx['category'] = $row['category'];
            $ctx['city'] = $row['city'];
            $ctx['serviceId'] = $row['service_id'] ?? null;
            $ctx['keywords'] = $row['keywords'] ?? null;
            if (!empty($row['image_prompt'])) {
                $ctx['coverImagePrompt'] = $row['image_prompt'];
                $ctx['prompt'] = $row['image_prompt'];
                $ctx['skipBriefMerge'] = true;
            }
            $blocks = $row['blocks'] ?? '[]';
            $decoded = is_string($blocks) ? json_decode($blocks, true) : $blocks;
            if (is_array($decoded)) {
                $ctx['blocks'] = $decoded;
            }
        }
    }
    return $ctx;
}

function aiImageGatewayGenerate(array $opts): array {
    $prompt = trim((string)($opts['prompt'] ?? ''));
    if ($prompt === '') {
        return ['ok' => false, 'error' => 'prompt obrigatório', 'attempts' => []];
    }
    $seed = isset($opts['seed']) ? (int)$opts['seed'] : null;
    $pdo = db();
    ensureAiImageTables($pdo);
    $providers = $pdo->query('SELECT * FROM ai_image_providers WHERE enabled = 1 ORDER BY priority ASC, id ASC')->fetchAll(PDO::FETCH_ASSOC);
    if (!$providers) {
        return ['ok' => false, 'error' => 'Nenhum provedor de imagem habilitado', 'attempts' => []];
    }

    $attempts = [];
    $hash = hash('sha256', $prompt);
    foreach ($providers as $p) {
        $type = (string)$p['provider_type'];
        $name = (string)$p['name'];
        $model = (string)($p['model'] ?? '');
        $timeout = max(10, (int)($p['timeout_sec'] ?? 45));
        $t0 = microtime(true);
        try {
            $result = match ($type) {
                'pollinations' => aiImageProviderPollinations($prompt, $model, $timeout, $seed),
                default => ['ok' => false, 'error' => 'provider_not_implemented'],
            };
        } catch (Throwable $e) {
            $result = ['ok' => false, 'error' => $e->getMessage()];
        }
        $ms = (int)round((microtime(true) - $t0) * 1000);
        $attempts[] = ['provider' => $name, 'type' => $type, 'ok' => (bool)($result['ok'] ?? false), 'error' => $result['error'] ?? null, 'latency_ms' => $ms];

        if (!empty($result['ok']) && !empty($result['binary'])) {
            $binary = (string)$result['binary'];
            if (!aiImageLooksValid($binary)) {
                $attempts[count($attempts) - 1]['ok'] = false;
                $attempts[count($attempts) - 1]['error'] = 'invalid_image_binary';
                continue;
            }
            $pdo->prepare('UPDATE ai_image_providers SET last_used_at=?, last_error=NULL, updated_at=? WHERE id=?')
                ->execute([dbNow(), dbNow(), (int)$p['id']]);
            $pdo->prepare('INSERT INTO ai_image_logs (prompt_hash, provider, provider_type, model, status, latency_ms, image_url, meta_json, created_at) VALUES (?,?,?,?,?,?,?,?,?)')
                ->execute([$hash, $name, $type, $model ?: null, 'ok', $ms, $result['source_url'] ?? null, json_encode(['attempts' => $attempts], JSON_UNESCAPED_UNICODE), dbNow()]);
            return [
                'ok' => true,
                'provider' => $name,
                'provider_type' => $type,
                'model' => $model,
                'binary' => $binary,
                'mime' => $result['mime'] ?? 'image/png',
                'source_url' => $result['source_url'] ?? null,
                'prompt' => $prompt,
                'attempts' => $attempts,
            ];
        }
        $pdo->prepare('UPDATE ai_image_providers SET last_error=?, updated_at=? WHERE id=?')
            ->execute([mb_substr((string)($result['error'] ?? 'erro'), 0, 500), dbNow(), (int)$p['id']]);
    }
    $pdo->prepare('INSERT INTO ai_image_logs (prompt_hash, status, error_code, error_message, meta_json, created_at) VALUES (?,?,?,?,?,?)')
        ->execute([$hash, 'error', 'all_failed', 'Todos os provedores falharam', json_encode(['attempts' => $attempts], JSON_UNESCAPED_UNICODE), dbNow()]);
    return ['ok' => false, 'error' => 'Todos os provedores falharam', 'attempts' => $attempts];
}

function aiImageProviderPollinations(string $prompt, string $model, int $timeout, ?int $seed = null): array {
    $encoded = rawurlencode($prompt);
    $url = 'https://image.pollinations.ai/prompt/' . $encoded;
    $query = [
        'model' => $model !== '' ? $model : 'flux',
        'width' => '1024',
        'height' => '1024',
        'nologo' => 'true',
        'private' => 'true',
        // enhance=true reescreve o prompt e gera capas fora do tema do artigo
        'enhance' => 'false',
    ];
    if ($seed !== null && $seed > 0) {
        $query['seed'] = (string) $seed;
    }
    $url .= '?' . http_build_query($query);
    $download = aiImageDownloadBinary($url, $timeout);
    if (empty($download['ok'])) {
        return ['ok' => false, 'error' => $download['error'] ?? 'pollinations_failed'];
    }
    return [
        'ok' => true,
        'binary' => (string)$download['binary'],
        'mime' => str_contains((string)($download['contentType'] ?? ''), 'jpeg') ? 'image/jpeg' : 'image/png',
        'source_url' => $url,
    ];
}

function handleAiImageProviders(string $method): void {
    requireAdmin();
    $pdo = db();
    ensureAiImageTables($pdo);
    if ($method === 'GET') {
        $rows = $pdo->query('SELECT id, name, provider_type, base_url, model, priority, timeout_sec, daily_limit, enabled, last_error, last_used_at, created_at, updated_at FROM ai_image_providers ORDER BY priority ASC, id ASC')
            ->fetchAll(PDO::FETCH_ASSOC);
        jsonRespond(['items' => $rows]);
    }
    $b = jsonBody();
    if ($method === 'POST') {
        $now = dbNow();
        $pdo->prepare('INSERT INTO ai_image_providers (name, provider_type, api_key_enc, base_url, model, priority, timeout_sec, daily_limit, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([
                san($b['name'] ?? '', 120),
                san($b['provider_type'] ?? '', 40),
                null,
                san($b['base_url'] ?? null, 500),
                san($b['model'] ?? null, 120),
                sanInt($b['priority'] ?? 100),
                max(10, sanInt($b['timeout_sec'] ?? 45)),
                sanInt($b['daily_limit'] ?? 0) ?: null,
                sanBool($b['enabled'] ?? true) ? 1 : 0,
                $now,
                $now,
            ]);
        jsonRespond(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
    }
    if ($method === 'PUT') {
        $id = sanInt($b['id'] ?? 0);
        if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);
        $pdo->prepare('UPDATE ai_image_providers SET name=?, provider_type=?, base_url=?, model=?, priority=?, timeout_sec=?, daily_limit=?, enabled=?, updated_at=? WHERE id=?')
            ->execute([
                san($b['name'] ?? '', 120),
                san($b['provider_type'] ?? '', 40),
                san($b['base_url'] ?? null, 500),
                san($b['model'] ?? null, 120),
                sanInt($b['priority'] ?? 100),
                max(10, sanInt($b['timeout_sec'] ?? 45)),
                sanInt($b['daily_limit'] ?? 0) ?: null,
                sanBool($b['enabled'] ?? true) ? 1 : 0,
                dbNow(),
                $id,
            ]);
        jsonRespond(['ok' => true]);
    }
    if ($method === 'DELETE') {
        $id = sanInt($_GET['id'] ?? 0);
        if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);
        $pdo->prepare('DELETE FROM ai_image_providers WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }
    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleAiImageLogs(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    ensureAiImageTables($pdo);
    $limit = max(10, min(100, sanInt($_GET['limit'] ?? 30)));
    $rows = $pdo->query("SELECT id, provider, provider_type, model, status, error_code, error_message, latency_ms, image_url, created_at FROM ai_image_logs ORDER BY id DESC LIMIT {$limit}")
        ->fetchAll(PDO::FETCH_ASSOC);
    jsonRespond(['items' => $rows]);
}

/** Geração pontual de imagem (admin) — registra na biblioteca de mídia. */
function handleAiImageGenerate(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('ai_image_generate', 12);

    $pdo = db();
    ensureAiImageTables($pdo);
    ensureCmsMigrated();

    $b = jsonBody();
    $ctx = [
        'prompt' => $b['prompt'] ?? null,
        'coverImagePrompt' => $b['coverImagePrompt'] ?? $b['cover_image_prompt'] ?? null,
        'title' => $b['title'] ?? null,
        'content' => $b['content'] ?? null,
        'text' => $b['text'] ?? null,
        'excerpt' => $b['excerpt'] ?? null,
        'category' => $b['category'] ?? null,
        'city' => $b['city'] ?? null,
        'keyword' => $b['keyword'] ?? $b['topic'] ?? null,
        'keywords' => $b['keywords'] ?? null,
        'serviceId' => $b['serviceId'] ?? $b['service_id'] ?? null,
        'slug' => $b['slug'] ?? $b['postSlug'] ?? null,
        'blocks' => $b['blocks'] ?? null,
        'skipBriefMerge' => !empty($b['skipBriefMerge']) || !empty($b['skip_brief_merge']),
    ];

    $fromDb = aiImageResolveContextFromIds(
        $pdo,
        sanInt($b['postId'] ?? 0) ?: null,
        san($b['postSlug'] ?? $b['slug'] ?? null, 180),
        sanInt($b['tipId'] ?? 0) ?: null,
    );
    foreach ($fromDb as $k => $v) {
        if (empty($ctx[$k]) && $v !== null && $v !== '') {
            $ctx[$k] = $v;
        }
    }

    $prompt = aiImagePromptFromContext($ctx);
    if (trim($prompt) === '') {
        jsonRespond(['error' => 'Informe prompt ou título/conteúdo para gerar a imagem'], 400);
    }
    $seed = aiImageSeedFromContext($ctx, $prompt);

    $folder = san($b['folder'] ?? 'Blog', 50) ?? 'Blog';
    if (!in_array($folder, cmsMediaFolders(), true)) {
        $folder = 'Blog';
    }

    $slug = san($b['slug'] ?? null, 180) ?? 'cover';
    $title = trim((string)($ctx['title'] ?? 'Imagem IA'));
    $imageMeta = [
        'alt' => $title !== '' ? "Imagem: {$title}" : 'Imagem gerada por IA',
        'caption' => $title,
        'description' => 'Gerada via AI Image Gateway (on-demand)',
        'optimizedName' => preg_replace('/[^a-z0-9\-]+/i', '-', strtolower($slug)),
    ];

    $postSlugBind = san($b['postSlug'] ?? $b['slug'] ?? null, 180);
    if ($postSlugBind && function_exists('cmsBlogPostSetImageMeta')) {
        cmsBlogPostSetImageMeta($pdo, $postSlugBind, [
            'imagePrompt' => $prompt,
            'imageStatus' => 'generating',
        ]);
    }

    $imgResult = aiImageGatewayGenerate([
        'prompt' => $prompt,
        'seed' => $seed,
        'provider_id' => sanInt($b['providerId'] ?? $b['provider_id'] ?? 0) ?: null,
    ]);

    // Retry único automático
    if (empty($imgResult['ok'])) {
        usleep(350000);
        $ctxRetry = $ctx;
        $ctxRetry['try'] = 2;
        $imgResult = aiImageGatewayGenerate([
            'prompt' => $prompt,
            'seed' => aiImageSeedFromContext($ctxRetry, $prompt),
            'provider_id' => sanInt($b['providerId'] ?? $b['provider_id'] ?? 0) ?: null,
        ]);
    }

    if (empty($imgResult['ok'])) {
        if ($postSlugBind && function_exists('cmsBlogPostSetImageMeta')) {
            cmsBlogPostSetImageMeta($pdo, $postSlugBind, [
                'imagePrompt' => $prompt,
                'imageStatus' => 'failed',
            ]);
        }
        if (function_exists('appLog')) {
            appLog('error', 'ai_image_generate_failed', [
                'slug' => $postSlugBind,
                'error' => $imgResult['error'] ?? null,
            ]);
        }
        jsonRespond([
            'error' => $imgResult['error'] ?? 'Falha na geração de imagem',
            'attempts' => $imgResult['attempts'] ?? [],
            'imageStatus' => 'failed',
            'prompt' => $prompt,
            'externalImagePrompt' => function_exists('aiImagePromptForExternalPlatform')
                ? aiImagePromptForExternalPlatform($ctx, $prompt)
                : $prompt,
        ], 502);
    }

    $media = mediaIngestFromBinary($pdo, [
        'binary' => (string)$imgResult['binary'],
        'mime' => (string)($imgResult['mime'] ?? 'image/png'),
        'folder' => $folder,
        'source' => 'ai',
        'provider' => (string)($imgResult['provider_type'] ?? 'pollinations'),
        'prompt' => $prompt,
        'title' => $title !== '' ? $title : 'Imagem IA',
        'meta' => $imageMeta,
    ]);

    $providerType = (string)($imgResult['provider_type'] ?? $imgResult['provider'] ?? 'pollinations');
    if ($postSlugBind && function_exists('cmsBlogPostSetImageMeta') && !empty($media['url'])) {
        cmsBlogPostSetImageMeta($pdo, $postSlugBind, [
            'imageUrl' => $media['url'],
            'ogImage' => $media['url'],
            'imagePrompt' => $prompt,
            'imageStatus' => 'completed',
            'imageProvider' => $providerType,
            'syncOg' => true,
        ]);
    }

    jsonRespond([
        'ok' => true,
        'imageUrl' => $media['url'] ?? null,
        'thumbUrl' => $media['thumbUrl'] ?? null,
        'media' => $media,
        'prompt' => $prompt,
        'provider' => $imgResult['provider'] ?? null,
        'imageStatus' => 'completed',
        'externalImagePrompt' => function_exists('aiImagePromptForExternalPlatform')
            ? aiImagePromptForExternalPlatform($ctx, $prompt)
            : $prompt,
    ]);
}
