<?php
/**
 * Object Storage — local disk (padrão cPanel) ou S3-compatible.
 * STORAGE_DRIVER=local|s3
 */

function alpStorageDriver(): string {
    $d = defined('STORAGE_DRIVER') ? strtolower((string)STORAGE_DRIVER) : 'local';
    return in_array($d, ['local', 's3'], true) ? $d : 'local';
}

/**
 * Persiste bytes e retorna URL pública.
 * @return array{ok:bool,url?:string,path?:string,error?:string}
 */
function alpStoragePut(string $relativePath, string $contents, string $mime = 'application/octet-stream'): array {
    $relativePath = ltrim(str_replace('\\', '/', $relativePath), '/');
    if ($relativePath === '' || strpos($relativePath, '..') !== false) {
        return ['ok' => false, 'error' => 'path inválido'];
    }

    if (alpStorageDriver() === 's3') {
        return alpStoragePutS3($relativePath, $contents, $mime);
    }

    $base = defined('UPLOADS_DIR') ? UPLOADS_DIR : (__DIR__ . '/uploads/');
    $full = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
    $dir = dirname($full);
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
        return ['ok' => false, 'error' => 'não foi possível criar diretório'];
    }
    if (@file_put_contents($full, $contents) === false) {
        return ['ok' => false, 'error' => 'falha ao gravar arquivo'];
    }
    $site = defined('SITE_URL') ? rtrim((string)SITE_URL, '/') : '';
    $url = $site . '/uploads/' . $relativePath;
    return ['ok' => true, 'url' => $url, 'path' => $relativePath];
}

function alpStoragePutS3(string $key, string $contents, string $mime): array {
    $bucket = defined('S3_BUCKET') ? (string)S3_BUCKET : '';
    $access = defined('S3_ACCESS_KEY') ? (string)S3_ACCESS_KEY : '';
    $secret = defined('S3_SECRET_KEY') ? (string)S3_SECRET_KEY : '';
    $region = defined('S3_REGION') ? (string)S3_REGION : 'us-east-1';
    $endpoint = defined('S3_ENDPOINT') ? rtrim((string)S3_ENDPOINT, '/') : '';
    $publicBase = defined('S3_PUBLIC_BASE_URL') ? rtrim((string)S3_PUBLIC_BASE_URL, '/') : '';

    if ($bucket === '' || $access === '' || $secret === '') {
        return ['ok' => false, 'error' => 'S3 não configurado — use STORAGE_DRIVER=local'];
    }

    // PutObject assinatura SigV4 mínima via cURL (sem AWS SDK)
    $host = $endpoint !== ''
        ? preg_replace('#^https?://#', '', $endpoint)
        : ($bucket . '.s3.' . $region . '.amazonaws.com');
    $url = ($endpoint !== '' ? $endpoint : ('https://' . $host)) . '/' . rawurlencode($bucket) . '/' . str_replace('%2F', '/', rawurlencode($key));
    // Simplificação: muitos providers S3-compatible usam path-style
    if ($endpoint !== '') {
        $url = $endpoint . '/' . $bucket . '/' . $key;
    }

    $amzDate = gmdate('Ymd\THis\Z');
    $dateStamp = gmdate('Ymd');
    $payloadHash = hash('sha256', $contents);
    $canonicalHeaders = "content-type:$mime\nhost:$host\nx-amz-content-sha256:$payloadHash\nx-amz-date:$amzDate\n";
    $signedHeaders = 'content-type;host;x-amz-content-sha256;x-amz-date';
    $canonicalRequest = "PUT\n/" . ($endpoint !== '' ? ($bucket . '/' . $key) : $key) . "\n\n$canonicalHeaders\n$signedHeaders\n$payloadHash";
    $credentialScope = "$dateStamp/$region/s3/aws4_request";
    $stringToSign = "AWS4-HMAC-SHA256\n$amzDate\n$credentialScope\n" . hash('sha256', $canonicalRequest);
    $kDate = hash_hmac('sha256', $dateStamp, 'AWS4' . $secret, true);
    $kRegion = hash_hmac('sha256', $region, $kDate, true);
    $kService = hash_hmac('sha256', 's3', $kRegion, true);
    $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
    $signature = hash_hmac('sha256', $stringToSign, $kSigning);
    $authorization = "AWS4-HMAC-SHA256 Credential=$access/$credentialScope, SignedHeaders=$signedHeaders, Signature=$signature";

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => 'PUT',
        CURLOPT_POSTFIELDS => $contents,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: $mime",
            "Host: $host",
            "x-amz-content-sha256: $payloadHash",
            "x-amz-date: $amzDate",
            "Authorization: $authorization",
        ],
        CURLOPT_TIMEOUT => 30,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($code < 200 || $code >= 300) {
        return ['ok' => false, 'error' => $err !== '' ? $err : ("S3 HTTP $code " . substr((string)$body, 0, 200))];
    }

    $publicUrl = $publicBase !== ''
        ? ($publicBase . '/' . $key)
        : $url;
    return ['ok' => true, 'url' => $publicUrl, 'path' => $key];
}
