<?php
/**
 * Instalador — Auto Limpeza Pro
 * Instalação em fases via GET (evita timeout POST no HostGator).
 */
declare(strict_types=1);

@ini_set('display_errors', '0');
@ini_set('log_errors', '1');
@set_time_limit(120);
@ini_set('memory_limit', '256M');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

const INSTALL_LAST_PHASE = 6;

$rootDir = __DIR__;
if (!is_file($rootDir . '/config.php') && is_file(dirname($rootDir) . '/config.php')) {
    $rootDir = dirname($rootDir);
}
$configFile = $rootDir . '/config.php';
$step       = isset($_GET['step']) ? (string)$_GET['step'] : 'check';
$phase      = isset($_GET['phase']) ? (int)$_GET['phase'] : 0;
$force      = isset($_GET['force']) && (string)$_GET['force'] === '1';

function installLog(string $msg): void
{
    global $rootDir;
    $dir = $rootDir . '/storage';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    @file_put_contents($dir . '/install.log', date('[Y-m-d H:i:s] ') . $msg . "\n", FILE_APPEND);
}

function installRequire(string $file, string $label, array &$results): bool
{
    if (!is_file($file)) {
        $results[] = ['table' => $label, 'status' => 'warn', 'msg' => 'Arquivo ausente: ' . basename($file)];
        return false;
    }
    require_once $file;
    return true;
}

function installConnectPdo(): PDO
{
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
    return new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
}

function installCreateTables(PDO $pdo, array $names, array $definitions, array &$results): void
{
    foreach ($names as $name) {
        if (!isset($definitions[$name])) {
            $results[] = ['table' => $name, 'status' => 'err', 'msg' => 'Definição SQL ausente'];
            continue;
        }
        try {
            $pdo->exec($definitions[$name]);
            $results[] = ['table' => $name, 'status' => 'ok', 'msg' => 'Criada / já existe'];
            installLog("Tabela OK: {$name}");
        } catch (PDOException $e) {
            $results[] = ['table' => $name, 'status' => 'err', 'msg' => $e->getMessage()];
            installLog("Tabela ERRO {$name}: " . $e->getMessage());
        }
    }
}

function installRunSeeds(PDO $pdo, string $rootDir, array &$results): void
{
    try {
        $smtpDefault = json_encode([
            'company_name' => 'Auto Limpeza Pro',
            'from_email'   => 'contato@autolimpezapro.com.br',
            'from_name'    => 'Auto Limpeza Pro',
            'smtp_host'    => 'smtp.titan.email',
            'smtp_port'    => 465,
            'encryption'   => 'SSL/TLS',
            'smtp_user'    => 'contato@autolimpezapro.com.br',
            'admin_email'  => 'contato@autolimpezapro.com.br',
            'enabled'      => true,
        ], JSON_UNESCAPED_UNICODE);
        $pdo->prepare("INSERT IGNORE INTO site_config (key_name,value,updated_at) VALUES
            ('ga_id',NULL,NOW()),('meta_pixel_id','1301066345201510',NOW()),('whatsapp','5531980252882',NOW()),
            ('business_name','Auto Limpeza Pro',NOW()),
            ('pushalert_rest_key',NULL,NOW()),('installed_at',NOW(),NOW()),
            ('smtp_config',?,NOW())")->execute([$smtpDefault]);
        $results[] = ['table' => 'site_config (dados)', 'status' => 'ok', 'msg' => 'Configurações iniciais inseridas'];
    } catch (Throwable $e) {
        $results[] = ['table' => 'site_config (dados)', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        $cmsFile = $rootDir . '/data/cms-default.json';
        if (is_file($cmsFile)) {
            $cmsJson = file_get_contents($cmsFile);
            $check = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'cms' LIMIT 1");
            $check->execute();
            $existing = $check->fetch();
            if (!$existing || empty($existing['value'])) {
                $pdo->prepare("INSERT INTO site_config (key_name,value,updated_at) VALUES ('cms',?,NOW())
                    ON DUPLICATE KEY UPDATE value = IF(value IS NULL OR value = '', VALUES(value), value), updated_at = NOW()")
                    ->execute([$cmsJson]);
                $results[] = ['table' => 'site_config (cms)', 'status' => 'ok', 'msg' => 'Conteúdo CMS inicial inserido'];
            } else {
                $results[] = ['table' => 'site_config (cms)', 'status' => 'ok', 'msg' => 'CMS já existente — mantido'];
            }
        } else {
            $results[] = ['table' => 'site_config (cms)', 'status' => 'warn', 'msg' => 'cms-default.json não encontrado'];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'site_config (cms)', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    if (!is_dir($rootDir . '/data')) {
        $results[] = ['table' => 'pasta data/', 'status' => 'warn', 'msg' => 'Pasta data/ ausente — copie do pacote'];
    }

    if (!is_dir($rootDir . '/uploads')) {
        mkdir($rootDir . '/uploads', 0755, true);
        $results[] = ['table' => 'pasta uploads/', 'status' => 'ok', 'msg' => 'Criada com permissão 755'];
    } else {
        $results[] = ['table' => 'pasta uploads/', 'status' => 'ok', 'msg' => 'Já existe'];
    }

    if (!is_dir($rootDir . '/uploads/challenge')) {
        mkdir($rootDir . '/uploads/challenge', 0755, true);
        $results[] = ['table' => 'pasta uploads/challenge/', 'status' => 'ok', 'msg' => 'Criada para fotos do desafio'];
    }

    try {
        $pdo->exec("INSERT IGNORE INTO challenge_badges (id, slug, nome, descricao, icon, pontos) VALUES
            ('bdg_resgate', 'resgate-extremo', 'Resgate Extremo', 'Transformação mais impressionante', 'flame', 500),
            ('bdg_raro', 'caso-raro', 'Caso Raro', 'Situação única e memorável', 'gem', 300),
            ('bdg_publico', 'escolha-publico', 'Escolha do Público', 'Mais votado pelos visitantes', 'heart', 400),
            ('bdg_mes', 'transformacao-mes', 'Transformação do Mês', 'Vencedor oficial mensal', 'trophy', 1000),
            ('bdg_share', 'top-compartilhador', 'Top Compartilhador', 'Maior alcance social', 'share-2', 250)");
        $results[] = ['table' => 'challenge_badges (seed)', 'status' => 'ok', 'msg' => 'Medalhas inseridas'];
    } catch (Throwable $e) {
        $results[] = ['table' => 'challenge_badges (seed)', 'status' => 'warn', 'msg' => $e->getMessage()];
    }
}

function installRunMigrations(PDO $pdo, string $rootDir, array &$results): ?array
{
    $adminCreds = null;

    try {
        if (installRequire($rootDir . '/admin-auth-handlers.php', 'admin-auth-handlers.php', $results)) {
            $checkAdmin = $pdo->query("SELECT COUNT(*) FROM admin_users")->fetchColumn();
            if ((int)$checkAdmin === 0) {
                // Sem fallback fixo: se config.php não define credenciais,
                // gera senha aleatória exibida uma única vez ao final.
                $adminEmail = defined('MASTER_ADMIN_EMAIL') && MASTER_ADMIN_EMAIL !== '' && strpos(MASTER_ADMIN_EMAIL, 'SUBSTITUA') !== 0
                    ? MASTER_ADMIN_EMAIL
                    : 'admin@' . (parse_url(defined('SITE_URL') ? SITE_URL : 'http://localhost', PHP_URL_HOST) ?: 'localhost');
                $adminPass  = defined('MASTER_ADMIN_PASSWORD') && MASTER_ADMIN_PASSWORD !== '' && strpos(MASTER_ADMIN_PASSWORD, 'SUBSTITUA') !== 0
                    ? MASTER_ADMIN_PASSWORD
                    : bin2hex(random_bytes(8)) . '@Alp';
                $adminCreds = createInitialAdminUser($pdo, $adminEmail, $adminPass, 'Administrador', false);
                $storageDir = $rootDir . '/storage';
                if (!is_dir($storageDir)) {
                    mkdir($storageDir, 0755, true);
                }
                @file_put_contents($storageDir . '/install-credentials.json', json_encode([
                    'email'      => $adminEmail,
                    'password'   => $adminPass,
                    'admin_url'  => '/admin',
                    'created_at' => date('c'),
                ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $results[] = ['table' => 'admin_users (seed)', 'status' => 'ok', 'msg' => 'Administrador criado'];
            } else {
                $results[] = ['table' => 'admin_users (seed)', 'status' => 'ok', 'msg' => 'Administrador já existe — mantido'];
            }
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'admin_users (seed)', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        if (installRequire($rootDir . '/migrate-cms.php', 'migrate-cms.php', $results)) {
            $cmsResults = runCmsMigrations($pdo);
            $results[] = ['table' => 'CMS v2', 'status' => 'ok', 'msg' => count($cmsResults) . ' etapas executadas'];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'CMS v2', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        installRequire($rootDir . '/site.php', 'site.php', $results);
        installRequire($rootDir . '/lang.php', 'lang.php', $results);
        installRequire($rootDir . '/functions.php', 'functions.php', $results);
        if (installRequire($rootDir . '/visitor-handlers.php', 'visitor-handlers.php', $results)) {
            ensureClientAddressColumns($pdo);
        }
        if (installRequire($rootDir . '/client-handlers.php', 'client-handlers.php', $results)) {
            ensureClientTables($pdo);
            $results[] = ['table' => 'Área do cliente', 'status' => 'ok', 'msg' => 'Tabelas clients e client_sessions'];
        }
        if (installRequire($rootDir . '/portal-handlers.php', 'portal-handlers.php', $results) && function_exists('ensurePortalTables')) {
            ensurePortalTables($pdo);
            $results[] = ['table' => 'Portal do Cliente', 'status' => 'ok', 'msg' => 'addresses, reviews, coupons, support'];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'Área do cliente', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        if (installRequire($rootDir . '/notification-handlers.php', 'notification-handlers.php', $results)) {
            migrateNotificationSchema($pdo);
            $results[] = ['table' => 'Notificações', 'status' => 'ok', 'msg' => 'system_notifications e client_notifications'];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'Notificações', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        if (installRequire($rootDir . '/logs-service.php', 'logs-service.php', $results)) {
            ensureSystemLogsTable($pdo);
            @mkdir($rootDir . '/storage/logs', 0755, true);
            $results[] = ['table' => 'Central de Logs', 'status' => 'ok', 'msg' => 'system_logs + storage/logs/'];
        }
        if (function_exists('ensureGeminiKeyFromConfig')) {
            ensureGeminiKeyFromConfig($pdo);
            $results[] = ['table' => 'Chave Gemini', 'status' => 'ok', 'msg' => 'Sincronizada config.php → site_config'];
        }
        if (installRequire($rootDir . '/mail-handlers.php', 'mail-handlers.php', $results) && function_exists('ensureMailLogTable')) {
            ensureMailLogTable($pdo);
            $results[] = ['table' => 'Histórico SMTP', 'status' => 'ok', 'msg' => 'mail_send_log'];
        }
        if (installRequire($rootDir . '/automation-handlers.php', 'automation-handlers.php', $results) && function_exists('ensureAutomationTables')) {
            ensureAutomationTables($pdo);
            $results[] = ['table' => 'Central Automações', 'status' => 'ok', 'msg' => 'captain_automation_*'];
        }
        if (installRequire($rootDir . '/notification-center.php', 'notification-center.php', $results) && function_exists('ensureNotificationCenterTables')) {
            ensureNotificationCenterTables($pdo);
            $results[] = ['table' => 'Central Híbrida NC', 'status' => 'ok', 'msg' => 'notification_queue/templates/logs'];
        }
        if (installRequire($rootDir . '/communication/hub.php', 'communication/hub.php', $results) && function_exists('ensureCommunicationHubTables')) {
            ensureCommunicationHubTables($pdo);
            $results[] = ['table' => 'Communication Hub', 'status' => 'ok', 'msg' => 'events + DLQ + AI log (aditivo)'];
        }
        if (installRequire($rootDir . '/tracking-service.php', 'tracking-service.php', $results) && function_exists('ensureTrackingTables')) {
            ensureTrackingTables($pdo);
            $results[] = ['table' => 'Acompanhamento tempo real', 'status' => 'ok', 'msg' => 'technicians + GPS + timeline (aditivo)'];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'Central de Logs', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        if (installRequire($rootDir . '/google-reviews-handlers.php', 'google-reviews-handlers.php', $results)) {
            $gr = runGoogleReviewsMigration($pdo);
            $results[] = ['table' => 'google_reviews', 'status' => 'ok', 'msg' => implode(', ', $gr)];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'google_reviews', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        if (installRequire($rootDir . '/landing-handlers.php', 'landing-handlers.php', $results) && function_exists('ensureLandingTables')) {
            ensureLandingTables($pdo);
            $results[] = ['table' => 'Landing Pages', 'status' => 'ok', 'msg' => 'cms_landing_pages'];
        }
        if (installRequire($rootDir . '/weather-service.php', 'weather-service.php', $results)) {
            ensureWeatherTables($pdo);
            $results[] = ['table' => 'Monitoramento Climático', 'status' => 'ok', 'msg' => 'weather + cache'];
        }
        if (installRequire($rootDir . '/prospeccao-service.php', 'prospeccao-service.php', $results)) {
            ensureProspeccaoTables($pdo);
            $results[] = ['table' => 'Prospecção Comercial', 'status' => 'ok', 'msg' => 'prospects + tasks'];
        }
        if (installRequire($rootDir . '/modules/prospeccao-engine/bootstrap.php', 'prospeccao-engine', $results)) {
            ensureProspeccaoEngineTables($pdo);
            $results[] = ['table' => 'Prospecção Engine Pro', 'status' => 'ok', 'msg' => 'engine tables'];
        }
        if (installRequire($rootDir . '/ai-gateway.php', 'ai-gateway.php', $results)) {
            ensureAiGatewayTables($pdo);
            if (function_exists('aiGatewaySyncProviderKeysFromConfig')) {
                aiGatewaySyncProviderKeysFromConfig($pdo);
            }
            $results[] = ['table' => 'AI Gateway', 'status' => 'ok', 'msg' => 'providers + logs'];
        }
        if (installRequire($rootDir . '/guardiao-handlers.php', 'guardiao-handlers.php', $results)) {
            ensureGuardiaoTables($pdo);
            $results[] = ['table' => 'Capitão Guardião', 'status' => 'ok', 'msg' => 'diagnostics + knowledge'];
        }
        if (installRequire($rootDir . '/seasonal-theme-handlers.php', 'seasonal-theme-handlers.php', $results)) {
            ensureSeasonalThemeTables($pdo);
            if (function_exists('seasonalSeedPresets')) {
                seasonalSeedPresets($pdo);
            }
            $results[] = ['table' => 'Temas Sazonais', 'status' => 'ok', 'msg' => 'seasonal_themes'];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'Módulos admin', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        installRequire($rootDir . '/quote-handlers.php', 'quote-handlers.php', $results);
        if (installRequire($rootDir . '/crm-handlers.php', 'crm-handlers.php', $results)) {
            if (!function_exists('ensureQuoteTables')) {
                throw new RuntimeException('ensureQuoteTables() indisponível após carregar quote-handlers.php');
            }
            if (!function_exists('ensureCrmTables')) {
                throw new RuntimeException('ensureCrmTables() indisponível após carregar crm-handlers.php');
            }
            ensureQuoteTables($pdo);
            ensureCrmTables($pdo);
            $results[] = ['table' => 'CRM Premium', 'status' => 'ok', 'msg' => 'Tabelas quote_photos, conversion_events e CRM verificadas'];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'CRM Premium', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    try {
        $tableCount = count($pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_NUM));
        $results[] = [
            'table'  => 'Resumo do banco',
            'status' => $tableCount > 0 ? 'ok' : 'err',
            'msg'    => $tableCount . ' tabela(s) em ' . DB_NAME,
        ];
    } catch (Throwable $e) {
        $results[] = ['table' => 'Resumo do banco', 'status' => 'warn', 'msg' => $e->getMessage()];
    }

    return $adminCreds;
}

function installPhaseLabel(int $phase): string
{
    $labels = [
        0 => 'Conexão e tabelas base',
        1 => 'Clientes e blog',
        2 => 'Leads e conversas',
        3 => 'Desafio (parte 1)',
        4 => 'Desafio (parte 2) e admin',
        5 => 'Dados iniciais',
        6 => 'Migrações finais',
    ];
    return $labels[$phase] ?? 'Instalação';
}

function installRenderHead(string $title): void
{
    echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<meta name="robots" content="noindex,nofollow">';
    echo '<title>' . htmlspecialchars($title) . '</title>';
    echo '<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:system-ui,-apple-system,sans-serif;background:#090F15;color:#E2EAF4;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
  .card{background:#111827;border:1px solid #1E2A3A;border-radius:20px;padding:32px;max-width:580px;width:100%}
  h1{font-size:20px;font-weight:700;margin-bottom:4px}
  .sub{color:#8B9CB0;font-size:13px;margin-bottom:24px}
  .step{margin-bottom:16px;padding:16px;border-radius:12px;border:1px solid #1E2A3A;background:#0D1724}
  .step h2{font-size:13px;font-weight:600;margin-bottom:8px;color:#1FB1F9}
  .step p{font-size:12px;color:#8B9CB0;line-height:1.6}
  .ok{color:#22C55E;font-weight:600}.err{color:#EF4444;font-weight:600}.warn{color:#F59E0B;font-weight:600}
  pre{font-size:11px;background:#090F15;padding:10px;border-radius:8px;overflow-x:auto;color:#94A3B8;margin-top:8px}
  .btn{display:block;width:100%;padding:14px;border-radius:12px;background:#1FB1F9;color:#fff;font-size:14px;font-weight:700;border:none;cursor:pointer;margin-top:20px;text-align:center;text-decoration:none}
  .btn:hover{background:#0EA5E9}.btn-danger{background:#EF4444}
  .divider{border:none;border-top:1px solid #1E2A3A;margin:20px 0}
  table{width:100%;border-collapse:collapse;font-size:12px}
  td,th{padding:6px 10px;text-align:left;border-bottom:1px solid #1E2A3A}
  th{color:#8B9CB0;font-weight:500}
  .spinner{display:inline-block;width:18px;height:18px;border:2px solid #1E2A3A;border-top-color:#1FB1F9;border-radius:50%;animation:spin .8s linear infinite;vertical-align:middle;margin-right:8px}
  @keyframes spin{to{transform:rotate(360deg)}}
  .progress{height:6px;background:#1E2A3A;border-radius:99px;overflow:hidden;margin-top:16px}
  .progress>div{height:100%;background:#1FB1F9;border-radius:99px;transition:width .3s}
</style></head><body>';
}

function installRenderAlreadyInstalled(string $detail = ''): void
{
    installRenderHead('Já instalado');
    echo '<div class="card">';
    echo '<h1>✅ Sistema já instalado</h1>';
    echo '<p class="sub">A instalação inicial já foi concluída neste ambiente.</p>';
    if ($detail !== '') {
        echo '<div class="step"><p>' . htmlspecialchars($detail) . '</p></div>';
    }
    echo '<div class="step"><p>Use <strong>Reparar</strong> para migrações incrementais sem recriar tabelas.</p>';
    echo '<p style="margin-top:8px">Reinstalação completa exige <code>?force=1</code> com token admin (Authorization: Bearer).</p></div>';
    echo '<a href="install.php?step=repair" class="btn">Reparar migrações (informe token)</a>';
    echo '<a href="/" class="btn" style="margin-top:10px;background:#334155">Abrir o site →</a>';
    echo '</div></body></html>';
}

function installRenderProgress(int $phase, string $detail, ?string $nextUrl): void
{
    $pct = (int)round((($phase + 1) / (INSTALL_LAST_PHASE + 1)) * 100);
    installRenderHead('Instalando — fase ' . ($phase + 1));
    echo '<div class="card">';
    echo '<h1><span class="spinner"></span> Instalando (' . ($phase + 1) . '/' . (INSTALL_LAST_PHASE + 1) . ')</h1>';
    echo '<p class="sub">' . htmlspecialchars(installPhaseLabel($phase)) . '</p>';
    echo '<div class="progress"><div style="width:' . $pct . '%"></div></div>';
    echo '<p class="sub" style="margin-top:12px">' . htmlspecialchars($detail) . '</p>';
    echo '<p style="font-size:11px;color:#64748B;margin-top:8px">Não feche esta página — cada etapa leva poucos segundos.</p>';
    echo '</div>';
    if ($nextUrl !== null) {
        echo '<script>setTimeout(function(){window.location.replace(' . json_encode($nextUrl) . ');},700);</script>';
        echo '<noscript><meta http-equiv="refresh" content="1;url=' . htmlspecialchars($nextUrl) . '"></noscript>';
    }
    echo '</body></html>';
    if (function_exists('ob_flush')) {
        @ob_flush();
    }
    @flush();
}

// ── Executar fase da instalação (GET) ─────────────────────────────────────
if ($step === 'run') {
    header('Content-Type: text/html; charset=utf-8');
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    if (!is_file($configFile)) {
        installRenderHead('Erro');
        echo '<div class="card"><h1 class="err">config.php não encontrado</h1></div></body></html>';
        exit;
    }

    require_once $configFile;
    require_once $rootDir . '/install-tables.php';
    require_once $rootDir . '/functions.php';

    if (isInstallCompleted()) {
        if (!$force) {
            installRenderAlreadyInstalled();
            exit;
        }
        if (!isAdmin()) {
            installRenderAlreadyInstalled('Reinstalação bloqueada: envie Authorization Bearer com token admin válido.');
            exit;
        }
        installLog('=== Reinstalação forçada (admin autenticado) ===');
    }

    $phase = max(0, min(INSTALL_LAST_PHASE, $phase));
    $results = $_SESSION['install_results'] ?? [];

    if ($phase === 0) {
        $_SESSION['install_results'] = [];
        $_SESSION['install_admin_creds'] = null;
        $results = [];
        installLog('=== Nova instalação iniciada ===');
    }

    try {
        $pdo = installConnectPdo();
        if ($phase === 0) {
            $results[] = ['table' => 'Conexão MySQL', 'status' => 'ok', 'msg' => 'Conectado com sucesso'];
        }

        $definitions = installGetTableDefinitions();
        $batches     = installGetPhaseTableBatches();

        if ($phase <= 4) {
            installCreateTables($pdo, $batches[$phase], $definitions, $results);
        } elseif ($phase === 5) {
            installRunSeeds($pdo, $rootDir, $results);
        } elseif ($phase === 6) {
            $adminCreds = installRunMigrations($pdo, $rootDir, $results);
            if ($adminCreds !== null) {
                $_SESSION['install_admin_creds'] = $adminCreds;
            }
        }

        $_SESSION['install_results'] = $results;

        if ($phase < INSTALL_LAST_PHASE) {
            $next = 'install.php?step=run&phase=' . ($phase + 1);
            $last = end($results);
            $detail = is_array($last) ? ($last['table'] . ': ' . $last['msg']) : 'Continuando...';
            installRenderProgress($phase, $detail, $next);
            exit;
        }

        header('Location: install.php?step=done', true, 302);
        exit;
    } catch (Throwable $e) {
        installLog('FATAL fase ' . $phase . ': ' . $e->getMessage());
        installRenderHead('Erro na instalação');
        echo '<div class="card"><h1 class="err">Instalação interrompida na fase ' . ($phase + 1) . '</h1>';
        echo '<div class="step"><pre>' . htmlspecialchars($e->getMessage()) . '</pre></div>';
        echo '<a href="install.php" class="btn">← Tentar novamente</a></div></body></html>';
        exit;
    }
}

// ── Reparar avisos pós-instalação (CMS, data/, área do cliente) ───────────
if ($step === 'repair') {
    header('Content-Type: text/html; charset=utf-8');
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    if (!is_file($configFile)) {
        installRenderHead('Erro');
        echo '<div class="card"><h1 class="err">config.php não encontrado</h1></div></body></html>';
        exit;
    }

    require_once $configFile;
    // Preferir header / POST — query ?token= funciona no repair (ops), mas vaza em access logs
    $provided = trim((string)($_SERVER['HTTP_X_ADMIN_TOKEN'] ?? ''));
    if ($provided === '') {
        $authHdr = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if (stripos($authHdr, 'Bearer ') === 0) {
            $provided = trim(substr($authHdr, 7));
        }
    }
    if ($provided === '' && isset($_POST['admin_token'])) {
        $provided = trim((string)$_POST['admin_token']);
    }
    $fromQuery = false;
    if ($provided === '' && isset($_GET['token'])) {
        $provided = trim((string)$_GET['token']);
        $fromQuery = true;
    }
    $expected = defined('ADMIN_TOKEN') ? (string)ADMIN_TOKEN : '';
    $ok = false;
    // Repair é ferramenta de deploy: ADMIN_TOKEN estático sempre válido aqui
    // (não depende de ALLOW_STATIC_ADMIN_TOKEN, que governa a API em produção)
    if (
        $expected !== ''
        && strpos($expected, 'SUBSTITUA') !== 0
        && $provided !== ''
        && hash_equals($expected, $provided)
    ) {
        $ok = true;
    }
    // Também aceita sessão admin válida (Bearer de login no painel)
    if (!$ok && $provided !== '' && is_file($rootDir . '/functions.php')) {
        require_once $rootDir . '/site.php';
        require_once $rootDir . '/lang.php';
        require_once $rootDir . '/functions.php';
        if (empty($_SERVER['HTTP_AUTHORIZATION'])) {
            $_SERVER['HTTP_AUTHORIZATION'] = 'Bearer ' . $provided;
        }
        try {
            if (function_exists('isAdmin') && isAdmin()) {
                $ok = true;
            }
        } catch (Throwable $e) {
            $ok = false;
        }
    }
    if (!$ok) {
        http_response_code(401);
        installRenderHead('Acesso negado');
        echo '<div class="card"><h1 class="err">Autenticação obrigatória</h1>';
        echo '<p class="sub">Cole o <code>ADMIN_TOKEN</code> de <code>config.local.php</code> (ou faça login no painel e use o Bearer da sessão).</p>';
        echo '<form method="post" action="install.php?step=repair" style="margin:16px 0;display:flex;flex-direction:column;gap:10px;max-width:420px">';
        echo '<input type="password" name="admin_token" required autocomplete="current-password" placeholder="ADMIN_TOKEN" style="padding:10px 12px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:#e2e8f0">';
        echo '<button type="submit" class="btn" style="border:0;cursor:pointer">Reparar migrações</button>';
        echo '</form>';
        echo '<p class="sub">Alternativa: header <code>X-Admin-Token</code> / <code>Authorization: Bearer</code>. Query <code>?token=</code> funciona, mas aparece em access logs.</p>';
        echo '<a href="install.php" class="btn">← Voltar</a></div></body></html>';
        exit;
    }
    if ($fromQuery) {
        $results = [['table' => 'Segurança', 'status' => 'warn', 'msg' => 'Token via query string — prefira POST ou header X-Admin-Token']];
    } else {
        $results = [];
    }
    $resyncMaster = isset($_GET['resync_master']) && (string)$_GET['resync_master'] === '1';

    try {
        $pdo = installConnectPdo();
        $results[] = ['table' => 'Conexão MySQL', 'status' => 'ok', 'msg' => 'Conectado'];

        // 1) Recria tabelas base ausentes (schema oficial de install-tables.php)
        if (installRequire($rootDir . '/install-tables.php', 'install-tables.php', $results)) {
            $definitions = installGetTableDefinitions();
            $existingMap = array_flip($pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN));
            $created = [];
            $failed  = [];
            foreach ($definitions as $name => $sql) {
                if (isset($existingMap[$name])) {
                    continue;
                }
                try {
                    $pdo->exec($sql);
                    $created[] = $name;
                    installLog("Reparo: tabela recriada {$name}");
                } catch (Throwable $e) {
                    $failed[] = $name;
                    installLog("Reparo ERRO {$name}: " . $e->getMessage());
                }
            }
            $totalBase = count($definitions);
            if ($failed) {
                $results[] = ['table' => 'Tabelas base', 'status' => 'err', 'msg' => 'Falha ao recriar: ' . implode(', ', $failed)];
            } elseif ($created) {
                $results[] = ['table' => 'Tabelas base', 'status' => 'ok', 'msg' => count($created) . " recriada(s): " . implode(', ', $created)];
            } else {
                $results[] = ['table' => 'Tabelas base', 'status' => 'ok', 'msg' => "Todas as {$totalBase} tabelas do schema presentes"];
            }
        }

        installRunSeeds($pdo, $rootDir, $results);

        installRequire($rootDir . '/site.php', 'site.php', $results);
        installRequire($rootDir . '/lang.php', 'lang.php', $results);
        installRequire($rootDir . '/functions.php', 'functions.php', $results);
        if (installRequire($rootDir . '/visitor-handlers.php', 'visitor-handlers.php', $results)) {
            ensureVisitorLocationColumns($pdo);
            ensureClientAddressColumns($pdo);
            $results[] = ['table' => 'Geolocalização', 'status' => 'ok', 'msg' => 'Colunas de endereço em visitors/clients'];
        }
        if (installRequire($rootDir . '/client-handlers.php', 'client-handlers.php', $results)) {
            ensureClientTables($pdo);
            $results[] = ['table' => 'Área do cliente', 'status' => 'ok', 'msg' => 'Tabelas e colunas verificadas'];
        }
        if (installRequire($rootDir . '/portal-handlers.php', 'portal-handlers.php', $results) && function_exists('ensurePortalTables')) {
            ensurePortalTables($pdo);
            $results[] = ['table' => 'Portal do Cliente', 'status' => 'ok', 'msg' => 'Tabelas portal verificadas'];
        }
        if (installRequire($rootDir . '/admin-auth-handlers.php', 'admin-auth-handlers.php', $results)) {
            if ($resyncMaster) {
                // Segundo arg true: força bcrypt a partir de MASTER_ADMIN_PASSWORD (sem isso o repair mentia "sincronizada").
                ensureMasterAdminUser($pdo, true);
                $m = masterAdminCredentials();
                $results[] = ['table' => 'Admin master', 'status' => 'ok', 'msg' => 'Senha sincronizada para ' . $m['email'] . ' (resync_master=1)'];
            } else {
                $results[] = ['table' => 'Admin master', 'status' => 'ok', 'msg' => 'Senha preservada — use &resync_master=1 para forçar reset'];
            }
        }
        installRequire($rootDir . '/quote-handlers.php', 'quote-handlers.php', $results);
        if (installRequire($rootDir . '/crm-handlers.php', 'crm-handlers.php', $results)) {
            ensureQuoteTables($pdo);
            ensureCrmTables($pdo);
            $results[] = ['table' => 'CRM Premium', 'status' => 'ok', 'msg' => 'Tabelas e colunas CRM verificadas'];
        }
        if (installRequire($rootDir . '/notification-handlers.php', 'notification-handlers.php', $results)) {
            migrateNotificationSchema($pdo);
            $results[] = ['table' => 'Notificações', 'status' => 'ok', 'msg' => 'Schema de notificações verificado'];
        }
        if (installRequire($rootDir . '/logs-service.php', 'logs-service.php', $results)) {
            ensureSystemLogsTable($pdo);
            @mkdir($rootDir . '/storage/logs', 0755, true);
            $results[] = ['table' => 'Central de Logs', 'status' => 'ok', 'msg' => 'system_logs verificada'];
        }
        if (installRequire($rootDir . '/mail-handlers.php', 'mail-handlers.php', $results)) {
            if (function_exists('ensureMailLogTable')) {
                ensureMailLogTable($pdo);
                $results[] = ['table' => 'Histórico SMTP', 'status' => 'ok', 'msg' => 'mail_send_log verificada'];
            }
        }
        if (installRequire($rootDir . '/automation-handlers.php', 'automation-handlers.php', $results)) {
            if (function_exists('ensureAutomationTables')) {
                ensureAutomationTables($pdo);
                $results[] = ['table' => 'Central Automações', 'status' => 'ok', 'msg' => 'captain_automation_* verificadas'];
            }
        }
        if (installRequire($rootDir . '/notification-center.php', 'notification-center.php', $results)) {
            if (function_exists('ensureNotificationCenterTables')) {
                ensureNotificationCenterTables($pdo);
                $results[] = ['table' => 'Central Híbrida NC', 'status' => 'ok', 'msg' => 'notification_queue verificada'];
            }
        }
        if (installRequire($rootDir . '/web-push-service.php', 'web-push-service.php', $results)) {
            if (function_exists('ensureNotificationEngineTables')) {
                ensureNotificationEngineTables($pdo);
                $results[] = ['table' => 'Notification Engine', 'status' => 'ok', 'msg' => 'push_subscriptions + campaigns + delivery logs'];
            }
        }
        if (installRequire($rootDir . '/communication/hub.php', 'communication/hub.php', $results)) {
            if (function_exists('ensureCommunicationHubTables')) {
                ensureCommunicationHubTables($pdo);
                $results[] = ['table' => 'Communication Hub', 'status' => 'ok', 'msg' => 'events + DLQ + AI log verificadas'];
            }
        }
        if (installRequire($rootDir . '/tracking-service.php', 'tracking-service.php', $results)) {
            if (function_exists('ensureTrackingTables')) {
                ensureTrackingTables($pdo);
                $results[] = ['table' => 'Acompanhamento tempo real', 'status' => 'ok', 'msg' => 'technicians + tracking sessions + timeline + GPS points'];
            }
        }
        if (function_exists('ensureGeminiKeyFromConfig')) {
            ensureGeminiKeyFromConfig($pdo);
            $results[] = ['table' => 'Chave Gemini', 'status' => 'ok', 'msg' => 'Sincronizada (gemini_key / GEMINI_API_KEY / gemini_api_key legado)'];
        }
        if (installRequire($rootDir . '/migrate-cms.php', 'migrate-cms.php', $results)) {
            $cmsResults = runCmsMigrations($pdo);
            $cmsOk = count(array_filter($cmsResults, static function ($r) { return ($r[0] ?? '') === 'ok'; }));
            $cmsWarn = count(array_filter($cmsResults, static function ($r) { return ($r[0] ?? '') === 'warn'; }));
            $results[] = [
                'table'  => 'CMS v2 / Blog',
                'status' => 'ok',
                'msg'    => "blog_categories, blog_comments e demais tabelas CMS ({$cmsOk} OK" . ($cmsWarn ? ", {$cmsWarn} avisos" : '') . ')',
            ];
        }
        // Meta de capa IA (image_prompt / image_status / …) — antes só via ensureCmsMigrated no blog API
        if (installRequire($rootDir . '/blog-post-helpers.php', 'blog-post-helpers.php', $results)) {
            if (function_exists('ensureBlogPostImageColumns')) {
                ensureBlogPostImageColumns($pdo);
                $results[] = ['table' => 'Blog capa IA (colunas)', 'status' => 'ok', 'msg' => 'image_prompt/image_status/image_provider/image_generated_at'];
            }
        }
        if (function_exists('alpEnsureVersionedSqlMigration')) {
            $blogImgPath = $rootDir . '/migrations/2026-08-01-blog_post_image_meta.sql';
            $blogImgApplied = alpEnsureVersionedSqlMigration('2026-08-01-blog_post_image_meta', $blogImgPath);
            $results[] = [
                'table'  => 'Blog capa IA (migration)',
                'status' => 'ok',
                'msg'    => $blogImgApplied
                    ? '2026-08-01-blog_post_image_meta aplicada'
                    : 'Já aplicado (schema_migrations)',
            ];
        }
        if (installRequire($rootDir . '/landing-handlers.php', 'landing-handlers.php', $results)) {
            if (function_exists('ensureLandingTables')) {
                ensureLandingTables($pdo);
                $results[] = ['table' => 'Landing Pages', 'status' => 'ok', 'msg' => 'cms_landing_pages verificada'];
            }
        }
        if (installRequire($rootDir . '/weather-service.php', 'weather-service.php', $results)) {
            ensureWeatherTables($pdo);
            $results[] = ['table' => 'Monitoramento Climático', 'status' => 'ok', 'msg' => 'Tabelas weather + cache verificadas'];
        }
        if (installRequire($rootDir . '/prospeccao-service.php', 'prospeccao-service.php', $results)) {
            ensureProspeccaoTables($pdo);
            $results[] = ['table' => 'Prospecção Comercial', 'status' => 'ok', 'msg' => 'prospeccao_prospects + tasks verificadas'];
        }
        if (installRequire($rootDir . '/modules/prospeccao-engine/bootstrap.php', 'prospeccao-engine', $results)) {
            ensureProspeccaoEngineTables($pdo);
            $results[] = ['table' => 'Prospecção Engine Pro', 'status' => 'ok', 'msg' => 'prospeccao_engine_jobs, leads, events, grid e cache verificadas'];
        }
        if (installRequire($rootDir . '/ai-gateway.php', 'ai-gateway.php', $results)) {
            ensureAiGatewayTables($pdo);
            if (function_exists('aiGatewaySyncProviderKeysFromConfig')) {
                aiGatewaySyncProviderKeysFromConfig($pdo);
            }
            $results[] = ['table' => 'AI Gateway', 'status' => 'ok', 'msg' => 'ai_providers, ai_gateway_logs, roteamento e prompts verificados'];
        }
        if (installRequire($rootDir . '/guardiao-handlers.php', 'guardiao-handlers.php', $results)) {
            ensureGuardiaoTables($pdo);
            $results[] = ['table' => 'Capitão Guardião', 'status' => 'ok', 'msg' => 'guardiao_observations, guardiao_diagnostics, guardiao_knowledge verificadas'];
        }
        if (installRequire($rootDir . '/seasonal-theme-handlers.php', 'seasonal-theme-handlers.php', $results)) {
            ensureSeasonalThemeTables($pdo);
            seasonalSeedPresets($pdo);
            $results[] = ['table' => 'Temas Sazonais', 'status' => 'ok', 'msg' => 'seasonal_themes + presets verificados'];
        }
        if (function_exists('alpEnsureVersionedSqlMigration')) {
            $secPath = $rootDir . '/migrations/2026-07-26-security-hardening.sql';
            $applied = alpEnsureVersionedSqlMigration('2026-07-26-security-hardening', $secPath);
            $results[] = [
                'table'  => 'Security hardening',
                'status' => 'ok',
                'msg'    => $applied
                    ? 'token_hash sessões + índices/FK aplicados (re-login obrigatório)'
                    : 'Já aplicado (schema_migrations)',
            ];
        } elseif (function_exists('alpRunSqlMigration')) {
            alpRunSqlMigration($pdo, $rootDir . '/migrations/2026-07-26-security-hardening.sql');
            $results[] = ['table' => 'Security hardening', 'status' => 'ok', 'msg' => 'SQL executado (idempotente)'];
        }

        // 3) Integridade física: CHECK TABLE em todas + REPAIR quando o engine suportar
        try {
            $tables = $pdo->query(
                "SELECT TABLE_NAME, ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE'"
            )->fetchAll(PDO::FETCH_ASSOC);
            $checked  = 0;
            $corrupt  = [];
            $repaired = [];
            foreach ($tables as $t) {
                $name   = $t['TABLE_NAME'];
                $engine = strtoupper((string)$t['ENGINE']);
                $rows   = $pdo->query('CHECK TABLE `' . str_replace('`', '', $name) . '` QUICK')->fetchAll(PDO::FETCH_ASSOC);
                $checked++;
                $bad = false;
                foreach ($rows as $r) {
                    if (strtolower((string)($r['Msg_type'] ?? '')) === 'error'
                        || (strtolower((string)($r['Msg_type'] ?? '')) === 'status' && strtoupper((string)($r['Msg_text'] ?? '')) !== 'OK')) {
                        $bad = true;
                    }
                }
                if (!$bad) {
                    continue;
                }
                // REPAIR TABLE só funciona em MyISAM/ARIA/CSV — InnoDB se recupera no restart
                if (in_array($engine, ['MYISAM', 'ARIA', 'CSV'], true)) {
                    $pdo->query('REPAIR TABLE `' . str_replace('`', '', $name) . '`');
                    $repaired[] = $name;
                    installLog("Reparo: REPAIR TABLE {$name}");
                } else {
                    $corrupt[] = "{$name} ({$engine})";
                    installLog("Reparo: corrupção detectada em {$name} ({$engine}) — REPAIR não suportado");
                }
            }
            if ($corrupt) {
                $results[] = ['table' => 'Integridade (CHECK TABLE)', 'status' => 'err', 'msg' => "Corrupção em: " . implode(', ', $corrupt) . ' — InnoDB: peça ao suporte da hospedagem para reiniciar o MySQL ou restaure backup'];
            } elseif ($repaired) {
                $results[] = ['table' => 'Integridade (CHECK TABLE)', 'status' => 'ok', 'msg' => "{$checked} verificadas; reparadas: " . implode(', ', $repaired)];
            } else {
                $results[] = ['table' => 'Integridade (CHECK TABLE)', 'status' => 'ok', 'msg' => "{$checked} tabelas verificadas, nenhuma corrompida"];
            }
        } catch (Throwable $e) {
            $results[] = ['table' => 'Integridade (CHECK TABLE)', 'status' => 'warn', 'msg' => $e->getMessage()];
        }
    } catch (Throwable $e) {
        $results[] = ['table' => 'Reparo', 'status' => 'err', 'msg' => $e->getMessage()];
    }

    $hasError = in_array('err', array_column($results, 'status'), true);
    installRenderHead('Reparo concluído');
    echo '<div class="card"><h1>' . ($hasError ? '⚠️' : '✅') . ' Reparo ' . ($hasError ? 'com erros' : 'concluído') . '</h1>';
    echo '<p class="sub">Itens corrigidos ou verificados:</p>';
    echo '<div class="step"><table><tr><th>Ação</th><th>Status</th><th>Detalhe</th></tr>';
    foreach ($results as $r) {
        echo '<tr><td>' . htmlspecialchars($r['table']) . '</td>';
        echo '<td class="' . htmlspecialchars($r['status']) . '">' . strtoupper($r['status']) . '</td>';
        echo '<td>' . htmlspecialchars($r['msg']) . '</td></tr>';
    }
    echo '</table></div>';
    echo '<a href="/" class="btn">Abrir o site →</a>';
    echo '<a href="install.php" class="btn" style="margin-top:10px;background:#334155">← Voltar</a>';
    echo '</div></body></html>';
    exit;
}

// ── Resultado final ─────────────────────────────────────────────────────────
if ($step === 'done') {
    if (!is_file($configFile)) {
        header('Location: install.php', true, 302);
        exit;
    }
    require_once $configFile;

    $results    = $_SESSION['install_results'] ?? [];
    $adminCreds = $_SESSION['install_admin_creds'] ?? null;
    $hasError   = in_array('err', array_column($results, 'status'), true);

    installRenderHead('Instalação concluída');
    echo '<div class="card">';
    echo '<h1>' . ($hasError ? '⚠️' : '✅') . ' Instalação ' . ($hasError ? 'com erros' : 'concluída') . '</h1>';
    echo '<p class="sub">Resultado de cada etapa:</p>';
    echo '<div class="step"><table><tr><th>Tabela / Ação</th><th>Status</th><th>Detalhe</th></tr>';
    foreach ($results as $r) {
        echo '<tr><td>' . htmlspecialchars($r['table']) . '</td>';
        echo '<td class="' . htmlspecialchars($r['status']) . '">' . strtoupper($r['status']) . '</td>';
        echo '<td>' . htmlspecialchars($r['msg']) . '</td></tr>';
    }
    echo '</table></div>';

    if (!$hasError && !empty($adminCreds)) {
        echo '<div class="step" style="border-color:#F59E0B44;background:#42200640">';
        echo '<h2 style="color:#F59E0B">Credenciais do administrador</h2>';
        echo '<p>Guarde em local seguro. A senha deve ser alterada no primeiro login.</p>';
        echo '<pre>URL:   /admin' . "\nE-mail: " . htmlspecialchars($adminCreds['email']) . "\n\nSenha:  " . htmlspecialchars($adminCreds['password']) . '</pre>';
        echo '</div>';
    }

    if (!$hasError) {
        if (function_exists('markInstallCompleted')) {
            require_once $rootDir . '/functions.php';
            markInstallCompleted();
        }
        echo '<div class="step" style="border-color:#22C55E44;background:#052e1640">';
        echo '<h2 style="color:#22C55E">Próximos passos</h2>';
        echo '<p>1. <strong>Delete install.php</strong> do servidor por segurança.<br>';
        echo '2. Acesse <code>/admin</code> e altere a senha no primeiro login.<br>';
        echo '3. Configure Google Analytics em Perfil → Configurações (opcional).</p>';
        echo '</div>';
        echo '<a href="/" class="btn">Abrir o site →</a>';
    } else {
        echo '<a href="install.php" class="btn btn-danger">← Tentar novamente</a>';
    }
    echo '</div></body></html>';

    unset($_SESSION['install_results'], $_SESSION['install_admin_creds']);
    exit;
}

// ── Verificação (padrão) ────────────────────────────────────────────────────
installRenderHead('Auto Limpeza Pro — Instalação');

if (!is_file($configFile)) {
    echo '<div class="card"><h1>⚙️ Auto Limpeza Pro — Instalação</h1>';
    echo '<p class="sub">Arquivo config.php não encontrado.</p>';
    echo '<div class="step"><h2>O que fazer</h2>';
    echo '<p>Crie o arquivo <strong>config.php</strong> na mesma pasta com as credenciais do banco MySQL.</p></div></div></body></html>';
    exit;
}

require_once $configFile;

$installLocked = false;
if (is_file($rootDir . '/functions.php')) {
    require_once $rootDir . '/functions.php';
    $installLocked = isInstallCompleted();
}

$dbOk    = false;
$dbError = '';
try {
    installConnectPdo();
    $dbOk = true;
} catch (PDOException $e) {
    $dbError = $e->getMessage();
}

$tokenSafe = defined('ADMIN_TOKEN')
    && ADMIN_TOKEN !== 'cleanpro_admin_2026_ALTERE'
    && strpos((string)ADMIN_TOKEN, 'SUBSTITUA') !== 0
    && strlen((string)ADMIN_TOKEN) >= 16;
?>
<div class="card">
  <h1>🔧 Auto Limpeza Pro — Instalação</h1>
  <p class="sub">Verificação do ambiente antes de criar as tabelas</p>

  <div class="step">
    <h2>PHP</h2>
    <p>Versão: <strong><?= phpversion() ?></strong>
    <?= version_compare(phpversion(), '7.4', '>=') ? '<span class="ok"> ✓ OK</span>' : '<span class="err"> ✗ Requer PHP 7.4+</span>' ?>
    </p>
  </div>

  <div class="step">
    <h2>Extensões PHP</h2>
    <p><?php
      $requiredExt = ['pdo_mysql' => true, 'curl' => true, 'json' => true, 'mbstring' => true, 'openssl' => true, 'gd' => false];
      foreach ($requiredExt as $ext => $required) {
          $has = extension_loaded($ext);
          echo $ext . ': ';
          if ($has) {
              echo '<span class="ok">✓</span>';
          } else {
              echo $required
                  ? '<span class="err">✗ obrigatória</span>'
                  : '<span class="warn">⚠ recomendada (miniaturas de imagem)</span>';
          }
          echo '<br>';
      }
    ?></p>
  </div>

  <div class="step">
    <h2>Permissões de escrita</h2>
    <p><?php
      foreach (['uploads', 'storage', 'logs'] as $dirName) {
          $dir = $rootDir . '/' . $dirName;
          if (!is_dir($dir)) {
              @mkdir($dir, 0755, true);
          }
          $writable = is_dir($dir) && is_writable($dir);
          echo $dirName . '/: ' . ($writable
              ? '<span class="ok">✓ gravável</span>'
              : '<span class="err">✗ sem escrita — ajuste para 755/775 no Gerenciador de Arquivos</span>') . '<br>';
      }
    ?></p>
  </div>

  <div class="step">
    <h2>Conexão com banco de dados</h2>
    <?php if ($dbOk): ?>
      <p><span class="ok">✓ Conectado</span><?php if (!$installLocked): ?> — <code><?= htmlspecialchars(DB_HOST) ?> / <?= htmlspecialchars(DB_NAME) ?></code><?php endif ?></p>
    <?php else: ?>
      <p><span class="err">✗ Falha na conexão</span></p>
      <?php if (!$installLocked): ?><pre><?= htmlspecialchars($dbError) ?></pre><?php endif ?>
    <?php endif ?>
  </div>

  <div class="step">
    <h2>Arquivos do instalador</h2>
    <p>
      install-tables.php: <?= is_file($rootDir . '/install-tables.php') ? '<span class="ok">✓</span>' : '<span class="err">✗ ausente</span>' ?><br>
      migrate-cms.php: <?= is_file($rootDir . '/migrate-cms.php') ? '<span class="ok">✓</span>' : '<span class="warn">⚠ ausente</span>' ?><br>
      google-reviews-handlers.php: <?= is_file($rootDir . '/google-reviews-handlers.php') ? '<span class="ok">✓</span>' : '<span class="warn">⚠ ausente</span>' ?>
    </p>
  </div>

  <div class="step">
    <h2>Token de administrador</h2>
    <p><?= $tokenSafe
        ? '<span class="ok">✓ Token personalizado configurado</span>'
        : '<span class="warn">⚠ Token padrão — altere ADMIN_TOKEN no config.php</span>' ?></p>
  </div>

  <?php if ($installLocked): ?>
  <div class="step" style="border-color:#22C55E44;background:#052e1640">
    <h2 style="color:#22C55E">Instalação concluída</h2>
    <p>Este ambiente já foi instalado. Use <strong>Reparar</strong> para migrações incrementais.</p>
    <a href="install.php?step=repair" class="btn" style="margin-top:12px">Reparar migrações (ADMIN_TOKEN)</a>
  </div>
  <?php elseif ($dbOk && extension_loaded('pdo_mysql') && is_file($rootDir . '/install-tables.php')): ?>
  <hr class="divider">
  <p style="font-size:13px;color:#8B9CB0;margin-bottom:12px">
    Tudo certo! A instalação roda em <strong>7 etapas rápidas</strong> (sem POST — compatível com HostGator).
    Tabelas existentes não serão apagadas.
  </p>
  <a href="install.php?step=run&amp;phase=0" class="btn">▶ Criar tabelas e instalar</a>
  <p style="font-size:11px;color:#64748B;margin-top:12px;text-align:center">
    Já instalou e viu avisos? Envie a pasta <code>data/</code> do pacote e
    <a href="install.php?step=repair" style="color:#1FB1F9">clique aqui para reparar (cole o ADMIN_TOKEN)</a>.
    · <a href="install-diagnose.php" style="color:#1FB1F9">Diagnóstico</a>
  </p>
  <?php else: ?>
  <a href="install.php" class="btn btn-danger">↺ Verificar novamente</a>
  <?php endif ?>
</div>
</body>
</html>
