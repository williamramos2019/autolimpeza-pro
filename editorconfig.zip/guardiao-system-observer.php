<?php
/**
 * Capitão Guardião — System Observer (READ ONLY)
 * Agrega sinais operacionais sem mutar dados de negócio.
 */

require_once __DIR__ . '/logs-handlers.php';
require_once __DIR__ . '/capitao-clean-handlers.php';

class SystemObserver
{
    /** @var string[] */
    private const MODULES = [
        'frontend', 'backend', 'database', 'server', 'crm', 'agenda', 'cms',
        'landing', 'seo', 'analytics', 'financial', 'ai_gateway', 'smtp',
        'whatsapp', 'notifications', 'prospeccao',
    ];

    /**
     * Agrega todos os sinais read-only da plataforma.
     */
    public static function observe(PDO $pdo): array
    {
        $now = date('c');
        $diag = function_exists('runSystemDiagnostico') ? runSystemDiagnostico($pdo) : ['checks' => [], 'overallScore' => 0];
        $ncHealth = class_exists('NotificationCenter') ? NotificationCenter::getSystemHealth($pdo) : [];
        $ctx = function_exists('capitaoCollectContext') ? capitaoCollectContext($pdo) : [];
        $logSignals = self::collectLogSignals($pdo);
        $apiSignals = self::collectApiSignals($pdo);
        $dbSignals = self::collectDatabaseSignals($pdo);

        $aiStatus = null;
        if (class_exists('AIProviderFactory')) {
            require_once __DIR__ . '/ai-providers.php';
            $aiStatus = AIProviderFactory::status();
        }

        $modules = [];
        foreach (self::MODULES as $key) {
            $modules[$key] = self::buildModuleHealth(
                $pdo,
                $key,
                $now,
                $diag,
                $ncHealth,
                $ctx,
                $logSignals,
                $apiSignals,
                $dbSignals,
                $aiStatus
            );
        }

        $scores = array_column($modules, 'score');
        $overallScore = $scores ? (int) round(array_sum($scores) / count($scores)) : 0;
        $overallStatus = self::scoreToStatus($overallScore);

        return [
            'generatedAt'   => $now,
            'overallScore'  => $overallScore,
            'overallStatus' => $overallStatus,
            'modules'       => $modules,
            'signals'       => [
                'logs'     => $logSignals,
                'api'      => $apiSignals,
                'database' => $dbSignals,
            ],
            'diagnostico'   => $diag,
            'context'       => $ctx,
            'aiProviders'   => $aiStatus,
            'notificationCenter' => $ncHealth,
        ];
    }

    /** Erros recentes em system_logs (somente SELECT) — só itens em aberto. */
    public static function collectLogSignals(PDO $pdo): array
    {
        ensureSystemLogsTable($pdo);
        $signals = [
            'recentErrors' => [],
            'errorCount24h' => 0,
            'errorCount7d'  => 0,
            'criticalCount' => 0,
            'byType'        => [],
        ];

        try {
            $signals['errorCount24h'] = (int) $pdo->query(
                "SELECT COUNT(*) FROM system_logs
                 WHERE resolved = 0
                   AND level IN ('error','critical','fatal','warning')
                   AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
            )->fetchColumn();

            $signals['errorCount7d'] = (int) $pdo->query(
                "SELECT COUNT(*) FROM system_logs
                 WHERE resolved = 0
                   AND level IN ('error','critical','fatal','warning')
                   AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
            )->fetchColumn();

            $signals['criticalCount'] = (int) $pdo->query(
                "SELECT COUNT(*) FROM system_logs
                 WHERE resolved = 0
                   AND level IN ('critical','fatal')
                   AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
            )->fetchColumn();

            $stmt = $pdo->query(
                "SELECT id, type, level, message, file, line, created_at
                 FROM system_logs
                 WHERE resolved = 0
                   AND level IN ('error','critical','fatal','warning')
                 ORDER BY id DESC LIMIT 20"
            );
            $signals['recentErrors'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $byType = $pdo->query(
                "SELECT type, COUNT(*) AS cnt FROM system_logs
                 WHERE resolved = 0
                   AND level IN ('error','critical','fatal')
                   AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                 GROUP BY type ORDER BY cnt DESC LIMIT 10"
            )->fetchAll(PDO::FETCH_ASSOC);
            foreach ($byType as $row) {
                $signals['byType'][$row['type']] = (int) $row['cnt'];
            }
        } catch (Throwable $e) {
            $signals['queryError'] = $e->getMessage();
        }

        return $signals;
    }

    /** Rotas registradas e falhas recentes de API (somente SELECT) — só em aberto. */
    public static function collectApiSignals(PDO $pdo): array
    {
        $signals = [
            'routeCount'    => 0,
            'recentFailures'=> [],
            'failureCount24h' => 0,
        ];

        if (defined('ROUTES') && is_array(ROUTES)) {
            $signals['routeCount'] = count(ROUTES);
        }

        try {
            ensureSystemLogsTable($pdo);
            $signals['failureCount24h'] = (int) $pdo->query(
                "SELECT COUNT(*) FROM system_logs
                 WHERE resolved = 0
                   AND type = 'api' AND level IN ('error','critical','fatal')
                   AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
            )->fetchColumn();

            $stmt = $pdo->query(
                "SELECT id, message, url, method, created_at
                 FROM system_logs
                 WHERE resolved = 0
                   AND type = 'api' AND level IN ('error','critical','fatal')
                 ORDER BY id DESC LIMIT 15"
            );
            $signals['recentFailures'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            $signals['queryError'] = $e->getMessage();
        }

        return $signals;
    }

    /** Contagens de tabelas e tabelas ausentes (somente SELECT). */
    public static function collectDatabaseSignals(PDO $pdo): array
    {
        $required = [
            'appointments', 'site_config', 'admin_users', 'system_logs', 'blog_posts',
            'clients', 'leads', 'crm_contacts', 'analytics', 'cms_landing_pages',
            'notification_queue', 'ai_providers', 'ai_gateway_logs', 'prospeccao_prospects',
            'prospeccao_engine_jobs', 'blog_categories', 'blog_comments', 'blog_authors',
        ];

        // Tenta criar tabelas aditivas antes de verificar ausências
        if (!function_exists('ensureAiGatewayTables') && is_file(__DIR__ . '/ai-gateway.php')) {
            require_once __DIR__ . '/ai-gateway.php';
        }
        if (!function_exists('ensureProspeccaoEngineTables') && is_file(__DIR__ . '/modules/prospeccao-engine/bootstrap.php')) {
            require_once __DIR__ . '/modules/prospeccao-engine/bootstrap.php';
        }
        if (function_exists('ensureAiGatewayTables')) {
            try { ensureAiGatewayTables($pdo); } catch (Throwable $e) { /* */ }
        }
        if (function_exists('ensureProspeccaoEngineTables')) {
            try { ensureProspeccaoEngineTables($pdo); } catch (Throwable $e) { /* */ }
        }
        if (function_exists('ensureCmsMigrated')) {
            try { ensureCmsMigrated(); } catch (Throwable $e) { /* */ }
        }

        $signals = [
            'connected'      => false,
            'latencyMs'      => null,
            'tableCounts'    => [],
            'missingTables'  => [],
            'totalTables'    => 0,
        ];

        try {
            $start = microtime(true);
            $pdo->query('SELECT 1');
            $signals['connected'] = true;
            $signals['latencyMs'] = (int) round((microtime(true) - $start) * 1000);
        } catch (Throwable $e) {
            $signals['connectionError'] = $e->getMessage();
            return $signals;
        }

        foreach ($required as $tbl) {
            try {
                $cnt = (int) $pdo->query("SELECT COUNT(*) FROM `{$tbl}`")->fetchColumn();
                $signals['tableCounts'][$tbl] = $cnt;
                $signals['totalTables']++;
            } catch (Throwable $e) {
                $signals['missingTables'][] = $tbl;
            }
        }

        return $signals;
    }

    /** Detalhe de um módulo específico. */
    public static function moduleDetail(PDO $pdo, string $module): array
    {
        $obs = self::observe($pdo);
        $key = strtolower(trim($module));
        if (!isset($obs['modules'][$key])) {
            return ['error' => 'Módulo desconhecido', 'available' => self::MODULES];
        }
        return [
            'module'      => $key,
            'health'      => $obs['modules'][$key],
            'generatedAt' => $obs['generatedAt'],
            'relatedLogs' => self::filterLogsForModule($obs['signals']['logs']['recentErrors'] ?? [], $key),
            'relatedSignals' => self::relatedSignalsForModule($key, $obs),
        ];
    }

    private static function buildModuleHealth(
        PDO $pdo,
        string $key,
        string $now,
        array $diag,
        array $ncHealth,
        array $ctx,
        array $logSignals,
        array $apiSignals,
        array $dbSignals,
        ?array $aiStatus
    ): array {
        $checks = [];
        $score = 100;

        switch ($key) {
            case 'frontend':
                $jsErrors = (int) ($logSignals['byType']['javascript'] ?? 0);
                $checks[] = self::check('assets_js', 'Erros JS em aberto (7d)', $jsErrors === 0 ? 'ok' : ($jsErrors < 5 ? 'warn' : 'error'), "{$jsErrors} erros");
                $score -= min(40, $jsErrors * 8);
                break;

            case 'backend':
                $phpErrors = (int) ($logSignals['byType']['php'] ?? 0);
                $apiFails = (int) ($apiSignals['failureCount24h'] ?? 0);
                $checks[] = self::check('php_errors', 'Erros PHP em aberto (7d)', $phpErrors === 0 ? 'ok' : ($phpErrors < 3 ? 'warn' : 'error'), "{$phpErrors} erros");
                $checks[] = self::check('api_failures', 'Falhas API em aberto (24h)', $apiFails === 0 ? 'ok' : ($apiFails < 5 ? 'warn' : 'error'), "{$apiFails} falhas");
                $checks[] = self::check('routes', 'Rotas registradas', 'ok', (string) ($apiSignals['routeCount'] ?? 0) . ' rotas');
                $score -= min(30, $phpErrors * 10 + $apiFails * 5);
                break;

            case 'database':
                $missing = count($dbSignals['missingTables'] ?? []);
                $latency = (int) ($dbSignals['latencyMs'] ?? 0);
                $checks[] = self::check('connection', 'Conexão MySQL', ($dbSignals['connected'] ?? false) ? 'ok' : 'error');
                $checks[] = self::check('latency', 'Latência', $latency <= 200 ? 'ok' : ($latency <= 500 ? 'warn' : 'error'), "{$latency}ms");
                $checks[] = self::check('tables', 'Tabelas ausentes', $missing === 0 ? 'ok' : 'error', $missing ? implode(', ', $dbSignals['missingTables']) : 'Todas presentes');
                if ($missing > 0) $score -= 40;
                if ($latency > 500) $score -= 20;
                break;

            case 'server':
                foreach ($diag['checks'] ?? [] as $c) {
                    if (in_array($c['id'] ?? '', ['php', 'pdo_mysql', 'curl', 'logs_dir', 'uploads', 'cron', 'cron_last'], true)) {
                        $st = ($c['status'] ?? '') === 'ok' ? 'ok' : (($c['status'] ?? '') === 'warn' ? 'warn' : 'error');
                        $checks[] = self::check($c['id'], $c['label'], $st, $c['detail'] ?? '');
                        if ($st === 'error') $score -= 15;
                        elseif ($st === 'warn') $score -= 5;
                    }
                }
                break;

            case 'crm':
                $leads = (int) ($ctx['totals']['leads'] ?? 0);
                $clients = (int) ($ctx['totals']['clients'] ?? 0);
                $forgotten = count($ctx['forgottenLeads'] ?? []);
                $checks[] = self::check('leads', 'Leads totais', 'ok', (string) $leads);
                $checks[] = self::check('clients', 'Contatos CRM', 'ok', (string) $clients);
                $checks[] = self::check('forgotten', 'Leads esquecidos', $forgotten === 0 ? 'ok' : ($forgotten < 5 ? 'warn' : 'error'), (string) $forgotten);
                $score -= min(25, $forgotten * 5);
                break;

            case 'agenda':
                $today = (int) ($ctx['today']['appointments'] ?? 0);
                $total = (int) ($ctx['totals']['appointments'] ?? 0);
                $apptCount = (int) ($dbSignals['tableCounts']['appointments'] ?? $total);
                $checks[] = self::check('today', 'Agendamentos hoje', 'ok', (string) $today);
                $checks[] = self::check('total', 'Total agendamentos', 'ok', (string) $apptCount);
                if (!isset($dbSignals['tableCounts']['appointments']) && in_array('appointments', $dbSignals['missingTables'] ?? [], true)) {
                    $checks[] = self::check('table', 'Tabela appointments', 'error', 'Ausente');
                    $score -= 50;
                }
                break;

            case 'cms':
                $posts = (int) ($ctx['totals']['blogPosts'] ?? 0);
                $cmsErrors = 0;
                foreach ($diag['checks'] ?? [] as $c) {
                    if (str_starts_with($c['id'] ?? '', 'cms_') || str_starts_with($c['id'] ?? '', 'table_blog')) {
                        $raw = (string)($c['status'] ?? '');
                        $st = $raw === 'ok' ? 'ok' : ($raw === 'warn' ? 'warn' : 'error');
                        $checks[] = self::check($c['id'], $c['label'], $st, $c['detail'] ?? '');
                        if ($st === 'error') $cmsErrors++;
                        elseif ($st === 'warn') $score -= 3;
                    }
                }
                $checks[] = self::check('posts', 'Posts publicados', $posts > 0 ? 'ok' : 'warn', (string) $posts);
                $score -= $cmsErrors * 15;
                break;

            case 'landing':
                $landings = (int) ($ctx['totals']['landings'] ?? 0);
                $checks[] = self::check('pages', 'Landing pages CMS', $landings > 0 ? 'ok' : 'warn', (string) $landings);
                if ($landings === 0) $score -= 10;
                break;

            case 'seo':
                $reviews = (int) ($ctx['totals']['reviews'] ?? 0);
                $checks[] = self::check('reviews', 'Reviews Google publicados', $reviews > 0 ? 'ok' : 'warn', (string) $reviews);
                $checks[] = self::check('sitemap', 'Sitemap', 'ok', 'Rota sitemap registrada');
                if ($reviews === 0) $score -= 5;
                break;

            case 'analytics':
                $visitors = (int) ($ctx['today']['visitors'] ?? 0);
                $pageviews = (int) ($ctx['today']['pageviews'] ?? 0);
                $hasTable = isset($dbSignals['tableCounts']['analytics']);
                $checks[] = self::check('table', 'Tabela analytics', $hasTable ? 'ok' : 'error');
                $checks[] = self::check('visitors', 'Visitantes hoje', 'ok', (string) $visitors);
                $checks[] = self::check('pageviews', 'Pageviews hoje', 'ok', (string) $pageviews);
                if (!$hasTable) $score -= 30;
                break;

            case 'financial':
                $revenue = (float) ($ctx['estimatedRevenue'] ?? 0);
                $checks[] = self::check('revenue', 'Receita estimada', 'ok', 'R$ ' . number_format($revenue, 2, ',', '.'));
                $checks[] = self::check('conversion', 'Taxa conversão', 'ok', round((float) ($ctx['conversionRate'] ?? 0), 1) . '%');
                break;

            case 'ai_gateway':
                $configured = !empty($aiStatus['anyConfigured']);
                $checks[] = self::check('providers', 'Provedores configurados', $configured ? 'ok' : 'warn');
                try {
                    $fail24 = (int) $pdo->query(
                        "SELECT COUNT(*) FROM ai_gateway_logs
                         WHERE status != 'ok' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
                    )->fetchColumn();
                    $total24 = (int) $pdo->query(
                        "SELECT COUNT(*) FROM ai_gateway_logs
                         WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
                    )->fetchColumn();
                    $failRate = $total24 > 0 ? round($fail24 / $total24 * 100) : 0;
                    $checks[] = self::check('fail_rate', 'Taxa falha IA (24h)', $failRate < 10 ? 'ok' : ($failRate < 30 ? 'warn' : 'error'), "{$failRate}% ({$fail24}/{$total24})");
                    if ($failRate >= 30) $score -= 30;
                    elseif ($failRate >= 10) $score -= 10;
                } catch (Throwable $e) {
                    $checks[] = self::check('logs', 'Logs AI Gateway', 'warn', 'Tabela indisponível');
                }
                if (!$configured) $score -= 20;
                break;

            case 'smtp':
                $smtp = $ncHealth['smtp'] ?? ['status' => 'yellow', 'message' => 'Não verificado'];
                $checks[] = self::check('smtp', 'SMTP', self::ncToCheck($smtp['status'] ?? 'yellow'), $smtp['message'] ?? '');
                $score = self::applyNcStatus($score, $smtp['status'] ?? 'yellow');
                break;

            case 'whatsapp':
                $wa = $ncHealth['whatsapp'] ?? ['status' => 'yellow', 'message' => 'Não verificado'];
                $checks[] = self::check('whatsapp', 'WhatsApp / Evolution', self::ncToCheck($wa['status'] ?? 'yellow'), $wa['message'] ?? '');
                $score = self::applyNcStatus($score, $wa['status'] ?? 'yellow');
                break;

            case 'notifications':
                $queue = $ncHealth['queue'] ?? ['status' => 'green', 'message' => ''];
                $push = $ncHealth['webpush'] ?? $ncHealth['pushalert'] ?? ['status' => 'yellow', 'message' => ''];
                $checks[] = self::check('queue', 'Fila de notificações', self::ncToCheck($queue['status'] ?? 'green'), $queue['message'] ?? '');
                $checks[] = self::check('push', 'Web Push VAPID', self::ncToCheck($push['status'] ?? 'yellow'), $push['message'] ?? '');
                $score = self::applyNcStatus($score, $queue['status'] ?? 'green');
                $score = self::applyNcStatus($score, $push['status'] ?? 'yellow');
                break;

            case 'prospeccao':
                $hasTable = isset($dbSignals['tableCounts']['prospeccao_prospects']);
                $prospects = (int) ($dbSignals['tableCounts']['prospeccao_prospects'] ?? 0);
                $checks[] = self::check('table', 'Tabela prospeccao_prospects', $hasTable ? 'ok' : 'error');
                $checks[] = self::check('prospects', 'Prospects cadastrados', 'ok', (string) $prospects);
                if (!$hasTable) $score -= 40;
                break;
        }

        $score = max(0, min(100, $score));
        return [
            'status'      => self::scoreToStatus($score),
            'score'       => $score,
            'checks'      => $checks,
            'lastChecked' => $now,
        ];
    }

    private static function check(string $id, string $label, string $status, string $detail = ''): array
    {
        return compact('id', 'label', 'status', 'detail');
    }

    private static function scoreToStatus(int $score): string
    {
        if ($score >= 80) return 'green';
        if ($score >= 55) return 'yellow';
        return 'red';
    }

    private static function ncToCheck(string $ncStatus): string
    {
        return match ($ncStatus) {
            'green' => 'ok',
            'yellow' => 'warn',
            'red' => 'error',
            default => 'warn',
        };
    }

    private static function applyNcStatus(int $score, string $ncStatus): int
    {
        return match ($ncStatus) {
            'red' => $score - 35,
            'yellow' => $score - 12,
            default => $score,
        };
    }

    private static function filterLogsForModule(array $logs, string $module): array
    {
        $typeMap = [
            'frontend' => ['javascript'],
            'backend'  => ['php', 'api'],
            'database' => ['database'],
            'ai_gateway' => ['gemini', 'ai'],
        ];
        $types = $typeMap[$module] ?? [];
        if (!$types) return array_slice($logs, 0, 5);
        return array_values(array_filter($logs, fn($l) => in_array($l['type'] ?? '', $types, true)));
    }

    private static function relatedSignalsForModule(string $module, array $obs): array
    {
        $out = [];
        if (in_array($module, ['backend', 'frontend', 'ai_gateway'], true)) {
            $out['api'] = $obs['signals']['api'] ?? [];
        }
        if (in_array($module, ['database', 'crm', 'agenda', 'analytics', 'prospeccao'], true)) {
            $out['database'] = $obs['signals']['database'] ?? [];
        }
        return $out;
    }
}
