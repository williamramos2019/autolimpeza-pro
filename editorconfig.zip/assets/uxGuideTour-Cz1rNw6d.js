function t(){window.dispatchEvent(new CustomEvent("alp-restart-tour"))}export{t as r};
