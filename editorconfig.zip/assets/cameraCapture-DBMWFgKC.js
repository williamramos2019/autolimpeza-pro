const a="image/jpeg,image/png,image/webp,image/heic,image/heif";function t(e){e.type="file",e.accept=a,e.setAttribute("capture","environment")}export{t as a};
