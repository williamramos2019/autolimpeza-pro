<?php
/**
 * Reset de Fábrica — limpeza segura de dados temporários/teste.
 * NÃO remove: schema, admin_users, site_config secrets, uploads de marca, credenciais.
 */

/**
 * POST action=system/factory-reset
 * Body: { "confirm": "RESET", "clearDatabase": true|false }
 */
function handleSystemFactoryReset(string $method): void {
    if ($method !== 'POST') {
        jsonRespond(['error' => 'Use POST'], 405);
    }
    // Sem rateLimit duplicado — rate da rota (2/min) em routes.php
    requireMasterAdmin();

    $b = jsonBody();
    $confirm = strtoupper(trim((string)($b['confirm'] ?? '')));
    if ($confirm !== 'RESET') {
        jsonRespond(['error' => 'Confirmação inválida. Digite RESET para continuar.'], 400);
    }

    $clearDb = !empty($b['clearDatabase']);
    $cleared = [
        'database' => [],
        'files' => [],
        'skipped' => [],
    ];

    if ($clearDb) {
        $cleared['database'] = factoryResetClearTempData(db());
    } else {
        $cleared['skipped'][] = 'database (clearDatabase=false)';
    }

    $cleared['files'] = factoryResetClearTempLogFiles();

    $hasError = false;
    foreach ($cleared['database'] as $v) {
        if ($v === 'error' || $v === 'invalid') {
            $hasError = true;
            break;
        }
    }

    appLog('warning', 'system_factory_reset', [
        'by' => adminSessionUserId(),
        'clearDatabase' => $clearDb,
        'counts' => $cleared['database'],
        'partial' => $hasError,
    ]);

    if ($hasError) {
        jsonRespond([
            'ok' => false,
            'partial' => true,
            'error' => 'Reset parcial — algumas limpezas falharam. Veja cleared.database.',
            'message' => 'Reset parcial. Sessão deve ser encerrada no cliente.',
            'cleared' => $cleared,
            'preserved' => factoryResetPreservedFlags(),
        ], 200);
    }

    jsonRespond([
        'ok' => true,
        'partial' => false,
        'message' => 'Reset de fábrica concluído. Sessão deve ser encerrada no cliente.',
        'cleared' => $cleared,
        'preserved' => factoryResetPreservedFlags(),
    ]);
}

/** @return array<string,bool> */
function factoryResetPreservedFlags(): array {
    return [
        'config' => true,
        'credentials' => true,
        'schema' => true,
        'adminUsers' => true,
        'siteConfig' => true,
        'brandUploads' => true,
        'aiProviderKeys' => true,
    ];
}

/**
 * Limpa apenas tabelas/linhas temporárias — nunca DROP DATABASE / DROP TABLE.
 * @return array<string,int|string>
 */
function factoryResetClearTempData(PDO $pdo): array {
    $results = [];

    $truncateTables = [
        'system_logs',
        'ai_gateway_logs',
        'notification_logs',
        'ai_content_jobs',
    ];
    foreach ($truncateTables as $table) {
        $results[$table] = factoryResetSafeTruncate($pdo, $table);
    }

    // Chat IA público (histórico efêmero Cap. Clean) — escopo do reset de fábrica
    $results['messages'] = factoryResetSafeDelete($pdo, 'DELETE FROM messages');
    $results['conversations'] = factoryResetSafeDelete($pdo, 'DELETE FROM conversations');

    $results['communication_events_test'] = factoryResetSafeDelete(
        $pdo,
        'DELETE FROM communication_events WHERE is_test = 1'
    );

    // Statuses reais do NotificationCenter (pt-BR)
    $results['notification_queue_temp'] = factoryResetSafeDelete(
        $pdo,
        "DELETE FROM notification_queue
         WHERE status IN ('pendente','falhou','reenviada')
           AND created_at < DATE_SUB(NOW(), INTERVAL 1 DAY)"
    );

    // Rascunhos de blog — só se coluna status existir
    if (factoryResetColumnExists($pdo, 'blog_posts', 'status')) {
        $results['blog_posts_draft'] = factoryResetSafeDelete(
            $pdo,
            "DELETE FROM blog_posts WHERE status = 'draft'"
        );
    } else {
        $results['blog_posts_draft'] = 'absent';
    }

    // Agendamentos de teste — coluna real é `client` (não name/email)
    $results['appointments_test'] = factoryResetSafeDelete(
        $pdo,
        "DELETE FROM appointments WHERE
            visitor_id LIKE 'test_%'
            OR visitor_id LIKE 'demo_%'
            OR LOWER(COALESCE(client,'')) LIKE 'teste%'
            OR LOWER(COALESCE(client,'')) LIKE 'test %'
            OR LOWER(COALESCE(client,'')) = 'teste'
            OR LOWER(COALESCE(client,'')) = 'test'"
    );

    // Notificações de visitantes de teste
    $results['client_notifications_test'] = factoryResetSafeDelete(
        $pdo,
        "DELETE FROM client_notifications WHERE
            visitor_id LIKE 'test_%'
            OR visitor_id LIKE 'demo_%'"
    );

    // CRM: e-mails claramente fictícios + nomes prefixo (evita %teste% em nomes reais)
    $results['crm_contacts_test'] = factoryResetSafeDelete(
        $pdo,
        "DELETE FROM crm_contacts WHERE
            LOWER(COALESCE(email,'')) LIKE '%@test.%'
            OR LOWER(COALESCE(email,'')) LIKE '%@example.%'
            OR LOWER(COALESCE(name,'')) LIKE 'teste%'
            OR LOWER(COALESCE(name,'')) LIKE 'test %'
            OR LOWER(COALESCE(name,'')) = 'teste'
            OR LOWER(COALESCE(name,'')) = 'test'"
    );

    return $results;
}

function factoryResetTableExists(PDO $pdo, string $table): bool {
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
        return false;
    }
    try {
        $stmt = $pdo->query('SHOW TABLES LIKE ' . $pdo->quote($table));
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function factoryResetColumnExists(PDO $pdo, string $table, string $column): bool {
    if (!factoryResetTableExists($pdo, $table)) {
        return false;
    }
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $column)) {
        return false;
    }
    try {
        $stmt = $pdo->prepare(
            'SELECT 1 FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
             LIMIT 1'
        );
        $stmt->execute([$table, $column]);
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        // Fallback: DESCRIBE
        try {
            $rows = $pdo->query('SHOW COLUMNS FROM `' . $table . '`')->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                if (($row['Field'] ?? '') === $column) {
                    return true;
                }
            }
        } catch (Throwable $e2) { /* */ }
        return false;
    }
}

/** @return int|string */
function factoryResetSafeTruncate(PDO $pdo, string $table) {
    if (!factoryResetTableExists($pdo, $table)) {
        return 'absent';
    }
    try {
        $pdo->exec('TRUNCATE TABLE `' . $table . '`');
        return 'truncated';
    } catch (Throwable $e) {
        try {
            $n = $pdo->exec('DELETE FROM `' . $table . '`');
            return is_int($n) ? $n : 0;
        } catch (Throwable $e2) {
            if (function_exists('appLog')) {
                appLog('error', 'factory_reset_truncate', ['table' => $table, 'err' => $e2->getMessage()]);
            }
            return 'error';
        }
    }
}

/** @return int|string */
function factoryResetSafeDelete(PDO $pdo, string $sql) {
    if (!preg_match('/^DELETE\s+FROM\s+`?([a-zA-Z0-9_]+)`?/i', $sql, $m)) {
        return 'invalid';
    }
    $table = $m[1];
    if (!factoryResetTableExists($pdo, $table)) {
        return 'absent';
    }
    try {
        $n = $pdo->exec($sql);
        return is_int($n) ? $n : 0;
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('error', 'factory_reset_delete', ['table' => $table, 'err' => $e->getMessage()]);
        }
        return 'error';
    }
}

/**
 * Remove arquivos de log rotativos em storage/logs (não apaga diretório nem config).
 * @return list<string>
 */
function factoryResetClearTempLogFiles(): array {
    $removed = [];
    $dir = __DIR__ . '/storage/logs';
    if (!is_dir($dir)) {
        return $removed;
    }
    $files = glob($dir . '/*.log') ?: [];
    foreach ($files as $file) {
        if (is_file($file) && @unlink($file)) {
            $removed[] = basename($file);
        }
    }
    return $removed;
}
