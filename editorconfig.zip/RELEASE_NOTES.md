# Release Notes — v1.25.18

**Auto Limpeza Pro** · 2026-08-01 · HostGator / cPanel

## Destaques

- Portal **Minha Casa** + hub **Care+** (jornada do cliente)
- Fix agendamento **Pós-obra**: metragem só no preço; slot 150 min
- Prompt profissional de capa (copiar para Midjourney/Leonardo/etc.)
- Cron processa **job_queue**; migrações não marcam sucesso falso; MIME upload sem spoof

## Compatibilidade

APIs e rotas existentes preservadas. Identidade visual inalterada.

## Pós-deploy

1. Extrair ZIP em `public_html`
2. Repair: `install.php?step=repair&token=…`
3. Smoke: home, `/conta/care-plus`, agendamento pós-obra, cron, analytics
4. Rotacionar secrets se o ZIP for compartilhado
