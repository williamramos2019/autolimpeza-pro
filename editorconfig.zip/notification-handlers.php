<?php
/**
 * Central de Notificações — motor de eventos, histórico e auditoria.
 */

// ── Metadados de eventos ──────────────────────────────────────────────────

const NOTIFICATION_EVENT_META = [
    'new_appointment'       => ['category' => 'agenda',    'priority' => 'high',   'module' => 'agenda'],
    'appointment_confirmed' => ['category' => 'agenda',    'priority' => 'medium', 'module' => 'agenda'],
    'appointment_cancelled' => ['category' => 'agenda',  'priority' => 'high',   'module' => 'agenda'],
    'appointment_reminder'  => ['category' => 'agenda',  'priority' => 'medium', 'module' => 'agenda'],
    'appointment_completed' => ['category' => 'agenda',  'priority' => 'low',    'module' => 'agenda'],
    'appointment_status'    => ['category' => 'agenda',  'priority' => 'medium', 'module' => 'agenda'],
    'new_lead'              => ['category' => 'forms',   'priority' => 'high',   'module' => 'forms'],
    'new_contact'           => ['category' => 'forms',   'priority' => 'medium', 'module' => 'forms'],
    'new_review'            => ['category' => 'forms',   'priority' => 'low',    'module' => 'forms'],
    'new_client'            => ['category' => 'clients', 'priority' => 'medium', 'module' => 'clients'],
    'profile_update'        => ['category' => 'clients', 'priority' => 'low',    'module' => 'clients'],
    'new_sale'              => ['category' => 'financial','priority' => 'medium','module' => 'financial'],
    'payment_received'      => ['category' => 'financial','priority' => 'medium','module' => 'financial'],
    'new_expense'           => ['category' => 'financial','priority' => 'low',    'module' => 'financial'],
    'new_article'           => ['category' => 'content', 'priority' => 'low',    'module' => 'blog'],
    'new_promotion'         => ['category' => 'content', 'priority' => 'medium', 'module' => 'content'],
    'new_campaign'          => ['category' => 'content', 'priority' => 'medium', 'module' => 'content'],
    'system_alert'          => ['category' => 'system',  'priority' => 'high',   'module' => 'logs'],
];

/** Tipos exclusivos do painel admin — nunca exibir no sininho público/cliente. */
function notificationAdminOnlyTypes(): array {
    return [
        'new_appointment',
        'new_lead',
        'new_contact',
        'new_review',
        'new_client',
        'new_sale',
        'new_expense',
        'payment_received',
        'system_alert',
        'new_campaign',
        'crm_automation',
        'blog_multichannel',
    ];
}

/** Tipos permitidos no sininho do visitante/cliente logado. */
function notificationClientVisibleTypes(): array {
    return [
        'appointment_confirmed',
        'automotive_wash_confirm',
        'appointment_cancelled',
        'appointment_completed',
        'appointment_reminder',
        'appointment_status',
        'DriverStarted',
        'DriverArrived',
        'ServiceStarted',
        'ServicePaused',
        'new_article',
        'new_promotion',
        'coupon_issued',
        'weather_alert',
        'tracking_update',
        'quote_update',
        'client_portal',
        'ReviewRequested',
    ];
}

function notificationClientTypeSqlFilter(): string {
    $adminOnly = notificationAdminOnlyTypes();
    $placeholders = implode(',', array_fill(0, count($adminOnly), '?'));
    return "type NOT IN ({$placeholders})";
}

function notificationClientTypeSqlParams(): array {
    return notificationAdminOnlyTypes();
}

function notificationIsClientVisibleType(string $type): bool {
    if (in_array($type, notificationAdminOnlyTypes(), true)) {
        return false;
    }
    $visible = notificationClientVisibleTypes();
    if ($visible === []) {
        return true;
    }
    return in_array($type, $visible, true)
        || str_starts_with($type, 'appointment_')
        || str_starts_with($type, 'Driver')
        || str_starts_with($type, 'Service')
        || str_starts_with($type, 'Review');
}

// ── Schema ────────────────────────────────────────────────────────────────

function migrateNotificationSchema(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `system_notifications` (
        `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `type`           VARCHAR(50)  NOT NULL,
        `category`       VARCHAR(50)  NOT NULL DEFAULT 'general',
        `priority`       VARCHAR(10)  NOT NULL DEFAULT 'medium',
        `title`          VARCHAR(200) NOT NULL,
        `body`           TEXT         DEFAULT NULL,
        `meta`           JSON         DEFAULT NULL,
        `recipient_type` VARCHAR(20)  NOT NULL DEFAULT 'admin',
        `recipient_id`   VARCHAR(64)  DEFAULT NULL,
        `source_module`  VARCHAR(50)  DEFAULT NULL,
        `action_url`     VARCHAR(500) DEFAULT NULL,
        `generated_by`   VARCHAR(100) DEFAULT NULL,
        `push_sent`      TINYINT(1)   NOT NULL DEFAULT 0,
        `email_sent`     TINYINT(1)   NOT NULL DEFAULT 0,
        `read_at`        DATETIME     DEFAULT NULL,
        `read_by`        INT UNSIGNED DEFAULT NULL,
        `created_at`     DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_unread`    (`read_at`, `created_at`),
        INDEX `idx_category`  (`category`, `created_at`),
        INDEX `idx_priority`  (`priority`, `created_at`),
        INDEX `idx_type`      (`type`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $alters = [
        'category'       => "VARCHAR(50) NOT NULL DEFAULT 'general'",
        'priority'       => "VARCHAR(10) NOT NULL DEFAULT 'medium'",
        'recipient_type' => "VARCHAR(20) NOT NULL DEFAULT 'admin'",
        'recipient_id'   => "VARCHAR(64) DEFAULT NULL",
        'source_module'  => "VARCHAR(50) DEFAULT NULL",
        'action_url'     => "VARCHAR(500) DEFAULT NULL",
        'generated_by'   => "VARCHAR(100) DEFAULT NULL",
        'push_sent'      => "TINYINT(1) NOT NULL DEFAULT 0",
        'email_sent'     => "TINYINT(1) NOT NULL DEFAULT 0",
        'read_by'        => "INT UNSIGNED DEFAULT NULL",
    ];
    foreach ($alters as $col => $def) {
        try { $pdo->exec("ALTER TABLE system_notifications ADD COLUMN `{$col}` {$def}"); } catch (PDOException $e) { /* exists */ }
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS `client_notifications` (
        `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `visitor_id` VARCHAR(64)  NOT NULL,
        `type`       VARCHAR(50)  NOT NULL,
        `title`      VARCHAR(200) NOT NULL,
        `body`       TEXT         DEFAULT NULL,
        `meta`       JSON         DEFAULT NULL,
        `action_url` VARCHAR(500) DEFAULT NULL,
        `read_at`    DATETIME     DEFAULT NULL,
        `created_at` DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_visitor` (`visitor_id`, `created_at`),
        INDEX `idx_visitor_unread` (`visitor_id`, `read_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `push_devices` (
        `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `owner_type`  VARCHAR(20)  NOT NULL DEFAULT 'visitor',
        `owner_id`    VARCHAR(64)  NOT NULL,
        `device_type` VARCHAR(20)  NOT NULL DEFAULT 'browser',
        `user_agent`  VARCHAR(500) DEFAULT NULL,
        `push_token`  VARCHAR(255) DEFAULT NULL,
        `enabled`     TINYINT(1)   NOT NULL DEFAULT 1,
        `last_seen`   DATETIME     NOT NULL,
        `created_at`  DATETIME     NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_owner_device` (`owner_type`, `owner_id`, `device_type`),
        INDEX `idx_owner` (`owner_type`, `owner_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function ensureSystemNotificationsTable(PDO $pdo): void {
    migrateNotificationSchema($pdo);
}

// ── Criação ───────────────────────────────────────────────────────────────

function createAdminNotification(
    PDO $pdo,
    string $type,
    string $title,
    string $body,
    array $meta = [],
    array $opts = []
): int {
    ensureSystemNotificationsTable($pdo);
    $eventMeta = NOTIFICATION_EVENT_META[$type] ?? ['category' => 'general', 'priority' => 'medium', 'module' => 'system'];

    $pdo->prepare("
        INSERT INTO system_notifications
            (type, category, priority, title, body, meta, recipient_type, recipient_id,
             source_module, action_url, generated_by, push_sent, email_sent, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ")->execute([
        $type,
        $opts['category'] ?? $eventMeta['category'],
        $opts['priority'] ?? $eventMeta['priority'],
        $title,
        $body,
        json_encode($meta, JSON_UNESCAPED_UNICODE),
        $opts['recipient_type'] ?? 'admin',
        $opts['recipient_id'] ?? null,
        $opts['source_module'] ?? $eventMeta['module'],
        $opts['action_url'] ?? null,
        $opts['generated_by'] ?? null,
        !empty($opts['push_sent']) ? 1 : 0,
        !empty($opts['email_sent']) ? 1 : 0,
        dbNow(),
    ]);
    return (int)$pdo->lastInsertId();
}

/** @deprecated use createAdminNotification */
function createSystemNotification(PDO $pdo, string $type, string $title, string $body, array $meta = []): void {
    createAdminNotification($pdo, $type, $title, $body, $meta);
}

function createClientNotification(
    PDO $pdo,
    string $visitorId,
    string $type,
    string $title,
    string $body,
    array $meta = [],
    ?string $actionUrl = null
): int {
    if ($visitorId === '' || !notificationIsClientVisibleType($type)) {
        appLog('warn', 'client_notification_blocked', ['type' => $type, 'visitor_id' => $visitorId !== '' ? 'set' : 'empty']);
        return 0;
    }
    ensureSystemNotificationsTable($pdo);
    $pdo->prepare("
        INSERT INTO client_notifications (visitor_id, type, title, body, meta, action_url, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ")->execute([
        $visitorId, $type, $title, $body,
        json_encode($meta, JSON_UNESCAPED_UNICODE),
        $actionUrl, dbNow(),
    ]);
    return (int)$pdo->lastInsertId();
}

function registerPushDevice(PDO $pdo, string $ownerType, string $ownerId, string $deviceType, ?string $userAgent, ?string $pushToken = null): void {
    ensureSystemNotificationsTable($pdo);
    $now = dbNow();
    $pdo->prepare("
        INSERT INTO push_devices (owner_type, owner_id, device_type, user_agent, push_token, enabled, last_seen, created_at)
        VALUES (?, ?, ?, ?, ?, 1, ?, ?)
        ON DUPLICATE KEY UPDATE
            user_agent = VALUES(user_agent),
            push_token = COALESCE(VALUES(push_token), push_token),
            enabled = 1,
            last_seen = VALUES(last_seen)
    ")->execute([$ownerType, $ownerId, $deviceType, $userAgent, $pushToken, $now, $now]);
}

// ── Dispatcher central ────────────────────────────────────────────────────

function notificationAbsoluteUrl(?string $path): string {
    if ($path === null || $path === '') {
        $base = defined('SITE_URL') ? rtrim((string) SITE_URL, '/') : '';
        return $base !== '' ? $base . '/comunicacao-admin' : '/comunicacao-admin';
    }
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }
    $base = defined('SITE_URL') ? rtrim((string) SITE_URL, '/') : '';
    return $base . (str_starts_with($path, '/') ? $path : '/' . $path);
}

function dispatchNotificationEvent(PDO $pdo, string $event, string $title, string $body, array $meta = [], array $opts = []): void {
    // Communication Hub — registra o evento no bus canônico (aditivo, nunca bloqueia)
    $hubEventId = function_exists('communicationEventRecord')
        ? communicationEventRecord($pdo, $event, $title, $meta, [
            'source'     => $opts['source'] ?? 'legacy_dispatch',
            'actor_id'   => $opts['visitor_id'] ?? ($meta['visitor_id'] ?? null),
            'actor_type' => isset($opts['visitor_id']) || isset($meta['visitor_id']) ? 'visitor' : null,
            'is_test'    => !empty($opts['is_test']),
        ])
        : null;

    if (class_exists('NotificationCenter')) {
        try {
            $dedupeKey = $opts['dedupe_key'] ?? ($meta['appointment_id'] ?? ($meta['id'] ?? null));
            $opts['communication_event_id'] = $hubEventId;
            if (function_exists('telegramEnrichOpts')) {
                $opts = telegramEnrichOpts($pdo, $opts, $meta);
            }
            $result = NotificationCenter::send([
            'type'            => $event,
            'title'           => $title,
            'body'            => $body,
            'meta'            => $meta,
            'opts'            => $opts,
            'dedupe_key'      => $dedupeKey ? ($event . ':' . $dedupeKey) : null,
            'async'           => $opts['async'] ?? true,
            'legacy_parallel' => !empty($opts['legacy_parallel']),
        ]);

        if (!empty($result['internal_id']) && !empty($result['results'])) {
            $pushSent = ($result['results']['push'] ?? '') === 'ok';
            $emailSent = ($result['results']['email'] ?? '') === 'ok';
            if ($pushSent || $emailSent) {
                $pdo->prepare('UPDATE system_notifications SET push_sent = ?, email_sent = ? WHERE id = ?')
                    ->execute([$pushSent ? 1 : 0, $emailSent ? 1 : 0, $result['internal_id']]);
            }
        }

        if (!empty($result['results'])) {
            foreach ($result['results'] as $channel => $status) {
                if (in_array($status, ['failed', 'error'], true)) {
                    if (function_exists('appLogRateLimited')) {
                        appLogRateLimited('warning', 'notification_channel_issue', [
                            'event' => $event, 'channel' => $channel, 'status' => $status, 'uuid' => $result['uuid'] ?? null,
                        ], 300);
                    } else {
                        appLog('warning', 'notification_channel_issue', [
                            'event' => $event, 'channel' => $channel, 'status' => $status, 'uuid' => $result['uuid'] ?? null,
                        ]);
                    }
                }
            }
        }

        if (!empty($result['skipped_duplicate'])) {
            appLog('info', 'notification_dedupe_skip', ['event' => $event, 'uuid' => $result['uuid']]);
        }

        if (function_exists('communicationEventFinalize')) {
            $status = !empty($result['skipped_duplicate']) ? 'deduped' : (!empty($result['queued']) ? 'queued' : 'processed');
            communicationEventFinalize($pdo, $hubEventId, $status, count($result['results'] ?? []), $result['uuid'] ?? null);
        }
        } catch (Throwable $e) {
            appLog('error', 'notification_dispatch_failed', [
                'event' => $event,
                'error' => $e->getMessage(),
            ]);
            if (function_exists('communicationEventFinalize')) {
                communicationEventFinalize($pdo, $hubEventId, 'failed', 0, null, $e->getMessage());
            }
            dispatchNotificationEventLegacy($pdo, $event, $title, $body, $meta, $opts);
        }
        return;
    }

    appLog('warning', 'notification_center_unavailable', ['event' => $event]);
    if (function_exists('communicationEventFinalize')) {
        communicationEventFinalize($pdo, $hubEventId, 'legacy_fallback', 0, null, 'NotificationCenter indisponível');
    }
    // Fallback legacy (não deveria ocorrer se notification-center.php carregado)
    dispatchNotificationEventLegacy($pdo, $event, $title, $body, $meta, $opts);
}

/** @internal Compatibilidade — lógica anterior preservada */
function dispatchNotificationEventLegacy(PDO $pdo, string $event, string $title, string $body, array $meta = [], array $opts = []): void {
    if (!function_exists('getNotificationChannels')) {
        require_once __DIR__ . '/mail-handlers.php';
    }
    $channels = getNotificationChannels($pdo);
    $ch       = $channels[$event] ?? [];

    $actionUrl      = $opts['action_url'] ?? null;
    $visitorId      = $opts['visitor_id'] ?? ($meta['visitor_id'] ?? null);
    $pushSent       = false;
    $emailSent      = false;
    $notificationId = null;
    $emailTemplates = $opts['email_templates'] ?? null;

    if (!empty($ch['panel'])) {
        $notificationId = createAdminNotification($pdo, $event, $title, $body, $meta, array_merge($opts, [
            'push_sent'  => false,
            'email_sent' => false,
        ]));
    }

    if (!empty($ch['push'])) {
        $pushUrl = $opts['push_url'] ?? notificationAbsoluteUrl($actionUrl);
        if (function_exists('sendWebPushIfConfigured') && function_exists('webPushIsConfigured') && webPushIsConfigured($pdo)) {
            $wp = sendWebPushIfConfigured($pdo, $title, $body, $pushUrl, [
                'urgency' => 'normal',
                'owner_type' => $opts['owner_type'] ?? null,
                'owner_id' => $opts['visitor_id'] ?? ($opts['owner_id'] ?? null),
            ]);
            $pushSent = ($wp['sent'] ?? 0) > 0;
        } elseif (function_exists('sendPushAlertIfConfigured')) {
            // Alias legado → Web Push (sendPushAlertIfConfigured já redireciona)
            $pushSent = sendPushAlertIfConfigured($pdo, $title, $body, $pushUrl);
        }
    }

    if (!empty($ch['email_admin']) && function_exists('sendMailMessage') && function_exists('getSmtpConfigRow')) {
        $cfg = getSmtpConfigRow($pdo);
        $to  = $cfg['admin_email'] ?: $cfg['from_email'];
        if ($to) {
            if (is_array($emailTemplates) && !empty($emailTemplates['admin']) && function_exists('renderMailTemplate')) {
                $t    = $emailTemplates['admin'];
                $mail = renderMailTemplate($t['template'], $t['vars'] ?? []);
                $res  = sendMailMessage($to, $mail['subject'], $mail['body']);
            } elseif (function_exists('mailWrapHtml')) {
                $html = mailWrapHtml($title, '<p>' . nl2br(htmlspecialchars($body, ENT_QUOTES, 'UTF-8')) . '</p>');
                $res  = sendMailMessage($to, $title, $html);
            } else {
                $res = ['ok' => false];
            }
            $emailSent = !empty($res['ok']);
        }
    }

    $clientEmail = $opts['client_email'] ?? ($meta['client_email'] ?? null);
    if (!empty($ch['email_client']) && $clientEmail && function_exists('sendMailMessage') && isEmail($clientEmail)) {
        if (is_array($emailTemplates) && !empty($emailTemplates['client']) && function_exists('renderMailTemplate')) {
            $t    = $emailTemplates['client'];
            $mail = renderMailTemplate($t['template'], $t['vars'] ?? []);
            $res  = sendMailMessage($clientEmail, $mail['subject'], $mail['body']);
        } else {
            $html = function_exists('mailWrapHtml')
                ? mailWrapHtml($title, '<p>' . nl2br(htmlspecialchars($body, ENT_QUOTES, 'UTF-8')) . '</p>')
                : $body;
            $res = sendMailMessage($clientEmail, $title, $html);
        }
        $emailSent = $emailSent || !empty($res['ok']);
    }

    if ($visitorId) {
        $clientNotif = $opts['client_notification'] ?? null;
        if (is_array($clientNotif)) {
            createClientNotification(
                $pdo,
                $visitorId,
                $clientNotif['type'] ?? $event,
                $clientNotif['title'] ?? $title,
                $clientNotif['body'] ?? $body,
                $meta,
                $clientNotif['action_url'] ?? $actionUrl
            );
        }
    }

    if ($notificationId && ($pushSent || $emailSent)) {
        $pdo->prepare('UPDATE system_notifications SET push_sent = ?, email_sent = ? WHERE id = ?')
            ->execute([$pushSent ? 1 : 0, $emailSent ? 1 : 0, $notificationId]);
    }

    appLog('info', 'notification_dispatched', [
        'event' => $event, 'push' => $pushSent, 'email' => $emailSent, 'panel' => (bool) $notificationId,
    ]);
}

function formatApptDateBr(string $dateStr): string {
    $parts = explode('-', $dateStr);
    if (count($parts) !== 3) return $dateStr;
    return sprintf('%02d/%02d/%04d', (int)$parts[2], (int)$parts[1], (int)$parts[0]);
}

function notifyNewAppointment(PDO $pdo, array $appt): void {
    $client   = $appt['client'] ?? 'Cliente';
    $phone    = $appt['phone'] ?? '';
    $services = is_array($appt['services'] ?? null) ? implode(', ', $appt['services']) : (string)($appt['services'] ?? '');
    $dateBr   = formatApptDateBr($appt['date'] ?? '');
    $time     = $appt['time'] ?? '';
    $address  = $appt['address'] ?? '';
    $visitorId = $appt['visitorId'] ?? $appt['visitor_id'] ?? null;
    $clientEmail = trim((string)($appt['client_email'] ?? $appt['clientEmail'] ?? ''));

    $title = 'Novo agendamento recebido';
    $body  = "Cliente {$client} solicitou {$services} para {$dateBr} às {$time}.";

    $meta = [
        'appointment_id' => $appt['id'] ?? null,
        'client'         => $client,
        'phone'          => $phone,
        'services'       => $appt['services'] ?? [],
        'service'        => $services,
        'date'           => $appt['date'] ?? '',
        'time'           => $time,
        'address'        => $address,
        'duration'       => $appt['duration'] ?? null,
        'visitor_id'     => $visitorId,
        'client_email'   => $clientEmail ?: null,
    ];

    $opts = [
        'action_url'    => '/agenda',
        'priority'      => 'high',
        'visitor_id'    => $visitorId,
        'client_email'  => $clientEmail ?: null,
        'phone'         => $phone ?: null,
        'enable_whatsapp' => $phone !== '',
        'push_url'      => notificationAbsoluteUrl('/agenda'),
        'email_templates' => [
            'admin' => [
                'template' => 'appointment_admin',
                'vars' => [
                    'nome' => $client, 'servico' => $services, 'data' => $dateBr,
                    'horario' => $time, 'telefone' => $phone,
                ],
            ],
            'client' => [
                'template' => 'appointment_client',
                'vars' => [
                    'nome_cliente' => $client, 'servico' => $services,
                    'data' => $dateBr, 'horario' => $time,
                ],
            ],
        ],
    ];

    if ($visitorId) {
        $isWash = stripos($services, 'lavagem') !== false || stripos($services, 'automotiv') !== false;
        $veiculo = '';
        if ($isWash && preg_match('/\(([^)]+)\)/', $services, $m)) {
            $veiculo = trim($m[1]);
        }
        $opts['client_notification'] = [
            'type'       => $isWash ? 'automotive_wash_confirm' : 'appointment_confirmed',
            'title'      => $isWash ? 'Lavagem Automotiva recebida!' : 'Agendamento recebido!',
            'body'       => $isWash
                ? ("Sua Lavagem Automotiva ({$services}) para {$dateBr} às {$time} foi registrada."
                    . ($veiculo !== '' ? " Veículo: {$veiculo}." : '')
                    . ' Em breve entraremos em contato.')
                : "Seu pedido de {$services} para {$dateBr} às {$time} foi registrado. Em breve entraremos em contato.",
            'action_url' => '/meu-agendamento',
        ];
    }

    dispatchNotificationEvent($pdo, 'new_appointment', $title, $body, $meta, $opts);
}

function notifyAppointmentStatusChange(PDO $pdo, array $appt, string $newStatus): void {
    $client   = $appt['client'] ?? 'Cliente';
    $services = is_array($appt['services'] ?? null) ? implode(', ', $appt['services']) : '';
    $dateBr   = formatApptDateBr($appt['date'] ?? '');
    $time     = $appt['time'] ?? '';
    $visitorId = $appt['visitor_id'] ?? $appt['visitorId'] ?? null;

    $map = [
        'confirmed'  => ['appointment_confirmed', 'Agendamento confirmado', "O agendamento de {$client} para {$dateBr} às {$time} foi confirmado."],
        'cancelled'  => ['appointment_cancelled', 'Agendamento cancelado', "O agendamento de {$client} para {$dateBr} foi cancelado."],
        'completed'  => ['appointment_completed', 'Serviço concluído', "Atendimento de {$client} ({$services}) foi concluído."],
        'en_route'   => ['DriverStarted', 'Profissional a caminho', "Equipe a caminho para atendimento de {$client}."],
        'arrived'    => ['DriverArrived', 'Equipe chegou', "Equipe chegou para atendimento de {$client}."],
        'in_service' => ['ServiceStarted', 'Serviço em andamento', "Atendimento de {$client} iniciado no local."],
        'paused'     => ['ServicePaused', 'Serviço pausado', "Atendimento de {$client} pausado temporariamente."],
    ];

    [$event, $title, $body] = $map[$newStatus] ?? ['appointment_status', 'Atualização de agendamento', "Status do agendamento de {$client} alterado para {$newStatus}."];

    $meta = ['appointment_id' => $appt['id'], 'status' => $newStatus, 'client' => $client, 'visitor_id' => $visitorId];
    $liveUrl = '/conta/agendamentos?live=' . urlencode((string)($appt['id'] ?? ''));

    $clientTitles = [
        'confirmed'  => ['Agendamento confirmado!', "Sua visita em {$dateBr} às {$time} foi confirmada."],
        'cancelled'  => ['Agendamento cancelado', 'Seu agendamento foi cancelado. Entre em contato para reagendar.'],
        'completed'  => ['Serviço concluído!', 'Obrigado pela preferência! Esperamos vê-lo novamente.'],
        'en_route'   => ['Profissional a caminho', 'Nossa equipe está se deslocando até você.'],
        'arrived'    => ['Equipe chegou', 'Nossa equipe chegou ao seu endereço.'],
        'in_service' => ['Serviço em andamento', 'O atendimento foi iniciado no local.'],
        'paused'     => ['Serviço pausado', 'O atendimento foi pausado temporariamente.'],
    ];

    $opts = [
        'action_url' => $liveUrl,
        'visitor_id' => $visitorId,
        'push_url'   => notificationAbsoluteUrl($liveUrl),
        'phone'      => $appt['phone'] ?? null,
    ];
    if ($visitorId && isset($clientTitles[$newStatus])) {
        [$ct, $cb] = $clientTitles[$newStatus];
        $isWash = stripos($services, 'lavagem') !== false || stripos($services, 'automotiv') !== false;
        $clientType = ($newStatus === 'confirmed' && $isWash) ? 'automotive_wash_confirm' : $event;
        if ($newStatus === 'confirmed' && $isWash) {
            $veiculo = '';
            if (preg_match('/\(([^)]+)\)/', $services, $m)) {
                $veiculo = trim($m[1]);
            }
            $ct = 'Lavagem Automotiva confirmada';
            $cb = "Sua Lavagem Automotiva ({$services}) está confirmada para {$dateBr} às {$time}."
                . ($veiculo !== '' ? " Veículo: {$veiculo}." : '');
        }
        $opts['client_notification'] = [
            'type'       => $clientType,
            'title'      => $ct,
            'body'       => $cb,
            'action_url' => $liveUrl,
        ];
    }

    dispatchNotificationEvent($pdo, $event, $title, $body, $meta, $opts);

    if ($newStatus === 'completed' && function_exists('captainAutomationOnServiceCompleted')) {
        try {
            captainAutomationOnServiceCompleted($pdo, $appt);
        } catch (Throwable $e) {
            appLog('warn', 'captainAutomationOnServiceCompleted failed', [
                'appointment_id' => $appt['id'] ?? null,
                'err' => $e->getMessage(),
            ]);
        }
    }
}

function notifyNewLead(PDO $pdo, array $lead): void {
    $name    = $lead['name'] ?? 'Visitante';
    $phone   = $lead['phone'] ?? '';
    $service = $lead['service'] ?? '';
    $city    = $lead['city'] ?? '';
    $source  = $lead['source'] ?? 'site';

    $sourceLabels = [
        'lead_modal' => 'Pedido de orçamento',
        'contact'    => 'Contato',
        'service'    => 'Solicitação de serviço',
        'review'     => 'Avaliação',
    ];
    $label = $sourceLabels[$source] ?? 'Novo contato';

    $title = "{$label} recebido pelo site";
    $body  = "{$name} — {$phone}" . ($service ? " • {$service}" : '') . ($city ? " • {$city}" : '');

    dispatchNotificationEvent($pdo, 'new_lead', $title, $body, $lead, [
        'action_url' => '/admin',
        'priority'   => $source === 'review' ? 'low' : 'high',
        'push_url'   => notificationAbsoluteUrl('/comunicacao-admin'),
    ]);
}

function notifyNewArticle(PDO $pdo, array $post, array $opts = []): void {
    $title   = $post['title'] ?? 'Novo artigo';
    $slug    = $post['slug'] ?? '';
    $excerpt = $post['excerpt'] ?? '';

    $adminTitle = 'Novo artigo publicado';
    $adminBody  = "Artigo \"{$title}\" foi publicado no blog.";

    try {
        dispatchNotificationEvent($pdo, 'new_article', $adminTitle, $adminBody, [
            'slug' => $slug, 'title' => $title,
        ], [
            'action_url' => "/dicas/{$slug}",
            'priority'   => 'low',
            'push_url'   => notificationAbsoluteUrl("/dicas/{$slug}"),
        ]);
    } catch (Throwable $e) {
        appLog('warn', 'notifyNewArticle_admin', ['err' => $e->getMessage()]);
    }

    if (empty($opts['notify_clients'])) return;

    $clientTitle = $opts['client_title'] ?? "Nova dica no blog da Auto Limpeza Pro";
    $clientBody  = $opts['client_body'] ?? "Publicamos: {$title}. " . ($excerpt ?: 'Confira no portal de dicas.');

    if (!empty($opts['push_clients']) && class_exists('NotificationCenter')) {
        try {
            NotificationCenter::send([
                'type'       => 'new_article',
                'title'      => $clientTitle,
                'body'       => $clientBody,
                'meta'       => ['slug' => $slug, 'title' => $title],
                'opts'       => [
                    'skip_internal'  => true,
                    'channels_only'  => ['push'],
                    'push_url'       => function_exists('notificationAbsoluteUrl')
                        ? notificationAbsoluteUrl("/dicas/{$slug}")
                        : (defined('SITE_URL') ? SITE_URL . "/dicas/{$slug}" : "/dicas/{$slug}"),
                ],
                'dedupe_key' => 'new_article_push:' . $slug,
                'async'      => true,
            ]);
        } catch (Throwable $e) {
            appLog('warn', 'notifyNewArticle_push', ['err' => $e->getMessage()]);
        }
    }

    if (!empty($opts['active_clients_only'])) {
        try {
            $rows = $pdo->query("SELECT DISTINCT visitor_id FROM appointments WHERE visitor_id IS NOT NULL AND visitor_id != '' AND status NOT IN ('cancelled','completed') LIMIT 500")->fetchAll();
            foreach ($rows as $row) {
                if ($row['visitor_id']) {
                    createClientNotification($pdo, $row['visitor_id'], 'new_article', $clientTitle, $clientBody, ['slug' => $slug], "/dicas/{$slug}");
                }
            }
        } catch (Throwable $e) {
            appLog('warn', 'notifyNewArticle_clients', ['err' => $e->getMessage()]);
        }
    }
}

function notifyFinancialEvent(PDO $pdo, string $event, string $title, string $body, array $meta = []): void {
    dispatchNotificationEvent($pdo, $event, $title, $body, $meta, [
        'action_url' => $meta['action_url'] ?? '/financas',
        'push_url'   => notificationAbsoluteUrl($meta['action_url'] ?? '/financas'),
    ]);
}

// ── API Handlers ──────────────────────────────────────────────────────────

function decodeAdminNotification(array $r): array {
    return [
        'id'             => (int)$r['id'],
        'type'           => $r['type'],
        'category'       => $r['category'] ?? 'general',
        'priority'       => $r['priority'] ?? 'medium',
        'title'          => $r['title'],
        'body'           => $r['body'],
        'meta'           => json_decode($r['meta'] ?? 'null', true),
        'recipientType'  => $r['recipient_type'] ?? 'admin',
        'recipientId'    => $r['recipient_id'],
        'sourceModule'   => $r['source_module'],
        'actionUrl'      => $r['action_url'],
        'generatedBy'    => $r['generated_by'],
        'pushSent'       => (bool)($r['push_sent'] ?? 0),
        'emailSent'      => (bool)($r['email_sent'] ?? 0),
        'read'           => $r['read_at'] !== null,
        'readAt'         => $r['read_at'],
        'readBy'         => $r['read_by'] ? (int)$r['read_by'] : null,
        'createdAt'      => $r['created_at'],
    ];
}

function handleSystemNotifications(string $method): void {
    requireAdmin();
    $pdo = db();
    ensureSystemNotificationsTable($pdo);

    if ($method === 'GET') {
        $unreadOnly = ($_GET['unread'] ?? '') === '1';
        $category   = san($_GET['category'] ?? null, 50);
        $priority   = san($_GET['priority'] ?? null, 10);
        $q          = san($_GET['q'] ?? null, 100);
        $limit      = min(100, max(10, sanInt($_GET['limit'] ?? 50)));

        $sql    = "SELECT * FROM system_notifications WHERE recipient_type = 'admin'";
        $params = [];
        if ($unreadOnly) $sql .= " AND read_at IS NULL";
        if ($category) { $sql .= " AND category = ?"; $params[] = $category; }
        if ($priority) { $sql .= " AND priority = ?"; $params[] = $priority; }
        if ($q) {
            $sql .= " AND (title LIKE ? OR body LIKE ? OR JSON_SEARCH(meta, 'one', ?) IS NOT NULL)";
            $like = "%{$q}%";
            $params[] = $like;
            $params[] = $like;
            $params[] = $q;
        }
        $sql .= " ORDER BY FIELD(priority,'high','medium','low'), created_at DESC LIMIT {$limit}";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = array_map('decodeAdminNotification', $stmt->fetchAll());

        $unreadStmt = $pdo->query("SELECT COUNT(*) FROM system_notifications WHERE recipient_type = 'admin' AND read_at IS NULL");
        $unread = (int)$unreadStmt->fetchColumn();

        header('Cache-Control: private, no-store');
        jsonRespond(['items' => $rows, 'unread' => $unread]);
    }

    if ($method === 'PUT') {
        $b       = jsonBody();
        $userId  = adminSessionUserId();
        $markAll = !empty($b['mark_all_read']);
        if ($markAll) {
            $pdo->prepare("UPDATE system_notifications SET read_at = NOW(), read_by = ? WHERE recipient_type = 'admin' AND read_at IS NULL")
                ->execute([$userId]);
            jsonRespond(['ok' => true]);
        }
        $id = sanInt($b['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare("UPDATE system_notifications SET read_at = NOW(), read_by = ? WHERE id = ?")
                ->execute([$userId, $id]);
        }
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleNotificationStats(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    ensureSystemNotificationsTable($pdo);

    $total   = (int)$pdo->query("SELECT COUNT(*) FROM system_notifications WHERE recipient_type = 'admin'")->fetchColumn();
    $unread  = (int)$pdo->query("SELECT COUNT(*) FROM system_notifications WHERE recipient_type = 'admin' AND read_at IS NULL")->fetchColumn();
    $read    = $total - $unread;
    $rate    = $total > 0 ? round(($read / $total) * 100) : 0;

    $byCategory = $pdo->query("
        SELECT category, COUNT(*) AS total,
               SUM(read_at IS NOT NULL) AS read_count
        FROM system_notifications WHERE recipient_type = 'admin' GROUP BY category
    ")->fetchAll();

    $byPeriod = $pdo->query("
        SELECT DATE(created_at) AS day, COUNT(*) AS total
        FROM system_notifications
        WHERE recipient_type = 'admin' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DATE(created_at) ORDER BY day
    ")->fetchAll();

    $byPriority = $pdo->query("
        SELECT priority, COUNT(*) AS total FROM system_notifications WHERE recipient_type = 'admin' GROUP BY priority
    ")->fetchAll();

    jsonRespond([
        'total'       => $total,
        'unread'      => $unread,
        'read'        => $read,
        'readRate'    => $rate,
        'byCategory'  => $byCategory,
        'byPeriod'    => $byPeriod,
        'byPriority'  => $byPriority,
        'devices'     => (int)$pdo->query("SELECT COUNT(*) FROM push_devices WHERE enabled = 1")->fetchColumn(),
    ]);
}

function handleClientNotifications(string $method): void {
    $pdo = db();
    ensureSystemNotificationsTable($pdo);
    if (function_exists('ensurePortalTables')) {
        try { ensurePortalTables($pdo); } catch (Throwable $e) { /* coluna client_id opcional */ }
    }

    $clientId = function_exists('clientSessionClientId') ? clientSessionClientId() : null;

    if ($method === 'GET') {
        $visitorId = san($_GET['visitor_id'] ?? null, 64);
        if (!$visitorId && !$clientId) jsonRespond(['error' => 'visitor_id obrigatório'], 400);
        rateLimit('client_notifications', 40);
        if ($visitorId) {
            assertVisitorOwnsId($visitorId);
        } elseif (!$clientId) {
            jsonRespond(['error' => 'visitor_id obrigatório'], 400);
        }

        if ($visitorId && $clientId && function_exists('visitorIdFromClientSession')) {
            $sessionVid = visitorIdFromClientSession();
            if ($sessionVid !== null && !hash_equals($sessionVid, $visitorId)) {
                // Cookie de visitante local divergente — consulta só pela conta logada
                $visitorId = null;
            }
        }

        $unreadOnly = ($_GET['unread'] ?? '') === '1';
        $where = [];
        $params = [];
        if ($visitorId) {
            $where[] = 'visitor_id = ?';
            $params[] = $visitorId;
        }
        if ($clientId) {
            $where[] = 'client_id = ?';
            $params[] = $clientId;
        }
        $typeFilter = notificationClientTypeSqlFilter();
        $typeParams = notificationClientTypeSqlParams();
        $sql = "SELECT id, type, title, body, meta, action_url, read_at, created_at
                FROM client_notifications WHERE (" . implode(' OR ', $where) . ") AND {$typeFilter}";
        if ($unreadOnly) $sql .= " AND read_at IS NULL";
        $sql .= " ORDER BY created_at DESC LIMIT 50";

        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_merge($params, $typeParams));
        $items = [];
        foreach ($stmt->fetchAll() as $r) {
            if (!notificationIsClientVisibleType((string)($r['type'] ?? ''))) {
                continue;
            }
            $items[] = [
                'id'        => (int)$r['id'],
                'type'      => $r['type'],
                'title'     => $r['title'],
                'body'      => $r['body'],
                'meta'      => json_decode($r['meta'] ?? 'null', true),
                'actionUrl' => $r['action_url'],
                'read'      => $r['read_at'] !== null,
                'createdAt' => $r['created_at'],
            ];
        }

        $countSql = "SELECT COUNT(*) FROM client_notifications WHERE (" . implode(' OR ', $where) . ") AND {$typeFilter} AND read_at IS NULL";
        $stmtU = $pdo->prepare($countSql);
        $stmtU->execute(array_merge($params, $typeParams));
        $unread = (int)$stmtU->fetchColumn();

        $apptCount = 0;
        try {
            if ($visitorId) {
                $stmtA = $pdo->prepare("
                    SELECT COUNT(*) FROM appointments
                    WHERE visitor_id = ? AND status NOT IN ('cancelled')
                ");
                $stmtA->execute([$visitorId]);
                $apptCount = (int)$stmtA->fetchColumn();
            }
        } catch (Throwable $e) { /* */ }

        $showBell = $unread > 0 || count($items) > 0;

        header('Cache-Control: private, no-store');
        jsonRespond([
            'items'           => $items,
            'unread'          => $unread,
            'showBell'        => $showBell,
            'hasAppointments' => $apptCount > 0,
        ]);
    }

    if ($method === 'PUT') {
        $b         = jsonBody();
        $visitorId = san($b['visitor_id'] ?? null, 64);
        if (!$visitorId && !$clientId) jsonRespond(['error' => 'visitor_id obrigatório'], 400);
        if ($visitorId) {
            assertVisitorOwnsId($visitorId);
        }
        if (!empty($b['mark_all_read'])) {
            $where = [];
            $params = [];
            if ($visitorId) { $where[] = 'visitor_id = ?'; $params[] = $visitorId; }
            if ($clientId) { $where[] = 'client_id = ?'; $params[] = $clientId; }
            if ($where) {
                $typeFilter = notificationClientTypeSqlFilter();
                $typeParams = notificationClientTypeSqlParams();
                $pdo->prepare("UPDATE client_notifications SET read_at = NOW() WHERE (" . implode(' OR ', $where) . ") AND {$typeFilter} AND read_at IS NULL")
                    ->execute(array_merge($params, $typeParams));
            }
            jsonRespond(['ok' => true]);
        }
        $id = sanInt($b['id'] ?? 0);
        if ($id > 0) {
            $where = [];
            $params = [$id];
            if ($visitorId) { $where[] = 'visitor_id = ?'; $params[] = $visitorId; }
            if ($clientId) { $where[] = 'client_id = ?'; $params[] = $clientId; }
            if ($where) {
                $typeFilter = notificationClientTypeSqlFilter();
                $typeParams = notificationClientTypeSqlParams();
                $pdo->prepare("UPDATE client_notifications SET read_at = NOW() WHERE id = ? AND (" . implode(' OR ', $where) . ") AND {$typeFilter}")
                    ->execute(array_merge($params, $typeParams));
            }
        }
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handlePushDevices(string $method): void {
    $pdo = db();
    ensureSystemNotificationsTable($pdo);

    if ($method === 'POST') {
        $b          = jsonBody();
        $ownerType  = san($b['owner_type'] ?? 'visitor', 20) ?? 'visitor';
        $ownerId    = san($b['owner_id'] ?? null, 64);
        $deviceType = san($b['device_type'] ?? 'browser', 20) ?? 'browser';
        if (!$ownerId) jsonRespond(['error' => 'owner_id obrigatório'], 400);

        // Impede registrar dispositivo em nome de terceiros:
        // visitor → assertVisitorAccess; client → sessão Bearer; demais → admin.
        if ($ownerType === 'visitor' && function_exists('assertVisitorAccess')) {
            assertVisitorAccess($ownerId);
        } elseif ($ownerType === 'client') {
            if (!function_exists('requireClient')) {
                jsonRespond(['error' => 'Auth de cliente indisponível'], 500);
            }
            $ownerId = (string) requireClient();
        } elseif ($ownerType !== 'visitor' && !isAdmin()) {
            jsonRespond(['error' => lang('unauthorized')], 401);
        }

        $ua = san($_SERVER['HTTP_USER_AGENT'] ?? '', 500);
        registerPushDevice($pdo, $ownerType, $ownerId, $deviceType, $ua, san($b['push_token'] ?? null, 255));
        jsonRespond(['ok' => true]);
    }

    requireAdmin();

    if ($method === 'GET') {
        $rows = $pdo->query("SELECT id, owner_type, owner_id, device_type, user_agent, enabled, last_seen, created_at FROM push_devices ORDER BY last_seen DESC LIMIT 200")->fetchAll();
        jsonRespond(['items' => $rows]);
    }

    if ($method === 'PUT') {
        $b  = jsonBody();
        $id = sanInt($b['id'] ?? 0);
        if ($id <= 0) jsonRespond(['error' => 'ID obrigatório'], 400);
        $enabled = isset($b['enabled']) ? ($b['enabled'] ? 1 : 0) : 1;
        $pdo->prepare("UPDATE push_devices SET enabled = ? WHERE id = ?")->execute([$enabled, $id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleNotificationEvent(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);

    $b     = jsonBody();
    $event = san($b['event'] ?? null, 50);
    $title = san($b['title'] ?? null, 200);
    $body  = san($b['body'] ?? null, 2000);
    if (!$event || !$title) jsonRespond(['error' => 'event e title obrigatórios'], 400);

    $meta = is_array($b['meta'] ?? null) ? $b['meta'] : [];
    dispatchNotificationEvent(db(), $event, $title, $body ?? '', $meta, [
        'action_url' => san($b['action_url'] ?? null, 500),
    ]);
    jsonRespond(['ok' => true]);
}

function handlePushVapidKey(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    $key = webPushPublicKey($pdo);
    $count = 0;
    try {
        ensurePushSubscriptionsTable($pdo);
        $count = (int)$pdo->query('SELECT COUNT(*) FROM push_subscriptions WHERE enabled = 1')->fetchColumn();
    } catch (Throwable $e) { /* */ }
    if (!$key) {
        jsonRespond(['configured' => false, 'publicKey' => null, 'subscriptions' => $count]);
    }
    jsonRespond(['configured' => true, 'publicKey' => $key, 'subscriptions' => $count]);
}

function handlePushSubscribe(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('push_subscribe', 30);
    $pdo = db();
    $b = jsonBody();
    $ownerType = san($b['owner_type'] ?? 'visitor', 20) ?? 'visitor';
    if (!in_array($ownerType, ['visitor', 'client', 'admin'], true)) {
        jsonRespond(['error' => 'owner_type inválido'], 400);
    }
    $ownerId   = san($b['owner_id'] ?? null, 64);
    if ($ownerType === 'admin') {
        // Antes: qualquer POST podia gravar assinatura como admin sem token.
        requireAdmin();
        if (!$ownerId) {
            $ownerId = 'admin';
        }
    } elseif ($ownerType === 'client') {
        if (!function_exists('requireClient')) {
            jsonRespond(['error' => 'Auth de cliente indisponível'], 500);
        }
        $ownerId = (string) requireClient();
    } elseif (!$ownerId) {
        jsonRespond(['error' => 'owner_id obrigatório'], 400);
    }
    if ($ownerType === 'visitor' && function_exists('assertVisitorAccess')) {
        assertVisitorAccess($ownerId);
    }

    $subscription = is_array($b['subscription'] ?? null) ? $b['subscription'] : $b;
    $meta = [
        'browser' => $b['browser'] ?? null,
        'platform' => $b['platform'] ?? null,
        'device' => $b['device'] ?? null,
        'language' => $b['language'] ?? null,
        'timezone' => $b['timezone'] ?? null,
        'client_id' => $b['client_id'] ?? null,
    ];
    if (!webPushSaveSubscription($pdo, $subscription, $ownerType, $ownerId, $meta)) {
        jsonRespond(['error' => 'Assinatura inválida — endpoint e keys obrigatórios'], 400);
    }
    jsonRespond(['ok' => true, 'provider' => 'webpush']);
}

function handlePushUnsubscribe(string $method): void {
    if ($method !== 'POST' && $method !== 'DELETE') jsonRespond(['error' => 'Use POST ou DELETE'], 405);
    $pdo = db();
    $b = jsonBody();
    $endpoint = trim((string)($b['endpoint'] ?? ($b['subscription']['endpoint'] ?? '')));
    if ($endpoint === '') jsonRespond(['error' => 'endpoint obrigatório'], 400);
    webPushRemoveSubscription($pdo, $endpoint);
    jsonRespond(['ok' => true]);
}

function handleWebPushSend(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    $b = jsonBody();
    $title = san($b['title'] ?? null, 200);
    $body  = san($b['body'] ?? null, 2000);
    $url   = san($b['url'] ?? null, 500);
    if (!$title) jsonRespond(['error' => 'title obrigatório'], 400);

    $result = sendWebPushIfConfigured(db(), $title, $body ?? '', $url, [
        'severity' => san($b['severity'] ?? 'info', 20) ?? 'info',
    ]);
    if ($result['total'] === 0 && !webPushIsConfigured(db())) {
        jsonRespond(['error' => 'Web Push VAPID não configurado'], 503);
    }
    jsonRespond(['ok' => $result['sent'] > 0, 'result' => $result]);
}
