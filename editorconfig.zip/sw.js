// Auto Limpeza Pro — Service Worker v14 (booking multi-serviço v1.24.4 + Notification Engine + GPS offline)
// Estratégia:
//   Assets com hash (JS/CSS/fontes) → Cache-First (imutáveis)
//   HTML e manifest                 → Network-First (sempre frescos)
//   API (/api/, api.php)            → Nunca cachear

const CACHE_STATIC  = "cleanpro-static-v14";
const CACHE_DYNAMIC = "cleanpro-dynamic-v14";
const DYNAMIC_MAX_ENTRIES = 80;
const DYNAMIC_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const OLD_CACHES    = [
  "cleanpro-v1", "cleanpro-v2", "cleanpro-v3", "cleanpro-v4", "cleanpro-v5", "cleanpro-v6",
  "cleanpro-v7", "cleanpro-v8", "cleanpro-v9",
  "cleanpro-static-v1", "cleanpro-static-v2", "cleanpro-static-v3", "cleanpro-static-v4", "cleanpro-static-v5", "cleanpro-static-v6",
  "cleanpro-static-v7", "cleanpro-static-v8", "cleanpro-static-v9", "cleanpro-static-v10", "cleanpro-static-v11", "cleanpro-static-v12",
  "cleanpro-dynamic-v1", "cleanpro-dynamic-v2", "cleanpro-dynamic-v3", "cleanpro-dynamic-v4", "cleanpro-dynamic-v5", "cleanpro-dynamic-v6",
  "cleanpro-dynamic-v7", "cleanpro-dynamic-v8", "cleanpro-dynamic-v9", "cleanpro-dynamic-v10", "cleanpro-dynamic-v11", "cleanpro-dynamic-v12",
];

const PRECACHE_ASSETS = [
  "/",
  "/manifest.webmanifest",
  "/icon-192.png",
  "/icon-512.png",
  "/icon-maskable-192.png",
  "/icon-maskable-512.png",
  "/apple-touch-icon.png",
  "/favicon.svg",
];

function withCacheMeta(response) {
  // `response` deve ser um clone dedicado ao cache (não o Response entregue à página).
  // Clonar depois que o body já foi lido gera: Failed to execute 'clone' on 'Response'.
  if (!response || !response.ok) return null;
  const headers = new Headers(response.headers);
  headers.set("x-sw-cached-at", String(Date.now()));
  return response.blob().then((body) =>
    new Response(body, {
      status: response.status,
      statusText: response.statusText,
      headers,
    }),
  );
}

function isCacheFresh(response) {
  if (!response) return false;
  const cachedAt = Number(response.headers.get("x-sw-cached-at") || 0);
  if (!cachedAt) return true; // entradas antigas sem meta: mantém até LRU
  return Date.now() - cachedAt < DYNAMIC_MAX_AGE_MS;
}

function cachePutSafe(cache, request, response) {
  return withCacheMeta(response).then((metaRes) => {
    if (!metaRes) return;
    return cache.put(request, metaRes).then(() => trimDynamicCache(cache));
  }).catch(() => {});
}

async function trimDynamicCache(cache) {
  try {
    const keys = await cache.keys();
    // Remove expirados primeiro
    for (const req of keys) {
      const res = await cache.match(req);
      if (res && !isCacheFresh(res)) {
        await cache.delete(req);
      }
    }
    const remaining = await cache.keys();
    if (remaining.length <= DYNAMIC_MAX_ENTRIES) return;
    const overflow = remaining.length - DYNAMIC_MAX_ENTRIES;
    for (let i = 0; i < overflow; i++) {
      await cache.delete(remaining[i]);
    }
  } catch (_) { /* ignore */ }
}

// ── Install ───────────────────────────────────────────────
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_STATIC)
      .then((cache) =>
        Promise.all(
          PRECACHE_ASSETS.map((asset) =>
            cache.add(asset).catch((err) => {
              console.warn("[SW] precache falhou:", asset, err);
            })
          )
        )
      )
      .then(() => self.skipWaiting())
  );
});

// ── Activate: limpa caches antigos ───────────────────────
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => OLD_CACHES.includes(k) || (k !== CACHE_STATIC && k !== CACHE_DYNAMIC))
            .map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

// ── Fetch ─────────────────────────────────────────────────
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;

  const url = new URL(event.request.url);

  if (
    url.pathname.startsWith("/api/") ||
    url.pathname.includes("api.php") ||
    url.hostname !== self.location.hostname
  ) return;

  if (url.pathname.startsWith("/assets/") || /\.(woff2?|ttf|otf)$/.test(url.pathname)) {
    event.respondWith(
      caches.open(CACHE_STATIC).then((cache) =>
        cache.match(event.request).then((cached) => {
          if (cached) return cached;
          return fetch(event.request).then((res) => {
            const toCache = res.clone();
            event.waitUntil(cachePutSafe(cache, event.request, toCache));
            return res;
          });
        })
      )
    );
    return;
  }

  // Imagens públicas: cache-first (já imutáveis / otimizadas)
  if (/\.(png|jpe?g|webp|gif|svg|ico)$/i.test(url.pathname)) {
    event.respondWith(
      caches.open(CACHE_STATIC).then((cache) =>
        cache.match(event.request).then((cached) => {
          if (cached) return cached;
          return fetch(event.request).then((res) => {
            if (res.ok) {
              const toCache = res.clone();
              event.waitUntil(cachePutSafe(cache, event.request, toCache));
            }
            return res;
          });
        })
      )
    );
    return;
  }

  if (
    event.request.headers.get("accept")?.includes("text/html") ||
    url.pathname.endsWith(".webmanifest") ||
    url.pathname === "/"
  ) {
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const toCache = res.clone();
          event.waitUntil(
            caches.open(CACHE_DYNAMIC).then((cache) => cachePutSafe(cache, event.request, toCache))
          );
          return res;
        })
        .catch(() =>
          caches.match(event.request).then((c) => {
            if (c && isCacheFresh(c)) return c;
            return caches.match("/");
          })
        )
    );
    return;
  }

  event.respondWith(
    caches.open(CACHE_DYNAMIC).then((cache) =>
      cache.match(event.request).then((cached) => {
        const freshCached = cached && isCacheFresh(cached) ? cached : null;
        const networkFetch = fetch(event.request)
          .then((res) => {
            const toCache = res.clone();
            event.waitUntil(cachePutSafe(cache, event.request, toCache));
            return res;
          })
          .catch(() => null);
        if (freshCached) {
          event.waitUntil(networkFetch);
          return freshCached;
        }
        return networkFetch.then((res) => res || cached || Response.error());
      })
    )
  );
});

self.addEventListener("sync", (event) => {
  if (event.tag !== "cleanpro-tracking-sync") return;
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) =>
      Promise.all(list.map((client) => client.postMessage({ type: "cleanpro:tracking-sync" })))
    )
  );
});

function trackNotification(eventType, data) {
  const notificationId = data && data.notificationId ? data.notificationId : null;
  const logId = data && data.logId ? data.logId : null;
  // Sem identificadores o backend não tem o que atualizar
  if (!notificationId && !logId) return Promise.resolve();
  try {
    const body = JSON.stringify({
      event: eventType,
      notification_id: notificationId,
      log_id: logId,
      tag: data && data.tag ? data.tag : null,
    });
    const url = "/api.php?action=notifications/track";
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      credentials: "same-origin",
      keepalive: true,
    }).catch(function () {});
  } catch (e) {
    return Promise.resolve();
  }
}

self.addEventListener("push", (event) => {
  if (!event.data) return;
  let payload = {};
  try {
    payload = event.data.json();
  } catch {
    payload = { title: "Auto Limpeza Pro", body: event.data.text() };
  }

  const title = payload.title || "Auto Limpeza Pro";
  const data = {
    url: payload.url || "/",
    severity: payload.severity || "info",
    notificationId: payload.notification_id || payload.notificationId || null,
    logId: payload.log_id || payload.logId || null,
    tag: payload.tag || "cleanpro-push",
  };
  const options = {
    body: payload.body || "",
    icon: payload.icon || "/icon-192.png",
    badge: payload.badge || "/icon-192.png",
    image: payload.image || undefined,
    tag: data.tag,
    lang: "pt-BR",
    data,
    vibrate: payload.vibrate || (payload.severity === "error" ? [200, 100, 200, 100, 200] : [100, 50, 100]),
    requireInteraction: payload.severity === "error" || payload.requireInteraction === true,
    actions: Array.isArray(payload.actions) ? payload.actions : undefined,
  };

  event.waitUntil(
    Promise.all([
      self.registration.showNotification(title, options),
      trackNotification("delivered", data),
    ])
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const data = event.notification.data || {};
  let target = data.url || "/";
  if (event.action && data.actionUrls && data.actionUrls[event.action]) {
    target = data.actionUrls[event.action];
  }

  event.waitUntil(
    (async () => {
      await trackNotification("clicked", data);

      let opened = false;
      let navigated = false;
      const list = await clients.matchAll({ type: "window", includeUncontrolled: true });
      for (const client of list) {
        if (!("focus" in client)) continue;
        try {
          if ("navigate" in client) {
            await client.navigate(target);
            navigated = true;
          }
          await client.focus();
          opened = true;
        } catch (_) {
          // Janela pode recusar navigate (cross-origin / descartada)
        }
        break;
      }

      // Se só focamos sem navegar (Safari/WebView), abre a URL alvo
      if ((!opened || !navigated) && clients.openWindow) {
        const win = await clients.openWindow(target).catch(() => null);
        if (win) opened = true;
      }

      // "opened" só conta quando o app realmente abriu/focou — antes duplicava "clicked"
      if (opened) await trackNotification("opened", data);
    })()
  );
});
