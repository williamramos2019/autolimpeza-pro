<?php
/**
 * AI Gateway — handlers admin (CRUD provedores, roteamento, prompts, logs, chat teste).
 */

function handleAiGatewayDashboard(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    require_once __DIR__ . '/ai-gateway.php';
    $pdo = db();
    $days = sanInt($_GET['days'] ?? 7) ?: 7;
    jsonRespond(AIGateway::metrics($pdo, min(30, max(1, $days))));
}

function handleAiGatewayProviders(string $method): void {
    requireAdmin();
    require_once __DIR__ . '/ai-gateway.php';
    $pdo = db();
    ensureAiGatewayTables($pdo);

    if ($method === 'GET') {
        try {
            $rows = $pdo->query('SELECT id, name, provider_type, api_key_enc, base_url, model, priority, weight, timeout_sec, rate_limit, enabled, last_used_at, last_error, avg_latency_ms, created_at, updated_at FROM ai_providers ORDER BY priority ASC, id ASC')->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            jsonRespond(['error' => 'Tabela ai_providers ausente. Execute install.php?step=repair', 'code' => 'schema_missing'], 503);
        }
        foreach ($rows as &$r) {
            $type = (string) ($r['provider_type'] ?? '');
            $key = decryptAiSecret((string) ($r['api_key_enc'] ?? ''));
            $corrupt = ($key !== '' && $type !== '' && !aiGatewayIsPlausibleApiKey($type, $key));
            if ($corrupt || $key === '') {
                // Repara a partir de site_config/config.php quando possível.
                if ($type !== '' && function_exists('aiConfigKey')) {
                    $fromCfg = (string) (aiConfigKey($type) ?? '');
                    if ($fromCfg !== '' && aiGatewayIsPlausibleApiKey($type, $fromCfg)) {
                        $enc = encryptAiSecret($fromCfg);
                        $pdo->prepare('UPDATE ai_providers SET api_key_enc = ?, last_error = NULL, updated_at = ? WHERE id = ?')
                            ->execute([$enc, dbNow(), (int) $r['id']]);
                        $key = $fromCfg;
                        $corrupt = false;
                    }
                }
            }
            if ($corrupt) {
                $r['keyPreview'] = null;
                $r['keyCorrupt'] = true;
                $r['last_error'] = $r['last_error'] ?: 'Chave ilegível no banco — cole uma chave nova em Editar ou em Configurações.';
            } else {
                $r['keyPreview'] = aiGatewayKeyPreview($key);
                $r['keyCorrupt'] = false;
            }
            unset($r['api_key_enc']);
        }
        unset($r);
        jsonRespond(['items' => $rows]);
    }

    if ($method === 'POST') {
        rateLimit('ai_gateway_providers', 20);
        $b = jsonBody();
        $name = san($b['name'] ?? '', 120);
        $type = san($b['provider_type'] ?? '', 40);
        if (!$name || !$type) jsonRespond(['error' => 'name e provider_type obrigatórios'], 400);
        $allowed = ['gemini', 'openai', 'deepseek', 'groq', 'openrouter', 'anthropic', 'mistral', 'together', 'cerebras', 'openai_compatible'];
        if (!in_array($type, $allowed, true)) jsonRespond(['error' => 'provider_type inválido'], 400);

        // sanSecret devolve null para vazio — normaliza para '' (comparações abaixo usam string)
        $apiKey = sanSecret($b['api_key'] ?? '') ?? '';
        if ($apiKey !== '' && !aiGatewayIsPlausibleApiKey($type, $apiKey)) {
            jsonRespond(['error' => 'Formato de chave inválido para ' . $type], 400);
        }
        $enc = $apiKey !== '' ? encryptAiSecret($apiKey) : null;
        $now = dbNow();
        $pdo->prepare('INSERT INTO ai_providers (name, provider_type, api_key_enc, base_url, model, priority, weight, timeout_sec, rate_limit, enabled, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([
                $name, $type, $enc,
                san($b['base_url'] ?? aiGatewayDefaultBaseUrl($type), 500),
                san($b['model'] ?? aiGatewayDefaultModel($type), 120),
                sanInt($b['priority'] ?? 100),
                sanInt($b['weight'] ?? 1) ?: 1,
                sanInt($b['timeout_sec'] ?? 90) ?: 90,
                sanInt($b['rate_limit'] ?? 0) ?: null,
                sanBool($b['enabled'] ?? true) ? 1 : 0,
                $now, $now,
            ]);
        if ($apiKey !== '') {
            aiGatewayMirrorKeyToSiteConfig($pdo, $type, $apiKey);
        }
        jsonRespond(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
    }

    if ($method === 'PUT') {
        rateLimit('ai_gateway_providers', 20);
        $b = jsonBody();
        $id = sanInt($b['id'] ?? 0);
        if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
        $stmt = $pdo->prepare('SELECT * FROM ai_providers WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) jsonRespond(['error' => 'Provedor não encontrado'], 404);

        $type = san($b['provider_type'] ?? $row['provider_type'], 40) ?? $row['provider_type'];
        $apiKey = sanSecret($b['api_key'] ?? '') ?? '';
        if ($apiKey !== '' && !aiGatewayIsPlausibleApiKey($type, $apiKey)) {
            jsonRespond(['error' => 'Formato de chave inválido para ' . $type], 400);
        }
        $enc = $apiKey !== '' ? encryptAiSecret($apiKey) : $row['api_key_enc'];

        $pdo->prepare('UPDATE ai_providers SET name=?, provider_type=?, api_key_enc=?, base_url=?, model=?, priority=?, weight=?, timeout_sec=?, rate_limit=?, enabled=?, updated_at=? WHERE id=?')
            ->execute([
                san($b['name'] ?? $row['name'], 120),
                $type,
                $enc,
                san($b['base_url'] ?? $row['base_url'], 500),
                san($b['model'] ?? $row['model'], 120),
                sanInt($b['priority'] ?? $row['priority']),
                sanInt($b['weight'] ?? $row['weight']) ?: 1,
                sanInt($b['timeout_sec'] ?? $row['timeout_sec']) ?: 90,
                isset($b['rate_limit']) ? (sanInt($b['rate_limit']) ?: null) : $row['rate_limit'],
                isset($b['enabled']) ? (sanBool($b['enabled']) ? 1 : 0) : (int)$row['enabled'],
                dbNow(), $id,
            ]);
        if ($apiKey !== '') {
            aiGatewayMirrorKeyToSiteConfig($pdo, $type, $apiKey);
        }
        jsonRespond(['ok' => true]);
    }

    if ($method === 'DELETE') {
        $id = sanInt($_GET['id'] ?? jsonBody()['id'] ?? 0);
        if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
        $pdo->prepare('DELETE FROM ai_providers WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleAiGatewayProviderTest(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('ai_gateway_test', 15);
    require_once __DIR__ . '/ai-gateway.php';
    $b = jsonBody();
    $pdo = db();
    ensureAiGatewayTables($pdo);

    $id = sanInt($b['id'] ?? 0);
    $type = san($b['provider_type'] ?? '', 40) ?: '';
    $encStored = null;
    $row = null;

    if ($id > 0) {
        $stmt = $pdo->prepare('SELECT * FROM ai_providers WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) jsonRespond(['ok' => false, 'error' => 'Provedor não encontrado'], 404);
        $type = (string)($row['provider_type'] ?? $type);
        $encStored = (string)($row['api_key_enc'] ?? '');
        // Testa com o modelo/base_url realmente configurados no provedor.
        if (empty($b['model']) && !empty($row['model'])) $b['model'] = $row['model'];
        if (empty($b['base_url']) && !empty($row['base_url'])) $b['base_url'] = $row['base_url'];
    }

    // Normaliza sempre para string: sanSecret(null/vazio) → '' e só então decrypt/fallback.
    $apiKey = aiGatewayNormalizeApiKey(
        isset($b['api_key']) ? (string)$b['api_key'] : null,
        $encStored,
        $type !== '' ? $type : null
    );

    if ($apiKey === '') {
        jsonRespond([
            'ok'    => false,
            'error' => 'Chave API obrigatória — informe a chave ou configure o provedor no AI Gateway.',
        ], 400);
    }
    if ($type === '') $type = 'gemini';

    // Hospedagem compartilhada mata o script em ~30s → viraria "Erro interno do servidor".
    @set_time_limit(120);

    $started = microtime(true);
    try {
        $result = AIProviderAdapter::complete($type, $apiKey, 'Responda apenas: ok', 'ping', 16, [
            'temperature'  => 0,
            'timeout'      => 15,
            'single_model' => true, // teste rápido: 1 modelo, sem varrer a cadeia de fallback
            'model'        => san($b['model'] ?? aiGatewayDefaultModel($type), 120),
            'base_url'     => san($b['base_url'] ?? aiGatewayDefaultBaseUrl($type), 500),
        ]);
    } catch (Throwable $e) {
        $result = ['ok' => false, 'error' => 'Falha no teste: ' . $e->getMessage(), 'http_code' => 0];
    }
    $ms = (int) round((microtime(true) - $started) * 1000);
    $ok = (bool) ($result['ok'] ?? false);
    $errMsg = $ok ? null : (string) ($result['error'] ?? 'Teste falhou');

    if ($id > 0) {
        try {
            $pdo->prepare('UPDATE ai_providers SET last_error = ?, avg_latency_ms = ?, last_used_at = ?, updated_at = ? WHERE id = ?')
                ->execute([$errMsg, $ms, dbNow(), dbNow(), $id]);
        } catch (Throwable $e) { /* ignore */ }
    }

    jsonRespond([
        'ok'         => $ok,
        'model'      => $result['model'] ?? null,
        'content'    => $result['content'] ?? null,
        'durationMs' => $ms,
        'httpCode'   => $result['http_code'] ?? 0,
        'error'      => $errMsg,
    ]);
}

function handleAiGatewayLogs(string $method): void {
    requireAdmin();
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    require_once __DIR__ . '/ai-gateway.php';
    $pdo = db();
    ensureAiGatewayTables($pdo);

    $page = max(1, sanInt($_GET['page'] ?? 1));
    $limit = min(100, max(10, sanInt($_GET['limit'] ?? 50)));
    $offset = ($page - 1) * $limit;
    $module = san($_GET['module'] ?? '', 40);
    $status = san($_GET['status'] ?? '', 20);

    $where = ['1=1'];
    $params = [];
    if ($module) { $where[] = 'module = ?'; $params[] = $module; }
    if ($status) { $where[] = 'status = ?'; $params[] = $status; }
    $w = implode(' AND ', $where);

    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM ai_gateway_logs WHERE {$w}");
    $countStmt->execute($params);
    $total = (int)$countStmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT id, module, prompt_hash, provider, model, latency_ms, tokens_in, tokens_out, status, error_code, failover_attempts, created_at FROM ai_gateway_logs WHERE {$w} ORDER BY id DESC LIMIT {$limit} OFFSET {$offset}");
    $stmt->execute($params);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($items as &$it) {
        if (is_string($it['failover_attempts'] ?? null)) {
            $it['failover_attempts'] = json_decode($it['failover_attempts'], true);
        }
        unset($it);
    }

    jsonRespond(['items' => $items, 'total' => $total, 'page' => $page, 'limit' => $limit]);
}

function handleAiGatewayRouting(string $method): void {
    requireAdmin();
    require_once __DIR__ . '/ai-gateway.php';
    $pdo = db();
    ensureAiGatewayTables($pdo);

    if ($method === 'GET') {
        $rows = $pdo->query('SELECT * FROM ai_module_routing ORDER BY module_key ASC')->fetchAll(PDO::FETCH_ASSOC);
        jsonRespond(['items' => $rows]);
    }

    if ($method === 'PUT') {
        rateLimit('ai_gateway_routing', 20);
        $b = jsonBody();
        $items = $b['items'] ?? [$b];
        if (!is_array($items)) jsonRespond(['error' => 'items inválido'], 400);

        $upd = $pdo->prepare('INSERT INTO ai_module_routing (module_key, strategy, preferred_provider_id, cache_ttl_sec, updated_at) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE strategy=VALUES(strategy), preferred_provider_id=VALUES(preferred_provider_id), cache_ttl_sec=VALUES(cache_ttl_sec), updated_at=VALUES(updated_at)');
        $now = dbNow();
        $allowed = ['priority', 'round_robin', 'lowest_latency', 'manual'];

        foreach ($items as $item) {
            if (!is_array($item)) continue;
            $key = san($item['module_key'] ?? '', 40);
            if (!$key) continue;
            $strat = san($item['strategy'] ?? 'priority', 20) ?? 'priority';
            if (!in_array($strat, $allowed, true)) $strat = 'priority';
            $pref = sanInt($item['preferred_provider_id'] ?? 0) ?: null;
            $ttl  = sanInt($item['cache_ttl_sec'] ?? 120);
            $upd->execute([$key, $strat, $pref, $ttl, $now]);
        }
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleAiGatewayPrompts(string $method): void {
    requireAdmin();
    require_once __DIR__ . '/ai-gateway.php';
    $pdo = db();
    ensureAiGatewayTables($pdo);

    if ($method === 'GET') {
        $module = san($_GET['module'] ?? '', 40);
        if ($module) {
            $stmt = $pdo->prepare('SELECT id, module, `key`, name, content, version, active, created_at, updated_at FROM ai_prompts WHERE module = ? ORDER BY `key` ASC');
            $stmt->execute([$module]);
        } else {
            $stmt = $pdo->query('SELECT id, module, `key`, name, content, version, active, created_at, updated_at FROM ai_prompts ORDER BY module ASC, `key` ASC');
        }
        jsonRespond(['items' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($method === 'POST') {
        rateLimit('ai_gateway_prompts', 20);
        $b = jsonBody();
        $module = san($b['module'] ?? '', 40);
        $key    = san($b['key'] ?? '', 80);
        $name   = san($b['name'] ?? '', 200);
        $content = trim((string)($b['content'] ?? ''));
        if (!$module || !$key || !$name || $content === '') {
            jsonRespond(['error' => 'module, key, name e content obrigatórios'], 400);
        }
        $now = dbNow();
        $pdo->prepare('INSERT INTO ai_prompts (module, `key`, name, content, version, active, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)')
            ->execute([$module, $key, $name, $content, sanInt($b['version'] ?? 1) ?: 1, sanBool($b['active'] ?? true) ? 1 : 0, $now, $now]);
        jsonRespond(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
    }

    if ($method === 'PUT') {
        rateLimit('ai_gateway_prompts', 20);
        $b = jsonBody();
        $id = sanInt($b['id'] ?? 0);
        if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
        $pdo->prepare('UPDATE ai_prompts SET module=?, `key`=?, name=?, content=?, version=?, active=?, updated_at=? WHERE id=?')
            ->execute([
                san($b['module'] ?? '', 40),
                san($b['key'] ?? '', 80),
                san($b['name'] ?? '', 200),
                trim((string)($b['content'] ?? '')),
                sanInt($b['version'] ?? 1) ?: 1,
                sanBool($b['active'] ?? true) ? 1 : 0,
                dbNow(), $id,
            ]);
        jsonRespond(['ok' => true]);
    }

    if ($method === 'DELETE') {
        $id = sanInt($_GET['id'] ?? jsonBody()['id'] ?? 0);
        if ($id <= 0) jsonRespond(['error' => 'id obrigatório'], 400);
        $pdo->prepare('DELETE FROM ai_prompts WHERE id = ?')->execute([$id]);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleAiGatewayChat(string $method): void {
    requireAdmin();
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    rateLimit('ai_gateway_chat', 10);
    require_once __DIR__ . '/ai-gateway.php';
    $b = jsonBody();
    $system = trim((string)($b['system'] ?? 'Você é um assistente útil.'));
    $user   = trim((string)($b['user'] ?? $b['message'] ?? ''));
    if ($user === '') jsonRespond(['error' => 'user/message obrigatório'], 400);

    $result = AIGateway::chat([
        'system'      => $system,
        'user'        => $user,
        'maxTokens'   => sanInt($b['maxTokens'] ?? 1024) ?: 1024,
        'module'      => san($b['module'] ?? 'default', 40) ?? 'default',
        'temperature' => (float)($b['temperature'] ?? 0.65),
        'json'        => sanBool($b['json'] ?? false),
        'skipCache'   => true,
        'provider_id' => sanInt($b['provider_id'] ?? 0) ?: null,
    ]);
    jsonRespond($result);
}
