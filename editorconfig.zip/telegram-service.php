<?php
/**
 * Telegram Bot — canal de saída (MVP).
 * Reutiliza NotificationCenter / logs / fila; não substitui WhatsApp.
 */

function ensureTelegramTables(PDO $pdo): void {
    static $done = false;
    if ($done) return;

    $pdo->exec("CREATE TABLE IF NOT EXISTS `crm_telegram_config` (
        `id` TINYINT UNSIGNED NOT NULL DEFAULT 1,
        `bot_token_enc` TEXT DEFAULT NULL,
        `bot_username` VARCHAR(120) DEFAULT NULL,
        `webhook_secret` VARCHAR(64) DEFAULT NULL,
        `webhook_url` VARCHAR(500) DEFAULT NULL,
        `enabled` TINYINT(1) NOT NULL DEFAULT 0,
        `auto_send` TINYINT(1) NOT NULL DEFAULT 1,
        `connection_status` VARCHAR(30) NOT NULL DEFAULT 'disconnected',
        `last_error` VARCHAR(500) DEFAULT NULL,
        `last_sync_at` DATETIME DEFAULT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $contactCols = [
        "ALTER TABLE `crm_contacts` ADD COLUMN `telegram_chat_id` VARCHAR(64) DEFAULT NULL",
        "ALTER TABLE `crm_contacts` ADD COLUMN `telegram_username` VARCHAR(120) DEFAULT NULL",
        "ALTER TABLE `crm_contacts` ADD COLUMN `telegram_notify` TINYINT(1) NOT NULL DEFAULT 1",
        "ALTER TABLE `crm_contacts` ADD COLUMN `notify_pref` VARCHAR(20) NOT NULL DEFAULT 'both'",
    ];
    foreach ($contactCols as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { /* já existe */ }
    }
    try {
        $pdo->exec("CREATE INDEX `idx_telegram_chat` ON `crm_contacts` (`telegram_chat_id`)");
    } catch (Throwable $e) { /* já existe */ }

    $row = $pdo->query("SELECT id FROM crm_telegram_config WHERE id = 1")->fetch();
    if (!$row) {
        $secret = bin2hex(random_bytes(16));
        $pdo->prepare("INSERT INTO crm_telegram_config (id, webhook_secret, enabled, auto_send, connection_status, updated_at)
            VALUES (1, ?, 0, 1, 'disconnected', ?)")
            ->execute([$secret, dbNow()]);
    }

    $done = true;
}

function telegramEncryptToken(string $plain): string {
    if (!function_exists('encryptMailSecret')) {
        require_once __DIR__ . '/mail-handlers.php';
    }
    return encryptMailSecret($plain);
}

function telegramDecryptToken(string $stored): string {
    if ($stored === '') return '';
    if (!function_exists('decryptMailSecret')) {
        require_once __DIR__ . '/mail-handlers.php';
    }
    $dec = decryptMailSecret($stored);
    if ($dec !== '') return $dec;
    // Legado: tokens gravados só em base64 (antes da criptografia)
    $raw = base64_decode($stored, true);
    if (is_string($raw) && preg_match('/^\d{6,}:[A-Za-z0-9_-]{20,}$/', $raw)) {
        return $raw;
    }
    return '';
}

/** @return array<string,mixed> */
function telegramGetConfig(PDO $pdo): array {
    ensureTelegramTables($pdo);
    $row = $pdo->query("SELECT * FROM crm_telegram_config WHERE id = 1")->fetch(PDO::FETCH_ASSOC) ?: [];
    return $row;
}

function telegramGetBotToken(PDO $pdo): string {
    $cfg = telegramGetConfig($pdo);
    return telegramDecryptToken((string)($cfg['bot_token_enc'] ?? ''));
}

function telegramIsConfigured(PDO $pdo): bool {
    return telegramGetBotToken($pdo) !== '';
}

function telegramIsEnabled(PDO $pdo): bool {
    $cfg = telegramGetConfig($pdo);
    return !empty($cfg['enabled']) && telegramIsConfigured($pdo);
}

function telegramAutoSend(PDO $pdo): bool {
    $cfg = telegramGetConfig($pdo);
    return !empty($cfg['auto_send']);
}

function telegramWebhookPublicUrl(PDO $pdo): string {
    $base = defined('SITE_URL') ? rtrim((string)SITE_URL, '/') : '';
    if ($base === '') return '';
    // Secret NÃO vai na query (vaza em access logs) — usa header X-Telegram-Bot-Api-Secret-Token
    return $base . '/api.php?action=telegram/webhook';
}

/**
 * @return array{ok:bool,http:int,error:?string,body:array}
 */
function telegramApiRequest(string $token, string $method, ?array $payload = null): array {
    $token = trim($token);
    if ($token === '') {
        return ['ok' => false, 'http' => 0, 'error' => 'Bot token ausente', 'body' => []];
    }
    $url = 'https://api.telegram.org/bot' . $token . '/' . ltrim($method, '/');
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
    ];
    if ($payload !== null) {
        $opts[CURLOPT_POST] = true;
        $opts[CURLOPT_HTTPHEADER] = ['Content-Type: application/json'];
        $opts[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_UNICODE);
    }
    curl_setopt_array($ch, $opts);
    $raw = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    $decoded = [];
    if (is_string($raw) && $raw !== '') {
        $tmp = json_decode($raw, true);
        if (is_array($tmp)) $decoded = $tmp;
    }

    if ($err) {
        if (function_exists('appLogRateLimited')) {
            appLogRateLimited('warn', 'telegram_curl', ['method' => $method, 'err' => $err], 300);
        }
        return ['ok' => false, 'http' => $http, 'error' => $err, 'body' => $decoded];
    }

    $ok = !empty($decoded['ok']);
    if (!$ok && $http >= 400) {
        $apiErr = is_string($decoded['description'] ?? null) ? $decoded['description'] : "HTTP {$http}";
        if (function_exists('appLogRateLimited')) {
            appLogRateLimited('warn', 'telegram_http', ['method' => $method, 'http' => $http, 'err' => $apiErr], 300);
        }
        return ['ok' => false, 'http' => $http, 'error' => $apiErr, 'body' => $decoded];
    }

    return ['ok' => $ok, 'http' => $http, 'error' => $ok ? null : (string)($decoded['description'] ?? 'Falha Telegram'), 'body' => $decoded];
}

/**
 * @return array{ok:bool,sent:bool,http:int,error:?string,message_id:?int}
 */
function telegramSendMessage(PDO $pdo, string $chatId, string $text): array {
    $chatId = trim($chatId);
    $text = trim($text);
    if ($chatId === '' || $text === '') {
        return ['ok' => false, 'sent' => false, 'http' => 0, 'error' => 'chat_id ou texto ausente', 'message_id' => null];
    }
    if (!telegramIsEnabled($pdo) && !telegramIsConfigured($pdo)) {
        return ['ok' => false, 'sent' => false, 'http' => 0, 'error' => 'Telegram não configurado', 'message_id' => null];
    }
    // Envio manual/teste pode usar token mesmo com enabled=0; auto_send é checado no NotificationCenter.
    $token = telegramGetBotToken($pdo);
    $res = telegramApiRequest($token, 'sendMessage', [
        'chat_id' => $chatId,
        'text'    => mb_substr($text, 0, 4096),
        'disable_web_page_preview' => true,
    ]);
    $msgId = null;
    if (!empty($res['body']['result']['message_id'])) {
        $msgId = (int)$res['body']['result']['message_id'];
    }
    return [
        'ok'         => !empty($res['ok']),
        'sent'       => !empty($res['ok']),
        'http'       => (int)($res['http'] ?? 0),
        'error'      => $res['error'] ?? null,
        'message_id' => $msgId,
    ];
}

/**
 * Enriquece $opts com chat_id / preferências a partir do contato (1 SELECT).
 * @param array<string,mixed> $opts
 * @param array<string,mixed> $meta
 * @return array<string,mixed>
 */
function telegramEnrichOpts(PDO $pdo, array $opts, array $meta = []): array {
    if (!empty($opts['telegram_enriched'])) return $opts;
    $opts['telegram_enriched'] = true;

    try {
        ensureTelegramTables($pdo);
    } catch (Throwable $e) {
        return $opts;
    }

    $contactId = (int)($opts['contact_id'] ?? $meta['contact_id'] ?? 0);
    $phone = (string)($opts['phone'] ?? $meta['phone'] ?? '');
    $norm = $phone !== '' && function_exists('crmNormalizePhone') ? crmNormalizePhone($phone) : preg_replace('/\D+/', '', $phone);

    $row = null;
    try {
        if ($contactId > 0) {
            $st = $pdo->prepare("SELECT id, telegram_chat_id, telegram_username, telegram_notify, notify_pref FROM crm_contacts WHERE id = ? LIMIT 1");
            $st->execute([$contactId]);
            $row = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        if (!$row && $norm !== '') {
            $st = $pdo->prepare("SELECT id, telegram_chat_id, telegram_username, telegram_notify, notify_pref FROM crm_contacts WHERE phone_normalized = ? LIMIT 1");
            $st->execute([$norm]);
            $row = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        if (!$row && !empty($meta['client_id'])) {
            $st = $pdo->prepare("SELECT id, telegram_chat_id, telegram_username, telegram_notify, notify_pref FROM crm_contacts WHERE client_id = ? LIMIT 1");
            $st->execute([(int)$meta['client_id']]);
            $row = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        }
    } catch (Throwable $e) {
        return $opts;
    }

    if (!$row) {
        if (!isset($opts['notify_pref'])) $opts['notify_pref'] = 'both';
        return $opts;
    }

    if (empty($opts['telegram_chat_id']) && !empty($row['telegram_chat_id'])) {
        $opts['telegram_chat_id'] = (string)$row['telegram_chat_id'];
    }
    if (!isset($opts['telegram_notify'])) {
        $opts['telegram_notify'] = (int)($row['telegram_notify'] ?? 1) === 1;
    }
    $pref = (string)($row['notify_pref'] ?? 'both');
    if (!in_array($pref, ['whatsapp', 'telegram', 'both'], true)) $pref = 'both';
    $opts['notify_pref'] = $opts['notify_pref'] ?? $pref;
    $opts['contact_id'] = $opts['contact_id'] ?? (int)$row['id'];
    return $opts;
}

function telegramLinkContact(PDO $pdo, int $contactId, string $chatId, ?string $username = null): bool {
    ensureTelegramTables($pdo);
    if ($contactId <= 0 || $chatId === '') return false;
    $pdo->prepare("UPDATE crm_contacts SET telegram_chat_id = ?, telegram_username = COALESCE(?, telegram_username), telegram_notify = 1, updated_at = ? WHERE id = ?")
        ->execute([$chatId, $username, dbNow(), $contactId]);
    return true;
}

function telegramSiteBaseUrl(): string {
    return defined('SITE_URL') ? rtrim((string)SITE_URL, '/') : 'https://autolimpezapro.com.br';
}

function telegramHelpText(): string {
    $base = telegramSiteBaseUrl();
    return "Menu Auto Limpeza Pro\n\n"
        . "/start — vincular notificações\n"
        . "/menu — este menu\n"
        . "/agendamento — agendar no site\n"
        . "/reagendar — área do cliente\n"
        . "/cancelar — área do cliente\n"
        . "/promocoes — ver ofertas\n"
        . "/ajuda — ajuda\n"
        . "/falar — falar conosco\n\n"
        . "Links:\n"
        . "Agendar: {$base}/\n"
        . "Minha conta: {$base}/conta\n"
        . "Agendamentos: {$base}/conta/agendamentos\n"
        . "WhatsApp continua disponível no site.";
}

/**
 * @param array<string,mixed> $update
 */
function telegramHandleUpdate(PDO $pdo, array $update): void {
    ensureTelegramTables($pdo);
    $msg = $update['message'] ?? $update['edited_message'] ?? null;
    if (!is_array($msg)) return;

    $chatId = (string)($msg['chat']['id'] ?? '');
    $text = trim((string)($msg['text'] ?? ''));
    $username = isset($msg['from']['username']) ? (string)$msg['from']['username'] : null;
    if ($chatId === '' || $text === '') return;

    $cmd = strtolower(explode(' ', explode('@', $text)[0], 2)[0]);
    $arg = trim(substr($text, strlen(explode(' ', $text, 2)[0])));

    $reply = null;

    if ($cmd === '/start') {
        $linked = false;
        if (preg_match('/^c(\d+)$/i', $arg, $m)) {
            $linked = telegramLinkContact($pdo, (int)$m[1], $chatId, $username);
        }
        // Sempre registra username no contato já vinculado por chat_id
        try {
            $st = $pdo->prepare("UPDATE crm_contacts SET telegram_username = COALESCE(?, telegram_username), updated_at = ? WHERE telegram_chat_id = ?");
            $st->execute([$username, dbNow(), $chatId]);
        } catch (Throwable $e) { /* */ }

        if ($linked) {
            $reply = "Pronto! Seu Telegram foi vinculado às notificações da Auto Limpeza Pro.\n\n" . telegramHelpText();
        } elseif ($arg !== '') {
            $reply = "Não encontramos o contato para vincular. Peça ao atendente o link correto.\n\n" . telegramHelpText();
        } else {
            $reply = "Olá! Bem-vindo à Auto Limpeza Pro.\n\n"
                . "Para receber avisos de agendamento aqui, peça ao atendente o link de vínculo "
                . "ou informe seu Chat ID: {$chatId}\n\n"
                . telegramHelpText();
        }
    } elseif (in_array($cmd, ['/menu', '/ajuda', '/help'], true)) {
        $reply = telegramHelpText();
    } elseif ($cmd === '/agendamento') {
        $reply = "Agende pelo site:\n" . telegramSiteBaseUrl() . "/";
    } elseif (in_array($cmd, ['/reagendar', '/cancelar'], true)) {
        $reply = "Gerencie pelo portal:\n" . telegramSiteBaseUrl() . "/conta/agendamentos";
    } elseif ($cmd === '/promocoes') {
        $reply = "Confira novidades e dicas:\n" . telegramSiteBaseUrl() . "/dicas";
    } elseif ($cmd === '/falar') {
        $reply = "Fale conosco pelo site ou WhatsApp:\n" . telegramSiteBaseUrl() . "/";
    } else {
        $reply = "Comando não reconhecido.\n\n" . telegramHelpText();
    }

    if ($reply !== null) {
        telegramSendMessage($pdo, $chatId, $reply);
    }
}

function telegramTestConnection(PDO $pdo): array {
    $token = telegramGetBotToken($pdo);
    if ($token === '') {
        return ['ok' => false, 'error' => 'Configure o Bot Token primeiro'];
    }
    $res = telegramApiRequest($token, 'getMe');
    if (empty($res['ok'])) {
        $pdo->prepare("UPDATE crm_telegram_config SET connection_status = 'disconnected', last_error = ?, last_sync_at = ?, updated_at = ? WHERE id = 1")
            ->execute([mb_substr((string)($res['error'] ?? 'getMe falhou'), 0, 500), dbNow(), dbNow()]);
        return ['ok' => false, 'error' => $res['error'] ?? 'getMe falhou'];
    }
    $username = (string)($res['body']['result']['username'] ?? '');
    $pdo->prepare("UPDATE crm_telegram_config SET bot_username = ?, connection_status = 'open', last_error = NULL, last_sync_at = ?, updated_at = ? WHERE id = 1")
        ->execute([$username !== '' ? $username : null, dbNow(), dbNow()]);
    return [
        'ok' => true,
        'username' => $username,
        'id' => $res['body']['result']['id'] ?? null,
        'firstName' => $res['body']['result']['first_name'] ?? null,
    ];
}

function telegramSetWebhook(PDO $pdo): array {
    $token = telegramGetBotToken($pdo);
    if ($token === '') {
        return ['ok' => false, 'error' => 'Bot Token ausente'];
    }
    $url = telegramWebhookPublicUrl($pdo);
    if ($url === '') {
        return ['ok' => false, 'error' => 'SITE_URL não definido'];
    }
    $cfg = telegramGetConfig($pdo);
    $secret = (string)($cfg['webhook_secret'] ?? '');
    if ($secret === '') {
        $secret = bin2hex(random_bytes(16));
        $pdo->prepare("UPDATE crm_telegram_config SET webhook_secret = ?, updated_at = ? WHERE id = 1")
            ->execute([$secret, dbNow()]);
    }
    // secret_token: Telegram envia em X-Telegram-Bot-Api-Secret-Token (1–256 chars [A-Za-z0-9_-])
    $payload = [
        'url' => $url,
        'allowed_updates' => ['message'],
        'secret_token' => $secret,
    ];
    $res = telegramApiRequest($token, 'setWebhook', $payload);
    if (!empty($res['ok'])) {
        $pdo->prepare("UPDATE crm_telegram_config SET webhook_url = ?, last_sync_at = ?, last_error = NULL, updated_at = ? WHERE id = 1")
            ->execute([$url, dbNow(), dbNow()]);
    } else {
        $pdo->prepare("UPDATE crm_telegram_config SET last_error = ?, updated_at = ? WHERE id = 1")
            ->execute([mb_substr((string)($res['error'] ?? 'setWebhook falhou'), 0, 500), dbNow()]);
    }
    return ['ok' => !empty($res['ok']), 'url' => $url, 'error' => $res['error'] ?? null];
}

/** @return array<string,mixed> */
function telegramMapStatus(PDO $pdo): array {
    $cfg = telegramGetConfig($pdo);
    $secret = (string)($cfg['webhook_secret'] ?? '');
    $webhook = telegramWebhookPublicUrl($pdo);
    $username = (string)($cfg['bot_username'] ?? '');
    $deepLink = $username !== '' ? 'https://t.me/' . ltrim($username, '@') : null;

    $linked = 0;
    $sentToday = 0;
    $failedToday = 0;
    try {
        $linked = (int)$pdo->query("SELECT COUNT(*) FROM crm_contacts WHERE telegram_chat_id IS NOT NULL AND telegram_chat_id != ''")->fetchColumn();
    } catch (Throwable $e) { /* */ }
    try {
        $today = date('Y-m-d');
        $st = $pdo->prepare("SELECT COUNT(*) FROM notification_logs WHERE canal = 'telegram' AND status = 'entregue' AND DATE(created_at) = ?");
        $st->execute([$today]);
        $sentToday = (int)$st->fetchColumn();
        $st = $pdo->prepare("SELECT COUNT(*) FROM notification_logs WHERE canal = 'telegram' AND status = 'falhou' AND DATE(created_at) = ?");
        $st->execute([$today]);
        $failedToday = (int)$st->fetchColumn();
    } catch (Throwable $e) { /* */ }

    return [
        'configured'       => telegramIsConfigured($pdo),
        'enabled'          => !empty($cfg['enabled']),
        'autoSend'         => !empty($cfg['auto_send']),
        'connectionStatus' => $cfg['connection_status'] ?? 'disconnected',
        'botUsername'      => $username !== '' ? $username : null,
        'hasToken'         => telegramIsConfigured($pdo),
        'webhookUrl'       => $webhook,
        'webhookSecretSet' => $secret !== '',
        'deepLink'         => $deepLink,
        'lastSyncAt'       => $cfg['last_sync_at'] ?? null,
        'lastError'        => $cfg['last_error'] ?? null,
        'linkedUsers'      => $linked,
        'messagesToday'    => $sentToday,
        'failuresToday'    => $failedToday,
        'blogChatId'       => (function () use ($pdo) {
            if (!function_exists('blogMultichannelGetConfig')) {
                $f = __DIR__ . '/blog-multichannel.php';
                if (is_file($f)) require_once $f;
            }
            if (!function_exists('blogMultichannelGetConfig')) return null;
            $mc = blogMultichannelGetConfig($pdo);
            $tg = is_array($mc['telegram'] ?? null) ? $mc['telegram'] : [];
            $id = trim((string)($tg['chat_id'] ?? $mc['blogChatId'] ?? ''));
            return $id !== '' ? $id : null;
        })(),
    ];
}

function handleCrmTelegram(string $method): void {
    requireAdmin();
    $pdo = db();
    ensureTelegramTables($pdo);

    if ($method === 'GET') {
        jsonRespond(telegramMapStatus($pdo));
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $action = san($b['action'] ?? 'save_config', 40) ?? 'save_config';

        if ($action === 'save_config') {
            $enabled = array_key_exists('enabled', $b) ? (!empty($b['enabled']) ? 1 : 0) : null;
            $autoSend = array_key_exists('autoSend', $b) ? (!empty($b['autoSend']) ? 1 : 0) : null;
            $tokenRaw = array_key_exists('botToken', $b) ? trim((string)$b['botToken']) : '';
            $sets = ['updated_at = ?'];
            $vals = [dbNow()];

            if ($tokenRaw !== '') {
                $sets[] = 'bot_token_enc = ?';
                $vals[] = telegramEncryptToken($tokenRaw);
            }
            if ($enabled !== null) {
                $sets[] = 'enabled = ?';
                $vals[] = $enabled;
            }
            if ($autoSend !== null) {
                $sets[] = 'auto_send = ?';
                $vals[] = $autoSend;
            }
            // Garante secret
            $cfg = telegramGetConfig($pdo);
            if (empty($cfg['webhook_secret'])) {
                $sets[] = 'webhook_secret = ?';
                $vals[] = bin2hex(random_bytes(16));
            }

            $pdo->prepare('UPDATE crm_telegram_config SET ' . implode(', ', $sets) . ' WHERE id = 1')->execute($vals);

            if (array_key_exists('blogChatId', $b)) {
                if (!function_exists('blogMultichannelGetConfig')) {
                    require_once __DIR__ . '/blog-multichannel.php';
                }
                $mc = blogMultichannelGetConfig($pdo);
                $chat = trim((string)($b['blogChatId'] ?? ''));
                $mc['blogChatId'] = $chat;
                $mc['telegram'] = array_merge(is_array($mc['telegram'] ?? null) ? $mc['telegram'] : [], [
                    'enabled' => true,
                    'chat_id' => $chat,
                ]);
                blogMultichannelSaveConfig($pdo, $mc);
            }

            if ($tokenRaw !== '') {
                telegramTestConnection($pdo);
            }
            jsonRespond(['status' => 'ok'] + telegramMapStatus($pdo));
        }

        if ($action === 'test') {
            $r = telegramTestConnection($pdo);
            jsonRespond($r + telegramMapStatus($pdo));
        }

        if ($action === 'set_webhook') {
            $r = telegramSetWebhook($pdo);
            jsonRespond($r + telegramMapStatus($pdo));
        }

        if ($action === 'send_test') {
            $chatId = san($b['chatId'] ?? '', 64) ?? '';
            $text = san($b['text'] ?? 'Teste Auto Limpeza Pro — Telegram OK', 500) ?? 'Teste Auto Limpeza Pro — Telegram OK';
            if ($chatId === '') jsonRespond(['error' => 'chatId obrigatório'], 400);
            $r = telegramSendMessage($pdo, $chatId, $text);
            jsonRespond($r);
        }

        if ($action === 'link_contact') {
            $contactId = sanInt($b['contactId'] ?? 0);
            $chatId = san($b['chatId'] ?? '', 64) ?? '';
            $username = san($b['username'] ?? null, 120);
            if (!$contactId || $chatId === '') jsonRespond(['error' => 'contactId e chatId obrigatórios'], 400);
            telegramLinkContact($pdo, $contactId, $chatId, $username);
            $cfg = telegramGetConfig($pdo);
            $uname = (string)($cfg['bot_username'] ?? '');
            $deep = $uname !== '' ? 'https://t.me/' . ltrim($uname, '@') . '?start=c' . $contactId : null;
            jsonRespond(['status' => 'ok', 'deepLink' => $deep]);
        }

        jsonRespond(['error' => 'Ação inválida'], 400);
    }

    jsonRespond(['error' => 'Método não suportado'], 405);
}

function handleTelegramWebhook(string $method): void {
    if ($method !== 'POST') jsonRespond(['error' => 'Use POST'], 405);
    $pdo = db();
    ensureTelegramTables($pdo);
    $cfg = telegramGetConfig($pdo);
    $secret = (string)($cfg['webhook_secret'] ?? '');
    if ($secret === '') {
        jsonRespond(['error' => 'Webhook não configurado'], 503);
    }
    $header = (string)($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '');
    // Query ?secret= rejeitado (vaza em access logs / Referer)
    if ($header === '' || !hash_equals($secret, $header)) {
        if (!empty($_GET['secret'])) {
            if (function_exists('appLog')) {
                appLog('warning', 'telegram_webhook_query_rejected', []);
            }
        }
        jsonRespond(['error' => 'forbidden'], 403);
    }

    $raw = file_get_contents('php://input') ?: '';
    $update = json_decode($raw, true);
    if (!is_array($update)) {
        jsonRespond(['ok' => true]);
    }

    try {
        telegramHandleUpdate($pdo, $update);
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('error', 'telegram_webhook', ['err' => $e->getMessage()]);
        }
    }
    jsonRespond(['ok' => true]);
}
