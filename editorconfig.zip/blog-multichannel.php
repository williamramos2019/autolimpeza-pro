<?php
/**
 * Blog Multichannel Publish — distribuição pós-publicação.
 * Reutiliza NotificationCenter + Telegram; demais canais = stub logado.
 */

function blogMultichannelGetConfig(PDO $pdo): array {
    try {
        $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'blog_multichannel_config' LIMIT 1");
        $stmt->execute();
        $raw = $stmt->fetchColumn();
        $decoded = $raw ? json_decode((string)$raw, true) : [];
        return is_array($decoded) ? $decoded : [];
    } catch (Throwable $e) {
        return [];
    }
}

function blogMultichannelSaveConfig(PDO $pdo, array $cfg): void {
    $json = json_encode($cfg, JSON_UNESCAPED_UNICODE);
    $now = dbNow();
    $pdo->prepare("INSERT INTO site_config (key_name, value, updated_at) VALUES ('blog_multichannel_config', ?, ?)
        ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)")
        ->execute([$json, $now]);
}

function blogMultichannelPostUrl(array $post): string {
    $slug = (string)($post['slug'] ?? '');
    $base = defined('SITE_URL') ? rtrim((string)SITE_URL, '/') : '';
    return $base !== '' ? "{$base}/dicas/{$slug}" : "/dicas/{$slug}";
}

function blogMultichannelBuildCaption(array $post, string $url): string {
    $title = trim((string)($post['title'] ?? 'Novo artigo'));
    $excerpt = trim((string)($post['excerpt'] ?? ''));
    if ($excerpt !== '') {
        $excerpt = mb_substr($excerpt, 0, 280);
    }
    $lines = ["📝 {$title}"];
    if ($excerpt !== '') $lines[] = $excerpt;
    $lines[] = $url;
    return implode("\n\n", $lines);
}

/** Tenta caption curta via AI Gateway; fallback estático. */
function blogMultichannelCaptionWithAi(array $post, string $url): string {
    $fallback = blogMultichannelBuildCaption($post, $url);
    if (!function_exists('aiGatewayGenerateText')) return $fallback;
    try {
        $title = (string)($post['title'] ?? '');
        $excerpt = mb_substr((string)($post['excerpt'] ?? ''), 0, 400);
        $r = aiGatewayGenerateText(
            'Você escreve legendas curtas para Telegram (máx 500 caracteres). Sem hashtags excessivas. Inclua o link no final.',
            "Título: {$title}\nResumo: {$excerpt}\nLink: {$url}\n\nEscreva só a legenda.",
            200,
            'blog_multichannel'
        );
        if (!empty($r['ok']) && !empty($r['text'])) {
            $text = trim((string)$r['text']);
            if ($text !== '' && !str_contains($text, $url)) {
                $text .= "\n\n" . $url;
            }
            return mb_substr($text, 0, 900);
        }
    } catch (Throwable $e) {
        if (function_exists('appLog')) {
            appLog('info', 'blog_multichannel_ai_skip', ['err' => $e->getMessage()]);
        }
    }
    return $fallback;
}

/**
 * @param array<string,bool|int|string> $channels
 * @return array{ok:bool,channels:array<string,array{ok:bool,detail:string}>}
 */
function dispatchBlogMultichannel(PDO $pdo, array $post, array $channels): array {
    $slug = (string)($post['slug'] ?? '');
    $report = ['ok' => true, 'channels' => []];
    if ($slug === '') {
        return ['ok' => false, 'channels' => ['_' => ['ok' => false, 'detail' => 'slug ausente']]];
    }

    $cfg = blogMultichannelGetConfig($pdo);
    $url = blogMultichannelPostUrl($post);
    $enabled = [];
    foreach ($channels as $k => $v) {
        if ($v === true || $v === 1 || $v === '1') {
            $enabled[] = (string)$k;
        }
    }
    if (!$enabled) {
        return ['ok' => true, 'channels' => []];
    }

    $caption = null;

    foreach ($enabled as $ch) {
        if ($ch === 'blog') {
            $report['channels']['blog'] = ['ok' => true, 'detail' => 'já no site'];
            continue;
        }

        if ($ch === 'telegram') {
            $tgCfg = is_array($cfg['telegram'] ?? null) ? $cfg['telegram'] : [];
            $chatId = trim((string)($tgCfg['chat_id'] ?? $cfg['blogChatId'] ?? ''));
            $tgOn = !array_key_exists('enabled', $tgCfg) || !empty($tgCfg['enabled']);
            if (!$tgOn || $chatId === '') {
                $detail = $chatId === ''
                    ? 'Configure o Chat ID do canal/grupo em CRM → Telegram (campo Blog Chat ID)'
                    : 'Telegram do blog está desabilitado na config multicanal';
                if (function_exists('appLog')) {
                    appLog('info', 'blog_multichannel_telegram_skip', [
                        'slug' => $slug,
                        'reason' => $chatId === '' ? 'blogChatId ausente' : 'telegram desabilitado no config',
                    ]);
                }
                if (class_exists('NotificationCenter')) {
                    NotificationCenter::logAttempt(
                        $pdo, bin2hex(random_bytes(8)), null, 'blog_multichannel', 'telegram',
                        NotificationCenter::STATUS_FAILED, null, $detail
                    );
                }
                $report['ok'] = false;
                $report['channels']['telegram'] = ['ok' => false, 'detail' => $detail];
                continue;
            }
            if (function_exists('telegramIsConfigured') && !telegramIsConfigured($pdo)) {
                $detail = 'Bot Telegram sem token — salve o token em CRM → Telegram e ative o canal';
                if (function_exists('appLog')) {
                    appLog('info', 'blog_multichannel_telegram_skip', ['slug' => $slug, 'reason' => 'bot não configurado']);
                }
                $report['ok'] = false;
                $report['channels']['telegram'] = ['ok' => false, 'detail' => $detail];
                continue;
            }

            if ($caption === null) {
                $caption = blogMultichannelCaptionWithAi($post, $url);
            }

            if (!class_exists('NotificationCenter')) {
                require_once __DIR__ . '/notification-center.php';
            }

            try {
                // Síncrono: o admin vê o resultado na hora (não depende do cron da fila)
                $sendResult = NotificationCenter::send([
                    'type'  => 'blog_multichannel',
                    'title' => (string)($post['title'] ?? 'Novo artigo'),
                    'body'  => $caption,
                    'meta'  => [
                        'slug' => $slug,
                        'url'  => $url,
                        'channel' => 'telegram',
                    ],
                    'opts'  => [
                        'skip_internal'     => true,
                        'async'             => false,
                        'channels_only'     => ['telegram'],
                        'enable_telegram'   => true,
                        'force_telegram'    => true,
                        'telegram_chat_id'  => $chatId,
                        'notify_pref'       => 'telegram',
                        'telegram_notify'   => true,
                        'priority'          => 'high',
                    ],
                    'async' => false,
                ]);
                $tgOk = !empty($sendResult['results']['telegram'])
                    && $sendResult['results']['telegram'] === 'ok';
                // processChannels pode marcar delivered de outras formas
                if (!$tgOk && !empty($sendResult['results']['telegram'])) {
                    $tgOk = in_array($sendResult['results']['telegram'], ['ok', 'delivered', true], true);
                }
                if (!$tgOk && isset($sendResult['results']['external']) && $sendResult['results']['external'] === 'not_configured') {
                    $detail = 'Telegram não pronto (token/enabled). Verifique CRM → Telegram.';
                    $report['ok'] = false;
                    $report['channels']['telegram'] = ['ok' => false, 'detail' => $detail];
                } elseif (!$tgOk) {
                    // Fallback: envio direto pela API Telegram
                    $direct = function_exists('telegramSendMessage')
                        ? telegramSendMessage($pdo, $chatId, $caption)
                        : ['sent' => false, 'error' => 'telegramSendMessage ausente'];
                    if (!empty($direct['sent'])) {
                        $report['channels']['telegram'] = ['ok' => true, 'detail' => 'enviado (direto)'];
                    } else {
                        $detail = (string)($direct['error'] ?? 'Falha ao enviar ao Telegram');
                        $report['ok'] = false;
                        $report['channels']['telegram'] = ['ok' => false, 'detail' => $detail];
                    }
                } else {
                    $report['channels']['telegram'] = ['ok' => true, 'detail' => 'enviado'];
                }
            } catch (Throwable $e) {
                if (function_exists('appLog')) {
                    appLog('warn', 'blog_multichannel_telegram_enqueue', ['err' => $e->getMessage(), 'slug' => $slug]);
                }
                $report['ok'] = false;
                $report['channels']['telegram'] = ['ok' => false, 'detail' => $e->getMessage()];
            }
            continue;
        }

        // Stubs: facebook, linkedin, gbp, instagram, youtube, pinterest, …
        if (function_exists('appLog')) {
            appLog('info', 'blog_multichannel_stub', [
                'channel' => $ch,
                'slug'    => $slug,
                'detail'  => 'Canal ainda não implementado nesta versão',
            ]);
        }
        if (class_exists('NotificationCenter')) {
            try {
                NotificationCenter::logAttempt(
                    $pdo, bin2hex(random_bytes(8)), null, 'blog_multichannel', $ch,
                    NotificationCenter::STATUS_FAILED, null, 'Canal em breve — não configurado'
                );
            } catch (Throwable $e) { /* */ }
        }
        $report['channels'][$ch] = ['ok' => false, 'detail' => 'Canal em breve — não implementado'];
    }

    return $report;
}
