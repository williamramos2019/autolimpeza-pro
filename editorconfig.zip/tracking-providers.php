<?php
/**
 * Providers desacoplados de localização / rota / tempo real.
 * Preferência: APIs gratuitas (OSM / Nominatim / OpenRouteService / Haversine).
 * Nunca expor chaves ao frontend.
 */

interface TrackingRealtimeProvider {
    /** @return array{provider:string,mode:string,pollSeconds:int} */
    public function transportInfo(): array;
}

interface TrackingRouteProvider {
    /**
     * @return array{distanceMeters:float,durationSeconds:float,geometry?:array}|null
     */
    public function route(float $fromLat, float $fromLng, float $toLat, float $toLng): ?array;
}

interface TrackingGeocodingProvider {
    /** @return array{lat:float,lng:float,displayName?:string}|null */
    public function geocode(string $address): ?array;
}

class MysqlPollingRealtimeProvider implements TrackingRealtimeProvider {
    public function transportInfo(): array {
        return [
            'provider' => 'mysql_polling',
            'mode' => 'adaptive_poll',
            'pollSeconds' => 5,
        ];
    }
}

/** Fallback gratuito: linha reta + velocidade média urbana. */
class HaversineRouteProvider implements TrackingRouteProvider {
    private float $avgSpeedKmh;

    public function __construct(float $avgSpeedKmh = 28.0) {
        $this->avgSpeedKmh = max(8.0, $avgSpeedKmh);
    }

    public function route(float $fromLat, float $fromLng, float $toLat, float $toLng): ?array {
        if (!function_exists('haversineMeters')) return null;
        $dist = haversineMeters($fromLat, $fromLng, $toLat, $toLng);
        // Fator de vias urbanas aproximado
        $road = $dist * 1.25;
        $hours = ($road / 1000.0) / $this->avgSpeedKmh;
        return [
            'distanceMeters' => round($road, 1),
            'durationSeconds' => (int)round($hours * 3600),
            'geometry' => [
                ['lat' => $fromLat, 'lng' => $fromLng],
                ['lat' => $toLat, 'lng' => $toLng],
            ],
            'provider' => 'haversine',
        ];
    }
}

/** OpenRouteService (quando ORS_API_KEY / site_config existir). */
class OpenRouteServiceProvider implements TrackingRouteProvider {
    private string $apiKey;
    private TrackingRouteProvider $fallback;

    public function __construct(string $apiKey, ?TrackingRouteProvider $fallback = null) {
        $this->apiKey = $apiKey;
        $this->fallback = $fallback ?? new HaversineRouteProvider();
    }

    public function route(float $fromLat, float $fromLng, float $toLat, float $toLng): ?array {
        if ($this->apiKey === '') {
            return $this->fallback->route($fromLat, $fromLng, $toLat, $toLng);
        }
        $url = 'https://api.openrouteservice.org/v2/directions/driving-car';
        $payload = json_encode([
            'coordinates' => [[$fromLng, $fromLat], [$toLng, $toLat]],
        ]);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: ' . $this->apiKey,
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 8,
        ]);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($raw === false || $code >= 400) {
            return $this->fallback->route($fromLat, $fromLng, $toLat, $toLng);
        }
        $data = json_decode($raw, true);
        $summary = $data['routes'][0]['summary'] ?? null;
        if (!is_array($summary)) {
            return $this->fallback->route($fromLat, $fromLng, $toLat, $toLng);
        }
        return [
            'distanceMeters' => (float)($summary['distance'] ?? 0),
            'durationSeconds' => (float)($summary['duration'] ?? 0),
            'provider' => 'openrouteservice',
        ];
    }
}

class NominatimGeocodingProvider implements TrackingGeocodingProvider {
    public function geocode(string $address): ?array {
        $address = trim($address);
        if ($address === '') return null;

        $cacheKey = 'nominatim_' . md5(mb_strtolower($address));
        if (function_exists('siteConfigGet')) {
            try {
                $cached = siteConfigGet(db(), $cacheKey);
                if (is_string($cached) && $cached !== '') {
                    $decoded = json_decode($cached, true);
                    if (is_array($decoded) && isset($decoded['lat'], $decoded['lng'])) {
                        return $decoded;
                    }
                }
            } catch (Throwable $e) { /* ignore */ }
        }

        $url = 'https://nominatim.openstreetmap.org/search?' . http_build_query([
            'q' => $address,
            'format' => 'json',
            'limit' => 1,
            'countrycodes' => 'br',
        ]);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_HTTPHEADER => [
                'User-Agent: AutoLimpezaPro/1.0 (contato@autolimpezapro.com.br)',
                'Accept-Language: pt-BR',
            ],
        ]);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($raw === false || $code >= 400) return null;
        $data = json_decode($raw, true);
        if (!is_array($data) || empty($data[0]['lat'])) return null;
        $result = [
            'lat' => (float)$data[0]['lat'],
            'lng' => (float)$data[0]['lon'],
            'displayName' => (string)($data[0]['display_name'] ?? $address),
        ];
        if (function_exists('siteConfigSet')) {
            try { siteConfigSet(db(), $cacheKey, json_encode($result, JSON_UNESCAPED_UNICODE)); } catch (Throwable $e) { /* ignore */ }
        }
        return $result;
    }
}

function trackingRealtimeProvider(): TrackingRealtimeProvider {
    return new MysqlPollingRealtimeProvider();
}

function trackingRouteProvider(): TrackingRouteProvider {
    $key = '';
    if (defined('ORS_API_KEY') && ORS_API_KEY) {
        $key = (string)ORS_API_KEY;
    } elseif (function_exists('siteConfigGet')) {
        try { $key = (string)(siteConfigGet(db(), 'ors_api_key') ?: ''); } catch (Throwable $e) { $key = ''; }
    }
    $fallback = new HaversineRouteProvider();
    return $key !== '' ? new OpenRouteServiceProvider($key, $fallback) : $fallback;
}

function trackingGeocodingProvider(): TrackingGeocodingProvider {
    return new NominatimGeocodingProvider();
}

function trackingMapTileConfig(): array {
    return [
        'provider' => 'openstreetmap',
        'urlTemplate' => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        'attribution' => '&copy; OpenStreetMap contributors',
        'maxZoom' => 19,
    ];
}

/**
 * Calcula ETA/distância e atualiza a sessão ativa.
 * @return array{distanceMeters:float,durationSeconds:float,etaMinutes:int,provider?:string}|null
 */
function trackingComputeEta(PDO $pdo, array $session, ?float $destLat, ?float $destLng): ?array {
    if ($session['last_lat'] === null || $session['last_lng'] === null) return null;
    if ($destLat === null || $destLng === null) return null;
    $route = trackingRouteProvider()->route(
        (float)$session['last_lat'],
        (float)$session['last_lng'],
        $destLat,
        $destLng
    );
    if (!$route) return null;
    $etaMinutes = (int)max(1, ceil(((float)$route['durationSeconds']) / 60));
    $now = dbNow();
    $pdo->prepare("
        UPDATE appointment_tracking_sessions
        SET eta_minutes = ?, route_distance_m = ?, updated_at = ?
        WHERE id = ?
    ")->execute([$etaMinutes, (float)$route['distanceMeters'], $now, (int)$session['id']]);
    $route['etaMinutes'] = $etaMinutes;
    return $route;
}
