<?php

namespace Database\Seeders;

use App\Models\MaterialCategory;
use Illuminate\Database\Seeder;

class MaterialCategorySeeder extends Seeder
{
    /**
     * Categorias iniciais de obra. Idempotente: `firstOrCreate` por `name`.
     */
    public function run(): void
    {
        $categories = [
            'Elétrica',
            'Hidráulica',
            'Estrutura',
            'Ferramentas',
            'EPI',
            'Consumíveis',
        ];

        foreach ($categories as $name) {
            MaterialCategory::firstOrCreate(['name' => $name], ['is_active' => true]);
        }
    }
}
