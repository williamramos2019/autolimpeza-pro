<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Seeder;

class RolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create roles
        $roles = [
            ['name' => 'administrador', 'label' => 'Administrador'],
            ['name' => 'conferente', 'label' => 'Conferente'],
            ['name' => 'recebedor', 'label' => 'Recebedor'],
            ['name' => 'gestor', 'label' => 'Gestor'],
            ['name' => 'auditor', 'label' => 'Auditor'],
        ];

        foreach ($roles as $roleData) {
            Role::firstOrCreate(['name' => $roleData['name']], $roleData);
        }

        // Create permissions
        $permissions = [
            ['name' => 'obras.view', 'label' => 'Visualizar Obras'],
            ['name' => 'obras.manage', 'label' => 'Gerenciar Obras'],
            ['name' => 'obras.users.manage', 'label' => 'Gerenciar Usuários da Obra'],
            ['name' => 'locais.manage', 'label' => 'Gerenciar Locais'],
            ['name' => 'materials.view', 'label' => 'Visualizar Materiais'],
            ['name' => 'materials.manage', 'label' => 'Gerenciar Materiais'],
            ['name' => 'movements.create', 'label' => 'Criar Movimentações'],
            ['name' => 'movements.send', 'label' => 'Enviar Movimentações'],
            ['name' => 'movements.view', 'label' => 'Visualizar Movimentações'],
            ['name' => 'movements.correct', 'label' => 'Corrigir Movimentações'],
            ['name' => 'movements.cancel', 'label' => 'Cancelar Movimentações'],
            ['name' => 'receipts.conference', 'label' => 'Conferir Recebimentos'],
            ['name' => 'divergences.view', 'label' => 'Visualizar Divergências'],
            ['name' => 'divergences.manage', 'label' => 'Gerenciar Divergências'],
            ['name' => 'pendencies.view', 'label' => 'Visualizar Pendências'],
            ['name' => 'pendencies.resolve', 'label' => 'Resolver Pendências'],
            ['name' => 'dashboards.conferente', 'label' => 'Dashboard Conferente'],
            ['name' => 'dashboards.recebedor', 'label' => 'Dashboard Recebedor'],
            ['name' => 'dashboards.gestor', 'label' => 'Dashboard Gestor'],
            ['name' => 'dashboards.auditor', 'label' => 'Dashboard Auditor'],
            ['name' => 'audit.view', 'label' => 'Visualizar Auditoria'],
        ];

        foreach ($permissions as $permData) {
            Permission::firstOrCreate(['name' => $permData['name']], $permData);
        }

        // Permission matrix from docs/PERMISSOES.md
        $matrix = [
            'administrador' => [
                'obras.view', 'obras.manage', 'obras.users.manage', 'locais.manage',
                'materials.view', 'materials.manage',
                'movements.create', 'movements.send', 'movements.view', 'movements.correct', 'movements.cancel',
                'receipts.conference',
                'divergences.view', 'divergences.manage',
                'pendencies.view', 'pendencies.resolve',
                'dashboards.conferente', 'dashboards.recebedor', 'dashboards.gestor', 'dashboards.auditor',
                'audit.view',
            ],
            'conferente' => [
                'obras.view',
                'materials.view', 'materials.manage',
                'movements.create', 'movements.send', 'movements.view',
                'divergences.view',
                'pendencies.view', 'pendencies.resolve',
                'dashboards.conferente',
            ],
            'recebedor' => [
                'obras.view',
                'materials.view',
                'movements.view',
                'receipts.conference',
                'divergences.view',
                'pendencies.view', 'pendencies.resolve',
                'dashboards.recebedor',
            ],
            'gestor' => [
                'obras.view', 'obras.manage', 'obras.users.manage', 'locais.manage',
                'materials.view', 'materials.manage',
                'movements.view', 'movements.correct', 'movements.cancel',
                'divergences.view', 'divergences.manage',
                'pendencies.view', 'pendencies.resolve',
                'dashboards.gestor',
            ],
            'auditor' => [
                'obras.view',
                'materials.view',
                'movements.view',
                'divergences.view',
                'pendencies.view',
                'dashboards.auditor',
                'audit.view',
            ],
        ];

        // Attach permissions to roles
        foreach ($matrix as $roleName => $permissionNames) {
            $role = Role::where('name', $roleName)->first();
            $permissions = Permission::whereIn('name', $permissionNames)->get();
            $role->permissions()->sync($permissions);
        }
    }
}
