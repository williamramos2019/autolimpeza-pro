<?php

namespace Database\Seeders;

use App\Models\MaterialUnit;
use Illuminate\Database\Seeder;

class MaterialUnitSeeder extends Seeder
{
    /**
     * Unidades de medida do catálogo. Idempotente: `firstOrCreate` por `code`.
     */
    public function run(): void
    {
        $units = [
            ['code' => 'UN', 'label' => 'Unidade'],
            ['code' => 'KG', 'label' => 'Quilograma'],
            ['code' => 'L', 'label' => 'Litro'],
            ['code' => 'M', 'label' => 'Metro'],
            ['code' => 'CX', 'label' => 'Caixa'],
            ['code' => 'PC', 'label' => 'Peça'],
            ['code' => 'KIT', 'label' => 'Kit'],
            ['code' => 'OUTRO', 'label' => 'Outro'],
        ];

        foreach ($units as $unit) {
            MaterialUnit::firstOrCreate(['code' => $unit['code']], $unit);
        }
    }
}
