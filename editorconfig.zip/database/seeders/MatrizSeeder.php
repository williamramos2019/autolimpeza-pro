<?php

namespace Database\Seeders;

use App\Enums\ObraStatus;
use App\Models\Local;
use App\Models\Obra;
use App\Services\MatrizLocator;
use Illuminate\Database\Seeder;

class MatrizSeeder extends Seeder
{
    /**
     * Cria a obra e o local do Depósito Drilling Matriz, origem PADRÃO (não fixa)
     * das movimentações. Código e nome vêm de `config/matriz.php`.
     *
     * Idempotente: `firstOrCreate` por `code` da obra e por (obra_id, name) do local.
     */
    public function run(): void
    {
        $locator = app(MatrizLocator::class);

        $obra = Obra::firstOrCreate(
            ['code' => $locator->obraCode()],
            [
                'name' => 'Drilling Matriz',
                'client_name' => 'Drilling',
                'address' => 'Sede administrativa',
                'city' => 'Matriz',
                'responsible_user_id' => null,
                'status' => ObraStatus::EM_ANDAMENTO,
                'start_date' => '2026-01-01',
                'expected_end_date' => null,
            ]
        );

        Local::firstOrCreate(
            ['obra_id' => $obra->getKey(), 'name' => $locator->localName()],
            ['is_active' => true]
        );
    }
}
