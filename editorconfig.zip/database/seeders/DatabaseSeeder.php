<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RolePermissionSeeder::class,
            MaterialUnitSeeder::class,
            MaterialCategorySeeder::class,
            MatrizSeeder::class,
        ]);

        // Conta de desenvolvimento. Nunca criar em produção/homologação HostGator.
        if (! app()->environment('production')
            && ! User::query()->where('email', 'test@example.com')->exists()) {
            User::factory()->create([
                'name' => 'Test User',
                'email' => 'test@example.com',
            ]);
        }
    }
}
