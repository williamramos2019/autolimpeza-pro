<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Fase 2: categorias passam a ter ativação/inativação e exclusão arquivada.
     * O schema original só tinha (id, name unique, timestamps).
     */
    public function up(): void
    {
        Schema::table('material_categories', function (Blueprint $table) {
            $table->boolean('is_active')->default(true)->after('name');
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::table('material_categories', function (Blueprint $table) {
            $table->dropSoftDeletes();
            $table->dropColumn('is_active');
        });
    }
};
