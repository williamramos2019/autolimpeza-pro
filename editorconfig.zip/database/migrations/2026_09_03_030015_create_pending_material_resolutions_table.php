<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pending_material_resolutions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pending_material_id')->constrained('pending_materials')->cascadeOnDelete();
            $table->decimal('qty_delivered', 12, 3);
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->timestamp('delivered_at');
            $table->text('notes')->nullable();
            $table->string('photo_path')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pending_material_resolutions');
    }
};
