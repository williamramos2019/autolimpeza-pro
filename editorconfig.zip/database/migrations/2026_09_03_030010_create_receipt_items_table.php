<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('receipt_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('receipt_id')->constrained('receipts')->cascadeOnDelete();
            $table->foreignId('movement_item_id')->unique()->constrained('movement_items')->cascadeOnDelete();
            $table->decimal('qty_received', 12, 3)->nullable();
            $table->decimal('qty_difference', 12, 3)->nullable();
            $table->string('status'); // ReceiptItemStatus enum values
            $table->timestamp('conferenced_at')->nullable();
            $table->foreignId('conferenced_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('receipt_items');
    }
};
