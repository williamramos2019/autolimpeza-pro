<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('movements', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->string('code')->unique();
            $table->foreignId('origin_obra_id')->constrained('obras')->cascadeOnDelete();
            $table->foreignId('origin_local_id')->constrained('locais')->cascadeOnDelete();
            $table->foreignId('destination_obra_id')->constrained('obras')->cascadeOnDelete();
            $table->foreignId('destination_local_id')->constrained('locais')->cascadeOnDelete();
            $table->foreignId('sender_user_id')->constrained('users')->cascadeOnDelete();
            $table->string('transporter_name')->nullable();
            $table->foreignId('transporter_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('movement_date');
            $table->time('movement_time');
            $table->text('notes')->nullable();
            $table->string('status'); // MovementStatus enum values
            $table->timestamp('sent_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->uuid('idempotency_key')->unique()->nullable();
            $table->string('qr_token')->unique();
            $table->timestamps();
            $table->softDeletes();
            
            // Indexes per BANCO.md
            $table->index('status');
            $table->index('destination_obra_id');
            $table->index('movement_date');
            $table->index('sender_user_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('movements');
    }
};
