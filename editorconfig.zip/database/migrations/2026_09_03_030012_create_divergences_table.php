<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('divergences', function (Blueprint $table) {
            $table->id();
            $table->foreignId('movement_id')->constrained('movements')->cascadeOnDelete();
            $table->foreignId('movement_item_id')->constrained('movement_items')->cascadeOnDelete();
            $table->foreignId('material_id')->constrained('materials')->cascadeOnDelete();
            $table->decimal('qty_sent', 12, 3);
            $table->decimal('qty_received', 12, 3);
            $table->decimal('qty_missing', 12, 3);
            $table->text('reason')->nullable();
            $table->text('notes')->nullable();
            $table->foreignId('responsible_user_id')->constrained('users')->cascadeOnDelete();
            $table->string('status'); // DivergenceStatus enum values
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('divergences');
    }
};
