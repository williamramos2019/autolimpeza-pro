<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pending_materials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('obra_id')->constrained('obras')->cascadeOnDelete();
            $table->foreignId('movement_id')->constrained('movements')->cascadeOnDelete();
            $table->foreignId('divergence_id')->unique()->constrained('divergences')->cascadeOnDelete();
            $table->foreignId('material_id')->constrained('materials')->cascadeOnDelete();
            $table->decimal('qty_sent', 12, 3);
            $table->decimal('qty_received', 12, 3);
            $table->decimal('qty_pending', 12, 3);
            $table->foreignId('responsible_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('due_date')->nullable();
            $table->string('status'); // PendingMaterialStatus enum values
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
            // NO softDeletes per BANCO.md
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pending_materials');
    }
};
