<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('divergences', function (Blueprint $table) {
            $table->unique('movement_item_id');
        });
    }

    public function down(): void
    {
        Schema::table('divergences', function (Blueprint $table) {
            $table->dropForeign(['movement_item_id']);
            $table->dropUnique(['movement_item_id']);
            $table->foreign('movement_item_id')
                ->references('id')
                ->on('movement_items')
                ->cascadeOnDelete();
        });
    }
};
