<?php

namespace Database\Factories;

use App\Enums\MovementStatus;
use App\Models\Local;
use App\Models\Obra;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class MovementFactory extends Factory
{
    public function definition(): array
    {
        $originObra = Obra::factory()->create();
        $destinationObra = Obra::factory()->create();

        return [
            'uuid' => Str::uuid(),
            'code' => 'MOV-' . now()->year . '-' . str_pad((string) $this->faker->unique()->numberBetween(1, 999999), 6, '0', STR_PAD_LEFT),
            'origin_obra_id' => $originObra->id,
            'origin_local_id' => Local::factory()->create(['obra_id' => $originObra->id])->id,
            'destination_obra_id' => $destinationObra->id,
            'destination_local_id' => Local::factory()->create(['obra_id' => $destinationObra->id])->id,
            'sender_user_id' => User::factory(),
            'transporter_name' => $this->faker->name(),
            'transporter_user_id' => null,
            'movement_date' => $this->faker->date(),
            'movement_time' => $this->faker->time(),
            'notes' => $this->faker->optional()->sentence(),
            'status' => MovementStatus::RASCUNHO,
            'sent_at' => null,
            'completed_at' => null,
            'idempotency_key' => null,
            'qr_token' => Str::random(32),
        ];
    }

    public function sent(): static
    {
        return $this->state(fn () => [
            'status' => MovementStatus::ENVIADO,
            'sent_at' => now(),
            'idempotency_key' => (string) Str::uuid(),
        ]);
    }

    public function emConferencia(): static
    {
        return $this->sent()->state(fn () => [
            'status' => MovementStatus::EM_CONFERENCIA,
        ]);
    }

    public function conferido(): static
    {
        return $this->sent()->state(fn () => [
            'status' => MovementStatus::CONFERIDO,
        ]);
    }

    public function divergente(): static
    {
        return $this->sent()->state(fn () => [
            'status' => MovementStatus::DIVERGENTE,
        ]);
    }

    public function concluido(): static
    {
        return $this->sent()->state(fn () => [
            'status' => MovementStatus::CONCLUIDO,
            'completed_at' => now(),
        ]);
    }

    public function cancelado(): static
    {
        return $this->state(fn () => [
            'status' => MovementStatus::CANCELADO,
        ]);
    }
}
