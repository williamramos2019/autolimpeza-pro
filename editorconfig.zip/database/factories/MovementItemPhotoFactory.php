<?php

namespace Database\Factories;

use App\Models\MovementItem;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class MovementItemPhotoFactory extends Factory
{
    public function definition(): array
    {
        return [
            'movement_item_id' => MovementItem::factory(),
            'user_id' => User::factory(),
            'path' => $this->faker->filePath(),
            'taken_at' => $this->faker->dateTime(),
        ];
    }
}
