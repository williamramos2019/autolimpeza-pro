<?php

namespace Database\Factories;

use App\Enums\ObraStatus;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ObraFactory extends Factory
{
    public function definition(): array
    {
        return [
            'code' => 'OBR-' . $this->faker->unique()->numberBetween(1000, 9999),
            'name' => $this->faker->words(3, true),
            'client_name' => $this->faker->company(),
            'address' => $this->faker->streetAddress(),
            'city' => $this->faker->city(),
            'responsible_user_id' => User::factory(),
            'status' => ObraStatus::EM_ANDAMENTO,
            'start_date' => $this->faker->date(),
            'expected_end_date' => $this->faker->optional()->date(),
        ];
    }

    public function planejada(): static
    {
        return $this->state(fn () => ['status' => ObraStatus::PLANEJADA]);
    }

    public function concluida(): static
    {
        return $this->state(fn () => ['status' => ObraStatus::CONCLUIDA]);
    }
}
