<?php

namespace Database\Factories;

use App\Enums\DivergenceStatus;
use App\Models\MovementItem;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class DivergenceFactory extends Factory
{
    public function definition(): array
    {
        $item = MovementItem::factory()->create();
        $qtySent = (float) $item->qty_sent;
        $qtyReceived = max(0, $qtySent - 1);

        return [
            'movement_id' => $item->movement_id,
            'movement_item_id' => $item->id,
            'material_id' => $item->material_id,
            'qty_sent' => $qtySent,
            'qty_received' => $qtyReceived,
            'qty_missing' => $qtySent - $qtyReceived,
            'reason' => $this->faker->optional()->sentence(),
            'notes' => $this->faker->optional()->sentence(),
            'responsible_user_id' => User::factory(),
            'status' => DivergenceStatus::ABERTA,
        ];
    }

    public function emAnalise(): static
    {
        return $this->state(fn () => ['status' => DivergenceStatus::EM_ANALISE]);
    }

    public function emResolucao(): static
    {
        return $this->state(fn () => ['status' => DivergenceStatus::EM_RESOLUCAO]);
    }

    public function resolvida(): static
    {
        return $this->state(fn () => ['status' => DivergenceStatus::RESOLVIDA]);
    }

    public function cancelada(): static
    {
        return $this->state(fn () => ['status' => DivergenceStatus::CANCELADA]);
    }
}
