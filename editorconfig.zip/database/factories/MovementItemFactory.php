<?php

namespace Database\Factories;

use App\Models\Material;
use App\Models\MaterialUnit;
use App\Models\Movement;
use Illuminate\Database\Eloquent\Factories\Factory;

class MovementItemFactory extends Factory
{
    public function definition(): array
    {
        $material = Material::factory()->create();

        return [
            'movement_id' => Movement::factory(),
            'material_id' => $material->id,
            'description_snapshot' => $material->description,
            'qty_sent' => $this->faker->randomFloat(3, 1, 100),
            'material_unit_id' => $material->material_unit_id,
            'notes' => $this->faker->optional()->sentence(),
            'sort_order' => $this->faker->numberBetween(0, 99),
        ];
    }
}
