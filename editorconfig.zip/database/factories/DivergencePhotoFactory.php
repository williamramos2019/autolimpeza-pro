<?php

namespace Database\Factories;

use App\Models\Divergence;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class DivergencePhotoFactory extends Factory
{
    public function definition(): array
    {
        return [
            'divergence_id' => Divergence::factory(),
            'user_id' => User::factory(),
            'path' => $this->faker->filePath(),
            'taken_at' => $this->faker->dateTime(),
        ];
    }
}
