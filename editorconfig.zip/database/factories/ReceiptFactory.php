<?php

namespace Database\Factories;

use App\Models\Movement;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReceiptFactory extends Factory
{
    public function definition(): array
    {
        return [
            'movement_id' => Movement::factory(),
            'receiver_user_id' => User::factory(),
            'started_at' => $this->faker->dateTime(),
            'finished_at' => $this->faker->optional()->dateTime(),
        ];
    }
}
