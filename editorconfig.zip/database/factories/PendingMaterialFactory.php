<?php

namespace Database\Factories;

use App\Enums\PendingMaterialStatus;
use App\Models\Divergence;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class PendingMaterialFactory extends Factory
{
    public function definition(): array
    {
        $divergence = Divergence::factory()->create();

        return [
            'obra_id' => $divergence->movement->destination_obra_id,
            'movement_id' => $divergence->movement_id,
            'divergence_id' => $divergence->id,
            'material_id' => $divergence->material_id,
            'qty_sent' => $divergence->qty_sent,
            'qty_received' => $divergence->qty_received,
            'qty_pending' => $divergence->qty_missing,
            'responsible_user_id' => User::factory(),
            'due_date' => null,
            'status' => PendingMaterialStatus::PENDENTE,
            'resolved_at' => null,
        ];
    }

    public function emTratamento(): static
    {
        return $this->state(fn () => ['status' => PendingMaterialStatus::EM_TRATAMENTO]);
    }

    /**
     * Pendência quitada: saldo zero e data de resolução preenchida.
     */
    public function resolvida(): static
    {
        return $this->state(fn () => [
            'qty_pending' => 0,
            'status' => PendingMaterialStatus::RESOLVIDA,
            'resolved_at' => now(),
        ]);
    }
}
