<?php

namespace Database\Factories;

use App\Models\Obra;
use Illuminate\Database\Eloquent\Factories\Factory;

class LocalFactory extends Factory
{
    public function definition(): array
    {
        return [
            'obra_id' => Obra::factory(),
            // unique(obra_id, name) no schema: sufixo garante nomes distintos na mesma obra
            'name' => 'Local ' . $this->faker->unique()->numberBetween(1, 999999),
            'is_active' => true,
        ];
    }

    public function inactive(): static
    {
        return $this->state(fn () => ['is_active' => false]);
    }
}
