<?php

namespace Database\Factories;

use App\Enums\ReceiptItemStatus;
use App\Models\MovementItem;
use App\Models\Receipt;
use App\Models\ReceiptItem;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReceiptItemFactory extends Factory
{
    public function definition(): array
    {
        $item = MovementItem::factory()->create();

        return [
            'receipt_id' => $this->receiptForMovement($item->movement_id)->id,
            'movement_item_id' => $item->id,
            'qty_received' => null,
            'qty_difference' => null,
            'status' => ReceiptItemStatus::PENDENTE,
            'conferenced_at' => null,
            'conferenced_by' => null,
        ];
    }

    /**
     * Amarra o item de conferência ao item enviado e ao recebimento da mesma movimentação.
     */
    public function forMovementItem(MovementItem $item): static
    {
        return $this->state(fn () => [
            'movement_item_id' => $item->id,
            'receipt_id' => $this->receiptForMovement($item->movement_id)->id,
        ]);
    }

    /**
     * Conferido sem diferença: recebido == enviado.
     */
    public function conferido(): static
    {
        return $this->state(fn () => [
            'status' => ReceiptItemStatus::CONFERIDO,
            'conferenced_at' => now(),
            'conferenced_by' => User::factory(),
        ])->afterMaking(function (ReceiptItem $receiptItem) {
            $qtySent = (float) MovementItem::findOrFail($receiptItem->movement_item_id)->qty_sent;

            $receiptItem->qty_received = $qtySent;
            $receiptItem->qty_difference = 0;
        });
    }

    /**
     * Divergência por falta: recebido = enviado - $missing.
     */
    public function divergencia(float $missing = 1): static
    {
        return $this->state(fn () => [
            'status' => ReceiptItemStatus::DIVERGENCIA,
            'conferenced_at' => now(),
            'conferenced_by' => User::factory(),
        ])->afterMaking(function (ReceiptItem $receiptItem) use ($missing) {
            $qtySent = (float) MovementItem::findOrFail($receiptItem->movement_item_id)->qty_sent;
            $qtyReceived = max(0, $qtySent - $missing);

            $receiptItem->qty_received = $qtyReceived;
            $receiptItem->qty_difference = $qtySent - $qtyReceived;
        });
    }

    private function receiptForMovement(int $movementId): Receipt
    {
        // receipts.movement_id é unique: reaproveita o recebimento já aberto da movimentação
        return Receipt::firstWhere('movement_id', $movementId)
            ?? Receipt::factory()->create(['movement_id' => $movementId]);
    }
}
