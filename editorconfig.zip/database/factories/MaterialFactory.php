<?php

namespace Database\Factories;

use App\Models\MaterialCategory;
use App\Models\MaterialUnit;
use Illuminate\Database\Eloquent\Factories\Factory;

class MaterialFactory extends Factory
{
    public function definition(): array
    {
        return [
            'code' => 'MAT-' . $this->faker->unique()->numberBetween(1000, 9999),
            'description' => $this->faker->words(4, true),
            'material_category_id' => MaterialCategory::factory(),
            'material_unit_id' => MaterialUnit::factory(),
            'brand' => $this->faker->optional()->company(),
            'model' => $this->faker->optional()->word(),
            'internal_code' => $this->faker->optional()->bothify('IC-####'),
            'min_stock' => $this->faker->randomFloat(3, 0, 100),
            'is_active' => true,
            'primary_photo_path' => null,
        ];
    }

    public function inactive(): static
    {
        return $this->state(fn () => ['is_active' => false]);
    }
}
