<?php

namespace Database\Factories;

use App\Enums\MovementStatus;
use App\Models\Movement;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class MovementStatusHistoryFactory extends Factory
{
    public function definition(): array
    {
        return [
            'movement_id' => Movement::factory(),
            'from_status' => MovementStatus::RASCUNHO,
            'to_status' => MovementStatus::ENVIADO,
            'user_id' => User::factory(),
            'created_at' => now(),
        ];
    }

    public function transition(MovementStatus $from, MovementStatus $to): static
    {
        return $this->state(fn () => [
            'from_status' => $from,
            'to_status' => $to,
        ]);
    }
}
