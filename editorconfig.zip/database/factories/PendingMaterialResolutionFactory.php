<?php

namespace Database\Factories;

use App\Models\PendingMaterial;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class PendingMaterialResolutionFactory extends Factory
{
    public function definition(): array
    {
        return [
            'pending_material_id' => PendingMaterial::factory(),
            'qty_delivered' => $this->faker->randomFloat(3, 1, 50),
            'user_id' => User::factory(),
            'delivered_at' => $this->faker->dateTime(),
            'notes' => $this->faker->optional()->sentence(),
            'photo_path' => $this->faker->optional()->filePath(),
        ];
    }
}
