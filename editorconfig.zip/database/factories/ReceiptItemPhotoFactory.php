<?php

namespace Database\Factories;

use App\Models\ReceiptItem;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReceiptItemPhotoFactory extends Factory
{
    public function definition(): array
    {
        return [
            'receipt_item_id' => ReceiptItem::factory(),
            'user_id' => User::factory(),
            'path' => $this->faker->filePath(),
            'taken_at' => $this->faker->dateTime(),
            'latitude' => $this->faker->optional()->latitude(),
            'longitude' => $this->faker->optional()->longitude(),
        ];
    }
}
