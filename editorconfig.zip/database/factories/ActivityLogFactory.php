<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ActivityLogFactory extends Factory
{
    public function definition(): array
    {
        return [
            'user_id' => $this->faker->optional()->randomElement([null, User::factory()]),
            'action' => $this->faker->word(),
            'subject_type' => $this->faker->word(),
            'subject_id' => $this->faker->numberBetween(1, 1000),
            'ip' => $this->faker->ipv4(),
            'old_values' => $this->faker->optional()->randomElement([null, ['key' => 'old_value']]),
            'new_values' => $this->faker->optional()->randomElement([null, ['key' => 'new_value']]),
        ];
    }
}
