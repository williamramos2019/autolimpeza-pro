<?php
/**
 * Content Studio IA
 * Pipeline assíncrono: texto + SEO + imagem + mídia + publicação.
 */

function ensureAiContentJobsTable(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `ai_content_jobs` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
        `topic` VARCHAR(255) DEFAULT NULL,
        `payload_json` JSON DEFAULT NULL,
        `result_json` JSON DEFAULT NULL,
        `error_message` TEXT DEFAULT NULL,
        `retry_count` INT NOT NULL DEFAULT 0,
        `max_retries` INT NOT NULL DEFAULT 3,
        `locked_at` DATETIME DEFAULT NULL,
        `locked_by` VARCHAR(80) DEFAULT NULL,
        `created_by` INT UNSIGNED DEFAULT NULL,
        `created_at` DATETIME NOT NULL,
        `updated_at` DATETIME NOT NULL,
        `started_at` DATETIME DEFAULT NULL,
        `finished_at` DATETIME DEFAULT NULL,
        PRIMARY KEY (`id`),
        INDEX `idx_ai_content_status` (`status`, `created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function contentStudioNormalizePayload(array $b): array {
    $publishMode = san($b['publishMode'] ?? 'draft', 20) ?? 'draft';
    if (!in_array($publishMode, ['draft', 'publish', 'schedule'], true)) {
        $publishMode = 'draft';
    }
    $targetChars = (int)($b['targetChars'] ?? $b['charCount'] ?? $b['target_chars'] ?? 0);
    if ($targetChars <= 0) {
        $wc = (int)($b['wordCount'] ?? $b['word_count'] ?? 0);
        $targetChars = $wc > 0 ? $wc * 6 : 5000;
    }
    $targetChars = max(800, min(12000, $targetChars));
    $wordCount = max(100, min(4000, (int)round($targetChars / 6)));
    return [
        'category' => san($b['category'] ?? 'Limpeza de Sofá', 80) ?? 'Limpeza de Sofá',
        'topic' => san($b['topic'] ?? null, 255),
        'keyword' => san($b['keyword'] ?? null, 255),
        'keywords' => san($b['keywords'] ?? null, 500),
        'cities' => is_array($b['cities'] ?? null) ? array_values(array_map('strval', $b['cities'])) : ['Vespasiano'],
        'targetChars' => $targetChars,
        'wordCount' => $wordCount,
        'tone' => san($b['tone'] ?? 'profissional e confiável', 120) ?? 'profissional e confiável',
        'promptType' => san($b['promptType'] ?? 'artigo-completo', 60) ?? 'artigo-completo',
        'contentLevel' => san($b['contentLevel'] ?? 'basico', 20) ?? 'basico',
        'providerId' => sanInt($b['providerId'] ?? 0) ?: null,
        'publishMode' => $publishMode,
        'scheduledAt' => san($b['scheduledAt'] ?? null, 40),
        'multichannelPublish' => is_array($b['multichannelPublish'] ?? null) ? $b['multichannelPublish'] : [],
        // Capa IA é etapa obrigatória do Content Studio (não desligar)
        'useImage' => true,
        'imageProviderId' => sanInt($b['imageProviderId'] ?? 0) ?: null,
        'compressionPreset' => san($b['compressionPreset'] ?? 'balanceado', 40) ?? 'balanceado',
    ];
}

function contentStudioEnqueueJob(array $payload): array {
    $pdo = db();
    ensureAiContentJobsTable($pdo);
    $now = dbNow();
    $uid = adminSessionUserId();
    $pdo->prepare('INSERT INTO ai_content_jobs (status, topic, payload_json, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?)')
        ->execute([
            'pending',
            san($payload['topic'] ?? $payload['keyword'] ?? null, 255),
            json_encode($payload, JSON_UNESCAPED_UNICODE),
            $uid,
            $now,
            $now,
        ]);
    return ['ok' => true, 'jobId' => (int)$pdo->lastInsertId()];
}

function contentStudioGetJob(PDO $pdo, int $id): ?array {
    $stmt = $pdo->prepare('SELECT * FROM ai_content_jobs WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function contentStudioBuildImageMeta(array $article): array {
    $title = trim((string)($article['title'] ?? ''));
    $slug = trim((string)($article['slug'] ?? 'artigo'));
    $brief = function_exists('aiImageVisualBriefFromArticle') ? aiImageVisualBriefFromArticle($article) : null;
    $alt = $title !== '' ? "Foto realista: {$title}" : 'Capa do artigo — tema específico de higienização';
    if (is_array($brief) && !empty($brief['subject'])) {
        $alt = "Foto profissional de {$brief['subject']} — {$title}";
    }
    return [
        'alt' => $alt,
        'caption' => $title !== '' ? $title : 'Imagem gerada por IA',
        'description' => 'Capa gerada automaticamente com prompt alinhado ao tema do artigo',
        'optimizedName' => preg_replace('/[^a-z0-9\-]+/i', '-', strtolower($slug)) . '-cover',
    ];
}

function contentStudioProcessSingleJob(PDO $pdo, array $job): array {
    ensureCmsMigrated();
    $id = (int)$job['id'];
    $payload = json_decode((string)($job['payload_json'] ?? '{}'), true);
    if (!is_array($payload)) $payload = [];
    $payload = contentStudioNormalizePayload($payload);

    $claim = $pdo->prepare("UPDATE ai_content_jobs SET status='running', started_at=COALESCE(started_at, ?), updated_at=?, locked_at=?, locked_by=? WHERE id=? AND status IN ('pending','failed')");
    $claim->execute([dbNow(), dbNow(), dbNow(), 'cron', $id]);
    if ($claim->rowCount() === 0) {
        return ['ok' => false, 'jobId' => $id, 'skipped' => true, 'error' => 'Job indisponível para processamento'];
    }

    try {
        $article = aiGenerateBlogArticle($payload);
        $article['contentLevel'] = $payload['contentLevel'];
        $article['city'] = $payload['cities'][0] ?? null;
        $article['keyword'] = $payload['keyword'] ?? $payload['topic'] ?? null;
        $imageMedia = null;
        $imageMeta = contentStudioBuildImageMeta($article);
        $imagePrompt = aiImagePromptFromArticle($article);
        $imageStatus = 'generating';
        $imageProvider = null;
        $imageError = null;
        $imgAttempts = [];

        // Obrigatório: gerar capa com 1 retry automático
        $maxImgTries = 2;
        for ($try = 1; $try <= $maxImgTries; $try++) {
            $imgResult = aiImageGatewayGenerate([
                'prompt' => $imagePrompt,
                'seed' => aiImageSeedFromContext(['slug' => $article['slug'] ?? '', 'try' => $try], $imagePrompt),
                'provider_id' => $payload['imageProviderId'] ?? null,
            ]);
            $imgAttempts[] = [
                'try' => $try,
                'ok' => !empty($imgResult['ok']),
                'error' => $imgResult['error'] ?? null,
                'provider' => $imgResult['provider_type'] ?? $imgResult['provider'] ?? null,
            ];
            if (!empty($imgResult['ok'])) {
                $imageMedia = mediaIngestFromBinary($pdo, [
                    'binary' => (string)$imgResult['binary'],
                    'mime' => (string)($imgResult['mime'] ?? 'image/png'),
                    'folder' => 'Blog',
                    'source' => 'ai',
                    'provider' => (string)($imgResult['provider_type'] ?? 'pollinations'),
                    'prompt' => $imagePrompt,
                    'title' => (string)($article['title'] ?? 'Imagem IA'),
                    'meta' => $imageMeta,
                ]);
                if (!empty($imageMedia['url'])) {
                    $imageStatus = 'completed';
                    $imageProvider = (string)($imgResult['provider_type'] ?? $imgResult['provider'] ?? 'pollinations');
                    break;
                }
                $imageError = 'Ingestão de mídia sem URL';
            } else {
                $imageError = (string)($imgResult['error'] ?? 'Falha na geração de imagem');
            }
            if ($try < $maxImgTries) {
                usleep(400000);
            }
        }
        if ($imageStatus !== 'completed') {
            $imageStatus = 'failed';
            if (function_exists('appLog')) {
                appLog('error', 'content_studio_image_failed', [
                    'slug' => $article['slug'] ?? null,
                    'error' => $imageError,
                    'attempts' => $imgAttempts,
                ]);
            }
        }

        $postBody = [
            'slug' => $article['slug'] ?? ('artigo-' . time()),
            'title' => $article['title'] ?? 'Artigo gerado por IA',
            'excerpt' => $article['excerpt'] ?? '',
            'content' => $article['content'] ?? '',
            'category' => $article['category'] ?? $payload['category'],
            'iconName' => $article['iconName'] ?? 'BookOpen',
            'readMinutes' => (int)($article['readMinutes'] ?? 8),
            'publishedAt' => substr((string)($article['publishedAt'] ?? date('Y-m-d')), 0, 10),
            'tags' => is_array($article['tags'] ?? null) ? $article['tags'] : [],
            'serviceId' => $article['serviceId'] ?? null,
            'imageUrl' => is_array($imageMedia) ? ($imageMedia['url'] ?? null) : null,
            'imagePrompt' => $imagePrompt,
            'imageStatus' => $imageStatus,
            'imageProvider' => $imageProvider,
            'related' => is_array($article['related'] ?? null) ? $article['related'] : [],
            'blocks' => is_array($article['blocks'] ?? null) ? $article['blocks'] : [],
            'metaTitle' => $article['metaTitle'] ?? $article['title'] ?? null,
            'metaDescription' => $article['metaDescription'] ?? $article['excerpt'] ?? null,
            'canonical' => $article['canonical'] ?? null,
            'ogImage' => is_array($imageMedia) ? ($imageMedia['url'] ?? null) : null,
            'status' => $payload['publishMode'] === 'publish' ? 'published' : ($payload['publishMode'] === 'schedule' ? 'scheduled' : 'draft'),
            'featuredHome' => false,
            'featuredBlog' => false,
            'authorName' => 'Auto Limpeza Pro',
            'scheduledAt' => $payload['publishMode'] === 'schedule' ? ($payload['scheduledAt'] ?: date('Y-m-d H:i:s', strtotime('+1 day'))) : null,
            'city' => $payload['cities'][0] ?? null,
            'contentLevel' => $payload['contentLevel'],
            'keywords' => $article['keywords'] ?? $payload['keywords'] ?? null,
            'faqSchema' => is_array($article['faqSchema'] ?? null) ? $article['faqSchema'] : [],
            'ctaConfig' => ['text' => $article['ctaText'] ?? null],
            'multichannelPublish' => is_array($payload['multichannelPublish']) ? $payload['multichannelPublish'] : [],
        ];

        if (function_exists('blogEnrichPostForSeo')) {
            $postBody['applyAffiliateLinks'] = true;
            $postBody = blogEnrichPostForSeo($pdo, $postBody);
        }

        // Regra de listagem: publicado com corpo → entra em /dicas, Últimas, resumo, etc.
        // Sem corpo suficiente, nunca publica (evita stub vazio no portal).
        if (!function_exists('cmsBlogPostHasBody')) {
            // cmsBlogPostHasBody vive em api.php — já carregado no request normal
        }
        $wantPublish = ($postBody['status'] ?? '') === 'published';
        // Garante content textual a partir dos blocks antes de validar/gravar
        if ((!is_string($postBody['content'] ?? null) || trim(strip_tags((string)$postBody['content'])) === '')
            && function_exists('cmsBlocksToPlainText')) {
            $plain = cmsBlocksToPlainText($postBody['blocks'] ?? []);
            if ($plain !== '') {
                $postBody['content'] = $plain;
            }
        }
        $hasBody = function_exists('cmsBlogPostHasBody') ? cmsBlogPostHasBody($postBody) : (mb_strlen(trim(strip_tags((string)($postBody['content'] ?? '')))) >= 40);
        $hasCover = function_exists('cmsBlogPostImageReady')
            ? cmsBlogPostImageReady($postBody)
            : (!empty($postBody['imageUrl']) && ($postBody['imageStatus'] ?? '') === 'completed');
        $publishBlocked = false;
        $publishBlockedReason = null;

        // Soft analysis (já vem do aiGenerateBlogArticle); reavalia pós-enrich
        $repetitionAnalysis = function_exists('blogAnalyzeRepetition')
            ? blogAnalyzeRepetition($postBody, is_string($postBody['keyword'] ?? null) ? (string)$postBody['keyword'] : ($payload['keyword'] ?? null))
            : ['score' => (int)($article['repetitionScore'] ?? 0), 'level' => $article['repetitionLevel'] ?? 'ok', 'warnings' => []];
        $repetitionScore = (int)($repetitionAnalysis['score'] ?? ($article['repetitionScore'] ?? 0));
        $repetitionLevel = (string)($repetitionAnalysis['level'] ?? ($article['repetitionLevel'] ?? 'ok'));
        $repetitionWarning = $article['repetitionWarning'] ?? null;
        if (function_exists('blogRepetitionIsSoftWarn') && blogRepetitionIsSoftWarn($repetitionAnalysis) && !$repetitionWarning) {
            $bits = !empty($repetitionAnalysis['warnings']) ? implode(' ', array_slice($repetitionAnalysis['warnings'], 0, 3)) : '';
            $repetitionWarning = "Repetição artificial (score {$repetitionScore}/100). {$bits}";
        }

        if ($wantPublish && !$hasBody) {
            $postBody['status'] = 'draft';
            $postBody['featuredBlog'] = false;
            $postBody['featuredHome'] = false;
            $publishBlocked = true;
            $publishBlockedReason = 'Conteúdo insuficiente para publicar. Salvo como rascunho — revise e publique.';
        } elseif ($wantPublish && !$hasCover) {
            $postBody['status'] = 'draft';
            $postBody['featuredBlog'] = false;
            $postBody['featuredHome'] = false;
            $publishBlocked = true;
            $publishBlockedReason = 'Capa IA obrigatória. Geração falhou ou incompleta — use «Gerar imagem novamente» ou prompt externo.';
        } elseif ($wantPublish && function_exists('blogRepetitionIsHardBlock') && blogRepetitionIsHardBlock($repetitionAnalysis)) {
            // Hard gate híbrido: só Content Studio com publishMode=publish
            $postBody['status'] = 'draft';
            $postBody['featuredBlog'] = false;
            $postBody['featuredHome'] = false;
            $publishBlocked = true;
            $bits = !empty($repetitionAnalysis['warnings']) ? ' ' . implode(' ', array_slice($repetitionAnalysis['warnings'], 0, 2)) : '';
            $publishBlockedReason = "Repetição artificial alta (score {$repetitionScore}/100). Mantido como rascunho — regenere ou edite antes de publicar.{$bits}";
        } elseif (($postBody['status'] ?? '') === 'published') {
            // Todo post publicado participa das listagens públicas (destaque editorial incluso)
            $postBody['featuredBlog'] = true;
        }

        // Reaproveita mesmo mecanismo do CMS.
        $now = dbNow();
        $uid = adminSessionUserId();
        $allowJs = adminRole() === 'admin';
        $slug = trim((string)$postBody['slug'], '-');
        if ($slug === '') $slug = 'artigo-' . time();
        // Evita sobrescrever artigo publicado/agendado com o mesmo slug (ON DUPLICATE KEY).
        try {
            $chk = $pdo->prepare('SELECT slug, status FROM blog_posts WHERE slug = ? LIMIT 1');
            $chk->execute([$slug]);
            $existing = $chk->fetch(PDO::FETCH_ASSOC);
            if ($existing && in_array((string)($existing['status'] ?? ''), ['published', 'scheduled'], true)) {
                $base = $slug;
                $suffix = '-ia-' . date('YmdHis');
                $candidate = mb_substr($base, 0, max(1, 180 - strlen($suffix))) . $suffix;
                $n = 0;
                while ($n < 5) {
                    $chk2 = $pdo->prepare('SELECT 1 FROM blog_posts WHERE slug = ? LIMIT 1');
                    $chk2->execute([$candidate]);
                    if (!$chk2->fetch()) {
                        $slug = $candidate;
                        $postBody['slug'] = $slug;
                        break;
                    }
                    $n++;
                    $candidate = mb_substr($base, 0, max(1, 175 - strlen($suffix))) . $suffix . '-' . $n;
                }
            }
        } catch (Throwable $e) {
            if (function_exists('appLog')) {
                appLog('warn', 'content_studio_slug_guard', ['err' => $e->getMessage()]);
            }
        }
        $pdo->prepare("
            INSERT INTO blog_posts
                (slug, title, excerpt, content, category, icon_name, read_minutes,
                 published_at, tags, service_id, image_url, related, blocks,
                 meta_title, meta_description, canonical, og_image, status,
                 featured_home, featured_blog, author_id, author_name, gallery,
                 scheduled_at, category_id, city, neighborhood, content_level,
                 products_cited, video_url, keywords, faq_schema, cta_config,
                 created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                title = VALUES(title), excerpt = VALUES(excerpt), content = VALUES(content),
                category = VALUES(category), icon_name = VALUES(icon_name), read_minutes = VALUES(read_minutes),
                published_at = VALUES(published_at), tags = VALUES(tags), service_id = VALUES(service_id),
                image_url = VALUES(image_url), related = VALUES(related), blocks = VALUES(blocks),
                meta_title = VALUES(meta_title), meta_description = VALUES(meta_description),
                canonical = VALUES(canonical), og_image = VALUES(og_image), status = VALUES(status),
                featured_home = VALUES(featured_home), featured_blog = VALUES(featured_blog),
                author_id = COALESCE(VALUES(author_id), author_id),
                author_name = COALESCE(NULLIF(VALUES(author_name), ''), author_name),
                gallery = VALUES(gallery),
                scheduled_at = VALUES(scheduled_at), category_id = VALUES(category_id), city = VALUES(city),
                neighborhood = VALUES(neighborhood), content_level = VALUES(content_level),
                products_cited = VALUES(products_cited), video_url = VALUES(video_url),
                keywords = VALUES(keywords), faq_schema = VALUES(faq_schema), cta_config = VALUES(cta_config), updated_at = VALUES(updated_at)
        ")->execute(cmsBlogPostParams($postBody, $slug, $now, $uid, 'Auto Limpeza Pro', $allowJs));

        if (function_exists('cmsBlogPostSetImageMeta')) {
            $extPrompt = function_exists('aiImagePromptForExternalPlatform')
                ? aiImagePromptForExternalPlatform($article, $imagePrompt)
                : $imagePrompt;
            cmsBlogPostSetImageMeta($pdo, $slug, [
                'imageUrl' => is_array($imageMedia) ? ($imageMedia['url'] ?? null) : null,
                'ogImage' => is_array($imageMedia) ? ($imageMedia['url'] ?? null) : null,
                'imagePrompt' => $extPrompt ?: $imagePrompt,
                'imageStatus' => $imageStatus,
                'imageProvider' => $imageProvider,
                'syncOg' => true,
            ]);
        }

        $stmt = $pdo->prepare('SELECT * FROM blog_posts WHERE slug = ? LIMIT 1');
        $stmt->execute([$slug]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $post = $row ? decodeBlogPost($row) : null;

        if ($post && ($post['status'] ?? '') === 'published' && !empty($payload['multichannelPublish'])) {
            try {
                if (!function_exists('dispatchBlogMultichannel')) {
                    require_once __DIR__ . '/blog-multichannel.php';
                }
                $post['multichannelResult'] = dispatchBlogMultichannel($pdo, $post, $payload['multichannelPublish']);
            } catch (Throwable $e) {
                $post['multichannelResult'] = [
                    'ok' => false,
                    'channels' => [
                        'telegram' => ['ok' => false, 'detail' => $e->getMessage()],
                    ],
                ];
            }
        }

        $externalPrompt = function_exists('aiImagePromptForExternalPlatform')
            ? aiImagePromptForExternalPlatform($article, $imagePrompt)
            : $imagePrompt;
        $result = [
            'post' => $post,
            'image' => $imageMedia,
            'imagePrompt' => $imagePrompt,
            'imageStatus' => $imageStatus,
            'imageError' => $imageError,
            'imageAttempts' => $imgAttempts,
            'coverImagePrompt' => $article['coverImagePrompt'] ?? null,
            'externalImagePrompt' => $externalPrompt,
            'provider' => $article['provider'] ?? null,
            'status' => 'ok',
            'publishBlocked' => !empty($publishBlocked),
            'publishBlockedReason' => $publishBlockedReason ?? null,
            'contentReady' => !empty($hasBody),
            'imageReady' => $imageStatus === 'completed' && !empty($postBody['imageUrl']),
            'bodyCharCount' => $article['bodyCharCount'] ?? null,
            'bodyLengthWarning' => $article['bodyLengthWarning'] ?? null,
            'repetitionScore' => $repetitionScore,
            'repetitionLevel' => $repetitionLevel,
            'repetitionWarning' => $repetitionWarning,
            'repetitionDetails' => $repetitionAnalysis['details'] ?? ($article['repetitionDetails'] ?? null),
        ];
        $pdo->prepare("UPDATE ai_content_jobs SET status='completed', result_json=?, error_message=NULL, finished_at=?, updated_at=? WHERE id=?")
            ->execute([json_encode($result, JSON_UNESCAPED_UNICODE), dbNow(), dbNow(), $id]);
        return ['ok' => true, 'jobId' => $id, 'result' => $result];
    } catch (Throwable $e) {
        $retry = (int)$job['retry_count'] + 1;
        $maxRetries = (int)$job['max_retries'];
        $status = $retry >= $maxRetries ? 'failed' : 'pending';
        $pdo->prepare('UPDATE ai_content_jobs SET status=?, retry_count=?, error_message=?, updated_at=?, locked_at=NULL, locked_by=NULL WHERE id=?')
            ->execute([$status, $retry, mb_substr($e->getMessage(), 0, 4000), dbNow(), $id]);
        return ['ok' => false, 'jobId' => $id, 'error' => $e->getMessage(), 'status' => $status];
    }
}

function processAiContentJobs(PDO $pdo, int $limit = 2): array {
    ensureAiContentJobsTable($pdo);
    $limit = max(1, min(10, $limit));
    $stmt = $pdo->prepare("SELECT * FROM ai_content_jobs WHERE status = 'pending' ORDER BY id ASC LIMIT {$limit}");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $out = [];
    foreach ($rows as $row) {
        $out[] = contentStudioProcessSingleJob($pdo, $row);
    }
    return ['processed' => count($out), 'items' => $out];
}

function handleContentStudio(string $method): void {
    requireAdmin();
    $pdo = db();
    ensureAiContentJobsTable($pdo);
    if ($method === 'POST') {
        $action = san($_GET['sub'] ?? $_GET['mode'] ?? 'generate', 40) ?? 'generate';
        $b = jsonBody();
        if ($action === 'generate') {
            $payload = contentStudioNormalizePayload($b);
            jsonRespond(contentStudioEnqueueJob($payload));
        }
        if ($action === 'cancel') {
            $id = sanInt($b['id'] ?? 0);
            if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);
            $pdo->prepare("UPDATE ai_content_jobs SET status='cancelled', updated_at=? WHERE id=? AND status IN ('pending','running')")
                ->execute([dbNow(), $id]);
            jsonRespond(['ok' => true]);
        }
        if ($action === 'run-now') {
            $id = sanInt($b['id'] ?? 0);
            if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);
            $job = contentStudioGetJob($pdo, $id);
            if (!$job) jsonRespond(['error' => 'job não encontrado'], 404);
            if (!in_array($job['status'], ['pending', 'failed'], true)) {
                jsonRespond(['error' => 'Job não pode ser reprocessado neste status', 'status' => $job['status']], 409);
            }
            jsonRespond(contentStudioProcessSingleJob($pdo, $job));
        }
        jsonRespond(['error' => 'Ação inválida'], 400);
    }

    if ($method === 'GET') {
        $sub = san($_GET['sub'] ?? 'history', 40) ?? 'history';
        if ($sub === 'status') {
            $id = sanInt($_GET['id'] ?? 0);
            if (!$id) jsonRespond(['error' => 'id obrigatório'], 400);
            $row = contentStudioGetJob($pdo, $id);
            if (!$row) jsonRespond(['error' => 'job não encontrado'], 404);
            $row['payload'] = json_decode((string)($row['payload_json'] ?? '{}'), true);
            $row['result'] = json_decode((string)($row['result_json'] ?? '{}'), true);
            unset($row['payload_json'], $row['result_json']);
            jsonRespond($row);
        }
        if ($sub === 'history') {
            $limit = max(10, min(100, sanInt($_GET['limit'] ?? 30)));
            $rows = $pdo->query("SELECT id, status, topic, retry_count, max_retries, error_message, created_at, updated_at, finished_at FROM ai_content_jobs ORDER BY id DESC LIMIT {$limit}")
                ->fetchAll(PDO::FETCH_ASSOC);
            jsonRespond(['items' => $rows]);
        }
        if ($sub === 'monitor') {
            $jobs = $pdo->query("SELECT status, COUNT(*) total FROM ai_content_jobs GROUP BY status")->fetchAll(PDO::FETCH_ASSOC);
            $img = [];
            $txt = [];
            try {
                ensureAiImageTables($pdo);
                $img = $pdo->query("SELECT provider_type, COUNT(*) total FROM ai_image_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY provider_type")->fetchAll(PDO::FETCH_ASSOC);
            } catch (Throwable $e) { /* */ }
            try {
                if (function_exists('ensureAiGatewayTables')) {
                    ensureAiGatewayTables($pdo);
                    $txt = $pdo->query("SELECT provider, COUNT(*) total FROM ai_gateway_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY provider")->fetchAll(PDO::FETCH_ASSOC);
                }
            } catch (Throwable $e) { /* */ }
            jsonRespond(['jobs' => $jobs, 'imageProviders7d' => $img, 'textProviders7d' => $txt]);
        }
        jsonRespond(['error' => 'sub inválido'], 400);
    }
    jsonRespond(['error' => 'Método não permitido'], 405);
}
