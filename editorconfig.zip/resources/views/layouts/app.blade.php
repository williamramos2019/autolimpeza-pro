<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="theme-color" content="#0f3d2e">
    @auth
        <meta name="user-id" content="{{ auth()->id() }}">
    @endauth
    <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
    <link rel="apple-touch-icon" href="{{ asset('icons/icon-192.png') }}">
    <title>@yield('title', 'Materiais em obras')</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="stylesheet" href="{{ asset('css/pwa.css') }}">
</head>
<body>
    @include('partials.pwa-shell')
    <div class="app">@yield('content')</div>
    @stack('nav')
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="{{ asset('js/offline-store.js') }}" defer></script>
    <script src="{{ asset('js/pwa.js') }}" defer></script>
    @stack('scripts')
</body>
</html>
