@extends('layouts.app')

@section('title', 'Login')

@section('content')
<div style="max-width: 400px; margin: 100px auto; padding: 20px;">
    <h1 style="margin-bottom: 20px;">Login</h1>

    @if ($errors->any())
        <div style="background: #fee; border: 1px solid #c00; padding: 10px; margin-bottom: 20px; border-radius: 4px;">
            <ul style="margin: 0; padding-left: 20px;">
                @foreach ($errors->all() as $error)
                    <li style="color: #c00;">{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('login') }}">
        @csrf

        <div style="margin-bottom: 15px;">
            <label for="email" style="display: block; margin-bottom: 5px;">E-mail</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}" required autofocus
                   style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>

        <div style="margin-bottom: 15px;">
            <label for="password" style="display: block; margin-bottom: 5px;">Senha</label>
            <input type="password" id="password" name="password" required
                   style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: flex; align-items: center;">
                <input type="checkbox" name="remember" style="margin-right: 5px;">
                <span>Lembrar-me</span>
            </label>
        </div>

        <button type="submit"
                style="width: 100%; padding: 10px; background: #0f3d2e; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Entrar
        </button>
    </form>

    <p style="margin-top: 24px; font-size: 0.9rem; color: #555;">
        <strong>Instalar aplicativo</strong><br>
        Android: menu do navegador → Adicionar à tela inicial.<br>
        iPhone: Compartilhar → Adicionar à tela de início.<br>
        A operação no celular continua mesmo sem instalar.
    </p>
</div>
@endsection
