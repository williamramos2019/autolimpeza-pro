@extends('layouts.app')

@section('title', 'Pendências')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'pendencias'])

    <div class="page-header">
        <h1 class="page-title">Pendências</h1>
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <form class="search-bar" method="GET" action="{{ route('pendencias.index') }}">
        <input class="form-control" type="search" name="q" value="{{ $search }}" placeholder="Código MOV ou material">
        <select class="form-control" name="obra_id">
            <option value="">Todas as obras</option>
            @foreach ($obras as $obra)
                <option value="{{ $obra->id }}" @selected((string) $obraId === (string) $obra->id)>
                    {{ $obra->code }} — {{ $obra->name }}
                </option>
            @endforeach
        </select>
        <select class="form-control" name="status">
            <option value="">Todos os status</option>
            @foreach ($statuses as $opcao)
                <option value="{{ $opcao->value }}" @selected($status === $opcao->value)>{{ $opcao->label() }}</option>
            @endforeach
        </select>
        <select class="form-control" name="tipo">
            <option value="">Falta e sobra</option>
            <option value="falta" @selected($tipo === 'falta')>Falta</option>
            <option value="sobra" @selected($tipo === 'sobra')>Sobra</option>
        </select>
        <input class="form-control" type="date" name="de" value="{{ $de }}">
        <input class="form-control" type="date" name="ate" value="{{ $ate }}">
        <button class="btn btn-primary" type="submit">Filtrar</button>
    </form>

    <ul class="card-list">
        @forelse ($pendencias as $pendencia)
            <li class="card">
                <div class="card-title">
                    {{ $pendencia->movement?->code ?? '—' }}
                    <span class="badge badge-{{ $pendencia->status->badgeModifier() }}">{{ $pendencia->status->label() }}</span>
                    <span class="badge {{ $pendencia->tipo() === 'sobra' ? 'badge-divergente' : 'badge-em-conferencia' }}">
                        {{ $pendencia->tipo() === 'sobra' ? 'Sobra' : 'Falta' }}
                    </span>
                </div>
                <div class="card-meta">
                    <span class="card-meta-item">Obra: {{ $pendencia->obra?->name }}</span>
                    <span class="card-meta-item">{{ $pendencia->material?->description }}</span>
                    <span class="card-meta-item">Enviado: {{ $pendencia->qty_sent }}</span>
                    <span class="card-meta-item">Recebido: {{ $pendencia->qty_received }}</span>
                    <span class="card-meta-item">Pendente: {{ $pendencia->qty_pending }}</span>
                </div>
                <div class="card-actions">
                    <a class="btn btn-primary" href="{{ route('pendencias.show', $pendencia) }}">Abrir</a>
                </div>
            </li>
        @empty
            <li class="empty-state">Nenhuma pendência encontrada.</li>
        @endforelse
    </ul>

    @include('partials.paginacao', ['paginator' => $pendencias])
</div>
@endsection
