@extends('layouts.app')

@section('title', 'Pendência '.$pending->movement?->code)

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'pendencias'])

    <div class="page-header">
        <h1 class="page-title">
            {{ $pending->movement?->code }}
            <span class="page-subtitle">{{ $pending->status->label() }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('pendencias.index') }}">Voltar</a>
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <div class="card">
        <div class="card-title">Movimentação</div>
        <div class="card-meta">
            <span class="card-meta-item">Tipo: {{ $pending->movement?->type()->label() }}</span>
            <span class="card-meta-item">Origem: {{ $pending->movement?->originObra?->name }} / {{ $pending->movement?->originLocal?->name }}</span>
            <span class="card-meta-item">Destino: {{ $pending->movement?->destinationObra?->name }} / {{ $pending->movement?->destinationLocal?->name }}</span>
            <span class="card-meta-item">Data: {{ $pending->movement?->movement_date?->format('d/m/Y') }}</span>
            <span class="card-meta-item">Remetente: {{ $pending->movement?->sender?->name }}</span>
        </div>
    </div>

    <div class="card">
        <div class="card-title">Material</div>
        <div class="card-meta">
            <span class="card-meta-item">{{ $pending->material?->description }}</span>
            <span class="card-meta-item">Código: {{ $pending->material?->code }}</span>
            <span class="card-meta-item">Unidade: {{ $pending->material?->unit?->code }}</span>
        </div>
    </div>

    <div class="card">
        <div class="card-title">Conferência</div>
        <div class="card-meta">
            <span class="card-meta-item">Enviado: {{ $pending->qty_sent }}</span>
            <span class="card-meta-item">Recebido: {{ $pending->qty_received }}</span>
            <span class="card-meta-item">
                Diferença: {{ number_format((float) $pending->qty_sent - (float) $pending->qty_received, 3, '.', '') }}
            </span>
            <span class="card-meta-item">
                Tipo: {{ $pending->tipo() === 'sobra' ? 'SOBRA' : 'FALTA' }}
            </span>
        </div>
    </div>

    <div class="card">
        <div class="card-title">Pendência</div>
        <div class="card-meta">
            <span class="card-meta-item">Original: {{ $pending->qtyOriginal() }}</span>
            <span class="card-meta-item">Resolvido: {{ $pending->qtyResolvida() }}</span>
            <span class="card-meta-item">Restante: {{ $pending->qty_pending }}</span>
            <span class="card-meta-item">Status: {{ $pending->status->label() }}</span>
            <span class="card-meta-item">Responsável: {{ $pending->responsibleUser?->name ?? '—' }}</span>
            @if ($pending->resolved_at)
                <span class="card-meta-item">Resolvida em {{ $pending->resolved_at->format('d/m/Y H:i') }}</span>
            @endif
        </div>
    </div>

    @if ($podeResolver)
        <form method="POST" action="{{ route('pendencias.resolver', $pending) }}" class="mt-3">
            @csrf
            <input type="hidden" name="idempotency_key" value="{{ old('idempotency_key', (string) \Illuminate\Support\Str::uuid()) }}">
            <div class="form-group">
                <label class="form-label" for="qty_resolved">Quantidade a resolver *</label>
                <input class="form-control" type="text" inputmode="decimal" id="qty_resolved"
                       name="qty_resolved" required value="{{ old('qty_resolved', $pending->qty_pending) }}">
                <p class="form-hint">Máximo {{ $pending->qty_pending }}. Até 3 casas decimais.</p>
                @error('qty_resolved')<span class="form-error">{{ $message }}</span>@enderror
            </div>
            <div class="form-group">
                <label class="form-label" for="notes">Observação</label>
                <textarea class="form-control" id="notes" name="notes" rows="3">{{ old('notes') }}</textarea>
            </div>
            <button class="btn btn-primary btn-lg btn-block" type="submit"
                    onclick="return confirm('Confirmar esta resolução?');">
                Registrar resolução
            </button>
        </form>
    @endif

    <h2 class="page-title mt-3">Histórico da pendência</h2>
    <ul class="card-list">
        <li class="card">
            <div class="card-title">Criação</div>
            <div class="card-meta">
                <span class="card-meta-item">{{ $pending->created_at?->format('d/m/Y H:i') }}</span>
                <span class="card-meta-item">Quantidade original: {{ $pending->qtyOriginal() }}</span>
            </div>
        </li>
        @foreach ($pending->resolutions as $resolucao)
            <li class="card">
                <div class="card-title">
                    Resolução de {{ $resolucao->qty_delivered }}
                </div>
                <div class="card-meta">
                    <span class="card-meta-item">{{ $resolucao->delivered_at?->format('d/m/Y H:i') }}</span>
                    <span class="card-meta-item">Por: {{ $resolucao->user?->name ?? '—' }}</span>
                    @if ($resolucao->notes)
                        <span class="card-meta-item">{{ $resolucao->notes }}</span>
                    @endif
                </div>
            </li>
        @endforeach
    </ul>

    <h2 class="page-title mt-3">Histórico da movimentação</h2>
    <ul class="card-list">
        @forelse ($pending->movement?->statusHistory ?? [] as $historico)
            <li class="card">
                <div class="card-title">
                    {{ $historico->from_status?->label() ?? 'Criação' }} → {{ $historico->to_status->label() }}
                </div>
                <div class="card-meta">
                    <span class="card-meta-item">{{ $historico->created_at?->format('d/m/Y H:i') }}</span>
                    <span class="card-meta-item">Por: {{ $historico->user?->name ?? 'sistema' }}</span>
                </div>
            </li>
        @empty
            <li class="empty-state">Sem histórico de status.</li>
        @endforelse
    </ul>
</div>
@endsection
