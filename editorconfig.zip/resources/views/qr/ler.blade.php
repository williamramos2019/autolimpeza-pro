@extends('layouts.app')

@section('title', 'Ler QR Code')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'qr'])

    <div class="page-header">
        <h1 class="page-title">Ler QR Code</h1>
        <a class="btn btn-secondary" href="{{ url()->previous() !== url()->current() ? url()->previous() : route('movimentacoes.index') }}">Voltar</a>
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <p class="page-subtitle">A leitura só identifica a movimentação. Nenhuma operação é executada.</p>

    <div class="card qr-scan-card">
        <div id="qr-feedback" class="qr-feedback" role="status" aria-live="polite"></div>
        <div class="qr-viewport">
            <video id="qr-camera" autoplay playsinline muted></video>
            <div class="qr-frame" aria-hidden="true"></div>
        </div>
        <div class="card-actions qr-scan-actions">
            <button type="button" class="btn btn-primary btn-lg btn-block" id="qr-start">Abrir câmera</button>
            <button type="button" class="btn btn-secondary btn-lg btn-block" id="qr-cancel" hidden>Cancelar</button>
        </div>
    </div>

    <div class="card">
        <h2 class="card-header">Digitar código</h2>
        <p class="card-body">Use se a câmera não estiver disponível. Cole o token do QR ou a URL <code>/qr/…</code>.</p>
        <form method="GET" action="{{ route('qr.ler') }}" id="qr-manual-form">
            <div class="form-group">
                <label class="form-label" for="qr_token">Token ou URL do QR</label>
                <input class="form-control" type="text" id="qr_token" name="qr_token" autocomplete="off" inputmode="text" required>
            </div>
            <button class="btn btn-primary btn-lg btn-block" type="submit">Abrir movimentação</button>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script src="{{ asset('js/qr-scan.js') }}" defer></script>
@endpush
