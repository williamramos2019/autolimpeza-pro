@extends('layouts.app')

@section('title', 'Instalação')

@section('content')
<div style="max-width: 720px; margin: 40px auto; padding: 20px;">
    <h1 style="margin-bottom: 8px;">Instalação</h1>
    <p style="color:#555; margin-bottom: 24px;">O endereço desta página é o domínio correto. Informe o banco MySQL deste cPanel e crie o administrador.</p>

    @if ($errors->any())
        <div style="background: #fee; border: 1px solid #c00; padding: 10px; margin-bottom: 20px; border-radius: 4px;">
            <ul style="margin: 0; padding-left: 20px;">
                @foreach ($errors->all() as $error)
                    <li style="color: #c00;">{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <h2>1. Servidor</h2>
    <p>PHP {{ $phpVersion }} · HTTPS: {{ $https ? 'sim' : 'não' }} · URL detectada: {{ $appUrl }}</p>
    <ul>
        @foreach ($requirements as $row)
            <li>{{ $row['ok'] ? '✅' : '❌' }} {{ $row['name'] }} — {{ $row['detail'] }}</li>
        @endforeach
    </ul>

    <h2>2. Diretórios</h2>
    <ul>
        @foreach ($directories as $row)
            <li>{{ $row['ok'] ? '✅' : '❌' }} {{ $row['path'] }} — {{ $row['detail'] }}</li>
        @endforeach
    </ul>

    <h2>3. Banco e administrador</h2>
    <p>A conexão atual (se houver) é só informativa. O instalador grava o que você digitar abaixo. A senha não é exibida de volta.</p>
    <p>
        Tentativa atual —
        Host: {{ $database['host'] ?: '—' }} ·
        Banco: {{ $database['database'] ?: '—' }} ·
        Usuário: {{ $database['username'] ?: '—' }} ·
        Status: {{ $database['ok'] ? '✅ conectado' : '❌ '.($database['error'] ?: 'não conectado') }}
    </p>

    @if ($requirementsOk && $directoriesOk)
        <form method="POST" action="{{ route('install.store') }}">
            @csrf
            <div style="margin-bottom: 12px;">
                <label for="db_host" style="display:block;">Host MySQL</label>
                <input id="db_host" name="db_host" value="{{ old('db_host', 'localhost') }}" required
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom: 12px;">
                <label for="db_port" style="display:block;">Porta</label>
                <input id="db_port" name="db_port" type="number" value="{{ old('db_port', '3306') }}" required
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom: 12px;">
                <label for="db_database" style="display:block;">Banco</label>
                <input id="db_database" name="db_database" value="{{ old('db_database') }}" required
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom: 12px;">
                <label for="db_username" style="display:block;">Usuário MySQL</label>
                <input id="db_username" name="db_username" value="{{ old('db_username') }}" required
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom: 16px;">
                <label for="db_password" style="display:block;">Senha MySQL</label>
                <input id="db_password" name="db_password" type="password"
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom: 12px;">
                <label for="name" style="display:block;">Nome do administrador</label>
                <input id="name" name="name" value="{{ old('name') }}" required
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom: 12px;">
                <label for="email" style="display:block;">E-mail do administrador</label>
                <input id="email" name="email" type="email" value="{{ old('email') }}" required
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom: 12px;">
                <label for="password" style="display:block;">Senha do administrador</label>
                <input id="password" name="password" type="password" required minlength="8"
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <div style="margin-bottom: 16px;">
                <label for="password_confirmation" style="display:block;">Confirmar senha</label>
                <input id="password_confirmation" name="password_confirmation" type="password" required minlength="8"
                       style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <button type="submit"
                    style="width:100%; padding:10px; background:#0f3d2e; color:#fff; border:none; border-radius:4px;">
                Instalar e ir para o login
            </button>
        </form>
    @else
        <p style="color:#c00;">Corrija PHP e permissões de pasta antes de instalar.</p>
    @endif
</div>
@endsection
