@extends('layouts.app')

@section('title', 'Dashboard operacional')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'dashboard'])

    <div class="page-header">
        <h1 class="page-title">Dashboard operacional</h1>
        <form method="POST" action="{{ route('logout') }}" data-pwa-logout="1">
            @csrf
            <button class="btn btn-secondary" type="submit">Sair</button>
        </form>
    </div>

    <form class="search-bar" method="GET" action="{{ route('dashboard') }}">
        <select class="form-control" name="obra_id">
            <option value="">Todas as obras</option>
            @foreach ($obras as $obra)
                <option value="{{ $obra->id }}" @selected((string) $filtros['obra_id'] === (string) $obra->id)>
                    {{ $obra->code }} — {{ $obra->name }}
                </option>
            @endforeach
        </select>
        <select class="form-control" name="status">
            <option value="">Todos os status</option>
            @foreach ($statuses as $status)
                <option value="{{ $status->value }}" @selected($filtros['status'] === $status->value)>{{ $status->label() }}</option>
            @endforeach
        </select>
        <select class="form-control" name="tipo">
            <option value="">Todos os tipos</option>
            @foreach ($tipos as $tipo)
                <option value="{{ $tipo->value }}" @selected($filtros['tipo'] === $tipo->value)>{{ $tipo->label() }}</option>
            @endforeach
        </select>
        <input class="form-control" type="date" name="from" value="{{ $filtros['from'] }}">
        <input class="form-control" type="date" name="to" value="{{ $filtros['to'] }}">
        <button class="btn btn-primary" type="submit">Filtrar</button>
    </form>

    <div class="kpi-grid">
        <div class="card kpi-card"><div class="kpi-value">{{ $kpis['TOTAL'] }}</div><div class="kpi-label">Movimentações</div></div>
        <div class="card kpi-card"><div class="kpi-value">{{ $kpis['RASCUNHO'] }}</div><div class="kpi-label">Rascunhos</div></div>
        <div class="card kpi-card"><div class="kpi-value">{{ $kpis['ENVIADO'] }}</div><div class="kpi-label">Enviadas</div></div>
        <div class="card kpi-card"><div class="kpi-value">{{ $kpis['EM_CONFERENCIA'] }}</div><div class="kpi-label">Em conferência</div></div>
        <div class="card kpi-card"><div class="kpi-value">{{ $kpis['CONFERIDO'] }}</div><div class="kpi-label">Conferidas</div></div>
        <div class="card kpi-card"><div class="kpi-value">{{ $kpis['DIVERGENTE'] }}</div><div class="kpi-label">Divergentes</div></div>
        <div class="card kpi-card"><div class="kpi-value">{{ $kpis['CONCLUIDO'] }}</div><div class="kpi-label">Concluídas</div></div>
        <div class="card kpi-card"><div class="kpi-value">{{ $kpis['PENDENCIAS_ABERTAS'] }}</div><div class="kpi-label">Pendências abertas</div></div>
    </div>

    <h2 class="page-title mt-3">Distribuição por status</h2>
    <div class="card">
        @foreach ($porStatus as $linha)
            <div class="bar-row">
                <span class="bar-label">{{ $linha['status']->label() }}</span>
                <div class="bar-track"><div class="bar-fill" style="width: {{ $linha['percentual'] }}%"></div></div>
                <span class="bar-total">{{ $linha['total'] }}</span>
            </div>
        @endforeach
    </div>

    <h2 class="page-title mt-3">Fluxo operacional</h2>
    <div class="kpi-grid">
        @foreach ($tipos as $tipo)
            <div class="card kpi-card">
                <div class="kpi-value">{{ $porTipo[$tipo->value] }}</div>
                <div class="kpi-label">{{ $tipo->label() }}</div>
            </div>
        @endforeach
    </div>

    <h2 class="page-title mt-3">Pendências abertas</h2>
    <ul class="card-list">
        @forelse ($pendencias as $pendencia)
            <li class="card">
                <div class="card-title">
                    {{ $pendencia->movement?->code }}
                    <span class="badge badge-divergente">{{ $pendencia->tipo() === 'sobra' ? 'SOBRA' : 'FALTA' }}</span>
                </div>
                <div class="card-meta">
                    <span class="card-meta-item">{{ $pendencia->obra?->name }}</span>
                    <span class="card-meta-item">{{ $pendencia->material?->description }}</span>
                    <span class="card-meta-item">Pendente: {{ $pendencia->qty_pending }}</span>
                    <span class="card-meta-item">{{ $pendencia->created_at?->format('d/m/Y') }}</span>
                </div>
                <div class="card-actions">
                    <a class="btn btn-primary" href="{{ route('pendencias.show', $pendencia) }}">Abrir pendência</a>
                </div>
            </li>
        @empty
            <li class="empty-state">Nenhuma pendência aberta no filtro atual.</li>
        @endforelse
    </ul>

    <h2 class="page-title mt-3">Divergências abertas</h2>
    <ul class="card-list">
        @forelse ($divergencias as $divergencia)
            <li class="card">
                <div class="card-title">{{ $divergencia->movement?->code }} — {{ $divergencia->material?->description }}</div>
                <div class="card-meta">
                    <span class="card-meta-item">Obra: {{ $divergencia->movement?->destinationObra?->name }}</span>
                    <span class="card-meta-item">Enviado: {{ $divergencia->qty_sent }}</span>
                    <span class="card-meta-item">Recebido: {{ $divergencia->qty_received }}</span>
                    <span class="card-meta-item">Diferença: {{ $divergencia->qty_missing }}</span>
                    <span class="card-meta-item">{{ (float) $divergencia->qty_missing > 0 ? 'FALTA' : 'SOBRA' }}</span>
                </div>
                @if ($divergencia->movement)
                    <div class="card-actions">
                        <a class="btn btn-secondary" href="{{ route('movimentacoes.historico', $divergencia->movement) }}">Ver histórico</a>
                    </div>
                @endif
            </li>
        @empty
            <li class="empty-state">Nenhuma divergência aberta no filtro atual.</li>
        @endforelse
    </ul>

    <h2 class="page-title mt-3">Movimentações recentes</h2>
    <ul class="card-list">
        @forelse ($recentes as $mov)
            <li class="card">
                <div class="card-title">
                    {{ $mov->code }}
                    <span class="badge badge-{{ $mov->status->badgeModifier() }}">{{ $mov->status->label() }}</span>
                </div>
                <div class="card-meta">
                    <span class="card-meta-item">{{ $mov->type()->label() }}</span>
                    <span class="card-meta-item">{{ $mov->originObra?->name }} → {{ $mov->destinationObra?->name }}</span>
                    <span class="card-meta-item">{{ $mov->sender?->name }}</span>
                    <span class="card-meta-item">{{ $mov->movement_date?->format('d/m/Y') }}</span>
                </div>
                <div class="card-actions">
                    <a class="btn btn-primary" href="{{ route('movimentacoes.show', $mov) }}">Abrir</a>
                    <a class="btn btn-secondary" href="{{ route('movimentacoes.historico', $mov) }}">Histórico</a>
                </div>
            </li>
        @empty
            <li class="empty-state">Nenhuma movimentação no filtro atual.</li>
        @endforelse
    </ul>

    <h2 class="page-title mt-3">Movimentações por obra</h2>
    <ul class="card-list">
        @forelse ($porObra as $linha)
            <li class="card">
                <div class="card-title">{{ $linha->obra?->name ?? 'Obra #'.$linha->obra?->id }}</div>
                <div class="card-meta">
                    <span class="card-meta-item">Total: {{ $linha->quantidade }}</span>
                    <span class="card-meta-item">Envios: {{ $linha->envios }}</span>
                    <span class="card-meta-item">Recebimentos: {{ $linha->recebimentos }}</span>
                    <span class="card-meta-item">Divergências: {{ $linha->divergencias }}</span>
                    <span class="card-meta-item">Pendências: {{ $linha->pendencias }}</span>
                </div>
            </li>
        @empty
            <li class="empty-state">Sem obras no filtro atual.</li>
        @endforelse
    </ul>

    <h2 class="page-title mt-3">Materiais mais movimentados</h2>
    <ul class="card-list">
        @forelse ($materiais as $material)
            <li class="card">
                <div class="card-title">{{ $material->description }}</div>
                <div class="card-meta">
                    <span class="card-meta-item">Código: {{ $material->code }}</span>
                    <span class="card-meta-item">Unidade: {{ $material->unidade }}</span>
                    <span class="card-meta-item">Enviado: {{ $material->total_enviado }}</span>
                    <span class="card-meta-item">Movimentações: {{ $material->movimentacoes }}</span>
                </div>
            </li>
        @empty
            <li class="empty-state">Nenhum material movimentado no filtro atual.</li>
        @endforelse
    </ul>
</div>
@endsection
