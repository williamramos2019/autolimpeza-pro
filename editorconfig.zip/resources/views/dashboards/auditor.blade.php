@extends('layouts.app')

@section('title', 'Dashboard Auditor')

@section('content')
<div style="padding: 20px;">
    <h1>Dashboard Auditor</h1>
    <p>Bem-vindo, {{ auth()->user()->name }}!</p>
    <form method="POST" action="{{ route('logout') }}" data-pwa-logout="1">
        @csrf
        <button type="submit" style="padding: 8px 16px; background: #0f3d2e; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Sair
        </button>
    </form>
</div>
@endsection
