@extends('layouts.app')

@section('title', 'Nova obra')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'obras'])

    <div class="page-header">
        <h1 class="page-title">Nova obra</h1>
        <a class="btn btn-secondary" href="{{ route('obras.index') }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('obras.store') }}">
            @csrf
            @include('obras._form', ['obra' => null])
            <button class="btn btn-primary btn-block" type="submit">Cadastrar obra</button>
        </form>
    </div>
</div>
@endsection
