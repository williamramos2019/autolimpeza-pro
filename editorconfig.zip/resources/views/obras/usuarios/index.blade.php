@extends('layouts.app')

@section('title', 'Usuários da obra')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'obras'])

    <div class="page-header">
        <h1 class="page-title">
            Usuários da obra
            <span class="page-subtitle">{{ $obra->code }} — {{ $obra->name }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('obras.show', $obra) }}">Voltar</a>
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <div class="card">
        <div class="card-header">Vincular usuário</div>
        <div class="card-body">
            Somente usuários vinculados a esta obra (ou com permissão de gestão de obras)
            podem operar movimentações desta obra.
        </div>
        <form class="mt-2" method="POST" action="{{ route('obras.usuarios.store', $obra) }}">
            @csrf

            <div class="form-group">
                <label class="form-label" for="user_id">Usuário *</label>
                <select class="form-control" id="user_id" name="user_id" required>
                    <option value="">Selecione</option>
                    @foreach ($disponiveis as $usuario)
                        <option value="{{ $usuario->id }}" @selected((int) old('user_id') === $usuario->id)>
                            {{ $usuario->name }} ({{ $usuario->email }})
                        </option>
                    @endforeach
                </select>
                @error('user_id')<span class="form-error">{{ $message }}</span>@enderror
            </div>

            <div class="form-group">
                <label class="form-label" for="site_role">Papel no canteiro</label>
                <input class="form-control" type="text" id="site_role" name="site_role" maxlength="60"
                       value="{{ old('site_role') }}" placeholder="Ex.: almoxarife, encarregado">
                @error('site_role')<span class="form-error">{{ $message }}</span>@enderror
            </div>

            <button class="btn btn-primary btn-block" type="submit">Vincular</button>
        </form>
    </div>

    <h2 class="page-title mt-3">Vinculados ({{ $vinculados->count() }})</h2>

    <ul class="card-list">
        @forelse ($vinculados as $usuario)
            <li class="card">
                <div class="card-title">{{ $usuario->name }}</div>
                <div class="card-meta">
                    <span class="card-meta-item">{{ $usuario->email }}</span>
                    <span class="card-meta-item">
                        Papel no canteiro: {{ $usuario->pivot->site_role ?? 'não definido' }}
                    </span>
                </div>

                <form class="mt-2" method="POST" action="{{ route('obras.usuarios.update', [$obra, $usuario]) }}">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                        <label class="form-label" for="site_role_{{ $usuario->id }}">Atualizar papel</label>
                        <input class="form-control" type="text" id="site_role_{{ $usuario->id }}"
                               name="site_role" maxlength="60" value="{{ $usuario->pivot->site_role }}">
                    </div>
                    <button class="btn btn-primary btn-block" type="submit">Salvar papel</button>
                </form>

                <form class="mt-2" method="POST" action="{{ route('obras.usuarios.destroy', [$obra, $usuario]) }}"
                      onsubmit="return confirm('Desvincular este usuário da obra?');">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-danger btn-block" type="submit">Desvincular</button>
                </form>
            </li>
        @empty
            <li class="empty-state">Nenhum usuário vinculado a esta obra.</li>
        @endforelse
    </ul>
</div>
@endsection
