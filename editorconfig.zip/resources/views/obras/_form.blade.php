@php($obra = $obra ?? null)

<div class="form-group">
    <label class="form-label" for="code">Código *</label>
    <input class="form-control" type="text" id="code" name="code" required maxlength="50"
           value="{{ old('code', $obra?->code) }}">
    @error('code')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="name">Nome da obra *</label>
    <input class="form-control" type="text" id="name" name="name" required maxlength="255"
           value="{{ old('name', $obra?->name) }}">
    @error('name')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="client_name">Cliente *</label>
    <input class="form-control" type="text" id="client_name" name="client_name" required maxlength="255"
           value="{{ old('client_name', $obra?->client_name) }}">
    @error('client_name')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="address">Endereço *</label>
    <input class="form-control" type="text" id="address" name="address" required maxlength="255"
           value="{{ old('address', $obra?->address) }}">
    @error('address')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="city">Cidade *</label>
    <input class="form-control" type="text" id="city" name="city" required maxlength="120"
           value="{{ old('city', $obra?->city) }}">
    @error('city')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="responsible_user_id">Responsável</label>
    <select class="form-control" id="responsible_user_id" name="responsible_user_id">
        <option value="">Não definido</option>
        @foreach ($responsaveis as $responsavel)
            <option value="{{ $responsavel->id }}"
                @selected((int) old('responsible_user_id', $obra?->responsible_user_id) === $responsavel->id)>
                {{ $responsavel->name }}
            </option>
        @endforeach
    </select>
    @error('responsible_user_id')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="status">Status *</label>
    <select class="form-control" id="status" name="status" required>
        @foreach ($statuses as $case)
            <option value="{{ $case->value }}"
                @selected(old('status', $obra?->status?->value) === $case->value)>
                {{ $case->label() }}
            </option>
        @endforeach
    </select>
    <span class="form-hint">
        Status é acompanhamento da obra. Para arquivar a obra e removê-la das listas
        e dos selects, use "Inativar obra" na tela de detalhes.
    </span>
    @error('status')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="start_date">Data de início *</label>
    <input class="form-control" type="date" id="start_date" name="start_date" required
           value="{{ old('start_date', $obra?->start_date?->format('Y-m-d')) }}">
    @error('start_date')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="expected_end_date">Data prevista de término</label>
    <input class="form-control" type="date" id="expected_end_date" name="expected_end_date"
           value="{{ old('expected_end_date', $obra?->expected_end_date?->format('Y-m-d')) }}">
    @error('expected_end_date')<span class="form-error">{{ $message }}</span>@enderror
</div>
