@extends('layouts.app')

@section('title', 'Novo local')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'obras'])

    <div class="page-header">
        <h1 class="page-title">
            Novo local
            <span class="page-subtitle">{{ $obra->code }} — {{ $obra->name }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('obras.locais.index', $obra) }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('obras.locais.store', $obra) }}">
            @csrf

            <div class="form-group">
                <label class="form-label" for="name">Nome do local *</label>
                <input class="form-control" type="text" id="name" name="name" required maxlength="120"
                       value="{{ old('name') }}">
                <span class="form-hint">O nome não pode repetir dentro desta obra.</span>
                @error('name')<span class="form-error">{{ $message }}</span>@enderror
            </div>

            <div class="form-group">
                <label class="form-check">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', true))>
                    <span>Local ativo</span>
                </label>
                @error('is_active')<span class="form-error">{{ $message }}</span>@enderror
            </div>

            <button class="btn btn-primary btn-block" type="submit">Cadastrar local</button>
        </form>
    </div>
</div>
@endsection
