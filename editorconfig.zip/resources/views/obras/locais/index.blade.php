@extends('layouts.app')

@section('title', 'Locais — ' . $obra->name)

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'obras'])

    <div class="page-header">
        <h1 class="page-title">
            Locais
            <span class="page-subtitle">{{ $obra->code }} — {{ $obra->name }}</span>
        </h1>
        @if ($podeGerenciar)
            <a class="btn btn-primary" href="{{ route('obras.locais.create', $obra) }}">Novo local</a>
        @endif
    </div>

    @include('partials.flash')

    <form class="search-bar" method="GET" action="{{ route('obras.locais.index', $obra) }}">
        <label class="form-label" for="q" style="width:100%">Buscar local por nome</label>
        <input class="form-control" type="search" id="q" name="q" value="{{ $search }}"
               placeholder="Ex.: Almoxarife, Pavimento 2">
        <button class="btn btn-primary" type="submit">Buscar</button>
    </form>

    <ul class="card-list">
        @forelse ($locais as $local)
            <li class="card">
                <div class="card-title">{{ $local->name }}</div>
                <div class="card-meta">
                    <span class="badge {{ $local->is_active ? 'badge-ativo' : 'badge-inativo' }}">
                        {{ $local->is_active ? 'Ativo' : 'Inativo' }}
                    </span>
                    <span class="card-meta-item">Obra: {{ $local->obra->name }}</span>
                </div>
                @if ($podeGerenciar)
                    <div class="card-actions">
                        <a class="btn btn-secondary" href="{{ route('obras.locais.edit', [$obra, $local]) }}">Editar</a>
                        <form method="POST" action="{{ route('obras.locais.toggle', [$obra, $local]) }}">
                            @csrf
                            @method('PATCH')
                            <button class="btn btn-primary" type="submit">
                                {{ $local->is_active ? 'Inativar' : 'Ativar' }}
                            </button>
                        </form>
                    </div>
                @endif
            </li>
        @empty
            <li class="empty-state">Nenhum local cadastrado para esta obra.</li>
        @endforelse
    </ul>

    @include('partials.paginacao', ['paginator' => $locais])

    <a class="btn btn-secondary btn-block" href="{{ route('obras.show', $obra) }}">Voltar para a obra</a>
</div>
@endsection
