@extends('layouts.app')

@section('title', 'Editar local')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'obras'])

    <div class="page-header">
        <h1 class="page-title">
            Editar local
            <span class="page-subtitle">{{ $obra->code }} — {{ $obra->name }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('obras.locais.index', $obra) }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('obras.locais.update', [$obra, $local]) }}">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label class="form-label" for="name">Nome do local *</label>
                <input class="form-control" type="text" id="name" name="name" required maxlength="120"
                       value="{{ old('name', $local->name) }}">
                <span class="form-hint">O nome não pode repetir dentro desta obra.</span>
                @error('name')<span class="form-error">{{ $message }}</span>@enderror
            </div>

            <div class="form-group">
                <label class="form-check">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $local->is_active))>
                    <span>Local ativo</span>
                </label>
                @error('is_active')<span class="form-error">{{ $message }}</span>@enderror
            </div>

            <button class="btn btn-primary btn-block" type="submit">Salvar alterações</button>
        </form>
    </div>
</div>
@endsection
