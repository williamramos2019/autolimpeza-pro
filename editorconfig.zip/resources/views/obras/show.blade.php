@extends('layouts.app')

@section('title', 'Obra ' . $obra->code)

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'obras'])

    <div class="page-header">
        <h1 class="page-title">
            {{ $obra->name }}
            <span class="page-subtitle">Código {{ $obra->code }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('obras.index') }}">Voltar</a>
    </div>

    @include('partials.flash')

    <div class="card">
        <div class="card-header">Dados da obra</div>
        <div class="card-body">
            <span class="badge badge-{{ $obra->status->badgeModifier() }}">{{ $obra->status->label() }}</span>
            <div class="card-meta">
                <span class="card-meta-item">Cliente: {{ $obra->client_name }}</span>
                <span class="card-meta-item">Endereço: {{ $obra->address }}</span>
                <span class="card-meta-item">Cidade: {{ $obra->city }}</span>
                <span class="card-meta-item">Responsável: {{ $obra->responsibleUser?->name ?? 'não definido' }}</span>
                <span class="card-meta-item">Início: {{ $obra->start_date?->format('d/m/Y') }}</span>
                <span class="card-meta-item">
                    Término previsto: {{ $obra->expected_end_date?->format('d/m/Y') ?? 'não informado' }}
                </span>
            </div>
        </div>
        <div class="card-actions">
            @can('update', $obra)
                <a class="btn btn-primary" href="{{ route('obras.edit', $obra) }}">Editar</a>
            @endcan
            <a class="btn btn-secondary" href="{{ route('obras.locais.index', $obra) }}">
                Locais ({{ $obra->locais->count() }})
            </a>
            @can('manageUsers', $obra)
                <a class="btn btn-secondary" href="{{ route('obras.usuarios.index', $obra) }}">Usuários</a>
            @endcan
        </div>
    </div>

    @can('delete', $obra)
        <div class="card">
            <div class="card-header">Inativar obra</div>
            <div class="card-body">
                Inativar arquiva a obra (soft delete): ela sai das listagens e de qualquer
                seleção de origem/destino de movimentação. O histórico é preservado.
            </div>
            <form method="POST" action="{{ route('obras.destroy', $obra) }}"
                  onsubmit="return confirm('Inativar (arquivar) esta obra?');">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger btn-block mt-2" type="submit">Inativar obra</button>
            </form>
        </div>
    @endcan
</div>
@endsection
