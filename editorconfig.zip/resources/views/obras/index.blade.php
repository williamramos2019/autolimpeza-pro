@extends('layouts.app')

@section('title', 'Obras')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'obras'])

    <div class="page-header">
        <h1 class="page-title">
            Obras
            <span class="page-subtitle">{{ $obras->total() }} obra(s) ativa(s)</span>
        </h1>
        @if ($podeGerenciar)
            <a class="btn btn-primary" href="{{ route('obras.create') }}">Nova obra</a>
        @endif
    </div>

    @include('partials.flash')

    <form class="search-bar" method="GET" action="{{ route('obras.index') }}">
        <label class="form-label" for="q" style="width:100%">Buscar por código, nome ou cidade</label>
        <input class="form-control" type="search" id="q" name="q" value="{{ $search }}"
               placeholder="Ex.: OBR-1024, Residencial, Recife">
        <select class="form-control" name="status" aria-label="Filtrar por status">
            <option value="">Todos os status</option>
            @foreach ($statuses as $case)
                <option value="{{ $case->value }}" @selected($status === $case->value)>{{ $case->label() }}</option>
            @endforeach
        </select>
        <button class="btn btn-primary" type="submit">Buscar</button>
    </form>

    <ul class="card-list">
        @forelse ($obras as $obra)
            <li class="card">
                <div class="card-title">{{ $obra->name }}</div>
                <div class="card-meta">
                    <span class="badge badge-{{ $obra->status->badgeModifier() }}">{{ $obra->status->label() }}</span>
                    <span class="card-meta-item">Código: {{ $obra->code }}</span>
                    <span class="card-meta-item">Cliente: {{ $obra->client_name }}</span>
                    <span class="card-meta-item">Cidade: {{ $obra->city }}</span>
                    <span class="card-meta-item">
                        Responsável: {{ $obra->responsibleUser?->name ?? 'não definido' }}
                    </span>
                </div>
                <div class="card-actions">
                    <a class="btn btn-secondary" href="{{ route('obras.show', $obra) }}">Detalhes</a>
                    <a class="btn btn-secondary" href="{{ route('obras.locais.index', $obra) }}">Locais</a>
                    @if ($podeGerenciar)
                        <a class="btn btn-primary" href="{{ route('obras.edit', $obra) }}">Editar</a>
                    @endif
                </div>
            </li>
        @empty
            <li class="empty-state">Nenhuma obra encontrada.</li>
        @endforelse
    </ul>

    @include('partials.paginacao', ['paginator' => $obras])
</div>
@endsection
