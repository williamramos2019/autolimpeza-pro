@extends('layouts.app')

@section('title', 'Editar obra')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'obras'])

    <div class="page-header">
        <h1 class="page-title">
            Editar obra
            <span class="page-subtitle">{{ $obra->code }} — {{ $obra->name }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('obras.show', $obra) }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('obras.update', $obra) }}">
            @csrf
            @method('PUT')
            @include('obras._form', ['obra' => $obra])
            <button class="btn btn-primary btn-block" type="submit">Salvar alterações</button>
        </form>
    </div>
</div>
@endsection
