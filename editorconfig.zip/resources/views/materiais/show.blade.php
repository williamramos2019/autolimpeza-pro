@extends('layouts.app')

@section('title', 'Material ' . $material->code)

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'materiais'])

    <div class="page-header">
        <h1 class="page-title">
            {{ $material->description }}
            <span class="page-subtitle">Código {{ $material->code }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('materiais.index') }}">Voltar</a>
    </div>

    @include('partials.flash')

    <div class="card">
        <div class="card-header">Dados do material</div>
        <div class="card-body">
            <span class="badge {{ $material->is_active ? 'badge-ativo' : 'badge-inativo' }}">
                {{ $material->is_active ? 'Ativo' : 'Inativo' }}
            </span>
            <div class="card-meta">
                <span class="card-meta-item">Categoria: {{ $material->category->name }}</span>
                <span class="card-meta-item">
                    Unidade: {{ $material->unit->code }} ({{ $material->unit->label }})
                </span>
                <span class="card-meta-item">Marca: {{ $material->brand ?? 'não informada' }}</span>
                <span class="card-meta-item">Modelo: {{ $material->model ?? 'não informado' }}</span>
                <span class="card-meta-item">
                    Código interno: {{ $material->internal_code ?? 'não informado' }}
                </span>
                <span class="card-meta-item">Estoque mínimo: {{ $material->min_stock }}</span>
            </div>

            @if ($material->primary_photo_path)
                <img class="mt-2" src="{{ asset('storage/' . $material->primary_photo_path) }}"
                     alt="Foto do material {{ $material->code }}" style="max-width:100%; border-radius:8px;">
            @endif
        </div>

        @can('update', $material)
            <div class="card-actions">
                <a class="btn btn-primary" href="{{ route('materiais.edit', $material) }}">Editar</a>
                <form method="POST" action="{{ route('materiais.toggle', $material) }}">
                    @csrf
                    @method('PATCH')
                    <button class="btn btn-secondary" type="submit">
                        {{ $material->is_active ? 'Inativar' : 'Ativar' }}
                    </button>
                </form>
            </div>
        @endcan
    </div>

    @can('delete', $material)
        <div class="card">
            <div class="card-header">Excluir material</div>
            <div class="card-body">
                A exclusão é sempre um arquivamento (soft delete): o material sai do
                catálogo e as movimentações que o referenciam permanecem íntegras.
            </div>
            <form method="POST" action="{{ route('materiais.destroy', $material) }}"
                  onsubmit="return confirm('Excluir (arquivar) este material?');">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger btn-block mt-2" type="submit">Excluir material</button>
            </form>
        </div>
    @endcan
</div>
@endsection
