@php($material = $material ?? null)

<div class="form-group">
    <label class="form-label" for="code">Código *</label>
    <input class="form-control" type="text" id="code" name="code" required maxlength="50"
           value="{{ old('code', $material?->code) }}">
    @error('code')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="description">Descrição *</label>
    <input class="form-control" type="text" id="description" name="description" required maxlength="255"
           value="{{ old('description', $material?->description) }}">
    @error('description')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="material_category_id">Categoria *</label>
    <select class="form-control" id="material_category_id" name="material_category_id" required>
        <option value="">Selecione</option>
        @foreach ($categorias as $categoria)
            <option value="{{ $categoria->id }}"
                @selected((int) old('material_category_id', $material?->material_category_id) === $categoria->id)>
                {{ $categoria->name }}
            </option>
        @endforeach
    </select>
    @error('material_category_id')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="material_unit_id">Unidade de medida *</label>
    <select class="form-control" id="material_unit_id" name="material_unit_id" required>
        <option value="">Selecione</option>
        @foreach ($unidades as $unidade)
            <option value="{{ $unidade->id }}"
                @selected((int) old('material_unit_id', $material?->material_unit_id) === $unidade->id)>
                {{ $unidade->code }} — {{ $unidade->label }}
            </option>
        @endforeach
    </select>
    @error('material_unit_id')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="brand">Marca</label>
    <input class="form-control" type="text" id="brand" name="brand" maxlength="120"
           value="{{ old('brand', $material?->brand) }}">
    @error('brand')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="model">Modelo</label>
    <input class="form-control" type="text" id="model" name="model" maxlength="120"
           value="{{ old('model', $material?->model) }}">
    @error('model')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="internal_code">Código interno</label>
    <input class="form-control" type="text" id="internal_code" name="internal_code" maxlength="50"
           value="{{ old('internal_code', $material?->internal_code) }}">
    @error('internal_code')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="min_stock">Estoque mínimo *</label>
    <input class="form-control" type="number" id="min_stock" name="min_stock" step="0.001" min="0" required
           value="{{ old('min_stock', $material?->min_stock ?? '0') }}">
    @error('min_stock')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-label" for="primary_photo">Foto principal</label>
    <input class="form-control" type="file" id="primary_photo" name="primary_photo" accept="image/jpeg,image/png,image/webp">
    <span class="form-hint">Opcional. JPEG, PNG ou WebP, até 4 MB.</span>
    @error('primary_photo')<span class="form-error">{{ $message }}</span>@enderror
</div>

<div class="form-group">
    <label class="form-check">
        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $material?->is_active ?? true))>
        <span>Material ativo</span>
    </label>
    <span class="form-hint">Material inativo não aparece na seleção de materiais para movimentação.</span>
    @error('is_active')<span class="form-error">{{ $message }}</span>@enderror
</div>
