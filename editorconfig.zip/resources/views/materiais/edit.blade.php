@extends('layouts.app')

@section('title', 'Editar material')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'materiais'])

    <div class="page-header">
        <h1 class="page-title">
            Editar material
            <span class="page-subtitle">{{ $material->code }} — {{ $material->description }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('materiais.show', $material) }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('materiais.update', $material) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            @include('materiais._form', ['material' => $material])
            <button class="btn btn-primary btn-block" type="submit">Salvar alterações</button>
        </form>
    </div>
</div>
@endsection
