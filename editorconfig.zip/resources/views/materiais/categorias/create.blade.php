@extends('layouts.app')

@section('title', 'Nova categoria')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'categorias'])

    <div class="page-header">
        <h1 class="page-title">Nova categoria</h1>
        <a class="btn btn-secondary" href="{{ route('materiais.categorias.index') }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('materiais.categorias.store') }}">
            @csrf

            <div class="form-group">
                <label class="form-label" for="name">Nome *</label>
                <input class="form-control" type="text" id="name" name="name" required maxlength="120"
                       value="{{ old('name') }}">
                <span class="form-hint">O nome da categoria é único no sistema.</span>
                @error('name')<span class="form-error">{{ $message }}</span>@enderror
            </div>

            <div class="form-group">
                <label class="form-check">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', true))>
                    <span>Categoria ativa</span>
                </label>
                @error('is_active')<span class="form-error">{{ $message }}</span>@enderror
            </div>

            <button class="btn btn-primary btn-block" type="submit">Cadastrar categoria</button>
        </form>
    </div>
</div>
@endsection
