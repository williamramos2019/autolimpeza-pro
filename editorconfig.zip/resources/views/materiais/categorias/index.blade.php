@extends('layouts.app')

@section('title', 'Categorias de material')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'categorias'])

    <div class="page-header">
        <h1 class="page-title">
            Categorias
            <span class="page-subtitle">{{ $categorias->total() }} categoria(s)</span>
        </h1>
        @if ($podeGerenciar)
            <a class="btn btn-primary" href="{{ route('materiais.categorias.create') }}">Nova categoria</a>
        @endif
    </div>

    @include('partials.flash')

    <form class="search-bar" method="GET" action="{{ route('materiais.categorias.index') }}">
        <label class="form-label" for="q" style="width:100%">Buscar categoria por nome</label>
        <input class="form-control" type="search" id="q" name="q" value="{{ $search }}"
               placeholder="Ex.: Elétrica">
        <button class="btn btn-primary" type="submit">Buscar</button>
    </form>

    <ul class="card-list">
        @forelse ($categorias as $categoria)
            <li class="card">
                <div class="card-title">{{ $categoria->name }}</div>
                <div class="card-meta">
                    <span class="badge {{ $categoria->is_active ? 'badge-ativo' : 'badge-inativo' }}">
                        {{ $categoria->is_active ? 'Ativa' : 'Inativa' }}
                    </span>
                    <span class="card-meta-item">{{ $categoria->materials_count }} material(is)</span>
                </div>
                @if ($podeGerenciar)
                    <div class="card-actions">
                        <a class="btn btn-secondary" href="{{ route('materiais.categorias.edit', $categoria) }}">Editar</a>
                        <form method="POST" action="{{ route('materiais.categorias.toggle', $categoria) }}">
                            @csrf
                            @method('PATCH')
                            <button class="btn btn-primary" type="submit">
                                {{ $categoria->is_active ? 'Inativar' : 'Ativar' }}
                            </button>
                        </form>
                        <form method="POST" action="{{ route('materiais.categorias.destroy', $categoria) }}"
                              onsubmit="return confirm('Excluir (arquivar) esta categoria?');">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger" type="submit">Excluir</button>
                        </form>
                    </div>
                @endif
            </li>
        @empty
            <li class="empty-state">Nenhuma categoria encontrada.</li>
        @endforelse
    </ul>

    @include('partials.paginacao', ['paginator' => $categorias])
</div>
@endsection
