@extends('layouts.app')

@section('title', 'Novo material')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'materiais'])

    <div class="page-header">
        <h1 class="page-title">Novo material</h1>
        <a class="btn btn-secondary" href="{{ route('materiais.index') }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('materiais.store') }}" enctype="multipart/form-data">
            @csrf
            @include('materiais._form', ['material' => null])
            <button class="btn btn-primary btn-block" type="submit">Cadastrar material</button>
        </form>
    </div>
</div>
@endsection
