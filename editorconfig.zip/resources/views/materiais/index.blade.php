@extends('layouts.app')

@section('title', 'Materiais')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'materiais'])

    <div class="page-header">
        <h1 class="page-title">
            Materiais
            <span class="page-subtitle">{{ $materiais->total() }} material(is) no catálogo</span>
        </h1>
        @if ($podeGerenciar)
            <a class="btn btn-primary" href="{{ route('materiais.create') }}">Novo material</a>
        @endif
    </div>

    @include('partials.flash')

    <form class="search-bar" method="GET" action="{{ route('materiais.index') }}">
        <label class="form-label" for="q" style="width:100%">Buscar por código, descrição ou código interno</label>
        <input class="form-control" type="search" id="q" name="q" value="{{ $search }}"
               placeholder="Ex.: MAT-1024, cimento">
        <select class="form-control" name="categoria" aria-label="Filtrar por categoria">
            <option value="">Todas as categorias</option>
            @foreach ($categorias as $cat)
                <option value="{{ $cat->id }}" @selected($categoria === $cat->id)>{{ $cat->name }}</option>
            @endforeach
        </select>
        <label class="form-check">
            <input type="checkbox" name="ativos" value="1" @checked($apenasAtivos)>
            <span>Somente ativos</span>
        </label>
        <button class="btn btn-primary" type="submit">Buscar</button>
    </form>

    <ul class="card-list">
        @forelse ($materiais as $material)
            <li class="card">
                <div class="card-title">{{ $material->description }}</div>
                <div class="card-meta">
                    <span class="badge {{ $material->is_active ? 'badge-ativo' : 'badge-inativo' }}">
                        {{ $material->is_active ? 'Ativo' : 'Inativo' }}
                    </span>
                    <span class="card-meta-item">Código: {{ $material->code }}</span>
                    <span class="card-meta-item">Categoria: {{ $material->category->name }}</span>
                    <span class="card-meta-item">
                        Unidade: {{ $material->unit->code }} ({{ $material->unit->label }})
                    </span>
                    <span class="card-meta-item">Estoque mínimo: {{ $material->min_stock }}</span>
                </div>
                <div class="card-actions">
                    <a class="btn btn-secondary" href="{{ route('materiais.show', $material) }}">Detalhes</a>
                    @if ($podeGerenciar)
                        <a class="btn btn-primary" href="{{ route('materiais.edit', $material) }}">Editar</a>
                        <form method="POST" action="{{ route('materiais.toggle', $material) }}">
                            @csrf
                            @method('PATCH')
                            <button class="btn btn-secondary" type="submit">
                                {{ $material->is_active ? 'Inativar' : 'Ativar' }}
                            </button>
                        </form>
                    @endif
                </div>
            </li>
        @empty
            <li class="empty-state">Nenhum material encontrado.</li>
        @endforelse
    </ul>

    @include('partials.paginacao', ['paginator' => $materiais])
</div>
@endsection
