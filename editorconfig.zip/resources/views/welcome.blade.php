@extends('layouts.app')

@section('title', 'Bem-vindo - Materiais em Obras')

@section('content')
<div class="container" style="padding-top: 40px;">
    <div class="card">
        <div class="card-header">Bem-vindo ao Sistema de Controle de Materiais</div>
        <div class="card-body">
            <p style="margin-bottom: 16px;">
                Sistema para gerenciamento e controle de movimentação de materiais em obras.
            </p>
            <p style="color: #757575;">
                Laravel {{ Illuminate\Foundation\Application::VERSION }} (PHP {{ PHP_VERSION }})
            </p>
        </div>
    </div>
</div>
@endsection
