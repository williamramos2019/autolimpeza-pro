@if ($paginator->hasPages())
    <nav class="pagination" aria-label="Paginação">
        @if ($paginator->onFirstPage())
            <span class="pagination-item is-disabled">Anterior</span>
        @else
            <a class="pagination-item" href="{{ $paginator->previousPageUrl() }}" rel="prev">Anterior</a>
        @endif

        <span class="pagination-status">
            Página {{ $paginator->currentPage() }} de {{ $paginator->lastPage() }}
        </span>

        @if ($paginator->hasMorePages())
            <a class="pagination-item" href="{{ $paginator->nextPageUrl() }}" rel="next">Próxima</a>
        @else
            <span class="pagination-item is-disabled">Próxima</span>
        @endif
    </nav>
@endif
