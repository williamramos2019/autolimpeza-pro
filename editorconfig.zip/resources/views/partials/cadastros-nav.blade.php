@php($atual = $atual ?? '')

<nav class="cadastros-nav" aria-label="Cadastros">
    @if (auth()->user()?->hasPermission('dashboards.gestor'))
        <a class="cadastros-nav-item @if ($atual === 'dashboard') active @endif" href="{{ route('dashboard') }}">Dashboard</a>
    @endif

    @can('viewAny', App\Models\Obra::class)
        <a class="cadastros-nav-item @if ($atual === 'obras') active @endif" href="{{ route('obras.index') }}">Obras</a>
    @endcan

    @can('viewAny', App\Models\Material::class)
        <a class="cadastros-nav-item @if ($atual === 'materiais') active @endif" href="{{ route('materiais.index') }}">Materiais</a>
    @endcan

    @can('viewAny', App\Models\MaterialCategory::class)
        <a class="cadastros-nav-item @if ($atual === 'categorias') active @endif" href="{{ route('materiais.categorias.index') }}">Categorias</a>
    @endcan

    @can('viewAny', App\Models\Movement::class)
        <a class="cadastros-nav-item @if ($atual === 'movimentacoes') active @endif" href="{{ route('movimentacoes.index') }}">Movimentações</a>
        <a class="cadastros-nav-item @if ($atual === 'qr') active @endif" href="{{ route('qr.ler') }}">Ler QR</a>
    @endcan

    @can('viewAny', App\Models\PendingMaterial::class)
        <a class="cadastros-nav-item @if ($atual === 'pendencias') active @endif" href="{{ route('pendencias.index') }}">Pendências</a>
    @endcan

    <a class="cadastros-nav-item" href="{{ route('home') }}">Início</a>
</nav>
