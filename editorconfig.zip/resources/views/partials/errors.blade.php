@if ($errors->any())
    <div class="alert alert-error" role="alert">
        <strong>Corrija os campos abaixo:</strong>
        <ul class="alert-list mt-1">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
