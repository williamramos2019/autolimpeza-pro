<div id="pwa-status" class="pwa-shell" data-state="online" role="status">
    <div>
        <div id="pwa-status-label" class="pwa-status-label">ONLINE</div>
        <div id="pwa-pending-count" class="pwa-pending-count">0 operações pendentes</div>
    </div>
    <div class="pwa-actions">
        <button type="button" class="btn" id="pwa-sync">SINCRONIZAR AGORA</button>
        <button type="button" class="btn" id="pwa-retry">Tentar novamente</button>
        <button type="button" class="btn" id="pwa-install" hidden>Instalar aplicativo</button>
    </div>
    <p id="pwa-install-hint" class="pwa-install-hint" hidden>
        Android: menu do navegador → Adicionar à tela inicial.
        iPhone: Compartilhar → Adicionar à tela de início.
        A operação continua sem instalar.
    </p>
    <div id="pwa-update-banner" class="pwa-update-banner" hidden>
        <span>Nova versão disponível. Atualizar agora.</span>
        <button type="button" class="btn" id="pwa-update">Atualizar agora</button>
    </div>
    <span class="visually-hidden">OFFLINE Aguardando conexão Sincronizando... Sincronizado Falha na sincronização</span>
</div>
