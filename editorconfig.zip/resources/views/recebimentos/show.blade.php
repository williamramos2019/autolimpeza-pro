@extends('layouts.app')

@section('title', 'Recebimento '.$movement->code)

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'movimentacoes'])

    <div class="page-header">
        <h1 class="page-title">
            Recebimento {{ $movement->code }}
            <span class="page-subtitle">{{ $movement->type()->label() }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('movimentacoes.show', $movement) }}">Voltar</a>
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <div class="card">
        <div class="card-header">
            <span class="badge badge-{{ $movement->status->badgeModifier() }}">
                {{ $movement->status->label() }}
            </span>
        </div>
        <div class="card-body">
            <div class="card-meta">
                <span class="card-meta-item">Origem: {{ $movement->originObra?->name }} / {{ $movement->originLocal?->name }}</span>
                <span class="card-meta-item">Destino: {{ $movement->destinationObra?->name }} / {{ $movement->destinationLocal?->name }}</span>
                <span class="card-meta-item">Remetente: {{ $movement->sender?->name ?? '—' }}</span>
                @if ($receipt)
                    <span class="card-meta-item">Recebedor: {{ $receipt->receiver?->name ?? '—' }}</span>
                @endif
            </div>
        </div>
    </div>

    @if ($podeIniciar)
        <form method="POST" action="{{ route('movimentacoes.receber.store', $movement) }}" class="mt-3" data-offline-form="receipt.start">
            @csrf
            <button class="btn btn-primary btn-lg btn-block" type="submit">Iniciar recebimento</button>
        </form>
    @endif

    @if ($receipt)
        <h2 class="page-title mt-3">Materiais</h2>
        <ul class="card-list">
            @foreach ($receipt->items as $item)
                @php($mi = $item->movementItem)
                <li class="card conference-card">
                    <div class="card-title">{{ $mi?->description_snapshot ?? 'Item' }}</div>
                    <div class="card-meta">
                        <span class="card-meta-item">
                            Quantidade enviada: {{ $mi?->qty_sent }} {{ $mi?->unit?->code }}
                        </span>
                        @if ($item->isConferenced())
                            <span class="card-meta-item">
                                Recebida: {{ $item->qty_received }} {{ $mi?->unit?->code }}
                            </span>
                            @if ($item->resultado() === 'falta')
                                <span class="badge badge-divergente">Falta {{ $item->qty_difference }}</span>
                            @elseif ($item->resultado() === 'sobra')
                                <span class="badge badge-divergente">Sobra {{ ltrim((string) $item->qty_difference, '-') }}</span>
                            @else
                                <span class="badge badge-conferido">Conferido</span>
                            @endif
                        @else
                            <span class="badge badge-rascunho">Pendente</span>
                        @endif
                        <span class="card-meta-item">Fotos: {{ $item->photos->count() }}</span>
                    </div>
                    @if ($podeConferir)
                        <div class="card-actions">
                            <a class="btn btn-primary" href="{{ route('movimentacoes.conferir', [$movement, $item]) }}">
                                {{ $item->isConferenced() ? 'Revisar item' : 'Conferir item' }}
                            </a>
                        </div>
                    @endif
                </li>
            @endforeach
        </ul>

        @if ($podeFinalizar)
            <form method="POST" action="{{ route('movimentacoes.finalizar', $movement) }}" class="mt-3">
                @csrf
                <button class="btn btn-primary btn-lg btn-block" type="submit"
                        onclick="return confirm('Finalizar o recebimento? Itens sem conferência bloqueiam esta ação.');">
                    Finalizar recebimento
                </button>
            </form>
        @endif
    @endif
</div>
@endsection
