@extends('layouts.app')

@section('title', 'Conferir item')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'movimentacoes'])

    <div class="page-header">
        <h1 class="page-title">{{ $item->movementItem?->description_snapshot }}</h1>
        <a class="btn btn-secondary" href="{{ route('movimentacoes.receber', $movement) }}">Voltar</a>
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <div class="card">
        <div class="card-meta">
            <span class="card-meta-item">
                Quantidade enviada:
                <strong>{{ $item->movementItem?->qty_sent }} {{ $item->movementItem?->unit?->code }}</strong>
            </span>
            <span class="card-meta-item">Código: {{ $item->movementItem?->material?->code ?? '—' }}</span>
            @if ($item->isConferenced())
                <span class="card-meta-item">
                    Resultado:
                    @if ($item->resultado() === 'falta') Falta
                    @elseif ($item->resultado() === 'sobra') Sobra
                    @else Conferido
                    @endif
                </span>
            @endif
        </div>
    </div>

    <form method="POST" action="{{ route('movimentacoes.conferir.store', [$movement, $item]) }}" class="mt-3" data-offline-form="receipt.conference">
        @csrf
        <div class="form-group">
            <label class="form-label" for="qty_received">Quantidade recebida *</label>
            <input class="form-control" type="text" inputmode="decimal" id="qty_received"
                   name="qty_received" required
                   value="{{ old('qty_received', $item->qty_received) }}"
                   autocomplete="off">
            <p class="form-hint">Use até 3 casas decimais. Zero significa falta total.</p>
            @error('qty_received')<span class="form-error">{{ $message }}</span>@enderror
        </div>
        <button class="btn btn-primary btn-lg btn-block" type="submit">Registrar conferência</button>
    </form>

    <h2 class="page-title mt-3">Fotografia</h2>
    <form method="POST" action="{{ route('movimentacoes.fotos.store', [$movement, $item]) }}"
          enctype="multipart/form-data" class="conference-photo-form" data-offline-photo="receipt.photo">
        @csrf
        <input type="hidden" name="idempotency_key" value="{{ old('idempotency_key', (string) \Illuminate\Support\Str::uuid()) }}">
        <div class="form-group">
            <label class="form-label" for="photo">Fotografar o material</label>
            <input class="form-control" type="file" id="photo" name="photo"
                   accept="image/*" capture="environment" required>
            <p class="form-hint">JPEG, PNG ou WebP. Até 4 MB. A câmera traseira abre quando o celular permitir.</p>
            @error('photo')<span class="form-error">{{ $message }}</span>@enderror
        </div>
        <input type="hidden" name="latitude" id="latitude" value="">
        <input type="hidden" name="longitude" id="longitude" value="">
        <input type="hidden" id="geo-accuracy" value="">
        <input type="hidden" id="geo-timestamp" value="">
        <p class="form-hint" id="geo-status">A localização será anexada se você autorizar. Negar não impede a foto.</p>
        <button class="btn btn-secondary btn-lg btn-block" type="submit">Salvar fotografia</button>
    </form>

    @if ($item->photos->isNotEmpty())
        <ul class="card-list mt-3">
            @foreach ($item->photos as $foto)
                <li class="card">
                    <img class="conference-thumb" src="{{ asset('storage/'.$foto->path) }}" alt="Foto da conferência">
                    <div class="card-meta">
                        <span class="card-meta-item">{{ $foto->taken_at?->format('d/m/Y H:i') }}</span>
                        @if ($foto->latitude)
                            <span class="card-meta-item">{{ $foto->latitude }}, {{ $foto->longitude }}</span>
                        @endif
                    </div>
                </li>
            @endforeach
        </ul>
    @endif
</div>
@endsection

@push('scripts')
<script src="{{ asset('js/conferencia.js') }}" defer></script>
@endpush
