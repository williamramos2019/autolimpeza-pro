@extends('layouts.app')

@section('title', 'Nova movimentação')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'movimentacoes'])

    <div class="page-header">
        <h1 class="page-title">
            Nova movimentação
            <span class="page-subtitle">Origem → Destino → Materiais → Quantidades → Revisão → Enviar</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('movimentacoes.index') }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('movimentacoes.store') }}" data-offline-form="movement.draft" data-offline-draft="1">
            @csrf
            <input type="hidden" name="idempotency_key" value="{{ old('idempotency_key', (string) \Illuminate\Support\Str::uuid()) }}">
            @include('movimentacoes._form', ['movement' => null])
            <button class="btn btn-primary btn-block btn-lg" type="submit">
                Salvar rascunho e revisar
            </button>
        </form>
    </div>
</div>
@endsection
