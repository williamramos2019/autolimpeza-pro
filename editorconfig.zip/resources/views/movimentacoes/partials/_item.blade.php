@php
    // $index pode ser o índice real da linha ou o placeholder __INDEX__ usado pelo
    // <template> que o JS clona. $item é um array simples (item persistido, `old()`
    // ou linha vazia).
    $item = $item ?? [];
    $itemId = $item['id'] ?? null;
    $materialSelecionado = (int) ($item['material_id'] ?? 0);
    $quantidade = $item['qty_sent'] ?? '';
    $observacao = $item['notes'] ?? '';
@endphp

<li class="item-row" data-item-row>
    @if ($itemId)
        <input type="hidden" name="items[{{ $index }}][id]" value="{{ $itemId }}">
    @endif

    <div class="form-group">
        <label class="form-label" for="item-{{ $index }}-material">Material *</label>
        <select class="form-control" id="item-{{ $index }}-material"
                name="items[{{ $index }}][material_id]" required>
            <option value="">Selecione o material</option>
            @foreach ($materiais as $material)
                <option value="{{ $material->id }}" @selected($materialSelecionado === $material->id)>
                    {{ $material->code }} — {{ $material->description }}
                </option>
            @endforeach
        </select>
        @error("items.{$index}.material_id")<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <div class="form-group">
        <label class="form-label" for="item-{{ $index }}-qty">Quantidade *</label>
        {{-- inputmode="decimal" abre o teclado numérico no celular; step casa com
             decimal(12,3) do banco. --}}
        <input class="form-control" type="text" id="item-{{ $index }}-qty"
               name="items[{{ $index }}][qty_sent]" value="{{ $quantidade }}"
               inputmode="decimal" autocomplete="off" required
               placeholder="Ex.: 12.5">
        <span class="form-hint">
            Maior que zero, no máximo 3 casas decimais. Use ponto como separador
            (a vírgula é convertida automaticamente).
        </span>
        @error("items.{$index}.qty_sent")<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <div class="form-group">
        <label class="form-label" for="item-{{ $index }}-notes">Observação do item</label>
        <input class="form-control" type="text" id="item-{{ $index }}-notes"
               name="items[{{ $index }}][notes]" value="{{ $observacao }}" maxlength="500">
        @error("items.{$index}.notes")<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <button class="btn btn-danger btn-block" type="button" data-remover-item>Remover item</button>
</li>
