@extends('layouts.app')

@section('title', 'Histórico '.$movement->code)

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'movimentacoes'])

    <div class="page-header">
        <h1 class="page-title">
            {{ $movement->code }}
            <span class="page-subtitle">{{ $movement->type()->label() }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('movimentacoes.show', $movement) }}">Voltar</a>
    </div>

    <div class="card">
        <div class="card-header">
            <span class="badge badge-{{ $movement->status->badgeModifier() }}">{{ $movement->status->label() }}</span>
        </div>
        <div class="card-meta">
            <span class="card-meta-item">UUID: {{ $movement->uuid }}</span>
            <span class="card-meta-item">Criada em {{ $movement->created_at?->format('d/m/Y H:i') }}</span>
            @if ($movement->sent_at)
                <span class="card-meta-item">Enviada em {{ $movement->sent_at->format('d/m/Y H:i') }}</span>
            @endif
            @if ($movement->completed_at)
                <span class="card-meta-item">Concluída em {{ $movement->completed_at->format('d/m/Y H:i') }}</span>
            @endif
        </div>
    </div>

    <div class="card">
        <div class="card-title">Rota</div>
        <div class="card-meta">
            <span class="card-meta-item">Origem: {{ $movement->originObra?->name }} / {{ $movement->originLocal?->name }}</span>
            <span class="card-meta-item">Destino: {{ $movement->destinationObra?->name }} / {{ $movement->destinationLocal?->name }}</span>
            <span class="card-meta-item">Remetente: {{ $movement->sender?->name ?? '—' }}</span>
            <span class="card-meta-item">Transporte: {{ $movement->transporter?->name ?? $movement->transporter_name ?? '—' }}</span>
            @if ($movement->receipt)
                <span class="card-meta-item">Recebedor: {{ $movement->receipt->receiver?->name ?? '—' }}</span>
            @endif
        </div>
    </div>

    <h2 class="page-title mt-3">Itens</h2>
    <ul class="card-list">
        @foreach ($movement->items as $item)
            @php($recibo = $item->receiptItem)
            <li class="card">
                <div class="card-title">{{ $item->description_snapshot }}</div>
                <div class="card-meta">
                    <span class="card-meta-item">Código: {{ $item->material?->code ?? '—' }}</span>
                    <span class="card-meta-item">Unidade: {{ $item->unit?->code }}</span>
                    <span class="card-meta-item">Quantidade enviada: {{ $item->qty_sent }}</span>
                    <span class="card-meta-item">Quantidade recebida: {{ $recibo?->qty_received ?? '—' }}</span>
                    <span class="card-meta-item">Diferença: {{ $recibo?->qty_difference ?? '—' }}</span>
                    @if ($recibo?->isConferenced())
                        <span class="card-meta-item">
                            Situação:
                            @if ($recibo->resultado() === 'falta') Falta
                            @elseif ($recibo->resultado() === 'sobra') Sobra
                            @else Conferido
                            @endif
                        </span>
                        <span class="card-meta-item">Conferido por: {{ $recibo->conferencedBy?->name ?? '—' }}</span>
                        <span class="card-meta-item">{{ $recibo->conferenced_at?->format('d/m/Y H:i') }}</span>
                    @else
                        <span class="card-meta-item">Situação: sem conferência</span>
                    @endif
                </div>
            </li>
        @endforeach
    </ul>

    @if ($movement->divergences->isNotEmpty())
        <h2 class="page-title mt-3">Divergências</h2>
        <ul class="card-list">
            @foreach ($movement->divergences as $divergencia)
                <li class="card">
                    <div class="card-title">{{ $divergencia->material?->description }}</div>
                    <div class="card-meta">
                        <span class="card-meta-item">Enviado: {{ $divergencia->qty_sent }}</span>
                        <span class="card-meta-item">Recebido: {{ $divergencia->qty_received }}</span>
                        <span class="card-meta-item">Diferença: {{ $divergencia->qty_missing }}</span>
                        <span class="card-meta-item">
                            Tipo: {{ (float) $divergencia->qty_missing > 0 ? 'FALTA' : 'SOBRA' }}
                        </span>
                        <span class="card-meta-item">Status: {{ $divergencia->status->label() }}</span>
                    </div>
                </li>
            @endforeach
        </ul>
    @endif

    @if ($movement->pendingMaterials->isNotEmpty())
        <h2 class="page-title mt-3">Pendências e resoluções</h2>
        @foreach ($movement->pendingMaterials as $pendencia)
            <div class="card">
                <div class="card-title">
                    {{ $pendencia->material?->description }}
                    <span class="badge badge-{{ $pendencia->status->badgeModifier() }}">{{ $pendencia->status->label() }}</span>
                    <span class="badge badge-divergente">{{ $pendencia->tipo() === 'sobra' ? 'SOBRA' : 'FALTA' }}</span>
                </div>
                <div class="card-meta">
                    <span class="card-meta-item">Original: {{ $pendencia->qtyOriginal() }}</span>
                    <span class="card-meta-item">Pendente: {{ $pendencia->qty_pending }}</span>
                    <span class="card-meta-item">Aberta em {{ $pendencia->created_at?->format('d/m/Y H:i') }}</span>
                    @if ($pendencia->resolved_at)
                        <span class="card-meta-item">Resolvida em {{ $pendencia->resolved_at->format('d/m/Y H:i') }}</span>
                    @endif
                </div>
                @foreach ($pendencia->resolutions as $resolucao)
                    <div class="card-meta">
                        <span class="card-meta-item">Resolução: {{ $resolucao->qty_delivered }}</span>
                        <span class="card-meta-item">{{ $resolucao->user?->name }}</span>
                        <span class="card-meta-item">{{ $resolucao->delivered_at?->format('d/m/Y H:i') }}</span>
                        @if ($resolucao->notes)
                            <span class="card-meta-item">{{ $resolucao->notes }}</span>
                        @endif
                    </div>
                @endforeach
            </div>
        @endforeach
    @endif

    @php($fotos = $movement->items->flatMap(fn ($item) => $item->receiptItem?->photos ?? collect()))
    @if ($fotos->isNotEmpty())
        <h2 class="page-title mt-3">Evidências</h2>
        <ul class="card-list">
            @foreach ($fotos as $foto)
                <li class="card">
                    <img class="conference-thumb" src="{{ asset('storage/'.$foto->path) }}" alt="Evidência da conferência">
                    <div class="card-meta">
                        <span class="card-meta-item">{{ $foto->taken_at?->format('d/m/Y H:i') }}</span>
                        @if ($foto->latitude)
                            <span class="card-meta-item">{{ $foto->latitude }}, {{ $foto->longitude }}</span>
                        @endif
                    </div>
                </li>
            @endforeach
        </ul>
    @endif

    <h2 class="page-title mt-3">Linha do tempo</h2>
    <ol class="timeline">
        @foreach ($eventos as $evento)
            <li class="timeline-item">
                <div class="timeline-when">{{ $evento['at']?->format('d/m/Y H:i') }}</div>
                <div class="timeline-title">{{ $evento['titulo'] }}</div>
                <div class="timeline-detail">{{ $evento['detalhe'] }}</div>
                @if ($evento['usuario'])
                    <div class="timeline-user">Usuário: {{ $evento['usuario'] }}</div>
                @endif
            </li>
        @endforeach
    </ol>
</div>
@endsection
