@extends('layouts.app')

@section('title', 'Revisar e enviar')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'movimentacoes'])

    <div class="page-header">
        <h1 class="page-title">
            Revisar {{ $movement->code }}
            <span class="page-subtitle">Confira antes de enviar. Depois do envio a quantidade fica travada.</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('movimentacoes.index') }}">Voltar</a>
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <div class="card">
        <div class="card-header">
            <span class="badge badge-{{ $movement->status->badgeModifier() }}">
                {{ $movement->status->label() }}
            </span>
        </div>
        <div class="card-body">
            <div class="card-meta">
                <span class="card-meta-item">Tipo: {{ $movement->type()->label() }}</span>
                <span class="card-meta-item">
                    Origem: {{ $movement->originObra?->name ?? '—' }}
                    / {{ $movement->originLocal?->name ?? '—' }}
                </span>
                <span class="card-meta-item">
                    Destino: {{ $movement->destinationObra?->name ?? '—' }}
                    / {{ $movement->destinationLocal?->name ?? '—' }}
                </span>
                <span class="card-meta-item">
                    Data: {{ $movement->movement_date?->format('d/m/Y') }}
                    às {{ substr((string) $movement->movement_time, 0, 5) }}
                </span>
                <span class="card-meta-item">Remetente: {{ $movement->sender?->name ?? '—' }}</span>
                <span class="card-meta-item">
                    Transporte:
                    {{ $movement->transporter?->name ?? $movement->transporter_name ?? '—' }}
                </span>
            </div>

            @if ($movement->notes)
                <p class="mt-2">{{ $movement->notes }}</p>
            @endif
        </div>
    </div>

    <h2 class="page-title mt-3">
        Materiais
        <span class="page-subtitle">{{ $movement->items->count() }} item(ns)</span>
    </h2>

    <ul class="card-list">
        @forelse ($movement->items as $item)
            <li class="card">
                <div class="card-title">{{ $item->description_snapshot }}</div>
                <div class="card-meta">
                    <span class="card-meta-item">
                        Quantidade: {{ $item->qty_sent }} {{ $item->unit?->code }}
                    </span>
                    @if ($item->notes)
                        <span class="card-meta-item">Observação: {{ $item->notes }}</span>
                    @endif
                </div>
            </li>
        @empty
            <li class="empty-state">
                Sem itens. Volte à edição e adicione pelo menos um material antes de enviar.
            </li>
        @endforelse
    </ul>

    <div class="card-actions mt-3">
        @can('update', $movement)
            <a class="btn btn-secondary" href="{{ route('movimentacoes.edit', $movement) }}">
                Corrigir rascunho
            </a>
        @endcan
    </div>

    @if ($podeEnviar)
        <div class="card mt-3">
            <form method="POST" action="{{ route('movimentacoes.enviar', $movement) }}"
                  data-enhance data-offline-form="movement.send" data-offline-idempotent="1"
                  data-confirmacao="Confirmar o envio de {{ $movement->code }}? A quantidade enviada será travada.">
                @csrf
                {{-- Chave gerada no SERVIDOR ao renderizar o resumo. Reenviar este
                     mesmo formulário repete a MESMA chave, então o envio não duplica. --}}
                <input type="hidden" name="idempotency_key" value="{{ $idempotencyKey }}">

                <label class="form-check">
                    <input type="checkbox" id="confirmacao-envio" required>
                    <span>
                        Confirmo que as quantidades acima correspondem ao material
                        efetivamente carregado.
                    </span>
                </label>

                <button class="btn btn-primary btn-block btn-lg mt-2" type="submit">
                    ENVIAR MOVIMENTAÇÃO
                </button>
            </form>
        </div>
    @else
        <p class="empty-state mt-3">
            Você não tem autorização para enviar esta movimentação
            @if (! $movement->isDraft())
                (ela não está mais em rascunho).
            @else
                (é necessária a permissão de envio).
            @endif
        </p>
    @endif
</div>
@endsection

@push('scripts')
    <script src="{{ asset('js/movimentacoes.js') }}" defer></script>
@endpush
