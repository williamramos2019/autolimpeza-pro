@php
    $movement = $movement ?? null;

    // Origem SUGERIDA: Depósito Drilling Matriz (config/matriz.php via MatrizLocator).
    // É só um padrão — quem pode operar outra obra troca livremente.
    $origemObra = (int) old('origin_obra_id', $movement?->origin_obra_id ?? $matrizObra?->id);
    $origemLocal = (int) old('origin_local_id', $movement?->origin_local_id ?? $matrizLocal?->id);
    $destinoObra = (int) old('destination_obra_id', $movement?->destination_obra_id);
    $destinoLocal = (int) old('destination_local_id', $movement?->destination_local_id);

    // Linhas de item na ordem de precedência: o que o operador acabou de digitar
    // (old), o que está persistido no rascunho, ou uma linha vazia.
    $itens = old('items');

    if (! is_array($itens) || $itens === []) {
        $itens = $movement
            ? $movement->items->map(fn ($item) => [
                'id' => $item->id,
                'material_id' => $item->material_id,
                // decimal:3 devolve "10.500"; o operador não precisa ver os zeros
                // à direita. O rtrim só roda quando há ponto decimal.
                'qty_sent' => str_contains((string) $item->qty_sent, '.')
                    ? rtrim(rtrim((string) $item->qty_sent, '0'), '.')
                    : (string) $item->qty_sent,
                'notes' => $item->notes,
            ])->values()->all()
            : [];
    }

    if ($itens === []) {
        $itens = [[]];
    }
@endphp

<fieldset class="form-fieldset">
    <legend class="form-legend">1. Origem</legend>

    <div class="form-group">
        <label class="form-label" for="origin_obra_id">Obra de origem *</label>
        <select class="form-control" id="origin_obra_id" name="origin_obra_id" required
                data-locais-de="origin_local_id">
            <option value="">Selecione a obra</option>
            @foreach ($obras as $obra)
                <option value="{{ $obra->id }}" @selected($origemObra === $obra->id)>
                    {{ $obra->code }} — {{ $obra->name }}
                </option>
            @endforeach
        </select>
        @error('origin_obra_id')<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <div class="form-group">
        <label class="form-label" for="origin_local_id">Local de origem *</label>
        {{-- Todas as opções são renderizadas no servidor (funciona sem JS) e o JS
             apenas filtra pela obra escolhida. --}}
        <select class="form-control" id="origin_local_id" name="origin_local_id" required>
            <option value="">Selecione o local</option>
            @foreach ($obras as $obra)
                @foreach ($obra->locais as $local)
                    <option value="{{ $local->id }}" data-obra-id="{{ $obra->id }}"
                        @selected($origemLocal === $local->id)>
                        {{ $local->name }} ({{ $obra->code }})
                    </option>
                @endforeach
            @endforeach
        </select>
        @error('origin_local_id')<span class="form-error">{{ $message }}</span>@enderror
    </div>
</fieldset>

<fieldset class="form-fieldset">
    <legend class="form-legend">2. Destino</legend>

    <div class="form-group">
        <label class="form-label" for="destination_obra_id">Obra de destino *</label>
        <select class="form-control" id="destination_obra_id" name="destination_obra_id" required
                data-locais-de="destination_local_id">
            <option value="">Selecione a obra</option>
            @foreach ($obras as $obra)
                <option value="{{ $obra->id }}" @selected($destinoObra === $obra->id)>
                    {{ $obra->code }} — {{ $obra->name }}
                </option>
            @endforeach
        </select>
        @error('destination_obra_id')<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <div class="form-group">
        <label class="form-label" for="destination_local_id">Local de destino *</label>
        <select class="form-control" id="destination_local_id" name="destination_local_id" required>
            <option value="">Selecione o local</option>
            @foreach ($obras as $obra)
                @foreach ($obra->locais as $local)
                    <option value="{{ $local->id }}" data-obra-id="{{ $obra->id }}"
                        @selected($destinoLocal === $local->id)>
                        {{ $local->name }} ({{ $obra->code }})
                    </option>
                @endforeach
            @endforeach
        </select>
        @error('destination_local_id')<span class="form-error">{{ $message }}</span>@enderror
    </div>
</fieldset>

<fieldset class="form-fieldset">
    <legend class="form-legend">3. Transporte e data</legend>

    <div class="form-group">
        <label class="form-label" for="transporter_name">Responsável pelo transporte</label>
        <input class="form-control" type="text" id="transporter_name" name="transporter_name"
               maxlength="255" value="{{ old('transporter_name', $movement?->transporter_name) }}"
               placeholder="Nome de quem leva a carga">
        @error('transporter_name')<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <div class="form-group">
        <label class="form-label" for="transporter_user_id">Transportador cadastrado</label>
        <select class="form-control" id="transporter_user_id" name="transporter_user_id">
            <option value="">Não informado</option>
            @foreach ($transportadores as $transportador)
                <option value="{{ $transportador->id }}"
                    @selected((int) old('transporter_user_id', $movement?->transporter_user_id) === $transportador->id)>
                    {{ $transportador->name }}
                </option>
            @endforeach
        </select>
        @error('transporter_user_id')<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <div class="form-group">
        <label class="form-label" for="movement_date">Data da movimentação *</label>
        <input class="form-control" type="date" id="movement_date" name="movement_date" required
               value="{{ old('movement_date', $movement?->movement_date?->format('Y-m-d') ?? now()->format('Y-m-d')) }}">
        @error('movement_date')<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <div class="form-group">
        <label class="form-label" for="movement_time">Hora da movimentação *</label>
        <input class="form-control" type="time" id="movement_time" name="movement_time" required
               value="{{ old('movement_time', substr((string) ($movement?->movement_time ?? now()->format('H:i')), 0, 5)) }}">
        @error('movement_time')<span class="form-error">{{ $message }}</span>@enderror
    </div>

    <div class="form-group">
        <label class="form-label" for="notes">Observação</label>
        <textarea class="form-control" id="notes" name="notes" rows="3"
                  maxlength="2000">{{ old('notes', $movement?->notes) }}</textarea>
        @error('notes')<span class="form-error">{{ $message }}</span>@enderror
    </div>
</fieldset>

<fieldset class="form-fieldset">
    <legend class="form-legend">4. Materiais e quantidades</legend>

    @error('items')<span class="form-error">{{ $message }}</span>@enderror

    <ul class="item-list" id="itens-da-movimentacao" data-proximo-indice="{{ count($itens) }}">
        @foreach ($itens as $indice => $item)
            @include('movimentacoes.partials._item', [
                'index' => $indice,
                'item' => $item,
                'materiais' => $materiais,
            ])
        @endforeach
    </ul>

    {{-- Molde clonado pelo JS. Conteúdo de <template> não é submetido pelo
         navegador, então não gera item fantasma. --}}
    <template id="molde-item-movimentacao">
        @include('movimentacoes.partials._item', [
            'index' => '__INDEX__',
            'item' => [],
            'materiais' => $materiais,
        ])
    </template>

    <button class="btn btn-secondary btn-block" type="button" id="adicionar-item">
        + Adicionar material
    </button>
</fieldset>

@push('scripts')
    <script src="{{ asset('js/movimentacoes.js') }}" defer></script>
@endpush
