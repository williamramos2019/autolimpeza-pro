@extends('layouts.app')

@section('title', $movement->code)

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'movimentacoes'])

    <div class="page-header">
        <h1 class="page-title">
            {{ $movement->code }}
            <span class="page-subtitle">{{ $movement->type()->label() }}</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('movimentacoes.index') }}">Voltar</a>
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <div class="card">
        <div class="card-header">
            <span class="badge badge-{{ $movement->status->badgeModifier() }}">
                {{ $movement->status->label() }}
            </span>
        </div>
        <div class="card-body">
            <div class="card-meta">
                <span class="card-meta-item">
                    Origem: {{ $movement->originObra?->name ?? '—' }}
                    / {{ $movement->originLocal?->name ?? '—' }}
                </span>
                <span class="card-meta-item">
                    Destino: {{ $movement->destinationObra?->name ?? '—' }}
                    / {{ $movement->destinationLocal?->name ?? '—' }}
                </span>
                <span class="card-meta-item">
                    Data: {{ $movement->movement_date?->format('d/m/Y') }}
                    às {{ substr((string) $movement->movement_time, 0, 5) }}
                </span>
                <span class="card-meta-item">Remetente: {{ $movement->sender?->name ?? '—' }}</span>
                <span class="card-meta-item">
                    Transporte:
                    {{ $movement->transporter?->name ?? $movement->transporter_name ?? '—' }}
                </span>
                @if ($movement->sent_at)
                    <span class="card-meta-item">
                        Enviada em {{ $movement->sent_at->format('d/m/Y H:i') }}
                    </span>
                @endif
            </div>

            @if ($movement->notes)
                <p class="mt-2">{{ $movement->notes }}</p>
            @endif
        </div>
    </div>

    @if ($qrSvg ?? null)
        <div class="card qr-label">
            <h2 class="card-header">QR Code</h2>
            {!! $qrSvg !!}
            <p class="qr-label-url">{{ $qrUrl }}</p>
            <p>A leitura abre esta movimentação. O QR não concede permissão.</p>
        </div>
    @endif

    <h2 class="page-title mt-3">Itens</h2>

    <ul class="card-list">
        @forelse ($movement->items as $item)
            <li class="card">
                <div class="card-title">{{ $item->description_snapshot }}</div>
                <div class="card-meta">
                    <span class="card-meta-item">
                        Quantidade enviada: {{ $item->qty_sent }} {{ $item->unit?->code }}
                    </span>
                    <span class="card-meta-item">
                        Material no catálogo: {{ $item->material?->code ?? '—' }}
                    </span>
                    @if ($item->notes)
                        <span class="card-meta-item">Observação: {{ $item->notes }}</span>
                    @endif
                </div>
            </li>
        @empty
            <li class="empty-state">Esta movimentação ainda não tem itens.</li>
        @endforelse
    </ul>

    <h2 class="page-title mt-3">Histórico</h2>

    <ul class="card-list">
        @forelse ($movement->statusHistory as $historico)
            <li class="card">
                <div class="card-title">
                    {{ $historico->from_status?->label() ?? 'Criação' }}
                    → {{ $historico->to_status->label() }}
                </div>
                <div class="card-meta">
                    <span class="card-meta-item">
                        {{ $historico->created_at?->format('d/m/Y H:i') }}
                    </span>
                    <span class="card-meta-item">
                        Por: {{ $historico->user?->name ?? 'sistema' }}
                    </span>
                </div>
            </li>
        @empty
            <li class="empty-state">Sem histórico registrado.</li>
        @endforelse
    </ul>

    <div class="card-actions mt-3">
        @can('update', $movement)
            <a class="btn btn-primary" href="{{ route('movimentacoes.edit', $movement) }}">
                Editar rascunho
            </a>
        @endcan
        @can('send', $movement)
            <a class="btn btn-primary" href="{{ route('movimentacoes.resumo', $movement) }}">
                Revisar e enviar
            </a>
        @endcan
        @can('cancel', $movement)
            <form method="POST" action="{{ route('movimentacoes.destroy', $movement) }}">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger" type="submit">Cancelar rascunho</button>
            </form>
        @endcan
        @can('audit', $movement)
            <a class="btn btn-secondary" href="{{ route('movimentacoes.historico', $movement) }}">
                Histórico e rastreio
            </a>
        @endcan
        @if ($podeReceber ?? false)
            <a class="btn btn-primary btn-lg" href="{{ route('movimentacoes.receber', $movement) }}">
                Receber e conferir
            </a>
        @elseif ($movement->receipt)
            <a class="btn btn-secondary" href="{{ route('movimentacoes.receber', $movement) }}">
                Ver conferência
            </a>
        @endif
    </div>
</div>
@endsection
