@extends('layouts.app')

@section('title', 'Editar rascunho')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'movimentacoes'])

    <div class="page-header">
        <h1 class="page-title">
            Editar {{ $movement->code }}
            <span class="page-subtitle">Rascunho — nada foi enviado ainda</span>
        </h1>
        <a class="btn btn-secondary" href="{{ route('movimentacoes.show', $movement) }}">Voltar</a>
    </div>

    @include('partials.errors')

    <div class="card">
        <form method="POST" action="{{ route('movimentacoes.update', $movement) }}" data-offline-form="movement.update" data-offline-draft="1">
            @csrf
            @method('PUT')
            @include('movimentacoes._form', ['movement' => $movement])
            <button class="btn btn-primary btn-block btn-lg" type="submit">
                Salvar rascunho e revisar
            </button>
        </form>
    </div>

    @can('cancel', $movement)
        <div class="card mt-3">
            <form method="POST" action="{{ route('movimentacoes.destroy', $movement) }}">
                @csrf
                @method('DELETE')
                <p class="form-hint">
                    Cancelar mantém a movimentação no histórico com status Cancelado — o
                    código {{ $movement->code }} não é reaproveitado.
                </p>
                <button class="btn btn-danger btn-block" type="submit">Cancelar rascunho</button>
            </form>
        </div>
    @endcan
</div>
@endsection
