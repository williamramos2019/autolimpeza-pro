@extends('layouts.app')

@section('title', 'Movimentações')

@section('content')
<div class="container">
    @include('partials.cadastros-nav', ['atual' => 'movimentacoes'])

    <div class="page-header">
        <h1 class="page-title">
            Movimentações
            <span class="page-subtitle">{{ $movimentacoes->total() }} movimentação(ões)</span>
        </h1>
        @if ($podeCriar)
            <a class="btn btn-primary" href="{{ route('movimentacoes.create') }}">Nova movimentação</a>
        @endif
    </div>

    @include('partials.flash')
    @include('partials.errors')

    <form class="search-bar" method="GET" action="{{ route('movimentacoes.index') }}">
        <label class="form-label" for="q" style="width:100%">Buscar pelo código da movimentação</label>
        <input class="form-control" type="search" id="q" name="q" value="{{ $search }}"
               placeholder="Ex.: MOV-{{ now()->year }}-000001">
        <select class="form-control" name="status" aria-label="Filtrar por status">
            <option value="">Todos os status</option>
            @foreach ($statuses as $case)
                <option value="{{ $case->value }}" @selected($status === $case->value)>
                    {{ $case->label() }}
                </option>
            @endforeach
        </select>
        <button class="btn btn-primary" type="submit">Buscar</button>
    </form>

    <ul class="card-list">
        @forelse ($movimentacoes as $movimentacao)
            <li class="card">
                <div class="card-title">{{ $movimentacao->code }}</div>
                <div class="card-meta">
                    <span class="badge badge-{{ $movimentacao->status->badgeModifier() }}">
                        {{ $movimentacao->status->label() }}
                    </span>
                    <span class="card-meta-item">
                        Origem: {{ $movimentacao->originObra?->name ?? '—' }}
                        / {{ $movimentacao->originLocal?->name ?? '—' }}
                    </span>
                    <span class="card-meta-item">
                        Destino: {{ $movimentacao->destinationObra?->name ?? '—' }}
                        / {{ $movimentacao->destinationLocal?->name ?? '—' }}
                    </span>
                    <span class="card-meta-item">Tipo: {{ $movimentacao->type()->label() }}</span>
                    <span class="card-meta-item">
                        Data: {{ $movimentacao->movement_date?->format('d/m/Y') }}
                        às {{ substr((string) $movimentacao->movement_time, 0, 5) }}
                    </span>
                    <span class="card-meta-item">Itens: {{ $movimentacao->items_count }}</span>
                    <span class="card-meta-item">Remetente: {{ $movimentacao->sender?->name ?? '—' }}</span>
                </div>
                <div class="card-actions">
                    <a class="btn btn-secondary" href="{{ route('movimentacoes.show', $movimentacao) }}">
                        Detalhes
                    </a>
                    @can('update', $movimentacao)
                        <a class="btn btn-primary" href="{{ route('movimentacoes.edit', $movimentacao) }}">
                            Editar
                        </a>
                    @endcan
                    @can('send', $movimentacao)
                        <a class="btn btn-primary" href="{{ route('movimentacoes.resumo', $movimentacao) }}">
                            Revisar e enviar
                        </a>
                    @endcan
                </div>
            </li>
        @empty
            <li class="empty-state">Nenhuma movimentação encontrada.</li>
        @endforelse
    </ul>

    @include('partials.paginacao', ['paginator' => $movimentacoes])
</div>
@endsection
