# VERSION

**Versão canônica:** `2026.08.10-v1.25.39`  
**Tag sugerida:** `v1.25.39`  
**Data:** 2026-08-10  

Fonte: `cpanel-src/config.php` → `APP_VERSION`.
