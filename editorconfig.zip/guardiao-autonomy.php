<?php
/**
 * Super Guardião Premium — autonomia segura (allowlist only).
 * Nunca muta CRM/agenda/leads/posts. Writes: guardiao_* + infra existente.
 */

require_once __DIR__ . '/guardiao-system-observer.php';

class GuardiaoAutonomy
{
    /** @var array<string, array{label:string,description:string,auto:bool}> */
    public const ALLOWLIST = [
        'observe_persist' => [
            'label'       => 'Snapshot de saúde',
            'description' => 'Persiste observação atual em guardiao_observations',
            'auto'        => true,
        ],
        'process_queue' => [
            'label'       => 'Processar fila de notificações',
            'description' => 'NotificationCenter::processQueue (até 25 itens)',
            'auto'        => true,
        ],
        'sync_whatsapp' => [
            'label'       => 'Sincronizar WhatsApp (Evolution)',
            'description' => 'Atualiza status da conexão Evolution (sem enviar mensagens)',
            'auto'        => true,
        ],
        'test_smtp' => [
            'label'       => 'Testar SMTP',
            'description' => 'Valida conexão SMTP configurada',
            'auto'        => false,
        ],
        'resolve_older_logs' => [
            'label'       => 'Arquivar logs antigos',
            'description' => 'Marca como resolvidos logs em aberto com mais de 7 dias',
            'auto'        => false,
        ],
    ];

    public static function catalog(): array
    {
        $out = [];
        foreach (self::ALLOWLIST as $id => $meta) {
            $out[] = [
                'id'          => $id,
                'label'       => $meta['label'],
                'description' => $meta['description'],
                'safe'        => true,
                'auto'        => !empty($meta['auto']),
            ];
        }
        return $out;
    }

    /**
     * Sugere ações allowlisted a partir do snapshot de saúde.
     *
     * @return list<array{id:string,label:string,safe:bool,reason:string}>
     */
    public static function proposeActions(array $observation): array
    {
        $suggested = [];
        $push = static function (string $id, string $reason) use (&$suggested): void {
            if (!isset(self::ALLOWLIST[$id])) return;
            foreach ($suggested as $s) {
                if (($s['id'] ?? '') === $id) return;
            }
            $suggested[] = [
                'id'     => $id,
                'label'  => self::ALLOWLIST[$id]['label'],
                'safe'   => true,
                'reason' => $reason,
            ];
        };

        $modules = $observation['modules'] ?? [];
        $overall = (string) ($observation['overallStatus'] ?? 'green');
        $score = (int) ($observation['overallScore'] ?? 100);

        $push('observe_persist', 'Manter histórico de saúde atualizado');

        $notif = $modules['notifications'] ?? null;
        if (is_array($notif) && (($notif['status'] ?? '') === 'red' || (int) ($notif['score'] ?? 100) < 70)) {
            $push('process_queue', 'Fila/notificações com sinais críticos');
        }

        $wa = $modules['whatsapp'] ?? $modules['crm'] ?? null;
        if (is_array($wa) && (($wa['status'] ?? '') === 'red' || (int) ($wa['score'] ?? 100) < 65)) {
            $push('sync_whatsapp', 'WhatsApp/CRM com status degradado');
        }

        $smtp = $modules['smtp'] ?? null;
        if (is_array($smtp) && (($smtp['status'] ?? '') === 'red' || (int) ($smtp['score'] ?? 100) < 70)) {
            $push('test_smtp', 'SMTP com falha ou configuração incompleta');
        }

        $logsSignal = $observation['signals']['logs'] ?? [];
        $openErrors = (int) ($logsSignal['open_errors'] ?? $logsSignal['errors_open'] ?? 0);
        if ($openErrors > 50 || $overall === 'red' || $score < 55) {
            $push('resolve_older_logs', 'Muitos logs em aberto — arquivar histórico >7 dias (manual)');
        }

        return $suggested;
    }

    /**
     * @return array{ok:bool,action:string,result:array,error?:string}
     */
    public static function execute(PDO $pdo, string $actionId, string $source = 'manual'): array
    {
        $actionId = strtolower(trim($actionId));
        if (!isset(self::ALLOWLIST[$actionId])) {
            return ['ok' => false, 'action' => $actionId, 'result' => [], 'error' => 'Ação não permitida (fora da allowlist)'];
        }

        try {
            $result = match ($actionId) {
                'observe_persist'    => self::actionObservePersist($pdo),
                'process_queue'      => self::actionProcessQueue($pdo),
                'sync_whatsapp'      => self::actionSyncWhatsapp($pdo),
                'test_smtp'          => self::actionTestSmtp($pdo),
                'resolve_older_logs' => self::actionResolveOlderLogs($pdo),
                default              => throw new RuntimeException('Ação não implementada'),
            };
        } catch (Throwable $e) {
            $fail = [
                'ok'     => false,
                'action' => $actionId,
                'result' => [],
                'error'  => $e->getMessage(),
            ];
            self::audit($pdo, $actionId, $source, $fail);
            return $fail;
        }

        $ok = true;
        if (is_array($result) && array_key_exists('ok', $result)) {
            $ok = !empty($result['ok']);
        }

        $payload = [
            'ok'     => $ok,
            'action' => $actionId,
            'result' => $result,
        ];
        if (!$ok && is_array($result) && !empty($result['error'])) {
            $payload['error'] = (string) $result['error'];
        }
        // Snapshot de rotina no cron não polui histórico de diagnósticos IA
        if (!($source === 'cron' && $actionId === 'observe_persist')) {
            self::audit($pdo, $actionId, $source, $payload);
        }
        return $payload;
    }

    /** Persiste snapshot já observado (evita observe() duplo no cron). */
    public static function persistObservation(PDO $pdo, array $snapshot): array
    {
        $stmt = $pdo->prepare('INSERT INTO guardiao_observations (snapshot_json, created_at) VALUES (?, ?)');
        $stmt->execute([json_encode($snapshot, JSON_UNESCAPED_UNICODE), dbNow()]);
        return [
            'observationId' => (int) $pdo->lastInsertId(),
            'overallScore'  => $snapshot['overallScore'] ?? null,
            'overallStatus' => $snapshot['overallStatus'] ?? null,
        ];
    }

    private static function actionObservePersist(PDO $pdo): array
    {
        $snapshot = SystemObserver::observe($pdo);
        return self::persistObservation($pdo, $snapshot);
    }

    private static function actionProcessQueue(PDO $pdo): array
    {
        if (!class_exists('NotificationCenter')) {
            throw new RuntimeException('NotificationCenter indisponível');
        }
        $processed = NotificationCenter::processQueue($pdo, 25);
        return ['processed' => $processed];
    }

    private static function actionSyncWhatsapp(PDO $pdo): array
    {
        if (!function_exists('crmSyncEvolutionWhatsapp')) {
            throw new RuntimeException('crmSyncEvolutionWhatsapp indisponível');
        }
        return crmSyncEvolutionWhatsapp($pdo, false);
    }

    private static function actionTestSmtp(PDO $pdo): array
    {
        if (!function_exists('testSmtpConnection')) {
            throw new RuntimeException('testSmtpConnection indisponível');
        }
        return testSmtpConnection($pdo);
    }

    private static function actionResolveOlderLogs(PDO $pdo): array
    {
        $days = 7;
        $affected = $pdo->exec(
            "UPDATE system_logs SET resolved = 1
             WHERE resolved = 0
               AND created_at < DATE_SUB(NOW(), INTERVAL {$days} DAY)"
        );
        return ['resolved' => (int) $affected, 'days' => $days];
    }

    private static function audit(PDO $pdo, string $actionId, string $source, array $payload): void
    {
        try {
            if (function_exists('ensureGuardiaoTables')) {
                ensureGuardiaoTables($pdo);
            }
            $report = [
                'executiveSummary' => 'Ação Super Guardião: ' . (self::ALLOWLIST[$actionId]['label'] ?? $actionId),
                'severity'         => !empty($payload['ok']) ? 'low' : 'high',
                'impact'           => 'Infraestrutura / observabilidade (sem mutar CRM/agenda)',
                'evidence'         => [$payload],
                'probableCause'    => 'Execução allowlisted',
                'confidence'       => 100,
                'fixSteps'         => [],
                'testSteps'        => ['Recarregue Central de Saúde / Operações'],
                'risks'            => [],
                'actionId'         => $actionId,
                'source'           => $source,
                'ok'               => !empty($payload['ok']),
                'generatedAt'      => date('c'),
            ];
            $stmt = $pdo->prepare(
                'INSERT INTO guardiao_diagnostics (scope, query, report_json, confidence, evidence_json, admin_email, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
            $admin = function_exists('guardiaoAdminEmail') ? guardiaoAdminEmail() : null;
            $stmt->execute([
                'action',
                'action:' . $actionId . ':' . $source,
                json_encode($report, JSON_UNESCAPED_UNICODE),
                100,
                json_encode([$payload], JSON_UNESCAPED_UNICODE),
                $admin,
                dbNow(),
            ]);
        } catch (Throwable $e) {
            // auditoria não deve quebrar a ação
        }
    }

    /**
     * Tick de cron: observe+persist, alerta se red, auto allowlisted com debounce 1h.
     *
     * @return array<string, mixed>
     */
    public static function cronTick(PDO $pdo): array
    {
        if (function_exists('ensureGuardiaoTables')) {
            ensureGuardiaoTables($pdo);
        }

        $out = [
            'ran_at'   => dbNow(),
            'actions'  => [],
            'alerted'  => false,
            'skipped'  => [],
        ];

        // Um único observe por tick (antes: execute(observe_persist) + observe de novo)
        $snapshot = SystemObserver::observe($pdo);
        $persist = self::persistObservation($pdo, $snapshot);
        $out['actions'][] = [
            'ok'     => true,
            'action' => 'observe_persist',
            'result' => $persist,
        ];

        $status = (string) ($snapshot['overallStatus'] ?? 'green');
        $score = (int) ($snapshot['overallScore'] ?? 100);
        $proposed = self::proposeActions($snapshot);
        $out['proposed'] = $proposed;

        if ($status === 'red') {
            $out['alerted'] = self::alertAdminRed($pdo, $score, $snapshot);
        }

        $now = time();
        foreach ($proposed as $item) {
            $id = (string) ($item['id'] ?? '');
            if ($id === '' || $id === 'observe_persist') continue;
            if (empty(self::ALLOWLIST[$id]['auto'])) {
                $out['skipped'][] = ['id' => $id, 'reason' => 'manual_only'];
                continue;
            }
            // Só auto em yellow/red
            if ($status === 'green' && $score >= 80) {
                $out['skipped'][] = ['id' => $id, 'reason' => 'healthy'];
                continue;
            }
            $key = 'guardiao_auto_' . $id . '_at';
            $last = function_exists('siteConfigGet') ? siteConfigGet($pdo, $key) : null;
            $lastTs = $last ? strtotime($last) : false;
            if ($lastTs && ($now - $lastTs) < 3600) {
                $out['skipped'][] = ['id' => $id, 'reason' => 'debounce_1h'];
                continue;
            }
            $exec = self::execute($pdo, $id, 'cron');
            $out['actions'][] = $exec;
            if (function_exists('siteConfigSet') && !empty($exec['ok'])) {
                siteConfigSet($pdo, $key, dbNow());
            }
        }

        if (function_exists('siteConfigSet')) {
            siteConfigSet($pdo, 'guardiao_autonomy_last_tick', dbNow());
            siteConfigSet($pdo, 'guardiao_autonomy_last_status', $status);
            siteConfigSet($pdo, 'guardiao_autonomy_last_score', (string) $score);
        }

        return $out;
    }

    private static function alertAdminRed(PDO $pdo, int $score, array $snapshot): bool
    {
        $key = 'guardiao_red_alert_at';
        $last = function_exists('siteConfigGet') ? siteConfigGet($pdo, $key) : null;
        $lastTs = $last ? strtotime($last) : false;
        if ($lastTs && (time() - $lastTs) < 3600) {
            return false;
        }

        $title = 'Super Guardião: saúde crítica';
        $body = "Score geral {$score}% (vermelho). Abra /guardiao-admin → Operações.";
        try {
            if (function_exists('createAdminNotification')) {
                createAdminNotification($pdo, 'guardiao_alert', $title, $body, [
                    'score'  => $score,
                    'status' => 'red',
                    'url'    => '/guardiao-admin',
                ], ['action_url' => '/guardiao-admin', 'priority' => 'high']);
            } elseif (function_exists('dispatchNotificationEvent')) {
                dispatchNotificationEvent($pdo, 'system_alert', $title, $body, [
                    'score' => $score,
                ], ['action_url' => '/guardiao-admin', 'priority' => 'high']);
            } else {
                return false;
            }
            if (function_exists('siteConfigSet')) {
                siteConfigSet($pdo, $key, dbNow());
            }
            return true;
        } catch (Throwable $e) {
            return false;
        }
    }

    public static function autonomyStatus(PDO $pdo): array
    {
        $lastTick = function_exists('siteConfigGet') ? siteConfigGet($pdo, 'guardiao_autonomy_last_tick') : null;
        $lastStatus = function_exists('siteConfigGet') ? siteConfigGet($pdo, 'guardiao_autonomy_last_status') : null;
        $lastScore = function_exists('siteConfigGet') ? siteConfigGet($pdo, 'guardiao_autonomy_last_score') : null;
        return [
            'enabled'     => true,
            'mode'        => 'safe_auto',
            'lastTick'    => $lastTick,
            'lastStatus'  => $lastStatus,
            'lastScore'   => $lastScore !== null ? (int) $lastScore : null,
            'allowlist'   => self::catalog(),
        ];
    }

    /** @return list<array{id:int,overallScore:?int,overallStatus:?string,created_at:string}> */
    public static function recentObservations(PDO $pdo, int $limit = 30): array
    {
        $limit = max(1, min(50, $limit));
        try {
            $rows = $pdo->query(
                "SELECT id, snapshot_json, created_at FROM guardiao_observations ORDER BY id DESC LIMIT {$limit}"
            )->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            return [];
        }
        $out = [];
        foreach ($rows as $row) {
            $snap = json_decode((string) ($row['snapshot_json'] ?? '{}'), true) ?: [];
            $out[] = [
                'id'            => (int) $row['id'],
                'overallScore'  => isset($snap['overallScore']) ? (int) $snap['overallScore'] : null,
                'overallStatus' => $snap['overallStatus'] ?? null,
                'created_at'    => (string) ($row['created_at'] ?? ''),
            ];
        }
        return $out;
    }
}
