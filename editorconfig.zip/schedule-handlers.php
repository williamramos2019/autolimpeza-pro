<?php
/**
 * Agenda — configuração, disponibilidade e validação de conflitos.
 */

const SCHEDULE_CONFIG_DEFAULT = [
    'workStart' => '08:00',
    'workEnd' => '18:00',
    'lunchStart' => '12:00',
    'lunchEnd' => '13:00',
    'slotStepMinutes' => 150,
    'advanceDays' => 30,
    // 18:00 removido: com workEnd 18:00 nenhum serviço (duração > 0) cabe nesse início
    'fixedSlotStarts' => ['08:00', '10:30', '13:00', '15:30'],
    'serviceDurations' => [
        'sofa' => 150,
        'poltrona' => 150,
        'colchao' => 150,
        'colchao-infantil' => 120,
        'impermeabilizacao' => 150,
        'auto-interna' => 150,
        'lavagem-automotiva' => 60,
        'lava-jato' => 60,
        'tapete' => 90,
        'cadeiras' => 90,
        'bebe-conforto' => 60,
        'cadeirinha-auto' => 60,
        'pos-obra' => 150,
    ],
];

const BLOCKING_STATUSES = ['pending', 'confirmed', 'en_route', 'arrived', 'in_service', 'paused'];
const BLOCKING_STATUSES_LEGACY_PT = ['pendente', 'confirmado', 'em_deslocamento', 'chegou', 'em_atendimento', 'pausado'];

function blockingStatusesForSql(): array {
    return array_merge(BLOCKING_STATUSES, BLOCKING_STATUSES_LEGACY_PT);
}

/** Normaliza status PT/legado para o enum canônico EN. */
function normalizeAppointmentStatus(string $status): string {
    $map = [
        'pendente' => 'pending',
        'confirmado' => 'confirmed',
        'em_deslocamento' => 'en_route',
        'em deslocamento' => 'en_route',
        'a_caminho' => 'en_route',
        'chegou' => 'arrived',
        'cheguei' => 'arrived',
        'arrived' => 'arrived',
        'em_atendimento' => 'in_service',
        'em atendimento' => 'in_service',
        'pausado' => 'paused',
        'pause' => 'paused',
        'concluido' => 'completed',
        'concluído' => 'completed',
        'cancelado' => 'cancelled',
    ];
    $s = strtolower(trim($status));
    if (in_array($s, ['pending', 'confirmed', 'en_route', 'arrived', 'in_service', 'paused', 'completed', 'cancelled'], true)) {
        return $s;
    }
    return $map[$s] ?? $s;
}

function scheduleParseMinutes(string $time): int {
    $parts = explode(':', $time);
    return ((int)($parts[0] ?? 0)) * 60 + ((int)($parts[1] ?? 0));
}

function scheduleMinutesToTime(int $total): string {
    return sprintf('%02d:%02d', intdiv($total, 60), $total % 60);
}

function getScheduleConfig(PDO $pdo): array {
    $stmt = $pdo->prepare("SELECT value FROM site_config WHERE key_name = 'schedule_config' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    $stored = $row && $row['value'] ? json_decode($row['value'], true) : [];
    if (!is_array($stored)) $stored = [];
    $merged = array_replace_recursive(SCHEDULE_CONFIG_DEFAULT, $stored);
    if (empty($merged['fixedSlotStarts']) || !is_array($merged['fixedSlotStarts'])) {
        $merged['fixedSlotStarts'] = SCHEDULE_CONFIG_DEFAULT['fixedSlotStarts'];
    }
    // Pós-obra legado (240+) esgotava o dia; metragem não deve inflar slot.
    $posDur = (int)($merged['serviceDurations']['pos-obra'] ?? 150);
    if ($posDur >= 240) {
        $merged['serviceDurations']['pos-obra'] = 150;
    }
    return $merged;
}

function saveScheduleConfig(PDO $pdo, array $config): array {
    $merged = array_replace_recursive(SCHEDULE_CONFIG_DEFAULT, $config);
    if (empty($merged['fixedSlotStarts']) || !is_array($merged['fixedSlotStarts'])) {
        $merged['fixedSlotStarts'] = SCHEDULE_CONFIG_DEFAULT['fixedSlotStarts'];
    }
    $json = json_encode($merged, JSON_UNESCAPED_UNICODE);
    $pdo->prepare("INSERT INTO site_config (key_name, value, updated_at) VALUES ('schedule_config', ?, NOW())
        ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = NOW()")
        ->execute([$json]);
    return $merged;
}

/**
 * Valida se o intervalo cabe no expediente.
 * Almoço = não INICIAR durante o intervalo (jobs fixos de 2h30 podem atravessar 12h–13h,
 * ex.: 10:30→13:00). A grade em passos já pula inícios no almoço; slots fixos alinham a isso.
 */
function isWithinWorkHours(int $start, int $end, array $cfg): bool {
    $ws = scheduleParseMinutes($cfg['workStart']);
    $we = scheduleParseMinutes($cfg['workEnd']);
    $ls = scheduleParseMinutes($cfg['lunchStart']);
    $le = scheduleParseMinutes($cfg['lunchEnd']);
    if ($start < $ws || $end > $we) return false;
    if ($ls < $le && $start >= $ls && $start < $le) return false;
    return true;
}

/**
 * Motivo do bloqueio do slot, ou null se livre.
 * @return null|'outside_hours'|'lunch'|'booked'
 */
function appointmentSlotBlockReason(
    PDO $pdo,
    string $date,
    string $time,
    int $duration,
    ?string $excludeId = null
): ?string {
    $start = scheduleParseMinutes($time);
    $end = $start + $duration;
    $cfg = getScheduleConfig($pdo);
    $ws = scheduleParseMinutes($cfg['workStart']);
    $we = scheduleParseMinutes($cfg['workEnd']);
    $ls = scheduleParseMinutes($cfg['lunchStart']);
    $le = scheduleParseMinutes($cfg['lunchEnd']);
    if ($start < $ws || $end > $we) {
        return 'outside_hours';
    }
    if ($ls < $le && $start >= $ls && $start < $le) {
        return 'lunch';
    }
    foreach (getBlockingAppointmentsForDate($pdo, $date, $excludeId) as $apt) {
        $aStart = scheduleParseMinutes($apt['time']);
        $aEnd = appointmentEndMinutes($apt);
        if (rangesOverlap($start, $end, $aStart, $aEnd)) {
            return 'booked';
        }
    }
    return null;
}

function rangesOverlap(int $aStart, int $aEnd, int $bStart, int $bEnd): bool {
    return $aStart < $bEnd && $bStart < $aEnd;
}

function getBlockingAppointmentsForDate(PDO $pdo, string $date, ?string $excludeId = null): array {
    $statuses = blockingStatusesForSql();
    $sql = "SELECT * FROM appointments WHERE date = ? AND status IN ('" . implode("','", $statuses) . "')";
    $params = [$date];
    if ($excludeId) {
        $sql .= " AND id != ?";
        $params[] = $excludeId;
    }
    // Dentro de transação: trava as linhas do dia para evitar double-booking em POSTs paralelos
    if ($pdo->inTransaction()) {
        $sql .= " FOR UPDATE";
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function appointmentEndMinutes(array $row): int {
    $start = scheduleParseMinutes($row['time'] ?? '08:00');
    $dur = (int)($row['duration'] ?? 0);
    if ($dur <= 0) $dur = 150;
    return $start + $dur;
}

function hasAppointmentConflict(
    PDO $pdo,
    string $date,
    string $time,
    int $duration,
    ?string $excludeId = null
): bool {
    return appointmentSlotBlockReason($pdo, $date, $time, $duration, $excludeId) !== null;
}

function findNextAvailableSlot(
    PDO $pdo,
    string $date,
    int $duration,
    ?string $fromTime = null,
    ?string $excludeId = null
): ?string {
    $cfg = getScheduleConfig($pdo);
    $fromMin = $fromTime ? scheduleParseMinutes($fromTime) : scheduleParseMinutes($cfg['workStart']);
    $fixed = $cfg['fixedSlotStarts'] ?? null;

    if (is_array($fixed) && count($fixed) > 0) {
        foreach ($fixed as $slot) {
            $t = scheduleParseMinutes($slot);
            if ($t < $fromMin) {
                continue;
            }
            if (!hasAppointmentConflict($pdo, $date, $slot, $duration, $excludeId)) {
                return $slot;
            }
        }
        return null;
    }

    $we = scheduleParseMinutes($cfg['workEnd']);
    $ls = scheduleParseMinutes($cfg['lunchStart']);
    $le = scheduleParseMinutes($cfg['lunchEnd']);
    $step = (int)($cfg['slotStepMinutes'] ?? 30);

    for ($t = $fromMin; $t + $duration <= $we; $t += $step) {
        if ($t >= $ls && $t < $le) {
            continue;
        }
        $slot = scheduleMinutesToTime($t);
        if (!hasAppointmentConflict($pdo, $date, $slot, $duration, $excludeId)) {
            return $slot;
        }
    }
    return null;
}

function suggestAlternativeSlots(
    PDO $pdo,
    string $date,
    string $requestedTime,
    int $duration,
    int $count = 4,
    ?string $excludeId = null
): array {
    $suggestions = [];
    $searchFrom = $requestedTime;
    $cfg = getScheduleConfig($pdo);
    $step = (int)($cfg['slotStepMinutes'] ?? 30);

    while (count($suggestions) < $count) {
        $next = findNextAvailableSlot($pdo, $date, $duration, $searchFrom, $excludeId);
        if (!$next) break;
        if (!in_array($next, $suggestions, true)) $suggestions[] = $next;
        $searchFrom = scheduleMinutesToTime(scheduleParseMinutes($next) + $step);
        if (scheduleParseMinutes($searchFrom) + $duration > scheduleParseMinutes($cfg['workEnd'])) break;
    }
    return $suggestions;
}

function generateAvailableSlots(PDO $pdo, string $date, int $duration, ?string $excludeId = null): array {
    $cfg = getScheduleConfig($pdo);
    $fixed = $cfg['fixedSlotStarts'] ?? null;
    $starts = is_array($fixed) && count($fixed) > 0
        ? $fixed
        : null;

    if ($starts) {
        $available = [];
        foreach ($starts as $slot) {
            if (!hasAppointmentConflict($pdo, $date, $slot, $duration, $excludeId)) {
                $available[] = $slot;
            }
        }
        return $available;
    }

    $ws = scheduleParseMinutes($cfg['workStart']);
    $we = scheduleParseMinutes($cfg['workEnd']);
    $ls = scheduleParseMinutes($cfg['lunchStart']);
    $le = scheduleParseMinutes($cfg['lunchEnd']);
    $step = (int)($cfg['slotStepMinutes'] ?? 30);
    $available = [];

    for ($t = $ws; $t + $duration <= $we; $t += $step) {
        if ($t >= $ls && $t < $le) continue;
        $slot = scheduleMinutesToTime($t);
        if (!hasAppointmentConflict($pdo, $date, $slot, $duration, $excludeId)) {
            $available[] = $slot;
        }
    }
    return $available;
}

/** Próximos N horários livres (um por dia útil), alinhado à agenda real. */
function collectNextAvailableSlots(PDO $pdo, int $duration, int $max = 3): array {
    if ($duration <= 0) {
        $duration = 150;
    }
    $max = max(1, min(6, $max));
    $cfg = getScheduleConfig($pdo);
    $advance = (int)($cfg['advanceDays'] ?? 7);
    $daysToScan = min(max($advance, 7), 21);

    $tz = defined('SITE_TIMEZONE') ? SITE_TIMEZONE : 'America/Sao_Paulo';
    $now = new DateTime('now', new DateTimeZone($tz));
    $out = [];

    for ($i = 0; $i < $daysToScan && count($out) < $max; $i++) {
        $day = clone $now;
        if ($i > 0) {
            $day->modify("+{$i} day");
        }
        $dateStr = $day->format('Y-m-d');
        if ($dateStr < $now->format('Y-m-d')) {
            continue;
        }

        $fromMin = null;
        if ($dateStr === $now->format('Y-m-d')) {
            $fromMin = (int)$now->format('H') * 60 + (int)$now->format('i');
        }

        $available = generateAvailableSlots($pdo, $dateStr, $duration, null);
        $slot = null;
        foreach ($available as $candidate) {
            if ($fromMin !== null && scheduleParseMinutes($candidate) < $fromMin) {
                continue;
            }
            $slot = $candidate;
            break;
        }
        if ($slot) {
            $out[] = ['date' => $dateStr, 'time' => $slot];
        }
    }

    return $out;
}

function handleScheduleNextSlots(string $method): void {
    if ($method !== 'GET') {
        jsonRespond(['error' => 'Use GET'], 405);
    }
    $pdo = db();
    $serviceId = san($_GET['serviceId'] ?? $_GET['service'] ?? null, 64);
    $duration = sanInt($_GET['duration'] ?? 150);
    if ($duration <= 0) {
        $duration = 150;
    }
    if ($serviceId) {
        $duration = availabilityServiceDuration($pdo, $serviceId, $duration);
    }
    $limit = sanInt($_GET['limit'] ?? 3);
    if ($limit <= 0) {
        $limit = 3;
    }

    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    jsonRespond([
        'slots'     => availabilityServiceNextSlots($pdo, $duration, $limit, $serviceId ?: null),
        'duration'  => $duration,
        'serviceId' => $serviceId ?: null,
    ]);
}

function validateAppointmentPayload(PDO $pdo, array $b, ?string $excludeId = null): ?string {
    $date = san($b['date'] ?? null, 10);
    $time = san($b['time'] ?? null, 10);
    if (!$date || !$time) return 'Data e horário obrigatórios';

    $tzName = defined('SITE_TIMEZONE') ? (string)SITE_TIMEZONE : 'America/Sao_Paulo';
    try {
        $today = (new DateTime('now', new DateTimeZone($tzName)))->format('Y-m-d');
    } catch (Throwable $e) {
        $today = date('Y-m-d');
    }
    if ($date < $today) return lang('appt_past_date');

    $services = $b['services'] ?? null;
    if (!is_array($services) || count(array_filter($services, static fn($s) => is_string($s) && trim($s) !== '')) < 1) {
        return 'Informe ao menos um serviço';
    }

    $duration = sanInt($b['duration'] ?? 150);
    if ($duration <= 0) $duration = 150;
    if ($duration > 12 * 60) $duration = 12 * 60;

    $blockReason = appointmentSlotBlockReason($pdo, $date, $time, $duration, $excludeId);
    if ($blockReason !== null) {
        $suggestions = suggestAlternativeSlots($pdo, $date, $time, $duration, 4, $excludeId);
        if ($blockReason === 'outside_hours') {
            $msg = lang('appt_outside_hours');
        } elseif ($blockReason === 'lunch') {
            $msg = lang('appt_lunch_block');
        } else {
            $msg = lang('appt_conflict');
        }
        if ($suggestions) {
            $msg .= ' Sugestões: ' . implode(', ', $suggestions);
        }
        return $msg;
    }
    return null;
}

function handleScheduleConfig(string $method): void {
    $pdo = db();
    if ($method === 'GET') {
        header('Cache-Control: public, max-age=60, stale-while-revalidate=120');
        jsonRespond(getScheduleConfig($pdo));
    }
    requireAdmin();
    if ($method === 'PUT' || $method === 'POST') {
        $b = jsonBody();
        jsonRespond(saveScheduleConfig($pdo, $b));
    }
    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleScheduleAvailability(string $method): void {
    if ($method !== 'GET') jsonRespond(['error' => 'Use GET'], 405);
    $pdo = db();
    $date = san($_GET['date'] ?? null, 10);
    if (!$date) jsonRespond(['error' => 'Parâmetro date obrigatório (YYYY-MM-DD)'], 400);
    $serviceId = san($_GET['serviceId'] ?? $_GET['service'] ?? null, 64);
    $duration = sanInt($_GET['duration'] ?? 150);
    if ($duration <= 0) $duration = 150;
    if ($serviceId) {
        $duration = availabilityServiceDuration($pdo, $serviceId, $duration);
    }
    $time = san($_GET['time'] ?? null, 10);
    $excludeId = san($_GET['exclude_id'] ?? null, 64);

    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    jsonRespond(availabilityServiceSnapshot($pdo, $date, $duration, $excludeId ?: null, $time ?: null));
}
