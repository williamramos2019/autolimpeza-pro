<?php
/**
 * Contas e APIs de campo do técnico — sessão própria, permissões mínimas.
 */

function ensureTechnicianAuthTables(PDO $pdo): void {
    if (function_exists('ensureTrackingTables')) {
        ensureTrackingTables($pdo);
    }
}

function technicianSessionId(): ?int {
    $auth = getAuthorizationHeader();
    if (strpos($auth, 'Bearer ') !== 0) return null;
    $token = trim(substr($auth, 7));
    if ($token === '' || strpos($token, 'tech_') !== 0) return null;
    $h = hashSessionToken($token);
    try {
        ensureTechnicianAuthTables(db());
        $stmt = db()->prepare(
            'SELECT s.technician_id FROM technician_sessions s
             INNER JOIN technicians t ON t.id = s.technician_id
             WHERE (s.token_hash = ? OR (s.token_hash IS NULL AND s.token = ?))
               AND s.expires_at > NOW()
               AND s.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
               AND t.active = 1 LIMIT 1'
        );
        $stmt->execute([$h, $token]);
        $row = $stmt->fetch();
        return $row ? (int)$row['technician_id'] : null;
    } catch (Throwable $e) {
        try {
            $stmt = db()->prepare(
                'SELECT s.technician_id FROM technician_sessions s
                 INNER JOIN technicians t ON t.id = s.technician_id
                 WHERE s.token = ? AND s.expires_at > NOW() AND t.active = 1 LIMIT 1'
            );
            $stmt->execute([$token]);
            $row = $stmt->fetch();
            return $row ? (int)$row['technician_id'] : null;
        } catch (Throwable $e2) {
            return null;
        }
    }
}

function requireTechnician(): int {
    $id = technicianSessionId();
    if (!$id) jsonRespond(['error' => 'Sessão de técnico inválida ou expirada'], 401);
    return $id;
}

function technicianCreateSession(PDO $pdo, int $technicianId): string {
    $token = 'tech_' . bin2hex(random_bytes(24));
    $expires = date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30);
    $hash = hashSessionToken($token);
    $prefix = sessionTokenPrefix($token);
    try {
        $pdo->prepare(
            'INSERT INTO technician_sessions (token, token_hash, token_prefix, technician_id, expires_at, created_at)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([$hash, $hash, $prefix, $technicianId, $expires, dbNow()]);
    } catch (Throwable $e) {
        if (!function_exists('pdoIsUnknownColumn') || !pdoIsUnknownColumn($e)) {
            throw $e;
        }
        $pdo->prepare('INSERT INTO technician_sessions (token, technician_id, expires_at, created_at) VALUES (?, ?, ?, ?)')
            ->execute([$token, $technicianId, $expires, dbNow()]);
    }
    return $token;
}

function handleTechnicianAuth(): void {
    $pdo = db();
    ensureTechnicianAuthTables($pdo);
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    // Sub-ação: NÃO usar ?action= (colide com a rota da API). Preferir ?op=
    $action = san($_GET['op'] ?? $_GET['sub'] ?? null, 40);
    if ($action === null || $action === '') {
        $bPeek = ($method === 'POST') ? (jsonBody() ?: []) : [];
        $action = san($bPeek['op'] ?? $bPeek['action'] ?? null, 40);
    }
    if ($action === null || $action === '') {
        $action = ($method === 'GET') ? 'me' : 'login';
    }

    if ($method === 'POST' && $action === 'login') {
        rateLimit('tech_login', 10);
        $b = jsonBody();
        $email = strtolower(trim((string)($b['email'] ?? '')));
        $password = (string)($b['password'] ?? '');
        if ($email === '' || $password === '') {
            jsonRespond(['error' => 'E-mail e senha obrigatórios'], 400);
        }
        $stmt = $pdo->prepare('SELECT * FROM technicians WHERE email = ? AND active = 1 LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user || !password_verify($password, $user['password_hash'])) {
            jsonRespond(['error' => 'Credenciais inválidas'], 401);
        }
        $token = technicianCreateSession($pdo, (int)$user['id']);
        jsonRespond([
            'token' => $token,
            'technician' => trackingDecodeTechnician($user),
            'realtime' => trackingRealtimeProvider()->transportInfo(),
        ]);
    }

    if ($method === 'POST' && $action === 'logout') {
        $techId = technicianSessionId();
        if ($techId) {
            $active = $pdo->prepare("SELECT appointment_id FROM appointment_tracking_sessions
                WHERE technician_id = ? AND status IN ('active','paused')");
            $active->execute([$techId]);
            foreach ($active->fetchAll(PDO::FETCH_COLUMN) ?: [] as $appointmentId) {
                trackingEndSession($pdo, (string)$appointmentId, 'technician_logout');
            }
        }
        $auth = getAuthorizationHeader();
        if (strpos($auth, 'Bearer ') === 0) {
            $token = trim(substr($auth, 7));
            $h = hashSessionToken($token);
            try {
                $pdo->prepare('DELETE FROM technician_sessions WHERE token_hash = ? OR token = ?')->execute([$h, $token]);
            } catch (Throwable $e) {
                $pdo->prepare('DELETE FROM technician_sessions WHERE token = ?')->execute([$token]);
            }
        }
        jsonRespond(['ok' => true]);
    }

    if ($method === 'GET' && $action === 'me') {
        $id = requireTechnician();
        $tech = trackingGetTechnician($pdo, $id);
        if (!$tech) jsonRespond(['error' => 'Técnico não encontrado'], 404);
        jsonRespond(['technician' => $tech]);
    }

    jsonRespond(['error' => 'Ação não permitida'], 405);
}

function handleTechnicianAdmin(): void {
    requireAdmin();
    $pdo = db();
    ensureTechnicianAuthTables($pdo);
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        $rows = $pdo->query('SELECT id, email, name, phone, avatar_url, active, available, city, neighborhood, created_at, updated_at FROM technicians ORDER BY name ASC')
            ->fetchAll(PDO::FETCH_ASSOC) ?: [];
        jsonRespond([
            'technicians' => array_map('trackingDecodeTechnician', $rows),
        ]);
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $email = strtolower(trim((string)($b['email'] ?? '')));
        $name = trim((string)($b['name'] ?? ''));
        $phone = trim((string)($b['phone'] ?? ''));
        $password = (string)($b['password'] ?? '');
        if ($email === '' || $name === '' || strlen($password) < 8) {
            jsonRespond(['error' => 'Nome, e-mail e senha (mín. 8) obrigatórios'], 400);
        }
        $now = dbNow();
        try {
            $pdo->prepare('
                INSERT INTO technicians (email, name, phone, password_hash, avatar_url, active, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 1, ?, ?)
            ')->execute([
                $email, $name, $phone !== '' ? $phone : null,
                password_hash($password, PASSWORD_DEFAULT),
                san($b['avatarUrl'] ?? null, 500),
                $now, $now,
            ]);
        } catch (PDOException $e) {
            jsonRespond(['error' => 'E-mail já cadastrado'], 409);
        }
        $id = (int)$pdo->lastInsertId();
        jsonRespond(['technician' => trackingGetTechnician($pdo, $id)], 201);
    }

    if ($method === 'PUT') {
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) jsonRespond(['error' => 'ID obrigatório'], 400);
        $b = jsonBody();
        $sets = [];
        $params = [];
        foreach (['name' => 'name', 'phone' => 'phone', 'avatar_url' => 'avatarUrl'] as $col => $key) {
            if (array_key_exists($key, $b)) {
                $sets[] = "{$col} = ?";
                $params[] = san($b[$key], $col === 'avatar_url' ? 500 : 200);
            }
        }
        if (isset($b['active'])) {
            $sets[] = 'active = ?';
            $params[] = !empty($b['active']) ? 1 : 0;
        }
        if (!empty($b['password']) && strlen((string)$b['password']) >= 6) {
            $sets[] = 'password_hash = ?';
            $params[] = password_hash((string)$b['password'], PASSWORD_DEFAULT);
        }
        if (!$sets) jsonRespond(['error' => 'Nada para atualizar'], 400);
        $sets[] = 'updated_at = ?';
        $params[] = dbNow();
        $params[] = $id;
        $pdo->prepare('UPDATE technicians SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
        jsonRespond(['technician' => trackingGetTechnician($pdo, $id)]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function technicianOwnsAppointment(PDO $pdo, int $techId, string $appointmentId): ?array {
    $stmt = $pdo->prepare('SELECT * FROM appointments WHERE id = ? AND technician_id = ? LIMIT 1');
    $stmt->execute([$appointmentId, $techId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function handleTechnicianAppointments(): void {
    $pdo = db();
    ensureTechnicianAuthTables($pdo);
    $techId = requireTechnician();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        $date = san($_GET['date'] ?? date('Y-m-d'), 10) ?? date('Y-m-d');
        $stmt = $pdo->prepare("
            SELECT * FROM appointments
            WHERE technician_id = ? AND date = ?
            ORDER BY time ASC
        ");
        $stmt->execute([$techId, $date]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $items = [];
        foreach ($rows as $row) {
            $decoded = decodeAppointment($row);
            $decoded['tracking'] = trackingPublicSnapshot($pdo, $row);
            $decoded['timeline'] = appointmentTimeline($pdo, (string)$row['id']);
            $items[] = $decoded;
        }
        jsonRespond([
            'date' => $date,
            'appointments' => $items,
            'realtime' => trackingRealtimeProvider()->transportInfo(),
            'map' => trackingMapTileConfig(),
        ]);
    }

    if ($method === 'PUT') {
        $id = san($_GET['id'] ?? null, 64);
        if (!$id) jsonRespond(['error' => 'ID obrigatório'], 400);
        $row = technicianOwnsAppointment($pdo, $techId, $id);
        if (!$row) jsonRespond(['error' => 'Agendamento não atribuído a este técnico'], 403);
        $b = jsonBody();
        $action = san($b['action'] ?? 'status', 40) ?? 'status';

        if ($action === 'status' || isset($b['status'])) {
            $to = normalizeAppointmentStatus(san($b['status'] ?? '', 20) ?? '');
            $result = appointmentTransitionStatus($pdo, $id, $to, [
                'type' => 'technician',
                'id' => (string)$techId,
                'technician_id' => $techId,
                'detail' => san($b['note'] ?? null, 500),
            ]);
            if (!$result['ok']) jsonRespond(['error' => $result['error']], 400);
            jsonRespond([
                'appointment' => $result['appointment'],
                'tracking' => trackingPublicSnapshot($pdo, array_merge($row, ['status' => $result['to'], 'technician_id' => $techId])),
            ]);
        }
        if ($action === 'pause_tracking') {
            if (!trackingPauseSession($pdo, $id, $techId)) {
                jsonRespond(['error' => 'Deslocamento não está ativo'], 409);
            }
            jsonRespond(['ok' => true, 'tracking' => trackingPublicSnapshot($pdo, $row)]);
        }
        if ($action === 'resume_tracking') {
            if (!trackingResumeSession($pdo, $id, $techId)) {
                jsonRespond(['error' => 'Deslocamento não está pausado'], 409);
            }
            jsonRespond(['ok' => true, 'tracking' => trackingPublicSnapshot($pdo, $row)]);
        }

        jsonRespond(['error' => 'Ação inválida'], 400);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleTechnicianLocation(): void {
    $pdo = db();
    ensureTechnicianAuthTables($pdo);
    $techId = requireTechnician();
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        jsonRespond(['error' => 'Método não permitido'], 405);
    }

    $b = jsonBody();
    $appointmentId = san($b['appointmentId'] ?? $b['appointment_id'] ?? null, 64);
    if (!$appointmentId) jsonRespond(['error' => 'appointmentId obrigatório'], 400);

    $row = technicianOwnsAppointment($pdo, $techId, $appointmentId);
    if (!$row) jsonRespond(['error' => 'Agendamento não atribuído a este técnico'], 403);

    $status = normalizeAppointmentStatus((string)($row['status'] ?? ''));
    if ($status !== 'en_route') {
        jsonRespond(['error' => 'Localização só é aceita durante deslocamento', 'code' => 'tracking_inactive'], 409);
    }

    $session = trackingActiveSession($pdo, $appointmentId);
    if (!$session) {
        $session = trackingStartSession($pdo, $appointmentId, $techId);
    }
    if (($session['status'] ?? '') !== 'active') {
        jsonRespond(['error' => 'Deslocamento pausado', 'code' => 'tracking_paused'], 409);
    }

    // Caminho único: sempre lote. Payload legado {lat,lng,...} vira lote de 1 ponto.
    $points = isset($b['points']) && is_array($b['points']) ? $b['points'] : null;
    if ($points === null) {
        if (!isset($b['lat'], $b['lng'])) {
            jsonRespond(['error' => 'Coordenadas obrigatórias'], 400);
        }
        $points = [[
            'sampleId' => san($b['sampleId'] ?? null, 64) ?: ('legacy-' . bin2hex(random_bytes(10))),
            'lat' => $b['lat'],
            'lng' => $b['lng'],
            'accuracy' => $b['accuracy'] ?? null,
            'speed' => $b['speed'] ?? null,
            'heading' => $b['heading'] ?? null,
            'timestamp' => $b['timestamp'] ?? null,
        ]];
    }

    $result = trackingIngestLocationBatch($pdo, $row, $session, $techId, $points);
    $fresh = trackingActiveSession($pdo, $appointmentId) ?: $session;
    trackingMaybeUpdateRouteAndNear($pdo, $row, $fresh);
    jsonRespond([
        'ok' => true,
        'batch' => $result,
        'tracking' => trackingPublicSnapshot($pdo, $row),
    ]);
}

function handleTechnicianChecklist(): void {
    $pdo = db();
    ensureTechnicianAuthTables($pdo);
    $techId = requireTechnician();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $appointmentId = san($_GET['id'] ?? $_GET['appointment_id'] ?? null, 64);
    if (!$appointmentId) jsonRespond(['error' => 'ID do agendamento obrigatório'], 400);
    $row = technicianOwnsAppointment($pdo, $techId, $appointmentId);
    if (!$row && !isAdmin()) jsonRespond(['error' => 'Sem acesso'], 403);

    if ($method === 'GET') {
        $stmt = $pdo->prepare('SELECT * FROM appointment_checklist_items WHERE appointment_id = ? ORDER BY sort_order ASC, id ASC');
        $stmt->execute([$appointmentId]);
        $items = array_map(static function (array $r): array {
            return [
                'id' => (int)$r['id'],
                'label' => $r['label'],
                'checked' => (int)$r['checked'] === 1,
                'photoUrl' => $r['photo_url'],
                'note' => $r['note'],
                'sortOrder' => (int)$r['sort_order'],
                'updatedAt' => $r['updated_at'],
            ];
        }, $stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
        jsonRespond(['items' => $items]);
    }

    if ($method === 'POST') {
        $b = jsonBody();
        $label = trim((string)($b['label'] ?? ''));
        if ($label === '') jsonRespond(['error' => 'label obrigatório'], 400);
        $now = dbNow();
        $pdo->prepare('
            INSERT INTO appointment_checklist_items
                (appointment_id, label, checked, photo_url, note, sort_order, updated_by, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ')->execute([
            $appointmentId,
            mb_substr($label, 0, 200),
            !empty($b['checked']) ? 1 : 0,
            san($b['photoUrl'] ?? null, 500),
            san($b['note'] ?? null, 500),
            (int)($b['sortOrder'] ?? 0),
            'tech:' . $techId,
            $now, $now,
        ]);
        jsonRespond(['ok' => true, 'id' => (int)$pdo->lastInsertId()], 201);
    }

    if ($method === 'PUT') {
        $b = jsonBody();
        $itemId = (int)($_GET['item_id'] ?? ($b['id'] ?? 0));
        if ($itemId <= 0) $itemId = (int)($b['id'] ?? 0);
        if ($itemId <= 0) jsonRespond(['error' => 'item_id obrigatório'], 400);
        $sets = [];
        $params = [];
        if (array_key_exists('checked', $b)) { $sets[] = 'checked = ?'; $params[] = !empty($b['checked']) ? 1 : 0; }
        if (array_key_exists('note', $b)) { $sets[] = 'note = ?'; $params[] = san($b['note'], 500); }
        if (array_key_exists('photoUrl', $b)) { $sets[] = 'photo_url = ?'; $params[] = san($b['photoUrl'], 500); }
        if (array_key_exists('label', $b)) { $sets[] = 'label = ?'; $params[] = san($b['label'], 200); }
        if (!$sets) jsonRespond(['error' => 'Nada para atualizar'], 400);
        $sets[] = 'updated_by = ?';
        $params[] = 'tech:' . $techId;
        $sets[] = 'updated_at = ?';
        $params[] = dbNow();
        $params[] = $itemId;
        $params[] = $appointmentId;
        $pdo->prepare('UPDATE appointment_checklist_items SET ' . implode(', ', $sets) . ' WHERE id = ? AND appointment_id = ?')
            ->execute($params);
        jsonRespond(['ok' => true]);
    }

    jsonRespond(['error' => 'Método não permitido'], 405);
}

function handleTechnicianNote(): void {
    $pdo = db();
    ensureTechnicianAuthTables($pdo);
    $techId = requireTechnician();
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') jsonRespond(['error' => 'Método não permitido'], 405);
    $b = jsonBody();
    $appointmentId = san($b['appointmentId'] ?? null, 64);
    $note = trim((string)($b['note'] ?? ''));
    $kind = san($b['kind'] ?? 'note', 40) ?? 'note';
    if (!$appointmentId || $note === '') jsonRespond(['error' => 'appointmentId e note obrigatórios'], 400);
    if (!technicianOwnsAppointment($pdo, $techId, $appointmentId)) {
        jsonRespond(['error' => 'Sem acesso'], 403);
    }
    $allowedKinds = [
        'note' => ['technician_note', 'Observação do técnico'],
        'incident' => ['technician_incident', 'Ocorrência registrada'],
        'delay' => ['technician_delay', 'Atraso registrado'],
        'blocked' => ['technician_blocked', 'Impedimento registrado'],
        'return' => ['technician_return', 'Retorno solicitado'],
    ];
    [$eventKey, $title] = $allowedKinds[$kind] ?? $allowedKinds['note'];
    appointmentRecordEvent($pdo, $appointmentId, $eventKey, $title, [
        'actor_type' => 'technician',
        'actor_id' => (string)$techId,
        'detail' => mb_substr($note, 0, 500),
    ]);
    jsonRespond(['ok' => true]);
}

function handleTechnicianPhoto(): void {
    $pdo = db();
    ensureTechnicianAuthTables($pdo);
    $techId = requireTechnician();
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') jsonRespond(['error' => 'Método não permitido'], 405);
    $appointmentId = san($_POST['appointmentId'] ?? $_POST['appointment_id'] ?? null, 64);
    if (!$appointmentId || !technicianOwnsAppointment($pdo, $techId, $appointmentId)) {
        jsonRespond(['error' => 'Sem acesso ao atendimento'], 403);
    }
    if (empty($_FILES['file'])) jsonRespond(['error' => 'Arquivo obrigatório'], 400);
    $kind = san($_POST['kind'] ?? 'service', 30) ?? 'service';
    if (!in_array($kind, ['service', 'checklist', 'signature'], true)) {
        jsonRespond(['error' => 'Tipo de foto inválido'], 400);
    }
    $entityType = $kind === 'signature' ? 'appointment_signature' : 'appointment';
    $stored = storeUploadedImage($pdo, $_FILES['file'], $entityType, $appointmentId);
    if ($kind === 'signature') {
        $pdo->prepare("UPDATE appointments SET client_signature_url = ?, client_signed_at = ?, updated_at = ? WHERE id = ?")
            ->execute([$stored['url'], dbNow(), dbNow(), $appointmentId]);
    }
    appointmentRecordEvent(
        $pdo,
        $appointmentId,
        $kind === 'signature' ? 'ClientSigned' : 'ServicePhotoAdded',
        $kind === 'signature' ? 'Assinatura do cliente registrada' : 'Foto do serviço adicionada',
        [
            'actor_type' => 'technician',
            'actor_id' => (string)$techId,
            'meta' => ['kind' => $kind, 'photo_id' => $stored['id'], 'url' => $stored['url']],
        ]
    );
    jsonRespond($stored, 201);
}
