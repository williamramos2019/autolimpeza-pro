<?php
/**
 * Perfil admin — GET/PUT settings por user_id (multi-dispositivo).
 * Rotas: admin/profile | api/v1/profile
 */

function ensureUserSettingsTable(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `user_settings` (
        `user_id` INT UNSIGNED NOT NULL,
        `profile_json` JSON NULL,
        `company_json` JSON NULL,
        `employees_json` JSON NULL,
        `notifications_json` JSON NULL,
        `security_json` JSON NULL,
        `primary_color` VARCHAR(32) DEFAULT '#0EA5FF',
        `meta_json` JSON NULL,
        `updated_at` DATETIME NOT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function userSettingsDefaults(): array {
    return [
        'profile' => [
            'id' => '1',
            'fullName' => defined('SITE_NAME') ? SITE_NAME : 'Auto Limpeza Pro',
            'email' => '',
            'phone' => '',
            'whatsapp' => '',
            'avatarUrl' => null,
            'isEmailVerified' => false,
            'isPhoneVerified' => false,
        ],
        'company' => [
            'name' => defined('SITE_NAME') ? SITE_NAME : 'Auto Limpeza Pro',
            'cnpj' => '',
            'address' => '',
            'city' => 'São José da Lapa',
            'state' => 'MG',
            'zipCode' => '',
            'phone' => '',
            'whatsapp' => '',
            'email' => defined('CONTACT_EMAIL') ? CONTACT_EMAIL : '',
            'openingHours' => 'Seg-Sex: 8h às 18h | Sáb: 8h às 14h',
            'logoUrl' => null,
            'isPublic' => true,
            'onlineBookingEnabled' => true,
        ],
        'employees' => [],
        'notifications' => [
            'emailEnabled' => true,
            'whatsappEnabled' => true,
            'pushEnabled' => true,
            'appointmentAlerts' => true,
            'paymentAlerts' => true,
            'reportAlerts' => false,
            'reminderHoursBefore' => 24,
        ],
        'security' => [
            'twoFactorEnabled' => false,
            'lastPasswordChange' => null,
            'connectedDevices' => [],
            'accessHistory' => [],
        ],
        'primaryColor' => '#0EA5FF',
        'subscription' => [
            'planName' => 'Plano Pro',
            'status' => 'active',
            'renewalDate' => null,
            'amount' => 0,
            'billingCycle' => 'monthly',
            'features' => [],
        ],
    ];
}

function userSettingsDecode(?string $json, $fallback) {
    if ($json === null || $json === '') return $fallback;
    $d = json_decode($json, true);
    return is_array($d) ? $d : $fallback;
}

function handleAdminProfile(string $method): void {
    requireAdmin();
    $pdo = db();
    ensureUserSettingsTable($pdo);

    $userId = adminSessionUserId();
    if (!$userId) {
        // Token estático / legado sem user_id — usa slot 0 (não ideal; preferir login real)
        $userId = 0;
    }

    $cacheKey = 'user_settings:' . $userId;

    if ($method === 'GET') {
        if (function_exists('alpCacheGet')) {
            $cached = alpCacheGet($cacheKey);
            if (is_array($cached)) {
                jsonRespond($cached);
            }
        }

        $defaults = userSettingsDefaults();
        $stmt = $pdo->prepare('SELECT * FROM user_settings WHERE user_id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // Enriquecer e-mail do admin_users se disponível
        if ($userId > 0) {
            try {
                $u = $pdo->prepare('SELECT email, name FROM admin_users WHERE id = ? LIMIT 1');
                $u->execute([$userId]);
                $admin = $u->fetch(PDO::FETCH_ASSOC);
                if ($admin) {
                    $defaults['profile']['email'] = $admin['email'] ?? '';
                    if (!empty($admin['name'])) {
                        $defaults['profile']['fullName'] = $admin['name'];
                    }
                }
            } catch (Throwable $e) { /* */ }
        }

        if (!$row) {
            $payload = array_merge($defaults, ['userId' => $userId, 'source' => 'defaults']);
            if (function_exists('alpCacheSet')) alpCacheSet($cacheKey, $payload, 60);
            jsonRespond($payload);
        }

        $payload = [
            'userId' => $userId,
            'source' => 'database',
            'profile' => array_merge($defaults['profile'], userSettingsDecode($row['profile_json'] ?? null, [])),
            'company' => array_merge($defaults['company'], userSettingsDecode($row['company_json'] ?? null, [])),
            'employees' => userSettingsDecode($row['employees_json'] ?? null, $defaults['employees']),
            'notifications' => array_merge($defaults['notifications'], userSettingsDecode($row['notifications_json'] ?? null, [])),
            'security' => array_merge($defaults['security'], userSettingsDecode($row['security_json'] ?? null, [])),
            'primaryColor' => $row['primary_color'] ?: $defaults['primaryColor'],
            'subscription' => $defaults['subscription'],
            'updatedAt' => $row['updated_at'] ?? null,
        ];
        if (function_exists('alpCacheSet')) alpCacheSet($cacheKey, $payload, 60);
        jsonRespond($payload);
    }

    if ($method === 'PUT' || $method === 'POST') {
        $b = jsonBody();
        $defaults = userSettingsDefaults();
        $now = dbNow();

        $profile = array_merge($defaults['profile'], is_array($b['profile'] ?? null) ? $b['profile'] : []);
        $company = array_merge($defaults['company'], is_array($b['company'] ?? $b['salon'] ?? null) ? ($b['company'] ?? $b['salon']) : []);
        $employees = is_array($b['employees'] ?? null) ? $b['employees'] : [];
        $notifications = array_merge($defaults['notifications'], is_array($b['notifications'] ?? null) ? $b['notifications'] : []);
        $security = array_merge($defaults['security'], is_array($b['security'] ?? null) ? $b['security'] : []);
        $primaryColor = san($b['primaryColor'] ?? $b['primary_color'] ?? '#0EA5FF', 32) ?? '#0EA5FF';

        $pdo->prepare(
            'INSERT INTO user_settings
                (user_id, profile_json, company_json, employees_json, notifications_json, security_json, primary_color, updated_at, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                profile_json = VALUES(profile_json),
                company_json = VALUES(company_json),
                employees_json = VALUES(employees_json),
                notifications_json = VALUES(notifications_json),
                security_json = VALUES(security_json),
                primary_color = VALUES(primary_color),
                updated_at = VALUES(updated_at)'
        )->execute([
            $userId,
            json_encode($profile, JSON_UNESCAPED_UNICODE),
            json_encode($company, JSON_UNESCAPED_UNICODE),
            json_encode($employees, JSON_UNESCAPED_UNICODE),
            json_encode($notifications, JSON_UNESCAPED_UNICODE),
            json_encode($security, JSON_UNESCAPED_UNICODE),
            $primaryColor,
            $now,
            $now,
        ]);

        if (function_exists('alpCacheDelete')) alpCacheDelete($cacheKey);

        jsonRespond([
            'ok' => true,
            'userId' => $userId,
            'updatedAt' => $now,
            'profile' => $profile,
            'company' => $company,
            'employees' => $employees,
            'notifications' => $notifications,
            'security' => $security,
            'primaryColor' => $primaryColor,
        ]);
    }

    jsonRespond(['error' => 'Método não suportado'], 405);
}
