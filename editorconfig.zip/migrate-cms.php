<?php
/**
 * CMS v2 — Migração idempotente (segura para reexecução).
 * Chamado automaticamente pela API ou manualmente via migrate-cms.php?run=1
 */

function cmsColumnExists(PDO $pdo, string $table, string $column): bool {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function cmsAddColumn(PDO $pdo, string $table, string $column, string $definition): void {
    if (!cmsColumnExists($pdo, $table, $column)) {
        $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
    }
}

function cmsTableExists(PDO $pdo, string $table): bool {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
    );
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() > 0;
}

function runCmsMigrations(PDO $pdo): array {
    $results = [];

    if (!cmsTableExists($pdo, 'blog_posts')) {
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS `blog_posts` (
                `slug` VARCHAR(200) NOT NULL, `title` VARCHAR(500) DEFAULT NULL,
                `excerpt` TEXT DEFAULT NULL, `content` LONGTEXT DEFAULT NULL,
                `category` VARCHAR(100) DEFAULT NULL, `icon_name` VARCHAR(50) DEFAULT NULL,
                `read_minutes` INT DEFAULT 5, `published_at` DATE DEFAULT NULL,
                `tags` JSON DEFAULT NULL, `service_id` VARCHAR(100) DEFAULT NULL,
                `image_url` VARCHAR(500) DEFAULT NULL, `related` JSON DEFAULT NULL,
                `blocks` JSON DEFAULT NULL, `created_at` DATETIME NOT NULL, `updated_at` DATETIME NOT NULL,
                PRIMARY KEY (`slug`), INDEX `idx_published_at` (`published_at`), INDEX `idx_category` (`category`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $results[] = ['ok', 'blog_posts (criada)'];
        } catch (Throwable $e) {
            $results[] = ['err', 'blog_posts: ' . $e->getMessage()];
        }
    }

    $blogCols = [
        'meta_title'       => 'VARCHAR(500) DEFAULT NULL',
        'meta_description' => 'TEXT DEFAULT NULL',
        'canonical'        => 'VARCHAR(500) DEFAULT NULL',
        'og_image'         => 'VARCHAR(500) DEFAULT NULL',
        'status'           => "VARCHAR(20) NOT NULL DEFAULT 'published'",
        'featured_home'    => 'TINYINT(1) NOT NULL DEFAULT 0',
        'featured_blog'    => 'TINYINT(1) NOT NULL DEFAULT 0',
        'author_id'        => 'INT UNSIGNED DEFAULT NULL',
        'author_name'      => 'VARCHAR(200) DEFAULT NULL',
        'gallery'          => 'JSON DEFAULT NULL',
        'scheduled_at'     => 'DATETIME DEFAULT NULL',
        'category_id'      => 'INT UNSIGNED DEFAULT NULL',
        'city'             => 'VARCHAR(100) DEFAULT NULL',
        'neighborhood'     => 'VARCHAR(100) DEFAULT NULL',
        'content_level'    => "VARCHAR(20) NOT NULL DEFAULT 'basico'",
        'products_cited'   => 'JSON DEFAULT NULL',
        'video_url'        => 'VARCHAR(500) DEFAULT NULL',
        'keywords'         => 'VARCHAR(500) DEFAULT NULL',
        'faq_schema'       => 'JSON DEFAULT NULL',
        'cta_config'       => 'JSON DEFAULT NULL',
    ];
    foreach ($blogCols as $col => $def) {
        try {
            cmsAddColumn($pdo, 'blog_posts', $col, $def);
            $results[] = ['ok', "blog_posts.{$col}"];
        } catch (Throwable $e) {
            // Alguns hosts MySQL antigos rejeitam JSON — tenta LONGTEXT
            if (stripos($def, 'JSON') !== false) {
                try {
                    cmsAddColumn($pdo, 'blog_posts', $col, 'LONGTEXT DEFAULT NULL');
                    $results[] = ['ok', "blog_posts.{$col} (LONGTEXT fallback)"];
                    continue;
                } catch (Throwable $e2) {
                    $results[] = ['err', "blog_posts.{$col}: " . $e2->getMessage()];
                    continue;
                }
            }
            $results[] = ['err', "blog_posts.{$col}: " . $e->getMessage()];
        }
    }

    try {
        cmsAddColumn($pdo, 'cms_transformations', 'gallery', 'JSON DEFAULT NULL');
        $results[] = ['ok', 'cms_transformations.gallery'];
    } catch (Throwable $e) {
        $results[] = ['err', 'cms_transformations.gallery: ' . $e->getMessage()];
    }

    // Tabelas críticas — CREATE explícito (cms_v2.sql tinha bug: statements
    // que começavam com "-- comentário" eram ignorados pelo parser).
    ensureCmsV2CoreTables($pdo, $results);

    $sqlFile = __DIR__ . '/migrations/cms_v2.sql';
    if (file_exists($sqlFile)) {
        $sql = file_get_contents($sqlFile);
        $statements = array_filter(array_map('trim', preg_split('/;\s*\n/', $sql)));
        foreach ($statements as $stmt) {
            if ($stmt === '') continue;
            // Remove linhas de comentário SQL no início/meio antes de decidir pular
            $clean = preg_replace('/^\s*--[^\n]*\n?/m', '', $stmt);
            $clean = trim((string) $clean);
            if ($clean === '' || stripos($clean, 'CREATE ') !== 0 && stripos($clean, 'ALTER ') !== 0 && stripos($clean, 'INSERT ') !== 0) {
                continue;
            }
            try {
                $pdo->exec($clean);
            } catch (Throwable $e) {
                if (strpos($e->getMessage(), 'already exists') === false) {
                    $results[] = ['warn', substr($clean, 0, 60) . '…: ' . $e->getMessage()];
                }
            }
        }
        $results[] = ['ok', 'cms_v2.sql'];
    }

    seedDefaultCategories($pdo, $results);
    seedNicheCategories($pdo, $results);
    seedDefaultAuthors($pdo, $results);
    auditBlogCmsTables($pdo, $results);

    // Módulos CMS extra (menus, forms, redirects, etc.)
    $extraSql = __DIR__ . '/migrations/cms_extra_modules_v1.sql';
    if (file_exists($extraSql)) {
        if (function_exists('alpRunSqlMigration')) {
            alpRunSqlMigration($pdo, $extraSql);
            $results[] = ['ok', 'cms_extra_modules_v1.sql'];
        } else {
            $sql = file_get_contents($extraSql);
            $statements = array_filter(array_map('trim', preg_split('/;\s*\n/', $sql)));
            foreach ($statements as $stmt) {
                $clean = trim((string) preg_replace('/^\s*--[^\n]*\n?/m', '', $stmt));
                if ($clean === '' || stripos($clean, 'CREATE ') !== 0) continue;
                try {
                    $pdo->exec($clean);
                } catch (Throwable $e) {
                    if (strpos($e->getMessage(), 'already exists') === false) {
                        $results[] = ['warn', 'cms_extra: ' . substr($clean, 0, 50) . '…: ' . $e->getMessage()];
                    }
                }
            }
            $results[] = ['ok', 'cms_extra_modules_v1.sql (inline)'];
        }
    } elseif (function_exists('ensureCmsExtraTables')) {
        ensureCmsExtraTables($pdo);
        $results[] = ['ok', 'cms_extra_tables'];
    }
    auditCmsExtraTables($pdo, $results);

    $affiliateSql = __DIR__ . '/migrations/2026-07-28-blog_affiliate_links_v1.sql';
    if (is_file($affiliateSql) && function_exists('alpRunSqlMigration')) {
        alpRunSqlMigration($pdo, $affiliateSql);
        $results[] = ['ok', '2026-07-28-blog_affiliate_links_v1.sql'];
        $affiliatePhp = __DIR__ . '/blog-affiliate-links.php';
        if (is_file($affiliatePhp)) {
            require_once $affiliatePhp;
        }
        if (function_exists('blogAffiliateLinksSeedDefaults')) {
            blogAffiliateLinksSeedDefaults($pdo);
            $results[] = ['ok', 'blog_affiliate_links seeds'];
        }
        $shopeeSeed = __DIR__ . '/migrations/2026-07-28-shopee_affiliate_links_seed.sql';
        if (is_file($shopeeSeed) && function_exists('alpRunSqlMigration')) {
            alpRunSqlMigration($pdo, $shopeeSeed);
            $results[] = ['ok', '2026-07-28-shopee_affiliate_links_seed.sql'];
        }
        $affSel = __DIR__ . '/migrations/2026-08-11-blog_affiliate_selection.sql';
        if (is_file($affSel) && function_exists('alpRunSqlMigration')) {
            alpRunSqlMigration($pdo, $affSel);
            $results[] = ['ok', '2026-08-11-blog_affiliate_selection.sql'];
        }
        if (function_exists('ensureBlogAffiliateUsageTable')) {
            ensureBlogAffiliateUsageTable($pdo);
            $results[] = ['ok', 'blog_affiliate_links usage columns'];
        }
    }

    return $results;
}

/** Verifica tabelas CMS/blog — nunca apaga dados */
function auditBlogCmsTables(PDO $pdo, array &$results): void {
    $required = [
        'blog_posts'           => 'posts',
        'blog_categories'      => 'categorias',
        'blog_comments'        => 'comentários',
        'blog_tags'            => 'tags',
        'blog_authors'         => 'autores',
        'media_library'        => 'biblioteca de mídia',
        'blog_tips'            => 'dicas rápidas',
        'blog_post_tags'       => 'tags de posts',
        'custom_blocks'        => 'blocos personalizados',
        'blog_post_revisions'  => 'revisões de posts',
        'blog_affiliate_links' => 'links afiliados',
        'blog_affiliate_link_usage' => 'histórico uso afiliados',
    ];
    foreach ($required as $table => $label) {
        if (cmsTableExists($pdo, $table)) {
            $results[] = ['ok', "tabela {$table} ({$label})"];
        } else {
            $results[] = ['err', "tabela {$table} ({$label}) ausente"];
        }
    }
}

/** Verifica tabelas dos 8 módulos CMS Premium extra */
function auditCmsExtraTables(PDO $pdo, array &$results): void {
    $required = [
        'cms_menus'                  => 'menus',
        'cms_downloads'              => 'downloads',
        'cms_forms'                  => 'formulários',
        'cms_form_submissions'       => 'envios de formulário',
        'cms_newsletter_subscribers' => 'newsletter',
        'cms_popups'                 => 'popups',
        'cms_redirects'              => 'redirecionamentos',
        'cms_backups'                => 'backups',
        'cms_widgets'                => 'widgets',
    ];
    foreach ($required as $table => $label) {
        if (cmsTableExists($pdo, $table)) {
            $results[] = ['ok', "tabela {$table} ({$label})"];
        } else {
            $results[] = ['err', "tabela {$table} ({$label}) ausente"];
        }
    }
}

/**
 * Garante tabelas CMS v2 mesmo se o parser do .sql falhar.
 * Idempotente — CREATE IF NOT EXISTS.
 */
function ensureCmsV2CoreTables(PDO $pdo, array &$results): void {
    $tables = [
        'blog_categories' => "CREATE TABLE IF NOT EXISTS `blog_categories` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `slug` VARCHAR(120) NOT NULL,
            `name` VARCHAR(200) NOT NULL,
            `icon` VARCHAR(50) DEFAULT 'BookOpen',
            `color` VARCHAR(20) DEFAULT '#1FB1F9',
            `description` TEXT DEFAULT NULL,
            `meta_title` VARCHAR(500) DEFAULT NULL,
            `meta_description` TEXT DEFAULT NULL,
            `canonical` VARCHAR(500) DEFAULT NULL,
            `og_image` VARCHAR(500) DEFAULT NULL,
            `sort_order` INT NOT NULL DEFAULT 0,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_cat_slug` (`slug`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'blog_tags' => "CREATE TABLE IF NOT EXISTS `blog_tags` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `slug` VARCHAR(120) NOT NULL,
            `name` VARCHAR(200) NOT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_tag_slug` (`slug`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'blog_post_tags' => "CREATE TABLE IF NOT EXISTS `blog_post_tags` (
            `post_slug` VARCHAR(200) NOT NULL,
            `tag_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY (`post_slug`, `tag_id`),
            INDEX `idx_tag_id` (`tag_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'blog_comments' => "CREATE TABLE IF NOT EXISTS `blog_comments` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `post_slug` VARCHAR(200) NOT NULL,
            `author_name` VARCHAR(200) NOT NULL,
            `email` VARCHAR(255) DEFAULT NULL,
            `content` TEXT NOT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_comment_post` (`post_slug`),
            INDEX `idx_comment_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'blog_authors' => "CREATE TABLE IF NOT EXISTS `blog_authors` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `slug` VARCHAR(120) NOT NULL,
            `name` VARCHAR(200) NOT NULL,
            `photo_url` VARCHAR(500) DEFAULT NULL,
            `bio` TEXT DEFAULT NULL,
            `specialty` VARCHAR(200) DEFAULT NULL,
            `social_json` JSON DEFAULT NULL,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `sort_order` INT NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_author_slug` (`slug`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'media_library' => "CREATE TABLE IF NOT EXISTS `media_library` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `filename` VARCHAR(255) NOT NULL,
            `original_name` VARCHAR(255) DEFAULT NULL,
            `folder` VARCHAR(50) NOT NULL DEFAULT 'Blog',
            `url` VARCHAR(500) NOT NULL,
            `mime` VARCHAR(100) DEFAULT NULL,
            `size` INT UNSIGNED DEFAULT 0,
            `width` INT UNSIGNED DEFAULT NULL,
            `height` INT UNSIGNED DEFAULT NULL,
            `uploaded_by` INT UNSIGNED DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_media_folder` (`folder`),
            INDEX `idx_media_created` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'blog_post_tags' => "CREATE TABLE IF NOT EXISTS `blog_post_tags` (
            `post_slug` VARCHAR(200) NOT NULL,
            `tag_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY (`post_slug`, `tag_id`),
            INDEX `idx_tag_id` (`tag_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'blog_tips' => "CREATE TABLE IF NOT EXISTS `blog_tips` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `slug` VARCHAR(200) NOT NULL,
            `title` VARCHAR(500) NOT NULL,
            `image_url` VARCHAR(500) DEFAULT NULL,
            `text` TEXT NOT NULL,
            `category_id` INT UNSIGNED DEFAULT NULL,
            `featured` TINYINT(1) NOT NULL DEFAULT 0,
            `status` VARCHAR(20) NOT NULL DEFAULT 'published',
            `sort_order` INT NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_tip_slug` (`slug`),
            INDEX `idx_tip_featured` (`featured`),
            INDEX `idx_tip_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'custom_blocks' => "CREATE TABLE IF NOT EXISTS `custom_blocks` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `identifier` VARCHAR(100) NOT NULL,
            `name` VARCHAR(200) NOT NULL,
            `html` LONGTEXT DEFAULT NULL,
            `css` LONGTEXT DEFAULT NULL,
            `js` LONGTEXT DEFAULT NULL,
            `active` TINYINT(1) NOT NULL DEFAULT 1,
            `created_by` INT UNSIGNED DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_block_identifier` (`identifier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        'blog_post_revisions' => "CREATE TABLE IF NOT EXISTS `blog_post_revisions` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `post_slug` VARCHAR(200) NOT NULL,
            `title` VARCHAR(500) NOT NULL,
            `excerpt` TEXT DEFAULT NULL,
            `content` LONGTEXT DEFAULT NULL,
            `blocks` JSON DEFAULT NULL,
            `meta_title` VARCHAR(500) DEFAULT NULL,
            `meta_description` TEXT DEFAULT NULL,
            `status` VARCHAR(20) DEFAULT NULL,
            `author_id` INT UNSIGNED DEFAULT NULL,
            `author_name` VARCHAR(200) DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_rev_slug` (`post_slug`),
            INDEX `idx_rev_created` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];

    foreach ($tables as $name => $ddl) {
        if (cmsTableExists($pdo, $name)) {
            continue;
        }
        try {
            // Fallback LONGTEXT se JSON não for suportado (hosts antigos)
            try {
                $pdo->exec($ddl);
            } catch (Throwable $e) {
                if (stripos($ddl, 'JSON') !== false && stripos($e->getMessage(), 'JSON') !== false) {
                    $pdo->exec(str_ireplace('JSON DEFAULT NULL', 'LONGTEXT DEFAULT NULL', $ddl));
                } else {
                    throw $e;
                }
            }
            $results[] = ['ok', "{$name} (criada)"];
        } catch (Throwable $e) {
            $results[] = ['err', "{$name}: " . $e->getMessage()];
        }
    }
}

function seedDefaultAuthors(PDO $pdo, array &$results): void {
    if (!cmsTableExists($pdo, 'blog_authors')) return;
    $count = (int)$pdo->query('SELECT COUNT(*) FROM blog_authors')->fetchColumn();
    if ($count > 0) return;

    $now = date('Y-m-d H:i:s');
    $authors = [
        ['william-coelho', 'William Coelho', 'Fundador e especialista em higienização profissional de estofados.', 'Estofados e impermeabilização', '{"instagram":"","linkedin":""}'],
        ['equipe-auto-limpeza-pro', 'Equipe Auto Limpeza Pro', 'Time técnico certificado em MG.', 'Higienização residencial e automotiva', '{}'],
        ['especialista-estofados', 'Especialista em Estofados', 'Conteúdo técnico sobre sofás, colchões e tecidos.', 'Estofados', '{}'],
        ['redacao', 'Redação', 'Matérias editoriais e notícias do portal.', 'Jornalismo', '{}'],
    ];
    $stmt = $pdo->prepare(
        'INSERT INTO blog_authors (slug, name, bio, specialty, social_json, active, sort_order, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)'
    );
    $i = 0;
    foreach ($authors as $a) {
        $stmt->execute([$a[0], $a[1], $a[2], $a[3], $a[4], $i++, $now, $now]);
    }
    $results[] = ['ok', 'seed blog_authors (' . count($authors) . ')'];
}

function seedDefaultCategories(PDO $pdo, array &$results): void {
    if (!cmsTableExists($pdo, 'blog_categories')) return;
    $count = (int)$pdo->query('SELECT COUNT(*) FROM blog_categories')->fetchColumn();
    if ($count > 0) return;

    $now = date('Y-m-d H:i:s');
    $cats = [
        ['higienizacao-sofas', 'Higienização de Sofás', 'Sofa', '#1FB1F9'],
        ['limpeza-colchoes', 'Limpeza de Colchões', 'Bed', '#06C6E0'],
        ['limpeza-automotiva', 'Limpeza Automotiva', 'Car', '#8B5CF6'],
        ['impermeabilizacao', 'Impermeabilização', 'Shield', '#22C55E'],
        ['dicas-limpeza', 'Dicas de Limpeza', 'BookOpen', '#F59E0B'],
        ['antes-depois', 'Antes e Depois', 'Sparkles', '#EC4899'],
        ['pos-obra', 'Pós-Obra', 'HardHat', '#64748B'],
    ];
    $stmt = $pdo->prepare(
        'INSERT INTO blog_categories (slug, name, icon, color, sort_order, active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?)'
    );
    $i = 0;
    foreach ($cats as $c) {
        $stmt->execute([$c[0], $c[1], $c[2], $c[3], $i++, $now, $now]);
    }
    $results[] = ['ok', 'seed blog_categories (' . count($cats) . ')'];
}

/** Upsert categorias do nicho sem apagar existentes */
function seedNicheCategories(PDO $pdo, array &$results): void {
    if (!cmsTableExists($pdo, 'blog_categories')) return;

    $now = date('Y-m-d H:i:s');
    $cats = [
        ['poltronas', 'Poltronas', 'Armchair', '#38bdf8'],
        ['cadeiras', 'Cadeiras', 'Chair', '#22d3ee'],
        ['tapetes-carpetes', 'Tapetes e Carpetes', 'LayoutGrid', '#14b8a6'],
        ['limpeza-residencial', 'Limpeza Residencial', 'Home', '#22c55e'],
        ['limpeza-empresarial', 'Limpeza Empresarial', 'Briefcase', '#6366f1'],
        ['estetica-automotiva', 'Estética Automotiva', 'Car', '#818cf8'],
        ['bancos-auto', 'Bancos Automotivos', 'Car', '#6366f1'],
        ['higienizacao-interna', 'Higienização Interna', 'Sparkles', '#2563eb'],
        ['cristalizacao', 'Cristalização', 'Gem', '#1d4ed8'],
        ['manutencao', 'Manutenção', 'Wrench', '#0891b2'],
        ['cuidados', 'Cuidados', 'Heart', '#0e7490'],
        ['conservacao', 'Conservação', 'ShieldCheck', '#164e63'],
        ['curiosidades', 'Curiosidades', 'Lightbulb', '#f59e0b'],
        ['promocoes', 'Promoções', 'Tag', '#ec4899'],
        ['casos-reais', 'Casos Reais', 'Star', '#f97316'],
    ];

    $check = $pdo->prepare('SELECT id FROM blog_categories WHERE slug = ? LIMIT 1');
    $insert = $pdo->prepare(
        'INSERT INTO blog_categories (slug, name, icon, color, sort_order, active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?)'
    );
    $i = 100;
    $added = 0;
    foreach ($cats as $c) {
        $check->execute([$c[0]]);
        if ($check->fetchColumn()) continue;
        $insert->execute([$c[0], $c[1], $c[2], $c[3], $i++, $now, $now]);
        $added++;
    }
    if ($added > 0) {
        $results[] = ['ok', "seed niche categories (+{$added})"];
    }
}

// CLI / browser manual
if (php_sapi_name() !== 'cli' && basename($_SERVER['SCRIPT_FILENAME'] ?? '') === 'migrate-cms.php') {
    header('Content-Type: application/json; charset=utf-8');
    $configFile = __DIR__ . '/config.php';
    if (!file_exists($configFile)) {
        echo json_encode(['error' => 'config.php não encontrado']);
        exit;
    }
    require_once $configFile;
    require_once __DIR__ . '/functions.php';
    if (empty($_GET['run'])) {
        echo json_encode(['info' => 'Adicione ?run=1&token=ADMIN_TOKEN para executar a migração CMS v2']);
        exit;
    }
    $provided = (string)($_SERVER['HTTP_X_ADMIN_TOKEN'] ?? $_GET['token'] ?? '');
    $expected = defined('ADMIN_TOKEN') ? (string)ADMIN_TOKEN : '';
    if ($expected === '' || !hash_equals($expected, $provided)) {
        http_response_code(401);
        echo json_encode(['error' => 'Token inválido. Use header X-Admin-Token ou ?token=']);
        exit;
    }
    try {
        $pdo = db();
        $results = runCmsMigrations($pdo);
        echo json_encode(['ok' => true, 'results' => $results], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}
