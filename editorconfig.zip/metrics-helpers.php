<?php
/**
 * Métricas compartilhadas — Dashboard Executivo, CRM, Capitão Clean, Conversão.
 * Evita divisão por zero, NaN e valores fixos arbitrários quando há dados reais.
 */

/** Percentual seguro (0 quando denominador <= 0). */
function metricsSafePercent(float|int $numerator, float|int $denominator, int $decimals = 1): float {
    $den = (float)$denominator;
    if ($den <= 0) {
        return 0.0;
    }
    $pct = ((float)$numerator / $den) * 100;
    if (!is_finite($pct) || $pct < 0) {
        return 0.0;
    }
    return round(min($pct, 100.0), $decimals);
}

/** Extrai valor monetário de string com R$ (ex.: "Sofá — R$ 250,00"). */
function metricsParseBrlFromString(string $text): float {
    if (!preg_match('/R\$\s*([\d.,]+)/u', $text, $m)) {
        return 0.0;
    }
    $raw = $m[1];
    // Formato BR (1.250,00): remove milhar e troca vírgula decimal.
    if (str_contains($raw, ',')) {
        $raw = str_replace('.', '', $raw);
        $raw = str_replace(',', '.', $raw);
    }
    $val = (float)$raw;
    return $val > 0 ? $val : 0.0;
}

/** Valor estimado de um agendamento a partir do JSON `services`. */
function metricsAppointmentServicesValue(mixed $servicesJson): float {
    if ($servicesJson === null || $servicesJson === '') {
        return 150.0;
    }
    // Se veio string pura (não JSON), tenta parsear R$ antes do fallback 150.
    if (is_string($servicesJson)) {
        $decoded = json_decode($servicesJson, true);
        if (!is_array($decoded)) {
            $fromStr = metricsParseBrlFromString($servicesJson);
            return $fromStr > 0 ? round($fromStr, 2) : 150.0;
        }
        $svc = $decoded;
    } else {
        $svc = $servicesJson;
    }
    if (!is_array($svc) || count($svc) === 0) {
        return 150.0;
    }
    $total = 0.0;
    foreach ($svc as $item) {
        if (is_array($item)) {
            $price = (float)($item['price'] ?? $item['fromPrice'] ?? $item['total'] ?? $item['estimatedValue'] ?? 0);
            if ($price <= 0) {
                // Labels legados com preço embutido no nome
                $label = (string)($item['name'] ?? $item['label'] ?? $item['title'] ?? '');
                $price = $label !== '' ? metricsParseBrlFromString($label) : 0.0;
            }
            $total += $price > 0 ? $price : 150.0;
        } elseif (is_string($item)) {
            $fromStr = metricsParseBrlFromString($item);
            // Prefere R$ embutido no rótulo; só cai no default 150 se não houver valor.
            $total += $fromStr > 0 ? $fromStr : 150.0;
        } else {
            $total += 150.0;
        }
    }
    return round($total, 2);
}

/**
 * Soma receita estimada de agendamentos (exclui cancelados por padrão).
 *
 * @param list<string>|null $statuses null = todos os status
 */
function metricsSumAppointmentsRevenue(PDO $pdo, ?array $statuses = null): float {
    $cancelled = ['cancelled', 'cancelado'];
    if ($statuses === null) {
        $stmt = $pdo->query('SELECT services, status FROM appointments');
    } else {
        $placeholders = implode(',', array_fill(0, count($statuses), '?'));
        $stmt = $pdo->prepare("SELECT services, status FROM appointments WHERE status IN ($placeholders)");
        $stmt->execute($statuses);
    }
    $sum = 0.0;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $st = strtolower((string)($row['status'] ?? ''));
        if ($statuses === null && in_array($st, $cancelled, true)) {
            continue;
        }
        $sum += metricsAppointmentServicesValue($row['services'] ?? null);
    }
    return round($sum, 2);
}

/** Receita confirmada/real quando existir módulo financeiro. */
function metricsSumFinancialIncome(PDO $pdo, ?string $monthYm = null): float {
    try {
        if (function_exists('ensureFinancialTables')) {
            ensureFinancialTables($pdo);
        }
        if ($monthYm) {
            $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM financial_transactions WHERE type='income' AND DATE_FORMAT(date,'%Y-%m')=?");
            $stmt->execute([$monthYm]);
        } else {
            $stmt = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM financial_transactions WHERE type='income'");
        }
        return round((float)$stmt->fetchColumn(), 2);
    } catch (Throwable $e) {
        return 0.0;
    }
}

/** Receita estimada consolidada: financeiro (se > 0) ou agendamentos + leads com valor. */
function metricsComputeEstimatedRevenue(PDO $pdo): float {
    $fromFinance = metricsSumFinancialIncome($pdo);
    if ($fromFinance > 0) {
        return $fromFinance;
    }

    $fromAppointments = metricsSumAppointmentsRevenue($pdo);
    $fromLeads = 0.0;
    try {
        $fromLeads = (float)$pdo->query(
            "SELECT COALESCE(SUM(estimated_value),0) FROM leads WHERE estimated_value IS NOT NULL AND estimated_value > 0"
        )->fetchColumn();
    } catch (Throwable $e) { /* coluna opcional */ }

    return round(max($fromAppointments, $fromLeads), 2);
}

/** Taxa de conversão de leads (aprovados + convertidos / total). */
function metricsLeadConversionRate(PDO $pdo): float {
    try {
        $total = (int)$pdo->query('SELECT COUNT(*) FROM leads')->fetchColumn();
        $approved = (int)$pdo->query(
            "SELECT COUNT(*) FROM leads WHERE crm_status IN ('aprovado','convertido')"
        )->fetchColumn();
        return metricsSafePercent($approved, $total);
    } catch (Throwable $e) {
        return 0.0;
    }
}

/** Conversão do dia: leads criados hoje que já convertidos / leads criados hoje. */
function metricsTodayLeadConversionRate(PDO $pdo): float {
    try {
        $newToday = (int)$pdo->query(
            'SELECT COUNT(*) FROM leads WHERE DATE(created_at) = CURDATE()'
        )->fetchColumn();
        $convertedToday = (int)$pdo->query(
            "SELECT COUNT(*) FROM leads WHERE DATE(created_at) = CURDATE() AND crm_status IN ('aprovado','convertido')"
        )->fetchColumn();
        return metricsSafePercent($convertedToday, $newToday);
    } catch (Throwable $e) {
        return 0.0;
    }
}

/** Conversão funil do dia: agendamentos criados hoje / leads criados hoje (fallback). */
function metricsTodayFunnelConversionRate(PDO $pdo): float {
    try {
        $newToday = (int)$pdo->query(
            'SELECT COUNT(*) FROM leads WHERE DATE(created_at) = CURDATE()'
        )->fetchColumn();
        $apptsCreatedToday = (int)$pdo->query(
            'SELECT COUNT(*) FROM appointments WHERE DATE(created_at) = CURDATE()'
        )->fetchColumn();
        if ($newToday > 0) {
            return metricsSafePercent($apptsCreatedToday, $newToday);
        }
        return metricsTodayLeadConversionRate($pdo);
    } catch (Throwable $e) {
        return 0.0;
    }
}
