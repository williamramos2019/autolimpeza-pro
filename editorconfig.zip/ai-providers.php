<?php
/**
 * Capitão Clean IA — Camada de abstração de provedores generativos
 * Uso: apenas conteúdo criativo (texto). Dados internos → capitao-clean-handlers.php (Core)
 * Todas as chamadas generativas roteiam pelo AIGateway.
 */

interface AIProviderInterface {
    /** @return string|null Texto gerado ou null se indisponível */
    public function chat(string $system, string $user, int $maxTokens = 1024): ?string;
    public function name(): string;
}

class GeminiProvider implements AIProviderInterface {
    public function name(): string { return 'gemini'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'gemini')['text'] ?? null;
    }
}

class OpenRouterProvider implements AIProviderInterface {
    public function name(): string { return 'openrouter'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'openrouter')['text'] ?? null;
    }
}

class DeepSeekProvider implements AIProviderInterface {
    public function name(): string { return 'deepseek'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'deepseek')['text'] ?? null;
    }
}

class GroqProvider implements AIProviderInterface {
    public function name(): string { return 'groq'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'groq')['text'] ?? null;
    }
}

class OpenAIProvider implements AIProviderInterface {
    public function name(): string { return 'openai'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'openai')['text'] ?? null;
    }
}

class AnthropicProvider implements AIProviderInterface {
    public function name(): string { return 'anthropic'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'anthropic')['text'] ?? null;
    }
}

class MistralProvider implements AIProviderInterface {
    public function name(): string { return 'mistral'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'mistral')['text'] ?? null;
    }
}

class TogetherProvider implements AIProviderInterface {
    public function name(): string { return 'together'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'together')['text'] ?? null;
    }
}

class CerebrasProvider implements AIProviderInterface {
    public function name(): string { return 'cerebras'; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, 'cerebras')['text'] ?? null;
    }
}

class OpenAICompatibleProvider implements AIProviderInterface {
    private string $label;
    public function __construct(string $label = 'openai_compatible') { $this->label = $label; }
    public function name(): string { return $this->label; }

    public function chat(string $system, string $user, int $maxTokens = 1024): ?string {
        return aiGatewayGenerateText($system, $user, $maxTokens, $this->label)['text'] ?? null;
    }
}

/**
 * Geração via AI Gateway — ponto único para módulos de negócio.
 * @return array{text:?string,provider:?string,model:?string,ok:bool,error:?string}
 */
function aiGatewayGenerateText(string $system, string $user, int $maxTokens = 1024, string $module = 'default'): array {
    if (!class_exists('AIGateway')) {
        require_once __DIR__ . '/ai-gateway.php';
    }
    try {
        $r = AIGateway::chat([
            'system'    => $system,
            'user'      => $user,
            'maxTokens' => $maxTokens,
            'module'    => $module,
        ]);
    } catch (Throwable $e) {
        return [
            'text'     => null,
            'provider' => null,
            'model'    => null,
            'ok'       => false,
            'error'    => 'Falha no AI Gateway: ' . $e->getMessage(),
        ];
    }
    if (($r['status'] ?? '') === 'ok' && !empty($r['content'])) {
        return [
            'text'     => $r['content'],
            'provider' => $r['provider'] ?? null,
            'model'    => $r['model'] ?? null,
            'ok'       => true,
            'error'    => null,
        ];
    }
    $err = (string)($r['error'] ?? 'IA indisponível');
    // Mensagem acionável quando nenhuma chave está configurada
    if (
        stripos($err, 'sem_chave') !== false
        || stripos($err, 'Chave API') !== false
        || stripos($err, 'Nenhum provedor') !== false
        || stripos($err, 'não configur') !== false
    ) {
        $err = 'Nenhum provedor de IA com chave válida. Configure a chave no AI Gateway (Sistema → AI Gateway) ou em Configurações.';
    }
    return [
        'text'     => null,
        'provider' => $r['provider'] ?? null,
        'model'    => $r['model'] ?? null,
        'ok'       => false,
        'error'    => $err,
    ];
}

/**
 * Gerenciador único de provedores — Dashboard, Capitão e Gerador IA consultam aqui.
 */
class AIProviderFactory {
    /** @return string[] */
    public static function order(): array {
        return ['gemini', 'openrouter', 'deepseek', 'huggingface', 'openai', 'groq', 'anthropic', 'mistral', 'together', 'cerebras'];
    }

    /** @return AIProviderInterface[] */
    public static function instances(): array {
        return [
            new GeminiProvider(),
            new OpenRouterProvider(),
            new DeepSeekProvider(),
            new GroqProvider(),
            new OpenAIProvider(),
            new AnthropicProvider(),
            new MistralProvider(),
            new TogetherProvider(),
            new CerebrasProvider(),
        ];
    }

    /**
     * Geração com failover via AI Gateway.
     * @param array{module?:string,temperature?:float,json?:bool,maxTokens?:int} $opts
     * @return array{text:?string,provider:?string,model:?string,ok:bool,error:?string}
     */
    public static function generate(string $system, string $user, int $maxTokens = 1024, array $opts = []): array {
        if (!class_exists('AIGateway')) {
            require_once __DIR__ . '/ai-gateway.php';
        }
        $r = AIGateway::chat([
            'system'      => $system,
            'user'        => $user,
            'maxTokens'   => $maxTokens,
            'module'      => $opts['module'] ?? 'default',
            'temperature' => (float)($opts['temperature'] ?? 0.65),
            'json'        => !empty($opts['json']),
            'skipCache'   => !empty($opts['skipCache']),
        ]);
        if (($r['status'] ?? '') === 'ok') {
            return [
                'text'     => $r['content'] ?? null,
                'provider' => $r['provider'] ?? null,
                'model'    => $r['model'] ?? null,
                'ok'       => true,
                'error'    => null,
            ];
        }
        return [
            'text'     => null,
            'provider' => null,
            'model'    => $r['model'] ?? null,
            'ok'       => false,
            'error'    => $r['error'] ?? 'Todos os provedores falharam',
        ];
    }

    public static function detectSource(string $name): ?string {
        $map = [
            'gemini'      => ['GEMINI_API_KEY', ['gemini_key', 'gemini_api_key']],
            'openrouter'  => ['OPENROUTER_API_KEY', ['openrouter_key']],
            'deepseek'    => ['DEEPSEEK_API_KEY', ['deepseek_key']],
            'huggingface' => ['HUGGINGFACE_API_KEY', ['huggingface_key']],
            'openai'      => ['OPENAI_API_KEY', ['openai_key']],
            'groq'        => ['GROQ_API_KEY', ['groq_key']],
            'anthropic'   => ['ANTHROPIC_API_KEY', ['anthropic_key']],
            'mistral'     => ['MISTRAL_API_KEY', ['mistral_key']],
            'together'    => ['TOGETHER_API_KEY', ['together_key']],
            'cerebras'    => ['CEREBRAS_API_KEY', ['cerebras_key']],
        ];
        if (!isset($map[$name])) {
            try {
                $pdo = db();
                if (!function_exists('ensureAiGatewayTables')) {
                    require_once __DIR__ . '/ai-gateway.php';
                }
                ensureAiGatewayTables($pdo);
                $stmt = $pdo->prepare('SELECT id FROM ai_providers WHERE provider_type = ? AND enabled = 1 AND api_key_enc IS NOT NULL AND api_key_enc != "" LIMIT 1');
                $stmt->execute([$name]);
                if ($stmt->fetchColumn()) return 'ai_providers';
            } catch (Throwable $e) { /* */ }
            return null;
        }
        [$const, $dbKeys] = $map[$name];
        if (defined($const) && trim((string) constant($const)) !== '') {
            return 'config.php';
        }
        try {
            $pdo = db();
            foreach ((array) $dbKeys as $dbKey) {
                $stmt = $pdo->prepare('SELECT value FROM site_config WHERE key_name = ? LIMIT 1');
                $stmt->execute([$dbKey]);
                $v = $stmt->fetchColumn();
                if ($v !== false && $v !== null && trim((string) $v) !== '') {
                    return 'site_config.' . $dbKey;
                }
            }
            if (!function_exists('ensureAiGatewayTables')) {
                require_once __DIR__ . '/ai-gateway.php';
            }
            ensureAiGatewayTables($pdo);
            $stmt = $pdo->prepare('SELECT id FROM ai_providers WHERE provider_type = ? AND enabled = 1 LIMIT 1');
            $stmt->execute([$name]);
            if ($stmt->fetchColumn()) return 'ai_providers';
        } catch (Throwable $e) {
            return null;
        }
        return null;
    }

    /** Status unificado para Dashboard, Capitão, diagnóstico e Gerador IA */
    public static function status(): array {
        $providers = [];
        $anyConfigured = false;
        foreach (self::order() as $name) {
            $key = function_exists('aiConfigKey') ? aiConfigKey($name) : null;
            $configured = $key !== null && $key !== '';
            if (!$configured) {
                $src = self::detectSource($name);
                $configured = $src === 'ai_providers';
            }
            if ($configured) $anyConfigured = true;
            $providers[$name] = [
                'configured' => $configured,
                'source'     => $configured ? self::detectSource($name) : null,
            ];
        }
        return [
            'anyConfigured' => $anyConfigured,
            'primary'       => $providers['gemini']['configured'] ? 'gemini' : (
                ($providers['openrouter']['configured'] ?? false) ? 'openrouter' : null
            ),
            'providers'     => $providers,
            'gateway'       => class_exists('AIGateway'),
        ];
    }
}

/** @return AIProviderInterface[] */
function aiProviderList(): array {
    return AIProviderFactory::instances();
}

/**
 * Geração generativa com fallback via AI Gateway. Nunca usar para dados internos do sistema.
 * @param string $module Módulo de roteamento (capitao, blog, chat, logs, etc.)
 */
function aiProviderGenerateText(string $system, string $user, int $maxTokens = 1024, string $module = 'capitao'): array {
    $r = AIProviderFactory::generate($system, $user, $maxTokens, ['module' => $module]);
    if ($r['ok'] && !empty($r['text'])) {
        return ['text' => $r['text'], 'provider' => $r['provider'], 'model' => $r['model'] ?? null];
    }
    return ['text' => null, 'provider' => null, 'model' => $r['model'] ?? null];
}
