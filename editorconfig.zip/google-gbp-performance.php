<?php
/**
 * Google Business Profile Performance API — serviço server-side.
 *
 * Endpoints Google:
 *  - GET  .../v1/locations/{id}:fetchMultiDailyMetricsTimeSeries
 *  - GET  .../v1/locations/{id}/searchkeywords/impressions/monthly
 *
 * Cache: alpCache (Redis/memory) + MySQL google_gbp_api_cache (TTL 12h padrão).
 * Tokens: GOOGLE_GBP_REFRESH_TOKEN / GOOGLE_REFRESH_TOKEN ou site_config.
 */

function gbpEnsureCacheTable(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `google_gbp_api_cache` (
        `cache_key` VARCHAR(191) NOT NULL PRIMARY KEY,
        `payload` LONGTEXT NOT NULL,
        `expires_at` DATETIME NOT NULL,
        `created_at` DATETIME NOT NULL,
        INDEX `idx_gbp_cache_expires` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function gbpCacheTtl(): int {
    $ttl = defined('GOOGLE_GBP_CACHE_TTL') ? (int) GOOGLE_GBP_CACHE_TTL : 43200;
    return $ttl > 0 ? $ttl : 43200; // 12h
}

function gbpCacheGet(string $key): ?array {
    $mem = alpCacheGet('gbp:' . $key);
    if (is_array($mem)) return $mem;

    try {
        $pdo = db();
        gbpEnsureCacheTable($pdo);
        $stmt = $pdo->prepare('SELECT payload FROM google_gbp_api_cache WHERE cache_key = ? AND expires_at > ? LIMIT 1');
        $stmt->execute([$key, dbNow()]);
        $raw = $stmt->fetchColumn();
        if (!$raw) return null;
        $decoded = json_decode((string) $raw, true);
        if (!is_array($decoded)) return null;
        alpCacheSet('gbp:' . $key, $decoded, min(3600, gbpCacheTtl()));
        return $decoded;
    } catch (Throwable $e) {
        return null;
    }
}

function gbpCacheSet(string $key, array $payload, ?int $ttl = null): void {
    $ttl = $ttl ?? gbpCacheTtl();
    alpCacheSet('gbp:' . $key, $payload, min(3600, $ttl));
    try {
        $pdo = db();
        gbpEnsureCacheTable($pdo);
        $expires = date('Y-m-d H:i:s', time() + $ttl);
        $pdo->prepare(
            'INSERT INTO google_gbp_api_cache (cache_key, payload, expires_at, created_at) VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE payload = VALUES(payload), expires_at = VALUES(expires_at)'
        )->execute([$key, json_encode($payload, JSON_UNESCAPED_UNICODE), $expires, dbNow()]);
    } catch (Throwable $e) { /* opcional */ }
}

function gbpCacheDelete(string $key): void {
    alpCacheDelete('gbp:' . $key);
    try {
        $pdo = db();
        gbpEnsureCacheTable($pdo);
        $pdo->prepare('DELETE FROM google_gbp_api_cache WHERE cache_key = ?')->execute([$key]);
    } catch (Throwable $e) { /* */ }
}

function gbpOauthClientId(): string {
    if (defined('GOOGLE_OAUTH_CLIENT_ID') && trim((string) GOOGLE_OAUTH_CLIENT_ID) !== '') {
        return trim((string) GOOGLE_OAUTH_CLIENT_ID);
    }
    return function_exists('googleOAuthClientId') ? trim((string) googleOAuthClientId()) : '';
}

function gbpOauthClientSecret(): string {
    if (defined('GOOGLE_OAUTH_CLIENT_SECRET')) {
        return trim((string) GOOGLE_OAUTH_CLIENT_SECRET);
    }
    return '';
}

function gbpRedirectUri(): string {
    $site = defined('SITE_URL') ? rtrim((string) SITE_URL, '/') : 'https://autolimpezapro.com.br';
    return $site . '/api.php?action=google-gbp-oauth-callback';
}

function gbpGetRefreshToken(): string {
    if (defined('GOOGLE_GBP_REFRESH_TOKEN') && trim((string) GOOGLE_GBP_REFRESH_TOKEN) !== '') {
        return trim((string) GOOGLE_GBP_REFRESH_TOKEN);
    }
    if (defined('GOOGLE_REFRESH_TOKEN') && trim((string) GOOGLE_REFRESH_TOKEN) !== '') {
        return trim((string) GOOGLE_REFRESH_TOKEN);
    }
    try {
        $fromDb = siteConfigGet(db(), 'google_gbp_refresh_token');
        return is_string($fromDb) ? trim($fromDb) : '';
    } catch (Throwable $e) {
        return '';
    }
}

function gbpSetRefreshToken(string $token): void {
    siteConfigSet(db(), 'google_gbp_refresh_token', $token);
}

function gbpGetLocationId(): string {
    if (defined('GOOGLE_LOCATION_ID') && trim((string) GOOGLE_LOCATION_ID) !== '') {
        return trim((string) GOOGLE_LOCATION_ID);
    }
    try {
        $fromDb = siteConfigGet(db(), 'google_gbp_location_id');
        return is_string($fromDb) ? trim($fromDb) : '';
    } catch (Throwable $e) {
        return '';
    }
}

function gbpSetLocationId(string $locationId): void {
    $locationId = preg_replace('#^locations/#', '', trim($locationId)) ?? '';
    siteConfigSet(db(), 'google_gbp_location_id', $locationId);
}

function gbpLocationResourceName(): string {
    $id = gbpGetLocationId();
    if ($id === '') return '';
    return strpos($id, 'locations/') === 0 ? $id : ('locations/' . $id);
}

function gbpHttp(string $method, string $url, ?array $jsonBody = null, array $headers = []): array {
    $ch = curl_init($url);
    $hdrs = array_merge(['Accept: application/json'], $headers);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 45,
        CURLOPT_CONNECTTIMEOUT => 12,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
        CURLOPT_HTTPHEADER => $hdrs,
    ];
    if ($jsonBody !== null) {
        $opts[CURLOPT_POSTFIELDS] = json_encode($jsonBody, JSON_UNESCAPED_UNICODE);
        $hdrs[] = 'Content-Type: application/json';
        $opts[CURLOPT_HTTPHEADER] = $hdrs;
    }
    curl_setopt_array($ch, $opts);
    $body = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    return [
        'code' => $code,
        'body' => is_string($body) ? $body : '',
        'err' => $err ?: null,
        'json' => is_string($body) ? (json_decode($body, true) ?: null) : null,
    ];
}

/**
 * Renova access_token via refresh_token (OAuth 2.0).
 * Cacheia access_token em memória/Redis por ~50 min.
 */
function gbpAccessToken(bool $forceRefresh = false): string {
    $cacheKey = 'gbp_access_token';
    if (!$forceRefresh) {
        $cached = alpCacheGet($cacheKey);
        if (is_string($cached) && $cached !== '') return $cached;
    }

    $refresh = gbpGetRefreshToken();
    $clientId = gbpOauthClientId();
    $secret = gbpOauthClientSecret();
    if ($refresh === '' || $clientId === '' || $secret === '') {
        throw new RuntimeException(
            'Credenciais GBP incompletas. Configure GOOGLE_OAUTH_CLIENT_ID/SECRET e conecte o OAuth (refresh token) ou defina GOOGLE_GBP_REFRESH_TOKEN.'
        );
    }

    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'client_id' => $clientId,
            'client_secret' => $secret,
            'refresh_token' => $refresh,
            'grant_type' => 'refresh_token',
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $body = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = is_string($body) ? json_decode($body, true) : null;
    if ($code !== 200 || !is_array($data) || empty($data['access_token'])) {
        $msg = is_array($data) ? ($data['error_description'] ?? $data['error'] ?? 'token_error') : 'token_error';
        throw new RuntimeException('Falha ao renovar access_token Google: ' . $msg);
    }
    $token = (string) $data['access_token'];
    $expiresIn = max(60, (int) ($data['expires_in'] ?? 3600) - 120);
    alpCacheSet($cacheKey, $token, $expiresIn);
    return $token;
}

function gbpAuthHeaders(): array {
    return ['Authorization: Bearer ' . gbpAccessToken()];
}

/** Métricas oficiais da Performance API (mapeia aliases do pedido). */
function gbpDailyMetricsList(): array {
    return [
        'BUSINESS_IMPRESSIONS_DESKTOP_MAPS',
        'BUSINESS_IMPRESSIONS_MOBILE_MAPS',
        'BUSINESS_IMPRESSIONS_DESKTOP_SEARCH',
        'BUSINESS_IMPRESSIONS_MOBILE_SEARCH',
        'CALL_CLICKS',
        'WEBSITE_CLICKS',
        'BUSINESS_DIRECTION_REQUESTS',
    ];
}

function gbpDateParts(DateTimeImmutable $d): array {
    return [
        'year' => (int) $d->format('Y'),
        'month' => (int) $d->format('n'),
        'day' => (int) $d->format('j'),
    ];
}

/**
 * Soma valores diários de uma série timeSeries.
 * @param array<string,mixed> $series
 */
function gbpSumTimeSeries(array $series): int {
    $total = 0;
    $datedValues = $series['datedValues'] ?? [];
    if (!is_array($datedValues)) return 0;
    foreach ($datedValues as $row) {
        if (!is_array($row)) continue;
        $total += (int) ($row['value'] ?? 0);
    }
    return $total;
}

/**
 * @return array{current:int,previous:int,deltaPct:float|null}
 */
function gbpComparePeriods(int $current, int $previous): array {
    $delta = null;
    if ($previous > 0) {
        $delta = round((($current - $previous) / $previous) * 100, 1);
    } elseif ($current > 0) {
        $delta = 100.0;
    } else {
        $delta = 0.0;
    }
    return ['current' => $current, 'previous' => $previous, 'deltaPct' => $delta];
}

/**
 * fetchMultiDailyMetricsTimeSeries — GET (API oficial) com fallback POST.
 * @return array<string,mixed>
 */
function gbpFetchMultiDailyMetrics(string $locationName, DateTimeImmutable $start, DateTimeImmutable $end): array {
    $metrics = gbpDailyMetricsList();
    $qs = [
        'dailyRange.start_date.year' => gbpDateParts($start)['year'],
        'dailyRange.start_date.month' => gbpDateParts($start)['month'],
        'dailyRange.start_date.day' => gbpDateParts($start)['day'],
        'dailyRange.end_date.year' => gbpDateParts($end)['year'],
        'dailyRange.end_date.month' => gbpDateParts($end)['month'],
        'dailyRange.end_date.day' => gbpDateParts($end)['day'],
    ];
    $url = 'https://businessprofileperformance.googleapis.com/v1/'
        . $locationName
        . ':fetchMultiDailyMetricsTimeSeries?'
        . http_build_query($qs);
    foreach ($metrics as $m) {
        $url .= '&dailyMetrics=' . rawurlencode($m);
    }

    $res = gbpHttp('GET', $url, null, gbpAuthHeaders());
    if ($res['code'] === 200 && is_array($res['json'])) {
        return $res['json'];
    }

    // Fallback POST (alguns clientes/documentações usam POST)
    $postBody = [
        'dailyMetrics' => $metrics,
        'dailyRange' => [
            'startDate' => gbpDateParts($start),
            'endDate' => gbpDateParts($end),
        ],
    ];
    $postUrl = 'https://businessprofileperformance.googleapis.com/v1/'
        . $locationName
        . ':fetchMultiDailyMetricsTimeSeries';
    $res2 = gbpHttp('POST', $postUrl, $postBody, gbpAuthHeaders());
    if ($res2['code'] === 200 && is_array($res2['json'])) {
        return $res2['json'];
    }

    $err = $res2['json']['error']['message'] ?? $res['json']['error']['message'] ?? $res['body'] ?: $res2['body'];
    throw new RuntimeException('Performance API metrics: HTTP ' . max($res['code'], $res2['code']) . ' — ' . (is_string($err) ? $err : json_encode($err)));
}

/**
 * listSearchKeywordsImpressionsMonthly
 * @return list<array{keyword:string,value:int,threshold?:string}>
 */
function gbpListSearchKeywords(string $locationName, int $monthsBack = 3): array {
    $end = new DateTimeImmutable('first day of this month');
    $start = $end->modify('-' . max(1, $monthsBack - 1) . ' months');
    $qs = http_build_query([
        'monthlyRange.start_month.year' => (int) $start->format('Y'),
        'monthlyRange.start_month.month' => (int) $start->format('n'),
        'monthlyRange.end_month.year' => (int) $end->format('Y'),
        'monthlyRange.end_month.month' => (int) $end->format('n'),
        'pageSize' => 50,
    ]);
    $url = 'https://businessprofileperformance.googleapis.com/v1/'
        . $locationName
        . '/searchkeywords/impressions/monthly?' . $qs;

    $res = gbpHttp('GET', $url, null, gbpAuthHeaders());
    if ($res['code'] !== 200 || !is_array($res['json'])) {
        // Keywords são opcionais — não derruba o painel
        return [];
    }

    $out = [];
    $rows = $res['json']['searchKeywordsCounts'] ?? $res['json']['searchKeywordCounts'] ?? [];
    if (!is_array($rows)) return [];
    foreach ($rows as $row) {
        if (!is_array($row)) continue;
        $kw = (string) ($row['searchKeyword'] ?? $row['keyword'] ?? '');
        if ($kw === '') continue;
        $insights = $row['insightsValue'] ?? $row['value'] ?? null;
        $value = 0;
        $threshold = null;
        if (is_array($insights)) {
            if (isset($insights['value'])) $value = (int) $insights['value'];
            if (isset($insights['threshold'])) $threshold = (string) $insights['threshold'];
        } elseif (is_numeric($insights)) {
            $value = (int) $insights;
        }
        $out[] = ['keyword' => $kw, 'value' => $value, 'threshold' => $threshold];
    }
    usort($out, static fn($a, $b) => ($b['value'] <=> $a['value']));
    return array_slice($out, 0, 25);
}

/**
 * @param array<string,mixed> $apiJson
 * @return array<string,int>
 */
function gbpParseMetricTotals(array $apiJson): array {
    $totals = array_fill_keys(gbpDailyMetricsList(), 0);
    $multi = $apiJson['multiDailyMetricTimeSeries'] ?? [];
    if (!is_array($multi)) return $totals;

    foreach ($multi as $block) {
        if (!is_array($block)) continue;
        $seriesList = $block['dailyMetricTimeSeries'] ?? [];
        if (!is_array($seriesList)) continue;
        foreach ($seriesList as $serie) {
            if (!is_array($serie)) continue;
            $metric = (string) ($serie['dailyMetric'] ?? '');
            if ($metric === '' || !array_key_exists($metric, $totals)) continue;
            $ts = $serie['timeSeries'] ?? [];
            $totals[$metric] += is_array($ts) ? gbpSumTimeSeries($ts) : 0;
        }
    }
    return $totals;
}

/**
 * Monta payload de KPI para o painel (período atual vs período anterior equivalente).
 *
 * @return array<string,mixed>
 */
function gbpBuildDashboardPayload(int $days = 30, bool $forceRefresh = false): array {
    $days = in_array($days, [30, 60, 90], true) ? $days : 30;
    $location = gbpLocationResourceName();
    if ($location === '') {
        throw new RuntimeException('GOOGLE_LOCATION_ID não configurado. Conecte o OAuth e selecione a unidade, ou defina GOOGLE_LOCATION_ID.');
    }

    $cacheKey = 'dashboard:' . $location . ':' . $days;
    if (!$forceRefresh) {
        $cached = gbpCacheGet($cacheKey);
        if ($cached) {
            $cached['cached'] = true;
            return $cached;
        }
    } else {
        gbpCacheDelete($cacheKey);
    }

    $tz = new DateTimeZone('America/Sao_Paulo');
    $end = new DateTimeImmutable('yesterday', $tz);
    $start = $end->modify('-' . ($days - 1) . ' days');
    $prevEnd = $start->modify('-1 day');
    $prevStart = $prevEnd->modify('-' . ($days - 1) . ' days');

    $currentRaw = gbpFetchMultiDailyMetrics($location, $start, $end);
    $previousRaw = gbpFetchMultiDailyMetrics($location, $prevStart, $prevEnd);
    $current = gbpParseMetricTotals($currentRaw);
    $previous = gbpParseMetricTotals($previousRaw);

    $impressionsCurrent =
        $current['BUSINESS_IMPRESSIONS_DESKTOP_MAPS']
        + $current['BUSINESS_IMPRESSIONS_MOBILE_MAPS']
        + $current['BUSINESS_IMPRESSIONS_DESKTOP_SEARCH']
        + $current['BUSINESS_IMPRESSIONS_MOBILE_SEARCH'];
    $impressionsPrevious =
        $previous['BUSINESS_IMPRESSIONS_DESKTOP_MAPS']
        + $previous['BUSINESS_IMPRESSIONS_MOBILE_MAPS']
        + $previous['BUSINESS_IMPRESSIONS_DESKTOP_SEARCH']
        + $previous['BUSINESS_IMPRESSIONS_MOBILE_SEARCH'];

    $actionsCurrent = $current['CALL_CLICKS'] + $current['WEBSITE_CLICKS'] + $current['BUSINESS_DIRECTION_REQUESTS'];
    $actionsPrevious = $previous['CALL_CLICKS'] + $previous['WEBSITE_CLICKS'] + $previous['BUSINESS_DIRECTION_REQUESTS'];

    $kpis = [
        'impressions' => gbpComparePeriods($impressionsCurrent, $impressionsPrevious),
        'impressionsMaps' => gbpComparePeriods(
            $current['BUSINESS_IMPRESSIONS_DESKTOP_MAPS'] + $current['BUSINESS_IMPRESSIONS_MOBILE_MAPS'],
            $previous['BUSINESS_IMPRESSIONS_DESKTOP_MAPS'] + $previous['BUSINESS_IMPRESSIONS_MOBILE_MAPS']
        ),
        'impressionsSearch' => gbpComparePeriods(
            $current['BUSINESS_IMPRESSIONS_DESKTOP_SEARCH'] + $current['BUSINESS_IMPRESSIONS_MOBILE_SEARCH'],
            $previous['BUSINESS_IMPRESSIONS_DESKTOP_SEARCH'] + $previous['BUSINESS_IMPRESSIONS_MOBILE_SEARCH']
        ),
        'calls' => gbpComparePeriods($current['CALL_CLICKS'], $previous['CALL_CLICKS']),
        'websiteClicks' => gbpComparePeriods($current['WEBSITE_CLICKS'], $previous['WEBSITE_CLICKS']),
        'directions' => gbpComparePeriods($current['BUSINESS_DIRECTION_REQUESTS'], $previous['BUSINESS_DIRECTION_REQUESTS']),
        'actions' => gbpComparePeriods($actionsCurrent, $actionsPrevious),
    ];

    $keywords = gbpListSearchKeywords($location, max(1, (int) ceil($days / 30)));

    $payload = [
        'ok' => true,
        'cached' => false,
        'location' => $location,
        'days' => $days,
        'range' => [
            'start' => $start->format('Y-m-d'),
            'end' => $end->format('Y-m-d'),
            'previousStart' => $prevStart->format('Y-m-d'),
            'previousEnd' => $prevEnd->format('Y-m-d'),
        ],
        'kpis' => $kpis,
        'metrics' => [
            'current' => $current,
            'previous' => $previous,
        ],
        'keywords' => $keywords,
        'fetchedAt' => (new DateTimeImmutable('now', $tz))->format(DateTimeInterface::ATOM),
        'cacheTtlSeconds' => gbpCacheTtl(),
    ];

    gbpCacheSet($cacheKey, $payload);
    return $payload;
}

function gbpBuildOauthAuthUrl(string $state): string {
    $params = [
        'client_id' => gbpOauthClientId(),
        'redirect_uri' => gbpRedirectUri(),
        'response_type' => 'code',
        'access_type' => 'offline',
        'prompt' => 'consent',
        'include_granted_scopes' => 'true',
        'scope' => implode(' ', [
            'https://www.googleapis.com/auth/business.manage',
        ]),
        'state' => $state,
    ];
    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
}

function gbpExchangeCode(string $code): array {
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'code' => $code,
            'client_id' => gbpOauthClientId(),
            'client_secret' => gbpOauthClientSecret(),
            'redirect_uri' => gbpRedirectUri(),
            'grant_type' => 'authorization_code',
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $body = curl_exec($ch);
    $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = is_string($body) ? json_decode($body, true) : null;
    if ($http !== 200 || !is_array($data)) {
        throw new RuntimeException('Troca de code OAuth falhou: HTTP ' . $http);
    }
    return $data;
}

/**
 * Lista contas e localizações (Account Management + Business Information).
 * @return list<array{account:string,locationId:string,title:string,storeCode?:string}>
 */
function gbpListLocations(): array {
    $headers = gbpAuthHeaders();
    $accountsRes = gbpHttp(
        'GET',
        'https://mybusinessaccountmanagement.googleapis.com/v1/accounts',
        null,
        $headers
    );
    $accounts = $accountsRes['json']['accounts'] ?? [];
    if (!is_array($accounts) || !$accounts) {
        return [];
    }

    $out = [];
    foreach ($accounts as $acc) {
        if (!is_array($acc) || empty($acc['name'])) continue;
        $parent = (string) $acc['name']; // accounts/123
        $url = 'https://mybusinessbusinessinformation.googleapis.com/v1/'
            . $parent
            . '/locations?readMask=name,title,storeCode,storefrontAddress&pageSize=100';
        $locRes = gbpHttp('GET', $url, null, $headers);
        $locations = $locRes['json']['locations'] ?? [];
        if (!is_array($locations)) continue;
        foreach ($locations as $loc) {
            if (!is_array($loc) || empty($loc['name'])) continue;
            $name = (string) $loc['name']; // locations/456 or accounts/x/locations/y
            if (preg_match('#locations/([^/]+)$#', $name, $m)) {
                $locId = $m[1];
            } else {
                $locId = $name;
            }
            $out[] = [
                'account' => $parent,
                'locationId' => $locId,
                'title' => (string) ($loc['title'] ?? $locId),
                'storeCode' => (string) ($loc['storeCode'] ?? ''),
            ];
        }
    }
    return $out;
}

function gbpConnectionStatus(): array {
    return [
        'clientIdConfigured' => gbpOauthClientId() !== '',
        'clientSecretConfigured' => gbpOauthClientSecret() !== '',
        'refreshTokenConfigured' => gbpGetRefreshToken() !== '',
        'locationId' => gbpGetLocationId(),
        'locationResource' => gbpLocationResourceName(),
        'redirectUri' => gbpRedirectUri(),
        'cacheTtlSeconds' => gbpCacheTtl(),
        'projectId' => defined('GOOGLE_OAUTH_PROJECT_ID') ? (string) GOOGLE_OAUTH_PROJECT_ID : '',
    ];
}
