<?php
/**
 * Shell SEO por hostname — injeta meta/canonical/OG/JSON-LD no index.html.
 * Telhados: 404 real para rotas que não existem neste site.
 */
declare(strict_types=1);

$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'config.php não encontrado';
    exit;
}

require_once $configFile;
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/brand-sites.php';

$site = alpCurrentBrandSite();
$path = '/';
if (isset($_SERVER['REQUEST_URI'])) {
    $path = (string)(parse_url((string)$_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/');
}
$path = alpNormalizePublicPath($path);

if (($site['id'] ?? '') === 'telhados' && $path === '/servicos/limpeza-de-calhas') {
    header('Location: ' . alpSiteOrigin('telhados') . '/servicos/limpeza-de-telhado', true, 301);
    exit;
}

$indexPath = __DIR__ . '/index.html';
if (!is_file($indexPath)) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'index.html não encontrado';
    exit;
}

$html = file_get_contents($indexPath);
if ($html === false) {
    http_response_code(500);
    exit;
}

$esc = static function (?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};

if (($site['id'] ?? '') !== 'telhados') {
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

$origin = alpSiteOrigin('telhados');
$ogImage = $origin . (string)$site['ogImage'];
$page = alpTelhadosPageMeta($path);
$httpStatus = 200;
$robots = 'index, follow';
$canonical = $origin . ($path === '/' ? '/' : $path);
$title = (string)$site['name'];
$description = (string)$site['tagline'];
$h1 = $title;
$body = '';
$indexable = false;

$adminPrefixes = function_exists('alpTelhadosPrivatePrefixes')
    ? alpTelhadosPrivatePrefixes()
    : ['/admin', '/conta', '/v'];
$isAppPath = false;
foreach ($adminPrefixes as $p) {
    if ($path === $p || str_starts_with($path, $p . '/')) {
        $isAppPath = true;
        break;
    }
}

if ($isAppPath) {
    $httpStatus = 200;
    $robots = 'noindex, nofollow';
    $title = (string)$site['name'] . ' — área interna';
    $description = 'Área interna da Auto Limpeza Pro. Não indexar.';
    $canonical = $origin . $path;
    $h1 = $title;
    $body = '';
    $indexable = false;
} elseif (alpPrincipalForbiddenOnTelhados($path)) {
    $httpStatus = 404;
    $robots = 'noindex, nofollow';
    $title = 'Página não encontrada | Auto Limpeza Pro — Telhados';
    $description = 'Este endereço não existe no site de limpeza de telhados.';
    $canonical = $origin . '/';
    $h1 = 'Página não encontrada';
    $body = 'O endereço não pertence a telhados.autolimpezapro.com.br.';
} elseif ($page) {
    $title = (string)$page['title'];
    $description = (string)$page['description'];
    $h1 = (string)$page['h1'];
    $body = (string)$page['body'];
    $indexable = !empty($page['index']);
    if (!$indexable) {
        $robots = 'noindex, follow';
    }
} else {
    $httpStatus = 404;
    $robots = 'noindex, nofollow';
    $title = 'Página não encontrada | Auto Limpeza Pro — Telhados';
    $description = 'Este endereço não existe no site de limpeza de telhados.';
    $canonical = $origin . '/';
    $h1 = 'Página não encontrada';
    $body = 'O endereço não pertence a telhados.autolimpezapro.com.br.';
    $indexable = false;
}

$jsonLd = [
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'LocalBusiness',
            '@id' => $origin . '/#business',
            'name' => $site['name'],
            'image' => $ogImage,
            'description' => $description,
            'telephone' => '+55-31-98025-2882',
            'email' => $site['email'],
            'url' => $origin . '/',
            'priceRange' => '$$',
            'areaServed' => [
                ['@type' => 'City', 'name' => 'São José da Lapa'],
                ['@type' => 'City', 'name' => 'Vespasiano'],
            ],
            'address' => [
                '@type' => 'PostalAddress',
                'addressLocality' => 'São José da Lapa',
                'addressRegion' => 'MG',
                'addressCountry' => 'BR',
            ],
            'parentOrganization' => [
                '@type' => 'Organization',
                'name' => 'Auto Limpeza Pro',
                'url' => 'https://autolimpezapro.com.br/',
            ],
        ],
        [
            '@type' => 'WebSite',
            '@id' => $origin . '/#website',
            'url' => $origin . '/',
            'name' => $site['name'],
            'inLanguage' => 'pt-BR',
        ],
        [
            '@type' => 'WebPage',
            '@id' => $canonical . '#webpage',
            'url' => $canonical,
            'name' => $title,
            'description' => $description,
            'isPartOf' => ['@id' => $origin . '/#website'],
        ],
    ],
];

$inject = '';
$inject .= '<title>' . $esc($title) . '</title>' . "\n";
$inject .= '<meta name="description" content="' . $esc($description) . '">' . "\n";
$inject .= '<link rel="canonical" href="' . $esc($canonical) . '">' . "\n";
$inject .= '<meta name="robots" content="' . $esc($robots) . '">' . "\n";
$inject .= '<meta property="og:type" content="website">' . "\n";
$inject .= '<meta property="og:site_name" content="' . $esc((string)$site['name']) . '">' . "\n";
$inject .= '<meta property="og:locale" content="pt_BR">' . "\n";
$inject .= '<meta property="og:title" content="' . $esc($title) . '">' . "\n";
$inject .= '<meta property="og:description" content="' . $esc($description) . '">' . "\n";
$inject .= '<meta property="og:url" content="' . $esc($canonical) . '">' . "\n";
$inject .= '<meta property="og:image" content="' . $esc($ogImage) . '">' . "\n";
$inject .= '<meta property="og:image:secure_url" content="' . $esc($ogImage) . '">' . "\n";
$inject .= '<meta property="og:image:type" content="image/png">' . "\n";
$inject .= '<meta property="og:image:width" content="1200">' . "\n";
$inject .= '<meta property="og:image:height" content="630">' . "\n";
$inject .= '<meta property="og:image:alt" content="' . $esc($title) . '">' . "\n";
$inject .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
$inject .= '<meta name="twitter:title" content="' . $esc($title) . '">' . "\n";
$inject .= '<meta name="twitter:description" content="' . $esc($description) . '">' . "\n";
$inject .= '<meta name="twitter:image" content="' . $esc($ogImage) . '">' . "\n";
$inject .= '<script type="application/ld+json">' .
    json_encode($jsonLd, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) .
    '</script>' . "\n";

$html = preg_replace('#<title>[^<]*</title>\s*#i', '', $html, 1) ?? $html;
$html = preg_replace('#<meta\s+[^>]*name=["\']description["\'][^>]*>\s*#i', '', $html) ?? $html;
$html = preg_replace('#<link\s+[^>]*rel=["\']canonical["\'][^>]*>\s*#i', '', $html) ?? $html;
$html = preg_replace('#<meta\s+[^>]*name=["\']robots["\'][^>]*>\s*#i', '', $html) ?? $html;
$html = preg_replace('#<meta\s+[^>]*name=["\']google-site-verification["\'][^>]*>\s*#i', '', $html) ?? $html;
$html = preg_replace('#<meta\s+[^>]*name=["\']p:domain_verify["\'][^>]*>\s*#i', '', $html) ?? $html;
$html = preg_replace('#<meta\s+[^>]*(?:property|name)=["\'](?:og:[^"\']+|twitter:[^"\']+|article:[^"\']+)["\'][^>]*>\s*#i', '', $html) ?? $html;
$html = preg_replace('#<script type=["\']application/ld\+json["\']>[\s\S]*?</script>\s*#i', '', $html, 1) ?? $html;
$html = preg_replace('#<meta\s+[^>]*name=["\']keywords["\'][^>]*>\s*#i', '', $html) ?? $html;

if (stripos($html, '</head>') !== false) {
    $html = preg_replace('#</head>#i', $inject . '</head>', $html, 1) ?? ($inject . $html);
} else {
    $html = $inject . $html;
}

$html = preg_replace(
    '#(<div class="brand">\s*<p>Auto Limpeza Pro</p>\s*<h1>)[^<]+(</h1>)#s',
    '$1' . $esc($h1) . '$2',
    $html,
    1
) ?? $html;

$noscript = '<noscript><article><h1>' . $esc($h1) . '</h1><p>' .
    $esc($description) . '</p><p>' . $esc($body) . '</p></article></noscript>';
if (stripos($html, '<div id="root">') !== false) {
    $html = preg_replace('#<div id="root">#i', $noscript . '<div id="root">', $html, 1) ?? $html;
}

http_response_code($httpStatus);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');
echo $html;
exit;
